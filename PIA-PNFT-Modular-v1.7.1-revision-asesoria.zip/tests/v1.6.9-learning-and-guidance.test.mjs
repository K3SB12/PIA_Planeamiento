import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

test('el juego se abre desde la portada y no forma parte de impresión',async()=>{
  const [body,html,css,runtime]=await Promise.all([read('src/templates/body-open.html'),read('src/templates/enhancements.html'),read('src/styles/08-enhancements.css'),read('src/application/enhancements.js')]);
  assert.match(body,/id="piaOpenMethodologyGame"/);
  assert.match(html,/id="piaMethodologyGame"[^>]+hidden/);
  assert.match(css,/@media print[^}]+\.pia-methodology-game/s);
  assert.match(runtime,/openMethodologyGame/);
  assert.doesNotMatch(runtime,/function answerGame[^}]+markDirty/);
});

test('el recorrido incluye preescolar, las tres metodologías y dos escenarios de secundaria',async()=>{
  const runtime=await read('src/application/enhancements.js');
  for(const text of ['La expedición lúdica de preescolar','Aprender mediante el juego','Aprendizaje Basado en Retos','Pensamiento de Diseño como ruta continua','Secundaria con una metodología integrada','Secundaria con metodologías coordinadas'])assert.match(runtime,new RegExp(text,'i'));
  for(const concept of ['RdA','saberes conceptuales','procedimentales','actitudinales','ejes transversales','perfil de salida','cognitiva, socioemocional y psicomotriz'])assert.match(runtime,new RegExp(concept,'i'));
});

test('DUA requiere activación explícita y conserva las opciones elegidas',async()=>{
  const [html,core,runtime]=await Promise.all([read('src/templates/enhancements.html'),read('src/domain/projection/projection-core.js'),read('src/application/enhancements.js')]);
  assert.match(html,/id="piaContextEnabled"/);
  assert.match(core,/context:\{enabled:false/);
  assert.match(runtime,/state\.context\.enabled=Boolean/);
  assert.match(runtime,/if\(!state\.context\?\.enabled\)return otherMethod\+references/);
});

test('el apoyo diagnóstico aplica proceso completo, tres dimensiones y máximo dos lecciones',async()=>{
  const [html,runtime]=await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js')]);
  assert.match(html,/id="piaPrepareDiagnosis"/);
  for(const text of ['cognitiva, socioemocional y psicomotriz','sistematizar','analizar','decidir','comunicar','máximo 80 minutos'])assert.match(runtime,new RegExp(text,'i'));
  assert.match(html,/id="piaDiagnosisLessons"[^>]+max="2"/);
});

test('Otra metodología muestra una ficha y se incorpora como fundamentación docente',async()=>{
  const [methodology,core,runtime]=await Promise.all([read('src/templates/methodology.html'),read('src/domain/projection/projection-core.js'),read('src/application/enhancements.js')]);
  for(const id of ['piaOtherMethodPurpose','piaOtherMethodRoute','piaOtherMethodStudentRole','piaOtherMethodEvidence'])assert.match(methodology,new RegExp(`id="${id}"`));
  assert.match(core,/methodology:\{purpose:'',route:'',studentRole:'',evidence:''\}/);
  assert.match(runtime,/FUNDAMENTACIÓN DE OTRA METODOLOGÍA/);
});

test('Afinar semana conserva currículo y metodología y exige justificar cualquier cambio',async()=>{
  const [week,prompt]=await Promise.all([read('src/ui/week-view.js'),read('src/prompts/weekly-prompt.js')]);
  assert.match(week,/Afinar semana \$\{numero\} con IA/);
  assert.match(prompt,/No reconstruya el semestre ni cambie silenciosamente su metodología/);
  assert.match(prompt,/versión coherente con la metodología original/);
  assert.match(prompt,/COPIAR COMPLETOS Y LITERALES/);
});

test('Proyecto coordina una o dos metodologías y vincula currículo oficial en fases posteriores',async()=>{
  const [runtime,prompt,catalog]=await Promise.all([read('src/application/enhancements.js'),read('src/prompts/semester-projection-prompt.js'),read('src/data/project-component-catalog.js')]);
  assert.match(runtime,/sourceType:'official-curriculum'/);
  assert.match(prompt,/Coordínela con Pensamiento de Diseño/);
  assert.match(prompt,/Pensamiento de Diseño organiza la mediación curricular y la ruta del Proyecto/);
  assert.match(catalog,/\['teacher-authored','official-curriculum'\]/);
});
