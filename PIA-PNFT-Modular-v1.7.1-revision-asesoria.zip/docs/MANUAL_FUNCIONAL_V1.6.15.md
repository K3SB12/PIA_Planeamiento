# Guía funcional — PIA-PNFT Modular 1.6.15

## Ruta segura para personas nuevas y experimentadas

1. Defina ciclo, nivel y contexto general sin ingresar datos personales del estudiantado.
2. Seleccione un módulo para el semestre. Si selecciona ambos, PIA solicitará confirmar que las semanas y lecciones cubren expresamente los dos periodos.
3. Revise áreas presentes, RdA del ciclo, saberes e indicadores literales. Un área ausente no se agrega y DESPUÉS no se adelanta.
4. Declare el tiempo real: semanas, diagnóstico, lecciones sin desarrollo curricular y reserva para aplicación/realimentación. PIA mostrará el presupuesto neto.
5. Confirme el perfil de evaluación solo después de verificar ciclo, modalidad y disposiciones aplicables. Hasta entonces es una referencia y Proyecto permanece oculto.
6. Prepare el diagnóstico únicamente si resulta pertinente. Sus resultados permiten decidir activación, apoyos o profundización del alcance actual; no prueban dominio ni autorizan adelantar el nivel siguiente.
7. Genere ventanas evaluativas como referencias iniciales. La IA analizará después la estrategia y las evidencias; la persona docente confirma, modifica o descarta.
8. Genere el prompt y revise la propuesta. La auditoría debe mostrar minutos netos, minutos asignados y diferencia.
9. Use la comprobación técnica para detectar omisiones literales y estructurales. Después realice la revisión pedagógica profesional antes de incorporar contenido a las semanas.

PIA estructura y protege la información; la IA propone; la persona docente o asesora contextualiza, valida y decide.

## Explorar un ejemplo de planeamiento

La portada incluye una experiencia formativa opcional para comprender cómo se conectan las funciones de PIA. Presione **Explorar un ejemplo de planeamiento** y seleccione **Comenzar el recorrido** o **Explorar un tema**.

El recorrido presenta siete momentos: horizonte curricular, punto de partida, ruta curricular, metodología, proyección semestral, construcción de una semana y revisión. Puede navegar en cualquier orden; los números no son grados ni niveles de dominio.

Los laboratorios **ABJ**, **ABR** y **APD** permiten probar decisiones y comparar sus implicaciones. En III Ciclo aparece además la articulación entre currículo y Proyecto. Toda la experiencia distingue referente oficial, ejemplo formativo y decisión docente.

Practicar no modifica el plan. El avance se conserva solamente en el navegador y puede reiniciarse sin borrar semanas, diagnóstico, Proyecto o prompts. Use **Volver a PIA** para cerrar la experiencia y continuar el planeamiento.

Consulte `GUIA_EXPERIENCIA_FORMATIVA_V1.6.14.md` para conocer el alcance, las fuentes y la validación.

## Trayectoria curricular

1. Seleccione ciclo, nivel, uno o ambos módulos y las áreas que desea consultar.
2. Presione **Explorar trayectoria curricular**, debajo de **Ver cobertura de las semanas**.
3. Elija **Tarjetas** para una lectura guiada o **Tabla comparativa** para contrastar varios saberes.
4. Filtre por módulo, área y alcance: todos los saberes disponibles o solo los incorporados a la proyección.
5. Lea **Referente curricular anterior**, **Ahora currículo que se proyecta** y **Continuidad curricular
   posterior**. AHORA muestra saber, indicador oficial, RdA y fuente.

Una celda vacía se presenta como **sin abordaje conceptual documentado**. No significa que el saber se
enseñó, reforzó o dominó. `N/A` significa no aplicable. La presencia conceptual o el fortalecimiento sin
evaluación solo pueden mostrarse cuando una fuente curricular lo establece expresamente.

La trayectoria es una consulta local: no cambia selecciones, semanas, cobertura, prompts ni exportaciones.

## Diagnóstico pedagógico

El diagnóstico inicia con **0 lecciones** y es opcional. Para prepararlo, seleccione una o dos lecciones,
ciclo, nivel, módulo, área y saber conceptual. El modo asesor genera un modelo con decisiones condicionales;
el modo docente utiliza únicamente resultados generales aportados.

Active **Incluir las decisiones del diagnóstico en el prompt semestral** solo cuando desee trasladar ese
bloque. Si la opción no está activada, PIA conserva el diagnóstico de manera independiente. **Reiniciar
diagnóstico** elimina únicamente su configuración, resultados y prompt, y conserva el resto del plan.

## Momentos evaluativos

El perfil que PIA muestra automáticamente es una **referencia compatible**, no una decisión confirmada.
Revise ciclo, modalidad y disposiciones vigentes y marque la confirmación explícita. Solo entonces PIA
habilita Proyecto —cuando corresponda— y permite generar las referencias evaluativas y el prompt semestral.

“Durante todo el periodo” describe el seguimiento continuo del trabajo cotidiano; no exige evaluar cada
semana ni fija dos, tres o cuatro observaciones. La persona docente determina la frecuencia según el proceso,
las evidencias, las lecciones disponibles y el contexto.

Las semanas sugeridas para tareas o prueba de ejecución son referencias proporcionales iniciales. No
significan que PIA ya haya analizado la complejidad de las actividades. La IA realiza ese análisis después
de diseñar actividades y evidencias; la persona docente confirma, mueve o descarta cada propuesta.

**Observación o decisión docente** permite justificar o contextualizar una selección. No corresponde a una
calificación.

## Auditoría temporal

Antes de generar el prompt, registre las reservas cuantificables. PIA calcula el tiempo neto mediante:
lecciones administrativas menos diagnóstico, lecciones sin desarrollo curricular y reserva para aplicación
y realimentación. Los periodos escritos en el campo de excepciones no se convierten automáticamente en
cantidades.

Después de construir la matriz y el desarrollo semanal, la IA revisa semanas, lecciones, minutos,
integración, profundidad, continuidad y evidencias. Utiliza una conclusión: **Viabilidad temporal
confirmada**, **Revisión temporal sugerida** o **Requiere ajuste temporal**. El conteo de indicadores y
bloques no determina por sí solo la viabilidad. La respuesta debe indicar minutos netos, minutos asignados
y diferencia; aun así, la suficiencia pedagógica requiere revisión profesional.
