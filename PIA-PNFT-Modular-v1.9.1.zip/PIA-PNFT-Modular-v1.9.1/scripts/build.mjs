import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fragments } from './fragment-manifest.mjs';

const root = resolve(import.meta.dirname, '..');
const chunks = await Promise.all(fragments.map((file) => readFile(join(root, file))));
const pnftIconSprite = await readFile(join(root, 'src/assets/pnft-area-icons.png'));
const learningJS = await readFile(join(root, 'src/learning/experience.js'), 'utf8');
const learningCSS = await readFile(join(root, 'src/learning/experience.css'), 'utf8');
const output = Buffer.from(Buffer.concat(chunks).toString('utf8').replace('__PIA_LEARNING_EXPERIENCE__', () => learningJS).replace('/* __PIA_LEARNING_STYLES__ */', () => learningCSS).replaceAll(
  '__PIA_PNFT_AREA_ICONS__',
  `data:image/png;base64,${pnftIconSprite.toString('base64')}`
));

for (const relativePath of ['index.html', 'dist/web/index.html', 'dist/portable/index.html']) {
  const target = join(root, relativePath);
  await mkdir(dirname(target), { recursive: true });
  await writeFile(target, output);
  console.log(`${relativePath}: ${output.length} bytes`);
}
