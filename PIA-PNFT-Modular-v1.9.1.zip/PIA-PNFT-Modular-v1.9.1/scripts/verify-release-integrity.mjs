import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const outputs=['index.html','dist/web/index.html','dist/portable/index.html'];
const digest=value=>createHash('sha256').update(value).digest('hex');
const buffers=await Promise.all(outputs.map(file=>readFile(resolve(root,file))));
const hashes=buffers.map(digest);
if(new Set(hashes).size!==1)throw new Error(`Las salidas HTML no son idénticas: ${hashes.join(', ')}`);

const current=await readFile(resolve(root,'CURRENT.sha256'),'utf8');
const declared=new Map(current.trim().split(/\r?\n/).map(line=>{const [hash,...name]=line.trim().split(/\s+/);return [name.join(' '),hash];}));
for(let index=0;index<outputs.length;index++){
  if(declared.get(outputs[index])!==hashes[index])throw new Error(`CURRENT.sha256 no coincide para ${outputs[index]}: esperado ${hashes[index]}, declarado ${declared.get(outputs[index])||'ausente'}`);
}

const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
const version=pkg.version;
const contracts=[['SPEC.md',new RegExp(`^# SPEC — PIA-PNFT Modular ${version.replaceAll('.','\\.')}$`,'m')],['info.md',new RegExp(`^# Estado operativo — PIA-PNFT Modular ${version.replaceAll('.','\\.')}$`,'m')],['README.md',new RegExp(`versión funcional\\s+actual es \\*\\*PIA-PNFT Modular ${version.replaceAll('.','\\.')}\\*\\*`,'i')],['CHANGELOG.md',new RegExp(`^## ${version.replaceAll('.','\\.')}$`,'m')]];
for(const [file,pattern] of contracts){const text=await readFile(resolve(root,file),'utf8');if(!pattern.test(text))throw new Error(`${file} no declara la versión vigente ${version}.`);}
for(const file of ['info.md',`docs/INFORME_VALIDACION_V${version}.md`]){const text=await readFile(resolve(root,file),'utf8');if(!text.includes(hashes[0]))throw new Error(`${file} no publica la huella vigente ${hashes[0]}.`);}
console.log(`RELEASE_INTEGRITY=PASS version=${version} sha256=${hashes[0]}`);
