import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = path => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');

test('el componente Proyecto está condicionado, versionado y se conserva por semana en esquema v6', () => {
  const template = read('src/templates/enhancements.html');
  const runtime = read('src/application/enhancements.js');
  const core = read('src/domain/projection/projection-core.js');
  assert.match(template, /id="piaProjectPlanningWrap"[^>]+hidden/);
  assert.match(template, /Planificar componente Proyecto/);
  assert.match(runtime, /profileHasProject/);
  assert.match(runtime, /renderWeekProject/);
  assert.match(runtime, /teacherText/);
  assert.match(runtime, /plan\.schemaVersion=6/);
  assert.match(core, /schemaVersion:6/);
});

test('el catálogo de instrumentos queda interno y no almacena datos estudiantiles', () => {
  const template = read('src/templates/enhancements.html');
  const catalog = read('src/data/evaluation-instruments.js');
  assert.doesNotMatch(template, /¿Qué necesita observar\?/);
  assert.match(template, /catálogo de instrumentos/i);
  assert.match(catalog, /PIA no registra datos de personas estudiantes, resultados individuales ni calificaciones/);
  assert.match(catalog, /Una misma evidencia no debe contabilizarse dos veces/);
});

test('cada semana ofrece tres modalidades y ubica Proyecto en las columnas oficiales', () => {
  const week = read('src/ui/week-view.js');
  const runtime = read('src/application/enhancements.js');
  for (const value of ['curricular','mixed','integrated']) assert.match(week, new RegExp(`value="${value}"`));
  assert.match(week, /data-pia-project-achievement-section/);
  assert.match(week, /data-pia-project-evaluation-section/);
  assert.match(runtime, /Restaurar el texto oficial/);
  assert.match(runtime, /contextualizaciones semanales/);
  assert.doesNotMatch(runtime, /milestonesCompleted|milestonesTotal/);
});

test('los tres prompts protegen literalidad, integración y desarrollo suficiente', () => {
  const semester = read('src/prompts/semester-projection-prompt.js');
  const general = read('src/prompts/general-prompt.js');
  const weekly = read('src/prompts/weekly-prompt.js');
  for (const source of [semester, general, weekly]) {
    assert.match(source, /indicador(?:es)? de logro oficial/i);
    assert.match(source, /literal/i);
    assert.match(source, /procedimentales y actitudinales/i);
    assert.match(source, /escuetas/i);
  }
  assert.match(semester, /tratamiento individual justificado/);
  assert.match(semester, /una evidencia no puede contabilizarse dos veces/);
});

test('Proyecto no crea una sección nueva en los exportadores oficiales', () => {
  const pdf = read('src/infrastructure/export/pdf-exporter.js');
  assert.doesNotMatch(pdf, /piaProjectPlanning|Componente Proyecto/);
});
