import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

test('el ejemplo no vuelve inerte al contenedor que lo contiene',async()=>{
  const learning=await read('src/learning/experience.js');
  assert.doesNotMatch(learning,/plan\.inert\s*=\s*true/);
  assert.match(learning,/plan\.contains\(container\)\?Array\.from\(plan\.children\)\.filter\(node=>node!==container\):\[plan\]/);
  assert.match(learning,/function isolatePlan\(container\)/);
  assert.match(learning,/function restorePlan\(\)/);
  assert.match(learning,/hadInert:node\.hasAttribute\('inert'\)/);
  assert.match(learning,/ariaHidden:node\.getAttribute\('aria-hidden'\)/);
});

test('el cierre restaura exactamente la interactividad y el foco previo',async()=>{
  const learning=await read('src/learning/experience.js');
  assert.match(learning,/if\(!hadInert\)node\.removeAttribute\('inert'\)/);
  assert.match(learning,/if\(ariaHidden===null\)node\.removeAttribute\('aria-hidden'\)/);
  assert.match(learning,/restorePlan\(\);closeCallback\?\.\(\);previousFocus\?\.focus/);
});

test('PIA distingue DUA, acceso, apoyo no significativo y PEI aprobada',async()=>{
  const [html,core,runtime]=await Promise.all([
    read('src/templates/enhancements.html'),
    read('src/domain/projection/projection-core.js'),
    read('src/application/enhancements.js')
  ]);
  for(const id of ['piaSupportFramework','piaInstitutionalCoordination','piaAuthorizedSupportNotes','piaVocationalGuidance','piaVocationalCoordination','piaVocationalSelectionBasis'])assert.match(html,new RegExp(`id="${id}"`));
  for(const value of ['dua','access','non-significant','significant-approved'])assert.match(html,new RegExp(`value="${value}"`));
  assert.match(core,/supportFramework:'dua'/);
  assert.match(core,/duaSupports:\[\]/);
  assert.match(core,/vocationalCoordination:false/);
  assert.match(runtime,/state\.context\.duaSupports=checked\('piaDuaSupport'\)/);
  assert.match(runtime,/No invente adecuaciones curriculares ni interprete una PEI/);
});

test('la guía de Plan Nacional conserva coordinación, diagnóstico, tiempo y límites curriculares',async()=>{
  const [html,runtime]=await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js')]);
  for(const text of ['Plan Nacional','docente guía','diagnóstico','herramientas de productividad','dos lecciones semanales','PIA contiene currículo hasta 9.º'])assert.match(html,new RegExp(text,'i'));
  assert.match(runtime,/Coordinación pedagógica para Plan Nacional/);
  assert.match(runtime,/no convierta referencias de otros niveles en currículo vigente/);
  assert.match(runtime,/(?:no|ni) invente saberes para 10\.º, 11\.º o 12\.º/);
  assert.match(runtime,/renderContextProfileGuidance/);
});

test('los apoyos siguen siendo opcionales, grupales y ajenos a la aprobación institucional',async()=>{
  const [html,runtime]=await Promise.all([read('src/templates/enhancements.html'),read('src/application/enhancements.js')]);
  assert.match(html,/sin nombres, diagnósticos clínicos ni datos sensibles/i);
  assert.match(html,/Seleccionar una opción no constituye aprobación ni modifica automáticamente saberes, indicadores o evaluación/i);
  assert.match(runtime,/PIA no valida su aprobación/);
  assert.match(runtime,/requiere validación institucional/);
});
