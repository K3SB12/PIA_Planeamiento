import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';

const root=new URL('../',import.meta.url);
const read=path=>readFile(new URL(path,root),'utf8');

test('el acceso al diagnóstico aparece después de los saberes y antes de Proyecto',async()=>{
  const html=await read('src/templates/enhancements.html');
  const lessons=html.indexOf('id="piaDiagnosisLessons"');
  const knowledge=html.indexOf('id="piaKnowledgeTitle"');
  const action=html.indexOf('id="piaPrepareDiagnosis"');
  const project=html.indexOf('id="piaProjectPlanningWrap"');
  assert.ok(lessons>-1&&knowledge>-1&&action>-1&&project>-1);
  assert.ok(lessons<knowledge&&knowledge<action&&action<project);
  assert.match(html,/id="piaPrepareDiagnosis" disabled/);
});

test('el diagnóstico exige contexto curricular suficiente pero continúa siendo opcional',async()=>{
  const runtime=await read('src/application/enhancements.js');
  assert.match(runtime,/function diagnosticReadiness/);
  for(const requirement of ["checked('piaModule').length","checked('piaArea').length","checked('piaConcept').length","piaDiagnosisLessons"])assert.ok(runtime.includes(requirement));
  assert.match(runtime,/button\.disabled=!readiness\.ready/);
  assert.doesNotMatch(runtime,/function semesterPrompt[\s\S]{0,3500}diagnosticReadiness\(\)/);
});

test('las ayudas contextuales son breves, centralizadas, accesibles y no se exportan',async()=>{
  const [html,week,runtime,css]=await Promise.all([read('src/templates/enhancements.html'),read('src/ui/week-view.js'),read('src/application/enhancements.js'),read('src/styles/08-enhancements.css')]);
  for(const key of ['dua','reference-indicators','semester-projection','diagnosis','rda','projection-knowledge','project-component','evaluation-components','evaluation-windows'])assert.match(html,new RegExp(`data-pia-help="${key}"`));
  assert.match(week,/data-pia-help="weekly-project-mode"/);
  assert.match(html,/id="piaContextHelpPopover"[^>]+role="tooltip"[^>]+hidden/);
  assert.match(runtime,/const contextHelpCatalog = Object\.freeze/);
  assert.match(runtime,/event\.key==='Escape'[\s\S]{0,100}closeContextHelp/);
  assert.match(runtime,/setAttribute\('aria-expanded','true'\)/);
  assert.match(css,/@media print[^}]+\.pia-context-help[^}]+display:none!important/s);
});
