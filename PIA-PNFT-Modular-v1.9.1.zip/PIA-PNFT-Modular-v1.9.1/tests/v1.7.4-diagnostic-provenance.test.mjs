import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const runtime = readFileSync(new URL('../src/application/enhancements.js', import.meta.url), 'utf8');
const template = readFileSync(new URL('../src/templates/enhancements.html', import.meta.url), 'utf8');

test('la interfaz muestra que la recomendación de IA no es una selección docente', () => {
  assert.match(template, /id="piaDiagnosticSelectionStatus"[^>]*role="status"/);
  assert.match(runtime, /pendiente de recomendación de la IA; no seleccionad/);
  assert.match(runtime, /renderDiagnosticSelectionStatus/);
});

test('el prompt conserva procedencia y estado de técnica e instrumento', () => {
  assert.match(runtime, /Recomendación de la IA — pendiente de validación docente/);
  assert.match(runtime, /No la presente como seleccionada, confirmada ni autorizada/);
  assert.match(runtime, /No lo presente como seleccionado, confirmado ni autorizado/);
  assert.match(runtime, /indicando por separado su procedencia y estado/);
});

test('revisar el anexo de IA no confirma técnica ni instrumento', () => {
  assert.match(template, /Aprobar el anexo no confirma automáticamente la técnica ni el instrumento/);
  assert.match(runtime, /Su revisión no confirma automáticamente la técnica ni el instrumento/);
});

test('el Word rotula la procedencia de las decisiones', () => {
  assert.match(runtime, /diagnosticChoiceStatus\('technique',diagnostic\.technique\)/);
  assert.match(runtime, /diagnosticChoiceStatus\('instrument',diagnostic\.instrument\)/);
});
