import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');

function field(value = '') {
  const classes = new Set();
  return {
    value,
    checked: false,
    classList: {
      add(name) { classes.add(name); },
      remove(name) { classes.delete(name); },
      contains(name) { return classes.has(name); },
    },
  };
}

test('un plan conserva sus datos al serializarse y cargarse nuevamente', async () => {
  const source = await readFile(resolve(root, 'src/application/plan-service.js'), 'utf8');
  const start = source.indexOf('        function obtenerDatosPlan()');
  const end = source.indexOf('        // ===== FUNCIONES DE EXPORTACIÓN', start);
  assert.ok(start >= 0 && end > start, 'No se pudieron aislar obtenerDatosPlan() y cargarPlan()');
  const functions = source.slice(start, end);

  const ids = {
    cursoLectivo: field('2026'), semestre: field('II'), direccionRegional: field('Heredia'),
    centroEducativo: field('Escuela PIA'), codigoCentro: field('1234'), nombreDocente: field('Docente'),
    circuito: field('01'), ciclo: field('II Ciclo'), nivel: field('5'), leccionesPlanificadas: field('4'),
    mesInicio: field('Agosto'), mesFinal: field('Septiembre'), asignatura: field('Formación tecnológica/Informática Educativa'),
    metodologiaActiva: field('ABR'), metodologiaPersonalizada: field(''), metodologiaPersonalizadaContainer: field(),
    queFunciono: field('Trabajo colaborativo'), queNoFunciono: field(''), queMejorar: field('Tiempo'),
    observaciones: field('Ajustes según el contexto'),
  };
  const axes = [{ value: 'pensamiento', checked: true }, { value: 'ciudadania', checked: false }];
  const originalWeeks = [{
    id: 1, nombre: 'Semana 1', lecciones: 'Lecciones 1 y 2', areas: ['Programación y Algoritmos'],
    modulos:['Módulo 2'], rda: '', saberes: ['Algoritmos'],
    saberRefs:[{modulo:'Módulo 2',area:'Programación y Algoritmos',nombre:'Algoritmos'}],
    procedimentales: ['formula'], actitudinales: ['aprender'],
    actividades: '<p>Actividad</p>', recursos: '', evaluacion: '<p>Evaluación</p>', indicadores: '<p>Indicador</p>',
    project:{mode:'mixed',stageId:'initial',phaseId:'empathize',records:{empathize:{phaseId:'empathize',stageId:'initial',achievementIndicators:[{id:'project.initial.empathize.001',officialText:'Texto oficial',teacherText:'Texto docente',evaluationIndicators:[{id:'evaluation.01',officialText:'Evaluación oficial',teacherText:'Evaluación docente',selected:true},{id:'evaluation.02',officialText:'Otra evaluación oficial',teacherText:'Otra evaluación docente',selected:false}]}]}}},
  }];
  const calls = { rebuild: 0, counters: 0 };
  const alerts = [];
  const context = vm.createContext({
    document: {
      getElementById(id) { return ids[id] ?? field(); },
      querySelectorAll(selector) {
        if (selector === 'input[name="eje"]:checked') return axes.filter((axis) => axis.checked);
        if (selector === 'input[name="eje"]') return axes;
        return [];
      },
    },
    semanas: structuredClone(originalWeeks),
    saberesSeleccionados: new Set(['Algoritmos']),
    saberesProcedimentalesGlobales: new Set(['formula']),
    saberesActitudinalesGlobales: new Set(['aprender']),
    actualizarNiveles() {},
    reconstruirVistaSemanasPreservandoContenido() { calls.rebuild += 1; },
    actualizarContadoresSemanas() { calls.counters += 1; },
    actualizarRdASemana() {}, actualizarOpcionesSaberesSemana() {}, actualizarIndicadoresSemana() {},
    actualizarSaberesConceptualesContenedor() {},
    alert(message) { alerts.push(message); },
    setTimeout(callback) { callback(); return 1; },
    Date,
  });

  vm.runInContext(`${functions}\n__saved = obtenerDatosPlan();`, context);
  const serialized = JSON.stringify(context.__saved);
  const parsed = JSON.parse(serialized);

  ids.nombreDocente.value = '';
  ids.centroEducativo.value = '';
  axes.forEach((axis) => { axis.checked = false; });
  context.semanas = [];
  context.saberesSeleccionados = new Set();
  context.saberesProcedimentalesGlobales = new Set();
  context.saberesActitudinalesGlobales = new Set();
  context.__plan = parsed;
  vm.runInContext('cargarPlan(__plan);', context);

  assert.equal(ids.nombreDocente.value, 'Docente');
  assert.equal(ids.centroEducativo.value, 'Escuela PIA');
  assert.equal(ids.metodologiaActiva.value, 'ABR');
  assert.equal(axes[0].checked, true);
  assert.deepEqual(structuredClone(context.semanas), originalWeeks);
  assert.deepEqual([...context.saberesSeleccionados], ['Algoritmos']);
  assert.deepEqual([...context.saberesProcedimentalesGlobales], ['formula']);
  assert.deepEqual([...context.saberesActitudinalesGlobales], ['aprender']);
  assert.equal(calls.rebuild, 1);
  assert.equal(calls.counters, 1);
  assert.match(alerts.at(-1), /cargado exitosamente/i);
});

test('Guardar produce un JSON descargable con el plan vigente', async () => {
  const source = await readFile(resolve(root, 'src/infrastructure/persistence/save-actions.js'), 'utf8');
  const downloads = [];
  const blobs = [];
  const messages = [];
  const menu = { classList: { remove() {} } };
  const context = vm.createContext({
    document: {
      getElementById() { return menu; },
      querySelector() { return null; },
      addEventListener() {},
      createElement() {
        return {
          download: '', href: '',
          click() { downloads.push({ download: this.download, href: this.href }); },
        };
      },
    },
    obtenerDatosPlan() { return { informacionGeneral: { nombreDocente: 'Docente' }, semanas: [{ id: 1 }] }; },
    mostrarMensaje(message) { messages.push(message); },
    descargarVersionPortable() {},
    URL: {
      createObjectURL(blob) { blobs.push(blob); return 'blob:json'; },
      revokeObjectURL() {},
    },
    Blob,
    setTimeout(callback) { callback(); return 1; },
  });

  vm.runInContext(`${source}\nejecutarGuardarNormal();`, context);
  assert.equal(downloads[0].download, 'planeamiento-didáctico.json');
  assert.equal(blobs[0].type, 'application/json');
  const saved = JSON.parse(await blobs[0].text());
  assert.equal(saved.informacionGeneral.nombreDocente, 'Docente');
  assert.equal(saved.semanas[0].id, 1);
  assert.match(messages[0], /guardado exitosamente/i);
});
