import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';

const read=path=>readFileSync(new URL(`../${path}`,import.meta.url),'utf8');

test('la proyección permite seleccionar fases posteriores y vincular indicadores oficiales del módulo',()=>{
  const runtime=read('src/application/enhancements.js');
  assert.match(runtime,/piaProjectTeacherPhase/);
  assert.match(runtime,/data-pia-project-curriculum-indicator/);
  assert.match(runtime,/sourceType:'official-curriculum'/);
  assert.match(runtime,/selectedPhaseIds/);
  assert.match(runtime,/phaseRecords/);
});

test('el esquema v6 conserva prompts general, semestral y semanales',()=>{
  const core=read('src/domain/projection/projection-core.js');
  const runtime=read('src/application/enhancements.js');
  assert.match(core,/aiPrompts:\{general:'',semester:'',weekly:\{\}\}/);
  assert.match(runtime,/state\.aiPrompts\.general/);
  assert.match(runtime,/state\.aiPrompts\.semester/);
  assert.match(runtime,/state\.aiPrompts\.weekly/);
  assert.match(runtime,/dataset\.promptKind/);
  assert.match(runtime,/dataset\.week/);
});

test('ocultar la proyección es estado visual y no elimina sus datos',()=>{
  const template=read('src/templates/enhancements.html');
  const runtime=read('src/application/enhancements.js');
  assert.match(template,/id="piaToggleProjection"/);
  assert.match(template,/id="piaProjectionContent"/);
  assert.match(runtime,/projectionExpanded/);
  assert.doesNotMatch(runtime,/piaToggleProjection[^\n]+defaultEnhancements/);
});

test('el prompt distingue indicadores del Proyecto, del módulo y textos históricos',()=>{
  const prompt=read('src/prompts/semester-projection-prompt.js');
  assert.match(prompt,/no presentar como oficial/i);
  assert.match(prompt,/Prototipar y Probar\/Evaluar/);
  assert.match(prompt,/indicadores oficiales del módulo/i);
});
