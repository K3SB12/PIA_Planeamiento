import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=path=>readFile(resolve(root,path),'utf8');

test('la barra contextual se abre desde la selección y conserva el campo activo',async()=>{
  const runtime=await read('src/application/enhancements.js');
  assert.match(runtime,/activeSelectionRange/);
  assert.match(runtime,/captureEditableSelection\(true\)/);
  assert.match(runtime,/restoreEditableSelection/);
  assert.match(runtime,/Aplicando formato a:/);
  assert.match(runtime,/data-field-kind="mediation"/);
  assert.match(runtime,/data-field-kind="evaluation"/);
});

test('el menú compacto incorpora opciones prioritarias sin habilitar el indicador curricular',async()=>{
  const week=await read('src/ui/week-view.js');
  assert.match(week,/data-pia-format-target/);
  assert.match(week,/class="pia-format-more"/);
  assert.match(week,/data-pia-format-preset="Inicio"/);
  assert.match(week,/data-pia-format-preset="Desarrollo"/);
  assert.match(week,/data-pia-format-preset="Cierre"/);
  assert.match(week,/data-pia-field-action="plain-paste"/);
  assert.match(week,/data-pia-field-action="link"/);
  assert.match(week,/data-pia-format-command="removeFormat"/);
  assert.match(week,/data-field-kind="official-indicator"/);
  assert.doesNotMatch(week,/contenteditable="true"[^>]+data-field-kind="official-indicator"/);
});

test('la presentación es adhesiva, plegable, accesible y no se exporta',async()=>{
  const css=await read('src/styles/08-enhancements.css');
  const runtime=await read('src/application/enhancements.js');
  assert.match(css,/\.pia-week-format-toolbar \{ position:sticky/);
  assert.match(css,/\.pia-format-more-panel/);
  assert.match(css,/min-height:44px/);
  assert.match(runtime,/event\.key==='Escape'/);
  assert.match(runtime,/\^https:\\\/\\\/\//);
  assert.match(css,/@media print[^}]+\.pia-week-format-toolbar/s);
});
