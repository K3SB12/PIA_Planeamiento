import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [preschool,frameworkSource,promptSource,evaluationSource,template,enhancements,core]=await Promise.all([
  read('src/data/preschool-curriculum.js'),read('src/data/curricular-framework.js'),read('src/prompts/semester-projection-prompt.js'),read('src/data/evaluation-profiles.js'),read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js')
]);
const context=vm.createContext({result:null});
vm.runInContext(`${preschool}\n${frameworkSource}\nresult=PIACurricularFramework;`,context);

test('el marco de consulta cubre Preescolar, I, II y III Ciclo sin sustituir el currículo protegido',()=>{
  const catalog=context.result;
  assert.equal(Object.keys(catalog.MODULE_PURPOSES).length,22);
  for(const [level,cycle] of [['0°','Materno Infantil/Transición'],['1°','I Ciclo'],['2°','I Ciclo'],['3°','I Ciclo'],['4°','II Ciclo'],['5°','II Ciclo'],['6°','II Ciclo'],['7°','III Ciclo'],['8°','III Ciclo'],['9°','III Ciclo']]){
    for(const module of ['Módulo 1','Módulo 2']){
      const data=catalog.framework({level,cycle,modules:[module],areas:['Programación y Algoritmos'],preschoolTrack:'optimal'});
      assert.equal(data.competencies.length,1,`${level} ${module}: competencia`);
      assert.equal(data.exitProfiles.length,1,`${level} ${module}: perfil`);
      assert.equal(data.modules.length,1,`${level} ${module}: descripción`);
      assert.ok(data.modules[0].pages,`${level} ${module}: páginas`);
    }
  }
  assert.match(frameworkSource,/No sustituye PNFT_DATA ni RDA_POR_CICLO/);
});

test('la interfaz diferencia DUA universal, contexto opcional e inventario de recursos',()=>{
  for(const id of ['piaResourceDevices','piaResourceSoftware','piaResourceMaterials','piaResourceOrganization','piaResourceAccessibility','piaResourceConstraints'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(template,/El DUA orienta el diseño general para todo el grupo/);
  assert.match(template,/Marco curricular que orienta este planeamiento/);
  assert.match(template,/Descargar modelo diagnóstico en Word/);
  assert.match(enhancements,/application\/msword/);
  assert.match(enhancements,/ejemplo de apoyo, no un formato oficial obligatorio/i);
});

test('el prompt incorpora marco curricular, integración, DUA y auditoría de contribución',()=>{
  const promptContext=vm.createContext({result:null});
  vm.runInContext(`${evaluationSource}\n${promptSource}\nresult={profiles:PIAEvaluationProfiles,prompt:PIASemesterPrompt};`,promptContext);
  const text=promptContext.result.prompt.build({level:'5°',cycle:'II Ciclo',weeks:20,lessons:40,netLessons:38,netMinutes:1520,blockMinutes:80,diagnosisLessons:1,modules:['Módulo 1'],areas:['Programación y Algoritmos'],methodology:'ABR',axes:['Pensamiento computacional'],rdas:['RdA'],rdaItems:[{area:'Programación y Algoritmos',text:'RdA'}],concepts:[{name:'Dato',module:'Módulo 1',area:'Programación y Algoritmos',indicators:['Indicador literal']}],procedural:['Resolución de problemas'],attitudinal:['Trabajo colaborativo'],indicators:['Indicador literal'],evaluationProfile:promptContext.result.profiles.profiles.primary,evaluationProfileConfirmed:true,evaluationInstruments:[],curricularFramework:{source:{title:'Guía oficial'},competencies:[{area:'Programación y Algoritmos',text:'Competencia literal'}],exitProfiles:[{area:'Programación y Algoritmos',statements:['Perfil literal']}],modules:[{module:'Módulo 1',pages:'85',text:'Propósito literal'}]}});
  for(const expected of ['Competencia literal','Perfil literal','Propósito literal','Integre dos o más saberes','múltiples formas de representación, participación y acción o expresión','Auditoría de contribución de la ruta','vacío o aspecto por revisar','G) Auditoría de contribución','H) Decisiones pendientes'])assert.equal(text.toLocaleLowerCase('es').includes(expected.toLocaleLowerCase('es')),true,expected);
});

test('el esquema v6 conserva inventario estructurado sin crear datos personales',()=>{
  const coreContext=vm.createContext({result:null});
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`,coreContext);
  const migrated=coreContext.result.migrate({pia:{context:{resourceInventory:{devices:'12 portátiles',constraints:'Internet intermitente'}}}});
  assert.equal(migrated.schemaVersion,6);
  assert.equal(migrated.context.resourceInventory.devices,'12 portátiles');
  assert.equal(migrated.context.resourceInventory.constraints,'Internet intermitente');
  assert.equal(Object.hasOwn(migrated.context.resourceInventory,'studentName'),false);
});
