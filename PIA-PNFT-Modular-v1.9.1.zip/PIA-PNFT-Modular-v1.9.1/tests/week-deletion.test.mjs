import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const sourcePath = resolve(root, 'src/domain/planning/week-operations.js');

function extractFunctionRange(source, startSignature, endSignature) {
  const start = source.indexOf(startSignature);
  const end = source.indexOf(endSignature, start);
  assert.notEqual(start, -1, `No se encontró ${startSignature}`);
  assert.ok(end > start, `No se pudo delimitar ${startSignature}`);
  return source.slice(start, end);
}

function createWeek(id) {
  return {
    id,
    nombre: `Semana ${id}`,
    lecciones: `Lecciones ${id * 2 - 1} y ${id * 2}`,
    areas: [],
    rda: `RDA ${id}`,
    saberes: [`Saber ${id}`],
    procedimentales: [`Procedimental ${id}`],
    actitudinales: [`Actitudinal ${id}`],
    actividades: `<p>Actividad ${id}</p>`,
    recursos: `<p>Recurso ${id}</p>`,
    evaluacion: `<p>Evaluación ${id}</p>`,
    indicadores: `<p>Indicador ${id}</p>`,
  };
}

test('eliminar semanas 8 y 7 sincroniza semanas, lecciones y contenido', async () => {
  const source = await readFile(sourcePath, 'utf8');
  const functions = extractFunctionRange(
    source,
    'function eliminarSemana(numero)',
    'function mostrarDetalleMetodologia',
  );

  const initialWeeks = Array.from({ length: 8 }, (_, index) => createWeek(index + 1));
  const expectedRemaining = structuredClone(initialWeeks.slice(0, 6));
  const elements = {
    leccionesPlanificadas: { value: '16' },
    semanasContainer: {
      innerHTML: 'contenido anterior',
      children: [],
      appendChild(element) {
        this.children.push(element);
      },
    },
    totalSemanas: { textContent: '8' },
    totalLecciones: { textContent: '16' },
  };
  const confirmations = [];

  const context = vm.createContext({
    __initialWeeks: structuredClone(initialWeeks),
    __initialSaberes: initialWeeks.flatMap((week) => week.saberes),
    __initialProcedimentales: initialWeeks.flatMap((week) => week.procedimentales),
    __initialActitudinales: initialWeeks.flatMap((week) => week.actitudinales),
    __result: null,
    document: {
      getElementById(id) {
        return elements[id] ?? null;
      },
      querySelector() {
        return null;
      },
      querySelectorAll() {
        return [];
      },
    },
    confirm(message) {
      confirmations.push(message);
      return true;
    },
    alert(message) {
      assert.fail(`No se esperaba alert(): ${message}`);
    },
    crearElementoSemana(numero, leccionInicio, leccionFin) {
      return { numero, leccionInicio, leccionFin };
    },
    setTimeout(callback) {
      callback();
      return 1;
    },
    console: { log() {} },
  });

  vm.runInContext(
    `
      let semanas = __initialWeeks;
      let saberesSeleccionados = new Set(__initialSaberes);
      let saberesProcedimentalesGlobales = new Set(__initialProcedimentales);
      let saberesActitudinalesGlobales = new Set(__initialActitudinales);
      ${functions}
      eliminarSemana(8);
      eliminarSemana(7);
      __result = {
        semanas,
        saberesSeleccionados: [...saberesSeleccionados],
        saberesProcedimentalesGlobales: [...saberesProcedimentalesGlobales],
        saberesActitudinalesGlobales: [...saberesActitudinalesGlobales],
      };
    `,
    context,
  );

  const result = structuredClone(context.__result);
  assert.equal(confirmations.length, 2, 'Cada eliminación debe confirmarse por separado');
  assert.equal(result.semanas.length, 6, 'Deben quedar exactamente seis semanas');
  assert.equal(elements.leccionesPlanificadas.value, '12', 'Seis semanas equivalen a 12 lecciones');
  assert.equal(String(elements.totalSemanas.textContent), '6', 'El contador visible debe mostrar seis semanas');
  assert.equal(String(elements.totalLecciones.textContent), '12', 'El contador visible debe mostrar 12 lecciones');
  assert.deepEqual(
    result.semanas.map((week) => week.id),
    [1, 2, 3, 4, 5, 6],
    'Los identificadores deben quedar normalizados de 1 a 6',
  );
  assert.deepEqual(
    result.semanas.map((week) => week.nombre),
    ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4', 'Semana 5', 'Semana 6'],
    'Los nombres deben quedar normalizados de Semana 1 a Semana 6',
  );
  assert.deepEqual(result.semanas, expectedRemaining, 'El contenido completo de las semanas 1 a 6 debe permanecer intacto');
  assert.deepEqual(
    result.saberesSeleccionados,
    expectedRemaining.flatMap((week) => week.saberes),
    'Los saberes globales de las semanas eliminadas no deben permanecer',
  );
  assert.deepEqual(
    result.saberesProcedimentalesGlobales,
    expectedRemaining.flatMap((week) => week.procedimentales),
    'Los procedimentales globales de las semanas eliminadas no deben permanecer',
  );
  assert.deepEqual(
    result.saberesActitudinalesGlobales,
    expectedRemaining.flatMap((week) => week.actitudinales),
    'Los actitudinales globales de las semanas eliminadas no deben permanecer',
  );
});
