import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const root = new URL('../', import.meta.url);
const dataSource = await readFile(new URL('src/data/pnft-data.js', root), 'utf8');
const serviceSource = await readFile(new URL('src/domain/curriculum/reference-indicators.js', root), 'utf8');
const context = {};
vm.createContext(context);
vm.runInContext(`${dataSource}\n${serviceSource}\nthis.api=PIAReferenceCurriculum;`, context);

test('las referencias proceden únicamente del catálogo PNFT y conservan literalidad', () => {
  const [level] = context.api.levels();
  const [moduleName] = context.api.modules(level);
  const [area] = context.api.areas(level, moduleName);
  const [concept] = context.api.concepts(level, moduleName, area);
  assert.ok(concept.indicadores[0]);
  const ref = context.api.normalize({sourceLevel:level,module:moduleName,area,concept:concept.nombre,officialText:concept.indicadores[0]});
  assert.equal(ref.officialText, concept.indicadores[0]);
  assert.match(context.api.promptBlock([ref]), /No los presente como indicadores oficiales del nivel administrativo actual/);
});

test('la selección semanal usa identificadores explícitos y no inferencias', () => {
  const refs = [{id:'a',sourceLevel:'1°',module:'Módulo 1',area:'A',concept:'C',officialText:'Texto A'},{id:'b',sourceLevel:'2°',module:'Módulo 1',area:'A',concept:'C',officialText:'Texto B'}];
  assert.deepEqual(context.api.selectedForWeek({referenceIndicatorIds:['b']}, refs).map(item=>item.id), ['b']);
});
