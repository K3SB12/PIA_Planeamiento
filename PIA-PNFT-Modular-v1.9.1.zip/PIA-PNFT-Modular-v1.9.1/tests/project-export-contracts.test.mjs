import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');

test('Word y PDF componen Proyecto mediante la misma selección efectiva',async()=>{
  const exporter=await readFile(resolve(root,'src/infrastructure/export/pdf-exporter.js'),'utf8');
  const calls=exporter.match(/projectExportForWeek\(/g)||[];
  assert.equal(calls.length,2);
  assert.match(exporter,/bloqueProyectoWord\('Indicador de logro del Proyecto',proyecto\.achievement\)/);
  assert.match(exporter,/bloqueProyectoWord\('Indicadores de evaluación del Proyecto',proyecto\.evaluation\)/);
  assert.match(exporter,/formatearContenidoConProyecto\(contenidoConReferencias\.html[^\n]+proyecto\.achievement\)/);
  assert.match(exporter,/formatearContenidoConProyecto\(semana\.evaluacion[^\n]+proyecto\.evaluation\)/);
});

test('la aplicación expone una única regla para exportar el texto guardado',async()=>{
  const runtime=await readFile(resolve(root,'src/application/enhancements.js'),'utf8');
  assert.match(runtime,/function projectExportForWeek\(week\)/);
  assert.match(runtime,/PIAProjectComponentCatalog\.exportSelection/);
  assert.match(runtime,/projectExportForWeek,referenceExportForWeek,institutionalExportHtml/);
  assert.match(runtime,/Incorporar este indicador en el planeamiento y la exportación/);
});
