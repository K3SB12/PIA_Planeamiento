import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { fragments } from '../scripts/fragment-manifest.mjs';

const root = resolve(import.meta.dirname, '..');
const read = path => readFile(resolve(root, path), 'utf8');

test('el manifiesto carga catálogos antes de sus consumidores y conserva ejecución HTML clásica', async () => {
  const positions = Object.fromEntries(fragments.map((item, index) => [item, index]));
  assert.ok(positions['src/data/preschool-curriculum.js'] > positions['src/data/pnft-data.js']);
  assert.ok(positions['src/data/institutional-centers.js'] < positions['src/domain/institution/center-lookup-service.js']);
  assert.ok(positions['src/domain/institution/center-lookup-service.js'] < positions['src/application/enhancements.js']);
  for (const file of ['src/data/institutional-centers.js', 'src/domain/institution/center-lookup-service.js']) {
    assert.doesNotMatch(await read(file), /^\s*(?:import|export)\s/m, `${file} debe poder ensamblarse dentro de index.html`);
  }
});

test('la consulta de centros es interna, accesible y no ofrece cargar Excel', async () => {
  const html = await read('src/templates/general-information.html');
  const app = await read('src/application/enhancements.js');
  assert.match(html, /id="piaCenterLookupStatus"[^>]+aria-live="polite"/);
  assert.match(html, /id="piaCenterMatches"[^>]+hidden/);
  assert.doesNotMatch(html, /type="file"[^>]*(?:xlsx|excel)|(?:xlsx|excel)[^>]*type="file"/i);
  assert.match(app, /state\.institutional\.codSaber = record\.codSaber/);
  assert.match(app, /result\.status === 'ambiguous'/);
  assert.match(app, /Código no encontrado\. Puede completar el centro manualmente/);
});

test('el catálogo público no expone datos personales ni códigos 0000', async () => {
  const catalog = await read('src/data/institutional-centers.js');
  assert.doesNotMatch(catalog, /(?:correo|email|tel[eé]fono|asesor(?:a)?)["']?\s*:/i);
  assert.doesNotMatch(catalog, /"codPres": "0000"/);
  assert.match(catalog, /"codPres": "0904"/);
});

test('el selector de preescolar activa la ruta oficial sin cambiar otros niveles', async () => {
  const preschool = await read('src/data/preschool-curriculum.js');
  const operations = await read('src/domain/curriculum/curriculum-operations.js');
  const originalFirst = { saberes: [{ nombre: 'Original', indicadores: ['Original'] }] };
  const data = { '0°': {}, '1°': { 'Módulo 1': { Área: originalFirst } } };
  const elements = new Map([
    ['nivel', { value: '0°' }],
    ['piaPreschoolTrack', { value: 'basic' }]
  ]);
  const context = vm.createContext({
    PNFT_DATA: data,
    RDA_POR_CICLO: {},
    document: { getElementById: id => elements.get(id) || null },
    semanas: []
  });
  vm.runInContext(`${preschool}\n${operations}\nactivarItinerarioPreescolar('basic');`, context);
  assert.equal(data['0°']['Módulo 1']['Apropiación tecnológica y Digital'].saberes.length, 3);
  assert.equal(data['0°']['Módulo 2']['Ciencia de datos e Inteligencia artificial'].saberes.length, 2);
  assert.equal(data['1°']['Módulo 1'].Área, originalFirst);
});

test('básico requerido ya no está bloqueado y el cambio refresca las semanas', async () => {
  const app = await read('src/application/enhancements.js');
  const template = await read('src/templates/enhancements.html');
  assert.match(template, /<option value="basic">Básico requerido<\/option>/);
  assert.doesNotMatch(app, /El selector está preparado, pero PIA no inventará/);
  assert.match(app, /activarItinerarioPreescolar\(state\.projection\.preschoolTrack\)/);
  assert.match(app, /refrescarCurriculoSemanas\(\)/);
});

test('el itinerario de preescolar se oculta y deshabilita fuera de 0°', async () => {
  const app = await read('src/application/enhancements.js');
  const css = await read('src/styles/08-enhancements.css');
  assert.match(app, /preschoolWrap\.hidden = !preschool/);
  assert.match(app, /preschoolSelect\.disabled = !preschool/);
  assert.match(app, /aria-hidden', String\(!preschool\)/);
  assert.match(css, /\.pia-field\[hidden\]\s*\{\s*display:none!important;\s*\}/);
});

test('el estado v6 conserva codSaber como dato interno opcional', async () => {
  const core = await read('src/domain/projection/projection-core.js');
  const context = vm.createContext({ result: null });
  vm.runInContext(`${core}\nresult=PIAProjectionCore;`, context);
  const fresh = context.result.defaultEnhancements();
  assert.equal(fresh.schemaVersion, 6);
  assert.equal(fresh.institutional.codSaber, '');
  const migrated = context.result.migrate({ pia: { institutional: { codSaber: '101094-00' } } });
  assert.equal(migrated.institutional.codSaber, '101094-00');
  assert.equal(context.result.migrate({}).institutional.codSaber, '');
});
