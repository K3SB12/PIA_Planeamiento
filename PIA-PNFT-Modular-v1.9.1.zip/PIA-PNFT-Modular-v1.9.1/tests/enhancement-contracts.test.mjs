import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');

test('el puente backend y la analítica permanecen inactivos y sin red', async () => {
  const source = await readFile(resolve(root, 'src/adapters/backend-bridge.js'), 'utf8');
  assert.match(source, /mode:\s*'local-only'/);
  assert.match(source, /backendConfigured:\s*false/);
  assert.match(source, /enabled:\s*false/);
  assert.doesNotMatch(source, /\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\b/);
});

test('la interfaz incorpora proyección de referencia, RdA, identidad y recuperación', async () => {
  const html = await readFile(resolve(root, 'src/templates/enhancements.html'), 'utf8');
  const identity = await readFile(resolve(root, 'src/templates/institutional-identity.html'), 'utf8');
  const support = await readFile(resolve(root, 'src/templates/support-tools.html'), 'utf8');
  assert.match(identity, /id="piaInstitutionLogo"/);
  assert.doesNotMatch(identity, /piaInstitutionName/);
  for (const id of ['piaProjectionWeeks','piaPreschoolTrack','piaGenerateSemesterPrompt','piaConceptFilter','piaProjectionGuidance','piaEvaluationProfile','piaProjectionRdas','piaCoverage']) {
    assert.match(html, new RegExp(`id="${id}"`));
  }
  for (const id of ['piaRecover','piaDiagnostics']) assert.match(support, new RegExp(`id="${id}"`));
  for (const removed of ['piaBuildDistribution','piaAiResponse','piaApproveAi','piaReviewAi']) assert.doesNotMatch(html, new RegExp(`id="${removed}"`));
  assert.doesNotMatch(support, /piaCopyMediation|piaStrategy|piaDuplicateLast/);
  assert.match(html, /id="piaToggleProjection"/);
  assert.doesNotMatch(html, /class="pia-time-pill"/);
});

test('la proyección es una etapa principal visible después de metodología y antes de semanas', async () => {
  const { fragments } = await import('../scripts/fragment-manifest.mjs');
  const methodology = fragments.indexOf('src/templates/methodology.html');
  const projection = fragments.indexOf('src/templates/enhancements.html');
  const weeks = fragments.indexOf('src/templates/weeks.html');
  const support = fragments.indexOf('src/templates/support-tools.html');
  assert.ok(methodology < projection && projection < weeks);
  assert.ok(projection < support && support < weeks);
  const html = await readFile(resolve(root, 'src/templates/enhancements.html'), 'utf8');
  assert.doesNotMatch(html, /<details[^>]+id="piaHerramientas"/);
  assert.doesNotMatch(html, /data-projection-step="4"/);
  assert.match(html, /Resumen en vivo/);
});

test('la interacción docente actualiza guía, métricas y filtro sin red', async () => {
  const runtime = await readFile(resolve(root, 'src/application/enhancements.js'), 'utf8');
  assert.match(runtime, /function updateProjectionSummary\(\)/);
  assert.match(runtime, /function filterConcepts\(\)/);
  assert.match(runtime, /function setVisibleConcepts\(value\)/);
  assert.match(runtime, /function renderProjectionRdas\(\)/);
  assert.match(runtime, /function weeklyCoverage\(\)/);
  assert.match(runtime, /semanas \|\| \[\]/);
  assert.doesNotMatch(runtime, /\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\b/);
});

test('el plan v6 se añade sin modificar los datos curriculares protegidos', async () => {
  const runtime = await readFile(resolve(root, 'src/application/enhancements.js'), 'utf8');
  assert.match(runtime, /plan\.schemaVersion=6/);
  assert.match(runtime, /plan\.pia=clone\(state\)/);
  assert.match(runtime, /activarItinerarioPreescolar/);
  assert.doesNotMatch(runtime, /PIA no inventará el conjunto curricular básico/);
  assert.doesNotMatch(runtime, /PNFT_DATA\s*\[[^\]]+\]\s*=/);
});
