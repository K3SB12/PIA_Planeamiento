import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const source=await readFile(resolve(root,'src/data/evaluation-instruments.js'),'utf8');
const context=vm.createContext({result:null});
vm.runInContext(`${source}\nresult=PIAEvaluationInstruments;`,context);
const api=context.result;

test('el catálogo de instrumentos está versionado, trazable y tiene identificadores únicos',()=>{
  assert.match(api.CATALOG_VERSION,/^\d{4}\.\d+$/);
  assert.equal(api.REVIEWED_AT,'2026-08-28');
  assert.equal(new Set(api.instruments.map(item=>item.id)).size,api.instruments.length);
  assert.equal(api.instruments.length,9);
  for(const instrument of api.instruments){
    for(const field of ['id','label','need','recommendedUse']) assert.ok(instrument[field],`${instrument.id}:${field}`);
    for(const field of ['evaluationFunctions','evidenceTypes','compatibleComponents','technicalRequirements','safeguards','sourceRefs']){
      assert.ok(Array.isArray(instrument[field])&&instrument[field].length,`${instrument.id}:${field}`);
    }
    assert.ok(instrument.sourceRefs.every(ref=>Object.values(api.SOURCES).some(sourceItem=>ref.startsWith(sourceItem.id))),instrument.id);
  }
});

test('las necesidades validadas conducen a instrumentos pertinentes sin imponer una única opción universal',()=>{
  assert.match(api.get('checklist').need,/presencia o ausencia/i);
  assert.match(api.get('analytic-rubric').recommendedUse,/proyectos, prototipos/i);
  assert.match(api.get('holistic-rubric').recommendedUse,/principalmente formativas/i);
  assert.match(api.get('performance-record').need,/desarrollo gradual/i);
  assert.match(api.get('anecdotal-record').need,/hechos, sucesos o situaciones/i);
  assert.match(api.get('performance-test').recommendedUse,/primaria/i);
  assert.match(api.get('daily-work-instrument').recommendedUse,/avance gradual/i);
});

test('la recomendación filtra por componente, función y evidencia',()=>{
  assert.deepEqual(Array.from(api.compatibleWith('prueba de ejecución'),item=>item.id),['descriptive-scale','performance-scale','analytic-rubric','performance-test']);
  assert.deepEqual(Array.from(api.recommend({component:'instrumento de evaluación sumativa',evaluationFunction:'sumativa'}),item=>item.id),['performance-scale','analytic-rubric']);
  assert.deepEqual(Array.from(api.recommend({component:'proyecto',evidenceType:'prototipo'}),item=>item.id),['analytic-rubric']);
  assert.equal(api.forFunction('formativa').some(item=>item.id==='anecdotal-record'),true);
});

test('las salvaguardas separan orientación, avance y calificación',()=>{
  for(const instrument of api.instruments){
    const safeguards=instrument.safeguards.join(' ');
    assert.match(safeguards,/decisión final corresponde a la persona docente/i);
    assert.match(safeguards,/no registra datos de personas estudiantes/i);
    assert.match(safeguards,/misma evidencia no debe contabilizarse dos veces/i);
  }
  assert.match(api.get('performance-record').safeguards.join(' '),/avance operativo no equivale.*calificación/i);
  assert.match(api.get('anecdotal-record').safeguards.join(' '),/no debe almacenar anécdotas/i);
});

test('el catálogo no define expedientes, estudiantes, resultados individuales ni notas',()=>{
  const forbiddenKeys=new Set(['student','students','studentId','studentName','grade','score','calification','calificacion','nota','resultadoIndividual']);
  function inspect(value){
    if(!value||typeof value!=='object') return;
    for(const [key,item] of Object.entries(value)){
      assert.equal(forbiddenKeys.has(key),false,`clave prohibida: ${key}`);
      inspect(item);
    }
  }
  inspect(api);
});

test('las reglas reglamentarias críticas quedan trazadas',()=>{
  const performanceTest=api.get('performance-test');
  assert.match(performanceTest.technicalRequirements.join(' '),/cinco días hábiles/i);
  assert.match(performanceTest.technicalRequirements.join(' '),/máximo reglamentario de cuatro lecciones/i);
  assert.ok(performanceTest.sourceRefs.includes('rea-45509-mep:38'));
  assert.ok(api.get('analytic-rubric').sourceRefs.includes('rea-45509-mep:35'));
  assert.match(api.get('daily-work-instrument').safeguards.join(' '),/no valorar.*únicamente.*producto final/i);
});
