import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const sources = await Promise.all([
  'src/data/pnft-data.js',
  'src/data/curricular-progression.js',
  'src/domain/curriculum/curricular-progression-service.js',
].map(file => readFile(resolve(root, file), 'utf8')));
const context = vm.createContext({ result: null });
vm.runInContext(`${sources.join('\n')}\nresult={curriculum:PNFT_DATA,catalog:PIACurricularProgressionData,service:PIACurricularProgression};`, context);
const { curriculum, catalog, service } = context.result;

test('el catálogo relacional conserva 38 familias, cuatro áreas y diez niveles', () => {
  assert.equal(catalog.families.length, 38);
  assert.deepEqual([...catalog.levelOrder], ['0°', '1°', '2°', '3°', '4°', '5°', '6°', '7°', '8°', '9°']);
  assert.deepEqual([...new Set(catalog.families.map(family => family.area))].sort(), [
    'Apropiación tecnológica y Digital',
    'Ciencia de datos e Inteligencia artificial',
    'Computación física y Robótica',
    'Programación y Algoritmos',
  ].sort());
  assert.equal(catalog.source.sha256, '8889390a01bd93b3478441da2ff7cc5a73c5ee53a67e66bc310c2229105672c8');
});

test('los 236 registros curriculares de PIA se relacionan explícitamente con una familia', () => {
  const total = Object.values(curriculum).flatMap(modules => Object.values(modules).flatMap(areas => Object.values(areas).flatMap(record => record.saberes))).length;
  assert.equal(total, 236);
  assert.equal(service.unmappedCurriculumRecords(curriculum).length, 0);
  const inconsistent = [];
  Object.entries(curriculum).forEach(([level, modules]) => Object.entries(modules).forEach(([module, areas]) => Object.entries(areas).forEach(([area, record]) => record.saberes.forEach(saber => {
    const familyId = service.familyIdFor(area, saber.nombre);
    if (service.stepFor(familyId, level)?.status !== 'explicit-evaluable') inconsistent.push({ level, module, area, name: saber.nombre });
  }))));
  assert.equal(inconsistent.length, 0);
});

test('Algoritmos reconoce progresión sin convertir celdas vacías en fortalecimiento', () => {
  assert.equal(service.familyIdFor('Programación y Algoritmos', 'Algoritmo (pseudocódigo)'), 'programming.algorithms');
  assert.equal(service.stepFor('programming.algorithms', '5°').status, 'explicit-evaluable');
  assert.equal(service.stepFor('programming.algorithms', '6°').status, 'no-curricular-record');
  assert.equal(service.stepFor('programming.algorithms', '8°').status, 'no-curricular-record');
  assert.equal(service.stepFor('programming.algorithms', '9°').status, 'explicit-evaluable');
});

test('Computación física y Robótica forma parte del mismo catálogo de progresión', () => {
  assert.equal(service.familyIdFor('Computación física y Robótica', 'Robot'), 'physical.robotics');
  assert.equal(service.familyIdFor('Computación física y Robótica', 'Microcontrolador'), 'physical.interfaces');
  assert.equal(service.familyIdFor('Computación física y Robótica', 'Prototipos'), 'physical.domotics');
});

test('el contexto interno identifica los vacíos sin inventar refuerzo o evaluación', () => {
  const text = service.promptContext({
    level: '7°',
    concepts: [{ area: 'Programación y Algoritmos', name: 'Algoritmo' }],
  });
  assert.match(text, /TRAYECTORIA: ALGORITMOS/);
  assert.match(text, /AHORA — PLANIFIQUE EN 7°/);
  assert.match(text, /ANTES — REFERENCIA ANTERIOR DE LA MISMA FAMILIA/);
  assert.match(text, /En 5° se contempla/);
  assert.match(text, /niveles intermedios sin abordaje conceptual registrado/i);
  assert.doesNotMatch(text, /En 6° se retoma|En 8° se retoma|se fortalece sin evaluación directa/i);
  assert.match(text, /En 9° se contempla/);
});

test('los niveles intermedios previos se presentan en orden cronológico', () => {
  const text = service.promptContext({
    level: '9°',
    concepts: [{ area: 'Computación física y Robótica', name: 'Domótica' }],
  });
  assert.match(text, /ANTES — REFERENCIA ANTERIOR DE LA MISMA FAMILIA/);
  assert.match(text, /niveles intermedios sin abordaje conceptual registrado o identificados como no aplicables/i);
  assert.match(text, /fuera del alcance del catálogo actual, que finaliza en 9°/i);
  assert.doesNotMatch(text, /7°: no aplicable|8°: no aplicable|Sin niveles intermedios/);
});

test('la trayectoria se presenta como AHORA, ANTES y DESPUÉS sin separadores técnicos', () => {
  const text = service.promptContext({
    level: '5°',
    concepts: [{ area: 'Apropiación tecnológica y Digital', name: 'Hardware' }],
  });
  for (const expected of ['AHORA — PLANIFIQUE EN 5°', 'ANTES — REFERENCIA PARA EL DIAGNÓSTICO', 'DESPUÉS — CONTINUIDAD CURRICULAR']) assert.match(text, new RegExp(expected));
  assert.match(text, /Saberes seleccionados:\n• Hardware/);
  assert.doesNotMatch(text, /Continuidad curricular intermedia|Sin niveles intermedios|\s\/\s-/);
});

test('el alcance actual no incorpora saberes de la familia que el docente no seleccionó', () => {
  const text = service.promptContext({
    level: '9°',
    concepts: [{ area: 'Computación física y Robótica', name: 'Domótica' }],
  });
  const currentSection = text.slice(text.indexOf('AHORA —'), text.indexOf('ANTES —'));
  assert.match(currentSection, /Domótica:/);
  assert.doesNotMatch(currentSection, /Prototipos:/);
});

test('el servicio conserva un resumen interno sin trasladar el detalle curricular', () => {
  const text = service.promptSummary({
    level: '9°',
    concepts: [
      { area: 'Programación y Algoritmos', name: 'Algoritmo' },
      { area: 'Computación física y Robótica', name: 'Domótica' },
    ],
  });
  assert.equal(text.split('\n').length, 1);
  for (const expected of ['integración horizontal', 'progresión vertical', 'Algoritmos', 'Domótica', 'únicamente el nivel actual', 'diagnóstico']) assert.match(text, new RegExp(expected, 'i'));
  assert.doesNotMatch(text, /AHORA|ANTES|DESPUÉS|N\/A|Sin niveles intermedios|En 7°|En 8°/);
});

test('la vista docente conserva indicadores literales y diferencia ausencia de registro', () => {
  const selected = curriculum['7°']['Módulo 1']['Programación y Algoritmos'].saberes
    .filter(saber => saber.nombre === 'Algoritmo')
    .map(saber => ({ level:'7°', module:'Módulo 1', area:'Programación y Algoritmos', name:saber.nombre, indicators:[...saber.indicadores] }));
  const [view] = service.trajectoryView({ level:'7°', concepts:selected, curriculum });
  assert.equal(view.familyLabel, 'Algoritmos');
  assert.deepEqual([...view.now.records[0].indicators], [...selected[0].indicators]);
  assert.equal(view.before.explicit.level, '5°');
  assert.equal(view.after.explicit.level, '9°');
  assert.equal(view.after.transition.some(step => step.level === '8°' && step.status === 'no-curricular-record'), true);
  assert.equal(view.before.explicit.records.every(record => record.indicators.length > 0), true);
});

test('la vista docente no amplía AHORA con saberes no seleccionados de la misma familia', () => {
  const saber = curriculum['9°']['Módulo 1']['Computación física y Robótica'].saberes.find(item => item.nombre === 'Domótica');
  const [view] = service.trajectoryView({level:'9°',concepts:[{level:'9°',module:'Módulo 1',area:'Computación física y Robótica',name:saber.nombre,indicators:[...saber.indicadores]}],curriculum});
  assert.equal(view.now.records.map(record => record.name).join('|'), 'Domótica');
  assert.equal(view.now.records.some(record => record.name === 'Prototipos'), false);
});
