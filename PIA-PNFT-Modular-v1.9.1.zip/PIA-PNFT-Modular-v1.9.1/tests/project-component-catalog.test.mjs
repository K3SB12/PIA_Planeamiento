import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const source = await readFile(resolve(root, 'src/data/project-component-catalog.js'), 'utf8');
const context = vm.createContext({ result: null });
vm.runInContext(`${source}\nresult=PIAProjectComponentCatalog;`, context);
const api = context.result;

test('el catálogo es clásico, versionado y limitado al alcance oficial', () => {
  assert.doesNotMatch(source, /^\s*(?:import|export)\s/m);
  assert.equal(api.CATALOG_VERSION, '2026.2');
  assert.equal(api.SOURCE.authority, 'Programa Nacional de Formación Tecnológica, DRTE-MEP');
  assert.deepEqual(Array.from(api.SOURCE.scope), ['III Ciclo', 'Educación Diversificada']);
  assert.equal(api.appliesTo('III Ciclo'), true);
  assert.equal(api.appliesTo('I Ciclo'), false);
});

test('define las tres etapas y las cinco fases continuas de Design Thinking', () => {
  assert.deepEqual(Array.from(api.stages, stage => stage.id), ['initial', 'development', 'final']);
  assert.deepEqual(Array.from(api.phases, phase => phase.id), ['empathize', 'define', 'ideate', 'prototype', 'test-evaluate']);
  assert.deepEqual(Array.from(api.phasesForStage('initial'), phase => phase.name), ['Empatizar', 'Definir', 'Idear']);
  assert.deepEqual(Array.from(api.phasesForStage('development'), phase => phase.name), ['Prototipar']);
  assert.deepEqual(Array.from(api.phasesForStage('final'), phase => phase.name), ['Probar/Evaluar']);
});

test('conserva literalmente los tres indicadores de logro oficiales de la etapa inicial', () => {
  assert.deepEqual(Array.from(api.indicators, indicator => indicator.text), [
    'Describir las necesidades, deseos y motivaciones de usuarios o clientes que tienen un problema o situación por resolver.',
    'Sintetizar los hallazgos relacionados con los intereses y necesidades del usuario o cliente, de modo que se entienda con claridad el problema o situación por resolver.',
    'Seleccionar la idea más eficiente para ofrecer una posible solución a un problema o situación por resolver.'
  ]);
  assert.equal(api.indicatorsForStage('initial').length, 3);
  assert.equal(api.indicators.every(indicator => indicator.official && indicator.catalogVersion === '2026.2'), true);
});

test('conserva literalmente los cinco indicadores de evaluación asociados', () => {
  const texts = api.indicators.flatMap(indicator => Array.from(indicator.evaluationIndicators, item => item.text));
  assert.deepEqual(Array.from(texts), [
    'Describe un problema o situación por resolver que es importante para un usuario o cliente.',
    'Registra los intereses y necesidades del usuario ante un problema o situación a resolver, por medio de entrevistas, observaciones, grabaciones, encuestas, entre otras.',
    'Sintetiza los intereses y necesidades del usuario o cliente en la construcción de un producto comunicativo.',
    'Selecciona la idea que ofrezca la solución más eficiente para resolver el problema o situación.',
    'Justifica de manera clara, con al menos dos ideas, por qué la solución elegida es la más eficiente, comparándola con otras.'
  ]);
});

test('desarrollo y final quedan vacíos sin inventar indicadores futuros', () => {
  for (const phaseId of ['prototype', 'test-evaluate']) {
    const phase = api.getPhase(phaseId);
    assert.equal(phase.indicatorStatus, 'pending-official-source');
    assert.deepEqual(Array.from(phase.indicatorIds), []);
    assert.deepEqual(Array.from(api.indicatorsForPhase(phaseId)), []);
  }
  assert.deepEqual(Array.from(api.indicatorsForStage('development')), []);
  assert.deepEqual(Array.from(api.indicatorsForStage('final')), []);
});

test('desarrollo y final no inventan logros y esperan vínculos curriculares explícitos', () => {
  for (const phaseId of ['prototype','test-evaluate']) {
    const record=api.phaseRecord(phaseId);
    assert.deepEqual(Array.from(record.achievementIndicators),[]);
  }
});

test('los indicadores oficiales del módulo vinculados a Prototipar se exportan con evaluaciones editables', () => {
  const indicator={id:'project.curriculum.prototype.sample',sourceType:'official-curriculum',officialText:'Indicador oficial literal del módulo.',teacherText:'Indicador oficial literal del módulo.',evaluationIndicators:[{id:'evaluation.01',sourceType:'teacher-authored',officialText:'',teacherText:'Construye el prototipo según los requerimientos acordados.',selected:true}]};
  const record={phaseId:'prototype',stageId:'development',achievementIndicators:[indicator]};
  const project={mode:'integrated',stageId:'development',phaseId:'prototype',records:{prototype:record}};
  const selected=api.exportSelection(project,[]);
  assert.deepEqual(Array.from(selected.achievement,item=>item.text),[indicator.teacherText]);
  assert.deepEqual(Array.from(selected.evaluation,item=>item.text),[indicator.evaluationIndicators[0].teacherText]);
  assert.equal(selected.achievement[0].sourceType,'official-curriculum');
});

test('las consultas desconocidas fallan de forma segura y los identificadores son únicos', () => {
  assert.equal(api.getStage('unknown'), null);
  assert.equal(api.getPhase('unknown'), null);
  assert.equal(api.getIndicator('unknown'), null);
  assert.deepEqual(Array.from(api.indicatorsForPhase('unknown')), []);
  const ids = [...api.stages, ...api.phases, ...api.indicators].map(item => item.id);
  assert.equal(new Set(ids).size, ids.length);
});

test('el registro semanal separa texto oficial y contextualización docente', () => {
  const record = api.phaseRecord('empathize');
  const indicator = record.achievementIndicators[0];
  assert.equal(indicator.officialText, api.indicatorsForPhase('empathize')[0].text);
  assert.equal(indicator.teacherText, indicator.officialText);
  indicator.teacherText = 'Contextualización docente conservada';
  const normalized = api.normalizeWeekProject({mode:'mixed',phaseId:'empathize',records:{empathize:record}});
  assert.equal(normalized.mode, 'mixed');
  assert.equal(normalized.records.empathize.achievementIndicators[0].teacherText, 'Contextualización docente conservada');
  assert.equal(normalized.records.empathize.achievementIndicators[0].officialText, api.indicatorsForPhase('empathize')[0].text);
});

test('la selección exportable prioriza texto docente y excluye indicadores desmarcados', () => {
  const record=api.phaseRecord('empathize');
  const indicator=record.achievementIndicators[0];
  indicator.teacherText='Indicador de logro contextualizado por la persona docente';
  indicator.evaluationIndicators[0].teacherText='Indicador de evaluación contextualizado';
  indicator.evaluationIndicators[1].teacherText='Este texto no debe exportarse';
  indicator.evaluationIndicators[1].selected=false;
  const project={mode:'mixed',stageId:'initial',phaseId:'empathize',records:{empathize:record}};
  const selected=api.exportSelection(project,[indicator.id]);
  assert.equal(selected.active,true);
  assert.deepEqual(Array.from(selected.achievement,item=>item.text),['Indicador de logro contextualizado por la persona docente']);
  assert.deepEqual(Array.from(selected.evaluation,item=>item.text),['Indicador de evaluación contextualizado']);
  assert.equal(JSON.stringify(selected).includes('Este texto no debe exportarse'),false);
  assert.equal(api.exportSelection({...project,mode:'curricular'},[indicator.id]).active,false);
});

test('la selección exportable usa el original cuando no existe edición docente', () => {
  const record=api.phaseRecord('define'),indicator=record.achievementIndicators[0];
  indicator.teacherText='';
  indicator.evaluationIndicators[0].teacherText='';
  const selected=api.exportSelection({mode:'integrated',stageId:'initial',phaseId:'define',records:{define:record}},[indicator.id]);
  assert.equal(selected.achievement[0].text,indicator.officialText);
  assert.equal(selected.evaluation[0].text,indicator.evaluationIndicators[0].officialText);
});
