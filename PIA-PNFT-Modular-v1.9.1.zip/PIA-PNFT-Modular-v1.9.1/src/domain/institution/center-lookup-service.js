// PIA_CENTER_LOOKUP_JS_START
const PIACenterLookup = (() => {
    function normalizeBudgetCode(value) {
        const normalized = String(value ?? '').trim();
        if (!/^\d{1,4}$/.test(normalized)) return '';
        return normalized.padStart(4, '0');
    }
    function create(records = PIAInstitutionalCenters) {
        const byBudgetCode = new Map();
        for (const record of records) {
            if (record.codPres === '0000') continue;
            const matches = byBudgetCode.get(record.codPres) || [];
            matches.push(record);
            byBudgetCode.set(record.codPres, matches);
        }
        return value => {
            const codPres = normalizeBudgetCode(value);
            const matches = codPres ? [...(byBudgetCode.get(codPres) || [])] : [];
            if (!matches.length) return { status: 'notFound', codPres, matches };
            if (matches.length === 1) return { status: 'unique', codPres, center: matches[0], matches };
            return { status: 'ambiguous', codPres, matches };
        };
    }
    return Object.freeze({ normalizeBudgetCode, create, lookup: create() });
})();
// PIA_CENTER_LOOKUP_JS_END
