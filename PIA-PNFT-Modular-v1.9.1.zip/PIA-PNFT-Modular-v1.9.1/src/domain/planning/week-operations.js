        function actualizarProcedimentalSemana(numeroSemana, checkbox) {
            const semana = semanas[numeroSemana-1];
            
            if (checkbox.checked) {
                if (!semana.procedimentales.includes(checkbox.value)) {
                    semana.procedimentales.push(checkbox.value);
                    saberesProcedimentalesGlobales.add(checkbox.value);
                }
            } else {
                semana.procedimentales = semana.procedimentales.filter(p => p !== checkbox.value);
                const enOtraSemana = semanas.some((s, index) => 
                    index !== numeroSemana-1 && s.procedimentales.includes(checkbox.value)
                );
                if (!enOtraSemana) {
                    saberesProcedimentalesGlobales.delete(checkbox.value);
                }
            }
        }

        function actualizarActitudinalSemana(numeroSemana, checkbox) {
            const semana = semanas[numeroSemana-1];
            
            if (checkbox.checked) {
                if (!semana.actitudinales.includes(checkbox.value)) {
                    semana.actitudinales.push(checkbox.value);
                    saberesActitudinalesGlobales.add(checkbox.value);
                }
            } else {
                semana.actitudinales = semana.actitudinales.filter(a => a !== checkbox.value);
                const enOtraSemana = semanas.some((s, index) => 
                    index !== numeroSemana-1 && s.actitudinales.includes(checkbox.value)
                );
                if (!enOtraSemana) {
                    saberesActitudinalesGlobales.delete(checkbox.value);
                }
            }
        }

        function actualizarLeccionesSemana(numero, nuevoNombre) {
            semanas[numero-1].lecciones = nuevoNombre;
        }

        function actualizarContenidoSemana(numero, tipo, contenido) {
            semanas[numero-1][tipo] = contenido;
        }

        function agregarSemanaManual() {
            const leccionesActual = parseInt(document.getElementById('leccionesPlanificadas').value) || 8;
            const nuevoNumero = semanas.length + 1;
            const leccionInicio = leccionesActual + 1;
            const leccionFin = leccionInicio + 1;
            
            // Actualizar lecciones planificadas
            document.getElementById('leccionesPlanificadas').value = leccionFin;
            
            semanas.push({
                id: nuevoNumero,
                nombre: `Semana ${nuevoNumero}`,
                lecciones: `Lecciones ${leccionInicio} y ${leccionFin}`,
                fase: nuevoNumero === 1 ? 'diagnóstico' : 'desarrollo',
                modulos: modulosPredeterminadosSemana(),
                areas: [],
                rda: '',
                saberes: [],
                saberRefs: [],
                procedimentales: [],
                actitudinales: [],
                actividades: '',
                recursos: '',
                evaluacion: '',
                indicadores: '',
                project: PIAProjectComponentCatalog.defaultWeekProject()
            });
            
            const container = document.getElementById('semanasContainer');
            const nuevaSemana = crearElementoSemana(nuevoNumero, leccionInicio, leccionFin);
            container.appendChild(nuevaSemana);
            
            actualizarContadoresSemanas();
        }

        function eliminarSemana(numero) {
            if (semanas.length <= 1) {
                alert('Debe haber al menos una semana');
                return;
            }
            
            if (!confirm('¿Está seguro de que desea eliminar esta semana? Se perderá todo el contenido de esta semana.')) {
                return;
            }
            
            const semanaAEliminar = semanas[numero-1];
            
            // SOLO eliminar los datos de ESTA semana específica
            semanaAEliminar.saberes.forEach(saber => {
                const enOtraSemana = semanas.some((s, index) => 
                    index !== numero-1 && s.saberes.includes(saber)
                );
                if (!enOtraSemana) {
                    saberesSeleccionados.delete(saber);
                }
            });
            
            semanaAEliminar.procedimentales.forEach(proc => {
                const enOtraSemana = semanas.some((s, index) => 
                    index !== numero-1 && s.procedimentales.includes(proc)
                );
                if (!enOtraSemana) {
                    saberesProcedimentalesGlobales.delete(proc);
                }
            });
            
            semanaAEliminar.actitudinales.forEach(act => {
                const enOtraSemana = semanas.some((s, index) => 
                    index !== numero-1 && s.actitudinales.includes(act)
                );
                if (!enOtraSemana) {
                    saberesActitudinalesGlobales.delete(act);
                }
            });
            
            // Eliminar solo la semana específica
            semanas.splice(numero-1, 1);

            // Mantener una identidad interna consecutiva sin alterar el contenido pedagógico.
            semanas.forEach((semana, index) => {
                semana.id = index + 1;
                semana.nombre = `Semana ${index + 1}`;
            });

            // Sincronizar el total con la última lección que realmente permanece en el plan.
            // Al eliminar las semanas finales 8 y 7, el total pasa de 16 a 14 y luego a 12.
            const numerosLeccionRestantes = semanas.flatMap(semana =>
                (String(semana.lecciones || '').match(/\d+/g) || [])
                    .map(Number)
                    .filter(Number.isFinite)
            );
            const totalLeccionesRestantes = numerosLeccionRestantes.length > 0
                ? Math.max(...numerosLeccionRestantes)
                : semanas.length * 2;
            document.getElementById('leccionesPlanificadas').value = String(totalLeccionesRestantes);
            
            // Reconstruir vista SIN afectar otras semanas
            reconstruirVistaSemanasPreservandoContenido();
            actualizarContadoresSemanas();
            
            console.log(`Semana ${numero} eliminada. Semanas restantes: ${semanas.length}. Lecciones restantes: ${totalLeccionesRestantes}`);
        }

        function reconstruirVistaSemanasPreservandoContenido() {
            const container = document.getElementById('semanasContainer');
            container.innerHTML = '';
            
            semanas.forEach((semana, index) => {
                const lecciones = semana.lecciones.match(/\d+/g) || [];
                const leccionInicio = lecciones[0] ? parseInt(lecciones[0]) : (index * 2 + 1);
                const leccionFin = lecciones[1] ? parseInt(lecciones[1]) : Math.min((index + 1) * 2, parseInt(document.getElementById('leccionesPlanificadas').value));
                
                const semanaElement = crearElementoSemana(index + 1, leccionInicio, leccionFin);
                container.appendChild(semanaElement);
                
                // Restaurar TODO el estado de la semana
                setTimeout(() => {
                    // 1. PRIMERO restaurar áreas seleccionadas (esto dispara actualizaciones automáticas)
                    semana.areas.forEach(area => {
                        const areaMapping = {
                            'Apropiación tecnológica y Digital': 'apropiacion',
                            'Programación y Algoritmos': 'programacion',
                            'Computación física y Robótica': 'robotica',
                            'Ciencia de datos e Inteligencia artificial': 'ciencia'
                        };
                        
                        const areaKey = areaMapping[area];
                        if (areaKey) {
                            const checkbox = document.querySelector(`input[name="area-semana-${index+1}"][value="${areaKey}"]`);
                            if (checkbox) {
                                checkbox.checked = true;
                                // EJECUTAR MANUALMENTE la función que se ejecutaría al marcar el checkbox
                                actualizarAreaSemana(index + 1, checkbox);
                            }
                        }
                    });
                    
                    // 2. LUEGO restaurar saberes conceptuales seleccionados
                    semana.saberes.forEach(saber => {
                        const checkboxes = document.querySelectorAll(`#saberes-conceptuales-${index+1} input[type="checkbox"]`);
                        checkboxes.forEach(checkbox => {
                            const saberNombre = checkbox.nextElementSibling?.querySelector('div')?.textContent;
                            if (saberNombre === saber) {
                                checkbox.checked = true;
                                checkbox.parentElement.classList.add('seleccionado');
                            }
                        });
                    });
                    
                    // 3. RESTAURAR procedimentales
                    semana.procedimentales.forEach(proc => {
                        const checkbox = document.querySelector(`input[name="procedimental-semana-${index+1}"][value="${proc}"]`);
                        if (checkbox) checkbox.checked = true;
                    });
                    
                    // 4. RESTAURAR actitudinales  
                    semana.actitudinales.forEach(act => {
                        const checkbox = document.querySelector(`input[name="actitudinal-semana-${index+1}"][value="${act}"]`);
                        if (checkbox) checkbox.checked = true;
                    });
                    
                    // 5. RESTAURAR contenido de campos editables
                    const indicadoresContainer = document.querySelector(`#semana-${index+1} .contenedor-oficial[data-field-kind="official-indicator"]`);
                    if (indicadoresContainer && semana.indicadores) {
                        indicadoresContainer.innerHTML = semana.indicadores;
                    }
                    
                    const actividadesContainer = document.querySelector(`#semana-${index+1} .contenedor-editable[data-field-kind="mediation"]`);
                    if (actividadesContainer && semana.actividades) {
                        actividadesContainer.innerHTML = semana.actividades;
                    }
                    
                    const evaluacionContainer = document.querySelector(`#semana-${index+1} .contenedor-editable[data-field-kind="evaluation"]`);
                    if (evaluacionContainer && semana.evaluacion) {
                        evaluacionContainer.innerHTML = semana.evaluacion;
                    }
                    
                }, 100);
            });
        }

        function actualizarContadoresSemanas() {
            document.getElementById('totalSemanas').textContent = semanas.length;
            document.getElementById('totalLecciones').textContent = document.getElementById('leccionesPlanificadas').value;
        }

        function mostrarDetalleMetodologia(metodologia) {
            // Esta función ya no es necesaria ya que eliminamos los detalles
            // Solo manejamos la visibilidad del campo personalizado
            manejarCambioMetodologia();
        }

