        const PIAIntegrationBridge = Object.freeze({
            mode: 'local-only',
            backendConfigured: false,
            repository: Object.freeze({
                capabilities() { return {remote:false,authentication:false,analytics:false,offline:true}; },
                async save() { throw new Error('Backend no configurado: PIA conserva el guardado local.'); },
                async load() { throw new Error('Backend no configurado: utilice Abrir archivo JSON.'); },
                async list() { return []; },
                async remove() { return {removed:false,code:'BACKEND_NOT_CONFIGURED'}; },
                async health() { return {available:false,mode:'inactive'}; }
            }),
            analytics: Object.freeze({
                enabled: false,
                capabilities() { return {enabled:false,remote:false,personalData:false}; },
                track() { return false; }
            })
        });
