        function mostrarOpcionesExportar() {
            // 1. Inicializar formato a PDF por defecto
            formatoExportacion = 'pdf';
            
            // 2. Limpiar selecciones visuales
            document.querySelectorAll('.export-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            // 3. Seleccionar PDF visualmente
            const opcionPDF = document.getElementById('opcionPDF');
            if (opcionPDF) {
                opcionPDF.classList.add('selected');
            }

            actualizarAyudaFormatoExportacion('pdf');
            
            // 4. Mostrar modal
            document.getElementById('exportarModal').style.display = 'block';
        }

        // Función para cerrar el modal
        function cerrarExportModal() {
            document.getElementById('exportarModal').style.display = 'none';
        }

        // ✅ FUNCIÓN CORREGIDA - Con parámetro 'elemento'
        function seleccionarFormato(formato, elemento) {
            console.log(`Seleccionando formato: ${formato}`);
            formatoExportacion = formato;
            
            // Remover selección de todas las opciones
            document.querySelectorAll('.export-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            // Agregar selección a la opción clickeada
            if (elemento) {
                elemento.classList.add('selected');
            }

            actualizarAyudaFormatoExportacion(formato);
        }

        function actualizarAyudaFormatoExportacion(formato) {
            const boton = document.getElementById('btnConfirmarExportacion');
            const ayuda = document.getElementById('ayudaFormatoExportacion');

            if (boton) boton.textContent = '📄 Exportar';

            if (formato === 'word') {
                if (ayuda) {
                    ayuda.textContent = 'Se abrirá una vista continua, sin saltos forzados, con opciones para guardar el archivo Word o imprimirlo.';
                }
                return;
            }

            if (ayuda) {
                ayuda.textContent = 'El recurso se generará como vista previa en una nueva pestaña. Desde allí podrá imprimirlo como PDF usando las opciones de su navegador.';
            }
        }

        // ✅ FUNCIÓN CORREGIDA - Con validación
        function confirmarExportacion() {
            console.log(`Exportando en formato: ${formatoExportacion}`);
            
            if (!formatoExportacion) {
                formatoExportacion = 'pdf'; // Por defecto PDF
            }
            
            if (formatoExportacion === 'word') {
                exportarAWord();
            } else {
                exportarAPDF();
            }
            
            cerrarExportModal();
        }

        function exportarAWord() {
            const nombreSolicitado = document.getElementById('nombreArchivo').value || 'Planeamiento-Didáctico';
            const nombreArchivo = nombreSolicitado
                .replace(/[\\/:*?"<>|]/g, '-')
                .replace(/\s+/g, ' ')
                .trim()
                .slice(0, 120) || 'Planeamiento-Didáctico';
            const exportarInformacionGeneral = document.getElementById('exportarInformacionGeneral').checked;
            const exportarSaberes = document.getElementById('exportarSaberes').checked;
            const exportarSemanas = document.getElementById('exportarSemanas').checked;
            const exportarReflexiones = document.getElementById('exportarReflexiones').checked;
            const exportarSaberesGlobales = document.getElementById('exportarSaberesGlobales').checked;
            const incluirEncabezado = document.getElementById('incluirEncabezado')?.checked ?? true;
            const incluirPiePagina = document.getElementById('incluirPiePagina')?.checked ?? true;

            function escaparTextoWord(valor) {
                return String(valor ?? '')
                    .replace(/&/g, '&amp;')
                    .replace(/</g, '&lt;')
                    .replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;')
                    .replace(/'/g, '&#39;');
            }

            function sanitizarContenidoWord(valor) {
                return String(valor || '')
                    .replace(/<\s*(script|style|iframe|object|embed|link|meta)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, '')
                    .replace(/<\s*(script|style|iframe|object|embed|link|meta)\b[^>]*\/?>/gi, '')
                    .replace(/\son\w+\s*=\s*(["']).*?\1/gi, '')
                    .replace(/\son\w+\s*=\s*[^\s>]+/gi, '')
                    .replace(/\s(href|src)\s*=\s*(["'])\s*javascript:[\s\S]*?\2/gi, '');
            }

            function obtenerProyectoSemanaParaExportar(semana) {
                if (typeof PIAEnhancements === 'undefined' || typeof PIAEnhancements.projectExportForWeek !== 'function') {
                    return {active:false,achievement:[],evaluation:[]};
                }
                return PIAEnhancements.projectExportForWeek(semana);
            }

            function obtenerReferenciasSemanaParaExportar(semana) {
                if (typeof PIAEnhancements === 'undefined' || typeof PIAEnhancements.referenceExportForWeek !== 'function') return [];
                return PIAEnhancements.referenceExportForWeek(semana);
            }

            function bloqueProyectoWord(titulo, items) {
                if (!Array.isArray(items) || !items.length) return '';
                return `<div class="project-export-block"><strong>${escaparTextoWord(titulo)}</strong>${items.map(item => `<div class="project-export-item">${escaparTextoWord(item.text)}</div>`).join('')}</div>`;
            }

            function descargarDocumentoWord(contenido) {
                const blob = new Blob(['\ufeff', contenido], {type: 'application/msword;charset=utf-8'});
                const enlace = document.createElement('a');
                enlace.download = `${nombreArchivo}.doc`;
                enlace.href = URL.createObjectURL(blob);
                document.body.appendChild(enlace);
                enlace.click();
                document.body.removeChild(enlace);
                setTimeout(() => URL.revokeObjectURL(enlace.href), 100);
            }
            
            // Obtener áreas únicas de todas las semanas para RdA globales
            const areasUnicas = new Set();
            semanas.forEach(semana => {
                semana.areas.forEach(area => areasUnicas.add(area));
            });

            // Crear contenido HTML para Word
            let contenidoHTML = `
                <!DOCTYPE html>
                <html xmlns:o="urn:schemas-microsoft-com:office:office"
                      xmlns:w="urn:schemas-microsoft-com:office:word"
                      xmlns="http://www.w3.org/TR/REC-html40">
                <head>
                    <meta charset="UTF-8">
                    <title>${nombreArchivo}</title>
                    <!--[if gte mso 9]>
                    <xml>
                        <w:WordDocument>
                            <w:View>Print</w:View>
                            <w:Zoom>90</w:Zoom>
                            <w:DoNotOptimizeForBrowser/>
                        </w:WordDocument>
                    </xml>
                    <![endif]-->
                    <style>
                        @page {
                            size: A4 landscape;
                            margin: 0.5in;
                        }
                        @page WordSection1 {
                            size: 841.9pt 595.3pt;
                            margin: 36pt;
                            mso-page-orientation: landscape;
                        }
                        .WordSection1 {
                            page: WordSection1;
                        }
                        body { 
                            font-family: 'Poppins', sans-serif; 
                            margin: 0; 
                            padding: 0; 
                            line-height: 1.4;
                            color: #000;
                            font-size: 12px;
                        }
                        .container {
                            width: 100%;
                            max-width: 10in;
                            margin: 0 auto;
                        }
                        @media screen {
                            body {
                                background: #eef1f6;
                                padding: 24px;
                            }
                            .container {
                                background: white;
                                padding: 18px;
                                box-shadow: 0 4px 18px rgba(0, 0, 0, 0.14);
                            }
                        }
                        table {
                            width: 100%;
                            table-layout: fixed;
                            border-collapse: collapse;
                            margin-bottom: 10px;
                            border: 1px solid #000;
                        }
                        td, th {
                            border: 1px solid #000;
                            padding: 6px;
                            vertical-align: top;
                            font-size: 11px;
                            overflow-wrap: break-word;
                            word-wrap: break-word;
                        }
                        th {
                            background: #45258F;
                            color: white;
                            font-weight: bold;
                            text-align: center;
                            line-height: 1.25;
                        }
                        .section-title {
                            background: #45258F;
                            color: white;
                            font-weight: bold;
                            text-align: center;
                            padding: 8px;
                            margin: 10px 0 5px 0;
                            border: 1px solid #000;
                            font-size: 12px;
                            width: 100%;
                            box-sizing: border-box;
                            line-height: 1.25;
                            white-space: normal;
                            overflow-wrap: break-word;
                            word-wrap: break-word;
                        }
                        .header {
                            text-align: center;
                            font-weight: bold;
                            font-size: 14px;
                            margin-bottom: 15px;
                            padding: 10px;
                            background: #f0f0f0;
                            border: 1px solid #000;
                        }
                        .semana-container {
                            margin-bottom: 10px;
                            page-break-inside: auto;
                            break-inside: auto;
                        }

                        .footer {
                            text-align: center;
                            margin-top: 20px;
                            font-weight: bold;
                            color: #45258F;
                            padding: 15px;
                            border-top: 2px solid #45258F;
                        }
                        .note {
                            margin: 15px 0;
                            padding: 10px;
                            background: #e7f3ff;
                            border-left: 3px solid #007bff;
                            border-radius: 4px;
                            font-size: 11px;
                        }
                        .word-reflection-area {
                            height: 100pt;
                            min-height: 100pt;
                            background: #ffffff !important;
                            color: #000000;
                            vertical-align: top;
                        }
                        .word-observations-area {
                            height: 145pt;
                            min-height: 145pt;
                            background: #ffffff !important;
                            color: #000000;
                            vertical-align: top;
                        }
                        .project-export-block {
                            margin-top: 8px;
                            padding: 7px;
                            border-left: 3px solid #10A8AD;
                            background: #F2FFFF;
                        }
                        .project-export-item { margin-top: 4px; }
                        .checkbox-table {
                            width: 100%;
                            border: none;
                        }
                        .checkbox-table td {
                            border: none;
                            text-align: center;
                            vertical-align: middle;
                        }
                        @media print {
                            .no-imprimir {
                                display: none !important;
                            }
                            body {
                                padding: 0;
                                background: white;
                            }
                            .container {
                                max-width: none;
                                padding: 0;
                                box-shadow: none;
                            }
                        }
                    </style>
                </head>
                <body>
                    <div class="WordSection1">
                        <div class="container">
            `;
            
            // ENCABEZADO
            if (incluirEncabezado) contenidoHTML += `
                <div class="header">
                    <strong>MINISTERIO DE EDUCACIÓN PÚBLICA</strong><br>
                    <strong>Plantilla de Planeamiento Didáctico</strong><br>
                    <strong>Programa Nacional de Formación Tecnológica</strong><br>
                    <span>Informática educativa</span>
                </div>
            `;

            // PIA_EXPORT_ENHANCEMENT_WORD_IDENTITY_START
            if (typeof PIAEnhancements !== 'undefined') {
                contenidoHTML += PIAEnhancements.institutionalExportHtml();
            }
            // PIA_EXPORT_ENHANCEMENT_WORD_IDENTITY_END
            
            // INFORMACIÓN GENERAL
            if (exportarInformacionGeneral) {
                contenidoHTML += `
                    <table>
                        <tr>
                            <td width="25%"><strong>Dirección Regional de Educación:</strong><br>${escaparTextoWord(document.getElementById('direccionRegional').value)}</td>
                            <td width="25%"><strong>Centro educativo:</strong><br>${escaparTextoWord(document.getElementById('centroEducativo').value)}</td>
                            <td width="25%"><strong>Código:</strong><br>${escaparTextoWord(document.getElementById('codigoCentro').value)}</td>
                            <td width="25%"><strong>Circuito:</strong><br>${escaparTextoWord(document.getElementById('circuito').value)}</td>
                        </tr>
                        <tr>
                            <td><strong>Nombre de la persona docente:</strong><br>${escaparTextoWord(document.getElementById('nombreDocente').value)}</td>
                            <td colspan="2"><strong>Asignatura: Formación tecnológica/Informática educativa</strong></td>
                            <td><strong>Curso lectivo:</strong><br>${escaparTextoWord(document.getElementById('cursoLectivo').value)}</td>
                        </tr>
                        <tr>
                            <td><strong>Ciclo:</strong><br>${escaparTextoWord(document.getElementById('ciclo').value)}</td>
                            <td><strong>Nivel:</strong><br>${escaparTextoWord(document.getElementById('nivel').value)}</td>
                            <td><strong>Lecciones planificadas:</strong><br>${escaparTextoWord(document.getElementById('leccionesPlanificadas').value)}</td>
                            <td><strong>Mes inicio - Mes final:</strong><br>${escaparTextoWord(document.getElementById('mesInicio').value)} - ${escaparTextoWord(document.getElementById('mesFinal').value)}</td>
                        </tr>
                    </table>
                `;
            }
            
            // EJES TRANSVERSALES
            if (exportarInformacionGeneral) {
                const ejesSeleccionados = Array.from(document.querySelectorAll('input[name="eje"]:checked')).map(cb => cb.value);
                
                contenidoHTML += `
                    <div class="section-title">Eje transversal del PNFT según competencia MEP, marque con una equis (x) el eje a desarrollar.</div>
                    <table class="checkbox-table">
                        <tr>
                            <td width="33%" style="text-align: center; padding: 10px;">
                                <strong>Ciudadanía y ética digital</strong><br>
                                Competencias para la ciudadanía responsable y solidaria<br><br>
                                <strong>${ejesSeleccionados.includes('ciudadania') ? '[X]' : '[ ]'}</strong>
                            </td>
                            <td width="34%" style="text-align: center; padding: 10px;">
                                <strong>Pensamiento computacional para la resolución de problemas</strong><br>
                                Competencias para la vida<br><br>
                                <strong>${ejesSeleccionados.includes('pensamiento') ? '[X]' : '[ ]'}</strong>
                            </td>
                            <td width="33%" style="text-align: center; padding: 10px;">
                                <strong>Emprendimiento e Innovación</strong><br>
                                Competencias para el empleo digno<br><br>
                                <strong>${ejesSeleccionados.includes('emprendimiento') ? '[X]' : '[ ]'}</strong>
                            </td>
                        </tr>
                    </table>
                `;
            }
            
            // METODOLOGÍA ACTIVA
            if (exportarInformacionGeneral) {
                let metodologia = document.getElementById('metodologiaActiva').value;
                if (metodologia === 'otra') {
                    metodologia = document.getElementById('metodologiaPersonalizada').value || 'Metodología personalizada';
                }
                
                if (metodologia) {
                    let metodologiaTexto = '';
                    if (metodologia === 'ABJ') metodologiaTexto = 'Aprendizaje basado en juegos (ABJ)';
                    else if (metodologia === 'ABR') metodologiaTexto = 'Aprendizaje basado en retos (ABR)';
                    else if (metodologia === 'APD') metodologiaTexto = 'Aprendizaje Pensamiento por Diseño (APD)';
                    else metodologiaTexto = escaparTextoWord(metodologia);
                    
                    contenidoHTML += `
                        <div class="section-title">Metodología activa:</div>
                        <table>
                            <tr>
                                <td>${metodologiaTexto}</td>
                            </tr>
                        </table>
                    `;
                }
            }
            
            // ✅ ÁREAS Y RDA GLOBALES - CORREGIDO: Solo muestra las áreas seleccionadas globalmente
            if (exportarSaberes && areasUnicas.size > 0) {
                const ciclo = document.getElementById('ciclo').value;
                
                contenidoHTML += `
                    <div class="section-title">Área de conocimiento y RdA:</div>
                    <table>
                        <tr>
                            <th width="40%">Área de conocimiento</th>
                            <th width="60%">RdA:</th>
                        </tr>
                `;
                
                areasUnicas.forEach(area => {
                    const rda = RDA_POR_CICLO[ciclo] && RDA_POR_CICLO[ciclo][area] ? RDA_POR_CICLO[ciclo][area] : 'No definido';
                    contenidoHTML += `
                        <tr>
                            <td>${escaparTextoWord(area)}</td>
                            <td>${escaparTextoWord(rda)}</td>
                        </tr>
                    `;
                });
                
                contenidoHTML += `</table>`;
            }
            
            // ✅ SABERES GLOBALES ELEGIDOS POR EL DOCENTE - CORREGIDO: Solo muestra los saberes realmente seleccionados
            if (exportarSaberesGlobales) {
                contenidoHTML += `
                    <div class="section-title">Saberes Globales</div>
                    <table>
                        <tr>
                            <th width="33%">Saberes conceptuales (saber)</th>
                            <th width="33%">Saberes procedimentales (saber hacer)</th>
                            <th width="34%">Saberes actitudinales (saber ser)</th>
                        </tr>
                        <tr>
                            <td style="vertical-align: top;">
                `;
                
                // ✅ SABERES CONCEPTUALES GLOBALES - Solo los seleccionados por el docente
                if (saberesSeleccionados.size > 0) {
                    contenidoHTML += Array.from(saberesSeleccionados).map(saber => `• ${escaparTextoWord(saber)}`).join('<br>');
                } else {
                    contenidoHTML += 'No se han seleccionado saberes conceptuales';
                }
                
                contenidoHTML += `
                            </td>
                            <td style="vertical-align: top;">
                `;
                
                // ✅ SABERES PROCEDIMENTALES GLOBALES - Solo los seleccionados por el docente
                if (saberesProcedimentalesGlobales.size > 0) {
                    contenidoHTML += Array.from(saberesProcedimentalesGlobales).map(proc => {
                        const mapping = {
                            'reconoce': '• Reconoce patrones',
                            'abstrae': '• Abstrae',
                            'generaliza': '• Generaliza',
                            'transfiere': '• Transfiere',
                            'modulariza': '• Modulariza',
                            'formula': '• Formula algoritmos',
                            'remezcla': '• Remezcla',
                            'depura': '• Depura',
                            'programa': '• Programa',
                            'comunica': '• Comunica',
                            'colabora': '• Colabora',
                            'piensa': '• Piensa de forma creativa',
                            'maneja': '• Maneja las tecnologías de forma ética y segura'
                        };
                        return mapping[proc] || `• ${escaparTextoWord(proc)}`;
                    }).join('<br>');
                } else {
                    contenidoHTML += 'No se han seleccionado saberes procedimentales';
                }
                
                contenidoHTML += `
                            </td>
                            <td style="vertical-align: top;">
                `;
                
                // ✅ SABERES ACTITUDINALES GLOBALES - Solo los seleccionados por el docente
                if (saberesActitudinalesGlobales.size > 0) {
                    contenidoHTML += Array.from(saberesActitudinalesGlobales).map(act => {
                        const mapping = {
                            'gusto': '• Gusto por la precisión',
                            'aprender': '• Aprender del error',
                            'flexibilidad': '• Flexibilidad para manejar problemas',
                            'tolerancia': '• Tolerancia a la frustración'
                        };
                        return mapping[act] || `• ${escaparTextoWord(act)}`;
                    }).join('<br>');
                } else {
                    contenidoHTML += 'No se han seleccionado saberes actitudinales';
                }
                
                contenidoHTML += `
                            </td>
                        </tr>
                    </table>
                `;
            }
            
            // ✅ PLANIFICACIÓN POR SEMANAS - CORREGIDO: Solo las 3 columnas requeridas
            if (exportarSemanas && semanas.length > 0) {
                contenidoHTML += `<div class="section-title">Planificación por Semanas</div>`;
                
                semanas.forEach((semana, index) => {
                    const proyecto=obtenerProyectoSemanaParaExportar(semana);
                    const referencias=obtenerReferenciasSemanaParaExportar(semana);
                    const logroCurricular=sanitizarContenidoWord(semana.indicadores);
                    const evaluacionCurricular=sanitizarContenidoWord(semana.evaluacion);
                    const logroCompleto=(logroCurricular||(!proyecto.achievement.length&&!referencias.length?'No especificado':''))+bloqueProyectoWord('Indicadores de referencia del currículo del PNFT',referencias)+bloqueProyectoWord('Indicador de logro del Proyecto',proyecto.achievement);
                    const evaluacionCompleta=(evaluacionCurricular||(!proyecto.evaluation.length?'No especificado':''))+bloqueProyectoWord('Indicadores de evaluación del Proyecto',proyecto.evaluation);
                    contenidoHTML += `
                        <div class="semana-container">
                            <table>
                                <tr>
                                    <td colspan="3" style="background: #45258F; color: white; font-weight: bold; text-align: center;">
                                        <strong>Semana ${index + 1}: ${escaparTextoWord(semana.lecciones)}</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <th width="33%">Indicadores de logro</th>
                                    <th width="34%">Estrategias de Mediación</th>
                                    <th width="33%">Indicadores de evaluación</th>
                                </tr>
                                <tr>
                                    <td style="vertical-align: top;">${logroCompleto}</td>
                                    <td style="vertical-align: top;">${sanitizarContenidoWord(semana.actividades) || 'No especificado'}</td>
                                    <td style="vertical-align: top;">${evaluacionCompleta}</td>
                                </tr>
                            </table>
                        </div>
                    `;
                });
            }
            
            // REFLEXIONES DOCENTES
            if (exportarReflexiones) {
                contenidoHTML += `
                    <div class="section-title">Reflexiones Docentes</div>
                    <table>
                        <tr>
                            <th width="33%">¿Qué funcionó?</th>
                            <th width="34%">¿Qué no funcionó?</th>
                            <th width="33%">¿Qué puedo mejorar?</th>
                        </tr>
                        <tr>
                            <td class="word-reflection-area" height="100">${escaparTextoWord(document.getElementById('queFunciono').value) || '&nbsp;'}</td>
                            <td class="word-reflection-area" height="100">${escaparTextoWord(document.getElementById('queNoFunciono').value) || '&nbsp;'}</td>
                            <td class="word-reflection-area" height="100">${escaparTextoWord(document.getElementById('queMejorar').value) || '&nbsp;'}</td>
                        </tr>
                    </table>
                    
                    <div class="section-title">Observaciones y/o recomendaciones didácticas por nivel:</div>
                    <table>
                        <tr>
                            <td class="word-observations-area" height="145">${escaparTextoWord(document.getElementById('observaciones').value) || '&nbsp;'}</td>
                        </tr>
                    </table>
                `;
            }
            
            // NOTA SOBRE IA
            contenidoHTML += `
                <div class="note">
                    <strong>Nota importante sobre el uso de IA:</strong> Lo que brinda la IA debe ser contextualizado por el educador, 
                    quien decide, observa y ejecuta según su criterio y conocimiento del grupo. La IA proporciona estrategias de mediación 
                    que deben ser definidas, reagrupadas y reestructuradas por el educador considerando el orden, estructura y forma de 
                    implementación más adecuada.
                </div>
            `;
            
            // FOOTER
            if (incluirPiePagina) contenidoHTML += `
                <div class="footer">
                    DIDI - Departamento de Investigación, Desarrollo e Implementación <br>
                    Dirección de Recursos Tecnológicos en Educación<br>
                    Ministerio de Educación Pública - Gobierno de Costa Rica
                </div>
            `;

            contenidoHTML += `
                        </div>
                    </div>
                </body>
                </html>
            `;

            // Abrir una vista continua antes de guardar o imprimir.
            const ventanaPreview = window.open('', '_blank');
            if (!ventanaPreview) {
                descargarDocumentoWord(contenidoHTML);
                alert('El navegador bloqueó la vista previa. Se descargó directamente el archivo Word.');
                return;
            }

            ventanaPreview.document.write(contenidoHTML);
            ventanaPreview.document.close();

            const barra = ventanaPreview.document.createElement('div');
            barra.className = 'no-imprimir';
            barra.style.cssText = 'position:fixed;top:12px;right:12px;display:flex;gap:8px;padding:10px;background:#45258F;border-radius:8px;box-shadow:0 3px 12px rgba(0,0,0,.25);z-index:10000;';

            const botonGuardar = ventanaPreview.document.createElement('button');
            botonGuardar.textContent = '💾 Guardar Word';
            botonGuardar.style.cssText = 'border:0;border-radius:5px;padding:9px 12px;background:#ffffff;color:#45258F;font-weight:bold;cursor:pointer;';
            botonGuardar.onclick = () => descargarDocumentoWord(contenidoHTML);

            const botonImprimir = ventanaPreview.document.createElement('button');
            botonImprimir.textContent = '🖨️ Imprimir';
            botonImprimir.style.cssText = 'border:0;border-radius:5px;padding:9px 12px;background:#28a745;color:#ffffff;font-weight:bold;cursor:pointer;';
            botonImprimir.onclick = () => ventanaPreview.print();

            const botonCerrar = ventanaPreview.document.createElement('button');
            botonCerrar.textContent = '✕ Cerrar';
            botonCerrar.style.cssText = 'border:1px solid #ffffff;border-radius:5px;padding:9px 12px;background:transparent;color:#ffffff;font-weight:bold;cursor:pointer;';
            botonCerrar.onclick = () => ventanaPreview.close();

            barra.appendChild(botonGuardar);
            barra.appendChild(botonImprimir);
            barra.appendChild(botonCerrar);
            ventanaPreview.document.body.appendChild(barra);
            ventanaPreview.focus();
        }

        function exportarAPDF() {
    try {
        console.log("Iniciando exportación a PDF...");
        
        // OBTENER VALORES DE CHECKBOXES
        const nombreArchivo = document.getElementById('nombreArchivo').value || 'Planeamiento-Didáctico';
        const exportarInformacionGeneral = document.getElementById('exportarInformacionGeneral')?.checked ?? true;
        const exportarSaberes = document.getElementById('exportarSaberes')?.checked ?? true;
        const exportarSemanas = document.getElementById('exportarSemanas')?.checked ?? true;
        const exportarReflexiones = document.getElementById('exportarReflexiones')?.checked ?? true;
        const exportarSaberesGlobales = document.getElementById('exportarSaberesGlobales')?.checked ?? true;
        const incluirEncabezado = document.getElementById('incluirEncabezado')?.checked ?? true;
        const incluirPiePagina = document.getElementById('incluirPiePagina')?.checked ?? true;
        
        // ÁREAS ÚNICAS
        const areasUnicas = new Set();
        semanas.forEach(semana => {
            semana.areas.forEach(area => areasUnicas.add(area));
        });
        
        // ===== FUNCIONES AUXILIARES MEJORADAS =====
        function limpiarContenidoParaPDF(texto) {
            if (!texto || texto.toString().trim() === '') {
                return 'No especificado';
            }
            
            let contenido = texto.toString();
            
            // 1. Convertir HTML a texto plano controlado
            contenido = contenido.replace(/<[^>]*>/g, ' ');
            
            // 2. Convertir entidades HTML
            contenido = contenido.replace(/&nbsp;/g, ' ');
            contenido = contenido.replace(/&lt;/g, '<');
            contenido = contenido.replace(/&gt;/g, '>');
            contenido = contenido.replace(/&amp;/g, '&');
            contenido = contenido.replace(/&quot;/g, '"');
            contenido = contenido.replace(/&#39;/g, "'");
            
            // 3. Normalizar espacios
            contenido = contenido.replace(/\s+/g, ' ');
            contenido = contenido.trim();
            
            return contenido;
        }
        
        function formatearContenidoComoHTML(texto) {
            // PIA_EXPORT_ENHANCEMENT_PDF_RICH_START
            if (typeof PIAEnhancements !== 'undefined' && /<[^>]+>/.test(String(texto || ''))) {
                const contenidoSeguro = PIAEnhancements.sanitizeRichText(texto);
                if (contenidoSeguro.trim()) return `<div style="line-height:1.3;font-size:8.5pt;">${contenidoSeguro}</div>`;
            }
            // PIA_EXPORT_ENHANCEMENT_PDF_RICH_END
            const contenidoLimpio = limpiarContenidoParaPDF(texto);
            
            // Si está vacío
            if (contenidoLimpio === 'No especificado' || contenidoLimpio.trim() === '') {
                return '<div style="color: #999; font-style: italic; font-size: 8.5pt;">No especificado</div>';
            }
            
            // Dividir por puntos para mejor legibilidad
            const lineas = contenidoLimpio.split(/(?<=\.)\s+/).filter(linea => linea.trim());
            
            if (lineas.length === 0) {
                return '<div style="color: #999; font-style: italic; font-size: 8.5pt;">No especificado</div>';
            }
            
            // Crear párrafos más compactos para PDF
            let resultado = '';
            
            lineas.forEach(linea => {
                // Si es una lista con números o viñetas
                if (linea.match(/^\d+[-).]/) || linea.match(/^[•\-]/)) {
                    resultado += `<div style="margin-bottom: 1.5mm; padding-left: 1mm; line-height: 1.3; font-size: 8.5pt;">${linea.trim()}</div>`;
                } else {
                    resultado += `<div style="margin-bottom: 1.5mm; line-height: 1.3; font-size: 8.5pt; text-indent: 2mm;">${linea.trim()}</div>`;
                }
            });
            
            return resultado;
        }
        
        // ✅ FUNCIÓN NUEVA: AJUSTAR FUENTE SEGÚN LONGITUD
        function ajustarFuenteSegunLongitud(texto) {
            if (!texto || texto.toString().trim() === '') return '9.5pt';
            
            const contenidoLimpio = limpiarContenidoParaPDF(texto);
            const longitud = contenidoLimpio.length;
            
            // Escala progresiva según longitud
            if (longitud > 3000) return '7.5pt';      // Contenido muy largo
            if (longitud > 2000) return '8pt';        // Contenido largo
            if (longitud > 1000) return '8.5pt';      // Contenido medio-largo
            if (longitud > 500) return '9pt';         // Contenido medio
            return '9.5pt';                           // Contenido corto
        }
        
        // ✅ FUNCIÓN NUEVA: AJUSTAR ALTURA MÍNIMA SEGÚN CONTENIDO
        function ajustarAlturaMinima(texto) {
            if (!texto || texto.toString().trim() === '') return '25mm';
            
            const contenidoLimpio = limpiarContenidoParaPDF(texto);
            const longitud = contenidoLimpio.length;
            
            // Ajustar altura mínima según longitud
            if (longitud > 2000) return '60mm';
            if (longitud > 1000) return '45mm';
            if (longitud > 500) return '35mm';
            return '25mm';
        }
        
        // ✅ FUNCIÓN NUEVA: FORMATEAR CONTENIDO CON AJUSTE DINÁMICO
        function formatearContenidoConAjuste(texto, tipoContenido = 'general') {
            const contenidoLimpio = limpiarContenidoParaPDF(texto);
            
            // Si está vacío
            if (contenidoLimpio === 'No especificado' || contenidoLimpio.trim() === '') {
                return {
                    html: '<div style="color: #999; font-style: italic;">No especificado</div>',
                    fontSize: '9pt',
                    minHeight: '25mm'
                };
            }
            
            // Determinar tamaño de fuente óptimo
            const fontSize = ajustarFuenteSegunLongitud(texto);
            const minHeight = ajustarAlturaMinima(texto);
            
            // Formatear contenido con el tamaño adecuado
            const lineas = contenidoLimpio.split(/(?<=\.)\s+/).filter(linea => linea.trim());
            let html = '';
            
            lineas.forEach(linea => {
                const esLista = linea.match(/^\d+[-).]/) || linea.match(/^[•\-]/);
                const estiloLinea = esLista 
                    ? `margin: 0 0 1mm ${tipoContenido === 'estrategias' ? '3mm' : '1mm'}; padding-left: 1mm;`
                    : `margin: 0 0 1mm 0; text-indent: 2mm;`;
                
                html += `
                    <div style="
                        ${estiloLinea}
                        line-height: 1.35;
                        font-size: ${fontSize};
                        text-align: ${tipoContenido === 'estrategias' ? 'justify' : 'left'};
                        hyphens: auto;
                        word-wrap: break-word;
                    ">
                        ${linea.trim()}
                    </div>
                `;
            });
            
            return {
                html: html,
                fontSize: fontSize,
                minHeight: minHeight
            };
        }

        // PIA_EXPORT_ENHANCEMENT_PDF_PROJECT_HELPERS_START
        function escaparTextoProyectoPDF(valor) {
            return String(valor ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
        }

        function obtenerProyectoSemanaParaPDF(semana) {
            if (typeof PIAEnhancements === 'undefined' || typeof PIAEnhancements.projectExportForWeek !== 'function') {
                return {active:false,achievement:[],evaluation:[]};
            }
            return PIAEnhancements.projectExportForWeek(semana);
        }

        function obtenerReferenciasSemanaParaPDF(semana) {
            if (typeof PIAEnhancements === 'undefined' || typeof PIAEnhancements.referenceExportForWeek !== 'function') return [];
            return PIAEnhancements.referenceExportForWeek(semana);
        }

        function formatearContenidoConProyecto(textoBase, tipoContenido, tituloProyecto, itemsProyecto) {
            const items=Array.isArray(itemsProyecto)?itemsProyecto:[],baseLimpia=limpiarContenidoParaPDF(textoBase),tieneBase=baseLimpia!=='No especificado'&&baseLimpia.trim()!=='';
            if(!items.length)return formatearContenidoConAjuste(textoBase,tipoContenido);
            const textoProyecto=items.map(item=>item.text).join(' '),textoLongitud=`${tieneBase?baseLimpia:''} ${textoProyecto}`.trim();
            const bloque=`<div style="margin-top:2mm;padding:2mm;border-left:2pt solid #10A8AD;background:#F2FFFF;"><strong>${escaparTextoProyectoPDF(tituloProyecto)}</strong>${items.map(item=>`<div style="margin-top:1mm;line-height:1.35;">${escaparTextoProyectoPDF(item.text)}</div>`).join('')}</div>`;
            const base=tieneBase?formatearContenidoConAjuste(textoBase,tipoContenido):{html:'',fontSize:'9.5pt',minHeight:'25mm'};
            return {html:base.html+bloque,fontSize:ajustarFuenteSegunLongitud(textoLongitud),minHeight:ajustarAlturaMinima(textoLongitud)};
        }
        // PIA_EXPORT_ENHANCEMENT_PDF_PROJECT_HELPERS_END
        
        // ===== GENERAR HTML PERFECTO PARA PDF =====
        let contenidoHTML = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>${nombreArchivo}</title>
    <style>
        /* ESTILOS DEFINITIVOS - PARA IMPRESIÓN */   
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            font-size: 10pt;
            line-height: 1.3;
            color: #000000;
            margin: 0;
            padding: 15mm;
        }
        
        .pagina {
            width: 297mm;
            height: 210mm;
            padding: 10mm;
        }
        
        /* ENCABEZADOS */
        .encabezado-institucional {
            text-align: center;
            margin-bottom: 8mm;
            padding-bottom: 4mm;
            border-bottom: 1pt solid #45258F;
        }
        
        .titulo-ministerio {
            font-size: 12pt;
            font-weight: bold;
            color: #45258F;
            margin-bottom: 2mm;
        }
        
        .titulo-gobierno {
            font-size: 11pt;
            font-weight: 600;
            color: #6c47c9;
        }
        
        .titulo-principal {
            text-align: center;
            font-size: 14pt;
            font-weight: bold;
            color: white;
            background-color: #45258F;
            padding: 4mm;
            margin: 6mm 0 4mm 0;
            border-radius: 2mm;
        }
        
        .subtitulo {
            text-align: center;
            font-size: 11pt;
            color: #6c47c9;
            margin-bottom: 8mm;
        }
        
        /* SECCIONES */
        .seccion {
            margin-bottom: 6mm;
            page-break-inside: avoid;
        }
        
        .titulo-seccion {
            background-color: #45258F;
            color: white;
            font-weight: bold;
            text-align: center;
            padding: 3mm;
            margin: 4mm 0 3mm 0;
            border-radius: 2mm;
            font-size: 11pt;
            page-break-after: avoid;
        }
        
        /* TABLAS PERFECTAS */
        .tabla {
            width: 100%;
            border-collapse: collapse;
            margin: 3mm 0;
            page-break-inside: avoid;
        }
        
        .tabla th {
            background-color: #45258F;
            color: white;
            font-weight: bold;
            text-align: center;
            padding: 2mm;
            border: 0.5pt solid black;
            font-size: 10pt;
        }
        
        .tabla td {
            border: 0.5pt solid #cccccc;
            padding: 2mm;
            vertical-align: top;
            font-size: 10pt;
            line-height: 1.3;
        }
        
        /* CONTENIDO */
        .contenido-celda {
            font-size: 10pt;
            line-height: 1.3;
            text-align: left;
        }
        
        .contenido-celda div {
            margin-bottom: 1mm;
        }
        
        /* SEMANAS */
        .encabezado-semana {
            background-color: #45258F;
            color: white;
            font-weight: bold;
            text-align: center;
            padding: 2mm;
            font-size: 11pt;
        }
        
        /* TRANSICIÓN SIN ESPACIOS */
        .linea-transicion {
            border-top: 0.5pt solid #6c47c9;
            margin: 3mm 0 2mm 0;
            height: 0;
        }
        
        .texto-transicion {
            text-align: center;
            color: #6c47c9;
            font-size: 10pt;
            font-style: italic;
            margin: 1mm 0 3mm 0;
        }
        
        /* ELEMENTOS DE DISEÑO */
        .tarjeta {
            background: white;
            border: 0.5pt solid #dddddd;
            border-radius: 2mm;
            padding: 3mm;
            margin-bottom: 3mm;
        }
        
        .tarjeta-titulo {
            font-weight: bold;
            color: #45258F;
            margin-bottom: 2mm;
            font-size: 10.5pt;
        }
        
        .tarjeta-contenido {
            font-size: 10pt;
            line-height: 1.3;
        }
        
        /* CONTROL DE IMPRESIÓN MEJORADO */
        @media print {
            @page {
                size: A4 landscape;
                margin: 15mm;
            }
            
            body {
                margin: 0 !important;
                padding: 15mm !important;
                orphans: 3;
                widows: 3;
            }
            
            .pagina {
                page-break-after: always;
            }
            
            .no-imprimir {
                display: none !important;
            }
            
            .titulo-seccion, .encabezado-semana-mejorado, .tabla th {
                background-color: #45258F !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
                page-break-after: avoid;
            }
            
            /* MEJOR CONTROL DE DIVISIÓN DE CONTENIDO */
            .contenido-adaptable {
                page-break-inside: auto !important;
                break-inside: auto !important;
            }
            
            /* Evitar que los encabezados queden solos */
            .encabezado-contenido {
                page-break-after: avoid;
            }
            
            /* Mejor legibilidad para texto pequeño */
            .texto-ajustado {
                -webkit-font-smoothing: antialiased;
                text-rendering: optimizeLegibility;
            }
        }
        
        /* UTILIDADES */
        .columna-33 {
            width: 33.33%;
        }
        
        .texto-centrado {
            text-align: center;
        }
        
        .texto-izquierda {
            text-align: left;
        }
        
        .margen-abajo {
            margin-bottom: 3mm;
        }
        
        /* GRID SIMPLE */
        .grid-3 {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 3mm;
            margin: 3mm 0;
        }
        
        /* NUEVOS ESTILOS PARA DISEÑO MEJORADO */
        .grid-2-columnas {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 6mm;
            margin: 4mm 0;
            align-items: stretch;
        }
        
        .columna-areas {
            border: 0.75pt solid #45258F;
            border-radius: 3mm;
            padding: 4mm;
            background: #f8f9fa;
        }
        
        .columna-rda {
            border: 0.75pt solid #6c47c9;
            border-radius: 3mm;
            padding: 4mm;
            background: #f0ebf9;
        }
        
        .titulo-columna {
            font-weight: bold;
            text-align: center;
            margin-bottom: 4mm;
            padding-bottom: 2mm;
            border-bottom: 1pt solid;
            font-size: 11pt;
        }
        
        .item-area {
            padding: 3mm;
            background: white;
            border-radius: 2mm;
            border-left: 3pt solid #45258F;
            font-weight: 500;
            font-size: 10pt;
            margin-bottom: 2mm;
            box-shadow: 0 1pt 3pt rgba(0,0,0,0.1);
        }
        
        .item-rda {
            padding: 3mm;
            background: white;
            border-radius: 2mm;
            border-left: 3pt solid #6c47c9;
            margin-bottom: 3mm;
            box-shadow: 0 1pt 3pt rgba(0,0,0,0.1);
        }
        
        .ejes-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 4mm;
            margin: 3mm 0;
        }
        
        .eje-item {
            border: 0.75pt solid #cccccc;
            border-radius: 3mm;
            padding: 4mm;
            text-align: center;
            background: white;
            transition: all 0.3s;
        }
        
        .eje-seleccionado {
            border: 1.5pt solid #45258F;
            background: #f0ebf9;
        }
        
        .eje-titulo {
            font-weight: bold;
            font-size: 11pt;
            margin-bottom: 2mm;
        }
        
        .eje-descripcion {
            font-size: 10pt;
            color: #666;
            margin-bottom: 3mm;
            line-height: 1.3;
        }
        
        .eje-marca {
            font-weight: bold;
            font-size: 12pt;
            border-radius: 2mm;
            padding: 2mm;
            display: inline-block;
            min-width: 25mm;
        }
        
        .marca-seleccionada {
            color: #28a745;
            border: 1.5pt solid #28a745;
        }
        
        .marca-no-seleccionada {
            color: #666;
            border: 1pt solid #666;
        }
        
        /* ESTILOS PARA CONTENIDO ADAPTABLE */
        .contenido-adaptable {
            page-break-inside: auto;
            break-inside: auto;
        }
        
        .encabezado-semana-mejorado {
            background: linear-gradient(135deg, #45258F, #6c47c9);
            color: white;
            font-weight: bold;
            padding: 2mm 3mm;
            font-size: 10.5pt;
            border-radius: 1.5mm 1.5mm 0 0;
            page-break-after: avoid;
            box-shadow: 0 1pt 2pt rgba(0,0,0,0.1);
        }
        
        .encabezado-contenido {
            font-weight: bold;
            color: #45258F;
            font-size: 9.5pt;
            margin-bottom: 1.5mm;
            padding-bottom: 1mm;
            border-bottom: 0.5pt solid #f0f0f0;
            page-break-after: avoid;
        }
        
        .texto-ajustado {
            text-align: justify;
            hyphens: auto;
            word-wrap: break-word;
            line-height: 1.35;
        }
    </style>
</head>
<body>
    <div class="pagina">
`;
        
        // ENCABEZADO INSTITUCIONAL
        if (incluirEncabezado) {
            contenidoHTML += `
        <div class="encabezado-institucional">
            <div class="titulo-ministerio">MINISTERIO DE EDUCACIÓN PÚBLICA</div>
            <div class="titulo-gobierno">Gobierno de Costa Rica</div>
        </div>
`;
        }

        // TÍTULO PRINCIPAL
        contenidoHTML += `
        <div class="titulo-principal">PLANTILLA DE PLANEAMIENTO DIDÁCTICO</div>
        <div class="subtitulo">
            PROGRAMA NACIONAL DE FORMACIÓN TECNOLÓGICA<br>
            <span style="font-size: 10pt;">Informática educativa</span>
        </div>
`;

        // PIA_EXPORT_ENHANCEMENT_PDF_IDENTITY_START
        if (typeof PIAEnhancements !== 'undefined') {
            contenidoHTML += PIAEnhancements.institutionalExportHtml();
        }
        // PIA_EXPORT_ENHANCEMENT_PDF_IDENTITY_END
        
        // INFORMACIÓN GENERAL
        if (exportarInformacionGeneral) {
            contenidoHTML += `
        <div class="seccion">
            <div class="titulo-seccion">INFORMACIÓN GENERAL</div>
            <table class="tabla">
                <tr>
                    <td style="width: 25%;"><strong>Dirección Regional:</strong><br>${document.getElementById('direccionRegional').value || ''}</td>
                    <td style="width: 25%;"><strong>Centro educativo:</strong><br>${document.getElementById('centroEducativo').value || ''}</td>
                    <td style="width: 25%;"><strong>Código:</strong><br>${document.getElementById('codigoCentro').value || ''}</td>
                    <td style="width: 25%;"><strong>Circuito:</strong><br>${document.getElementById('circuito').value || ''}</td>
                </tr>
                <tr>
                    <td><strong>Docente:</strong><br>${document.getElementById('nombreDocente').value || ''}</td>
                    <td><strong>Asignatura:</strong><br>Formación tecnológica/Informática educativa</td>
                    <td><strong>Ciclo/Nivel:</strong><br>${document.getElementById('ciclo').value || ''} / ${document.getElementById('nivel').value || ''}</td>
                    <td><strong>Lecciones:</strong><br>${document.getElementById('leccionesPlanificadas').value || ''}</td>
                </tr>
            </table>
        </div>
`;
        }
        
        // EJES TRANSVERSALES - CORREGIDO Y COMPLETO
        if (exportarInformacionGeneral) {
            const ejesSeleccionados = Array.from(document.querySelectorAll('input[name="eje"]:checked')).map(cb => cb.value);
            
            contenidoHTML += `
        <div class="seccion">
            <div class="titulo-seccion">EJES TRANSVERSALES DEL PNFT SEGÚN COMPETENCIA MEP</div>
            
            <div style="text-align: center; font-size: 10pt; color: #666; margin-bottom: 4mm; font-style: italic;">
                Marque con una equis (x) el eje a desarrollar
            </div>
            
            <div class="ejes-grid">
                <!-- CIUDADANÍA -->
                <div class="eje-item ${ejesSeleccionados.includes('ciudadania') ? 'eje-seleccionado' : ''}">
                    <div class="eje-titulo" style="color: ${ejesSeleccionados.includes('ciudadania') ? '#45258F' : '#333'}">
                        Ciudadanía y ética digital
                    </div>
                    
                    <div class="eje-descripcion">
                        Competencias para la ciudadanía responsable y solidaria
                    </div>
                    
                    <div class="eje-marca ${ejesSeleccionados.includes('ciudadania') ? 'marca-seleccionada' : 'marca-no-seleccionada'}">
                        ${ejesSeleccionados.includes('ciudadania') ? '[X] SELECCIONADO' : '[   ]'}
                    </div>
                </div>
                
                <!-- PENSAMIENTO COMPUTACIONAL -->
                <div class="eje-item ${ejesSeleccionados.includes('pensamiento') ? 'eje-seleccionado' : ''}">
                    <div class="eje-titulo" style="color: ${ejesSeleccionados.includes('pensamiento') ? '#45258F' : '#333'}">
                        Pensamiento computacional
                    </div>
                    
                    <div class="eje-descripcion">
                        Competencias para la vida y resolución de problemas
                    </div>
                    
                    <div class="eje-marca ${ejesSeleccionados.includes('pensamiento') ? 'marca-seleccionada' : 'marca-no-seleccionada'}">
                        ${ejesSeleccionados.includes('pensamiento') ? '[X] SELECCIONADO' : '[   ]'}
                    </div>
                </div>
                
                <!-- EMPRENDIMIENTO -->
                <div class="eje-item ${ejesSeleccionados.includes('emprendimiento') ? 'eje-seleccionado' : ''}">
                    <div class="eje-titulo" style="color: ${ejesSeleccionados.includes('emprendimiento') ? '#45258F' : '#333'}">
                        Emprendimiento e Innovación
                    </div>
                    
                    <div class="eje-descripcion">
                        Competencias para el empleo digno
                    </div>
                    
                    <div class="eje-marca ${ejesSeleccionados.includes('emprendimiento') ? 'marca-seleccionada' : 'marca-no-seleccionada'}">
                        ${ejesSeleccionados.includes('emprendimiento') ? '[X] SELECCIONADO' : '[   ]'}
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; font-size: 9pt; color: #999; margin-top: 3mm; font-style: italic;">
                Nota: Se marca con X el eje transversal seleccionado para desarrollar según competencia MEP
            </div>
        </div>
    `;
        }

        // METODOLOGÍA ACTIVA - NUEVA SECCIÓN PARA INCLUIR EN PDF
        if (exportarInformacionGeneral) {
            let metodologia = document.getElementById('metodologiaActiva').value;
            if (metodologia === 'otra') {
                metodologia = document.getElementById('metodologiaPersonalizada').value || 'Metodología personalizada';
            }
            
            if (metodologia) {
                let metodologiaTexto = '';
                if (metodologia === 'ABJ') metodologiaTexto = 'Aprendizaje basado en juegos (ABJ)';
                else if (metodologia === 'ABR') metodologiaTexto = 'Aprendizaje basado en retos (ABR)';
                else if (metodologia === 'APD') metodologiaTexto = 'Aprendizaje Pensamiento por Diseño (APD)';
                else metodologiaTexto = metodologia;
                
                contenidoHTML += `
            <div class="seccion">
                <div class="titulo-seccion" style="background: linear-gradient(135deg, #6c47c9, #45258F);">
                    METODOLOGÍA ACTIVA SELECCIONADA
                </div>
                
                <div class="tarjeta" style="background: #f8f9fa; border-color: #6c47c9;">
                    <div style="text-align: center; font-weight: bold; color: #45258F; font-size: 11pt; margin-bottom: 3mm;">
                        ${metodologiaTexto}
                    </div>
                    
                    <div style="margin-top: 3mm; padding-top: 2mm; border-top: 0.5pt dashed #ddd; font-size: 9pt; color: #666; text-align: center;">
                        <strong>Nota:</strong> Las estrategias de mediación deben adaptarse a esta metodología seleccionada.
                    </div>
                </div>
            </div>
            `;
            }
        }
        
        // ÁREAS DE CONOCIMIENTO Y RDA EN DOS COLUMNAS - VERSIÓN MEJORADA
        if (exportarSaberes && areasUnicas.size > 0) {
            const ciclo = document.getElementById('ciclo').value;
            
            contenidoHTML += `
        <div class="seccion">
            <div class="titulo-seccion">ÁREAS DE CONOCIMIENTO Y RESULTADOS DE APRENDIZAJE (RDA)</div>
            
            <!-- CONTENEDOR DE DOS COLUMNAS PARALELAS -->
            <div class="grid-2-columnas">
                
                <!-- COLUMNA IZQUIERDA: ÁREAS DE CONOCIMIENTO -->
                <div class="columna-areas">
                    <div class="titulo-columna" style="color: #45258F; border-bottom-color: #45258F;">
                        ÁREAS DE CONOCIMIENTO
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 2mm;">
            `;
            
            // Lista completa de áreas (para mostrar todas con su estado)
            const todasLasAreas = [
                "Apropiación tecnológica y Digital",
                "Programación y Algoritmos", 
                "Computación física y Robótica",
                "Ciencia de datos e Inteligencia artificial"
            ];
            
            todasLasAreas.forEach(area => {
                const estaSeleccionada = areasUnicas.has(area);
                
                contenidoHTML += `
                        <div class="item-area" style="border-left-color: ${estaSeleccionada ? '#45258F' : '#cccccc'}; background: ${estaSeleccionada ? '#f0ebf9' : 'white'}">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-weight: ${estaSeleccionada ? 'bold' : 'normal'}; color: ${estaSeleccionada ? '#45258F' : '#333'}">
                                    ${area}
                                </span>
                                <span style="font-weight: bold; font-size: 11pt; color: ${estaSeleccionada ? '#28a745' : '#ccc'}">
                                    ${estaSeleccionada ? '[✓]' : '[  ]'}
                                </span>
                            </div>
                        </div>
                `;
            });
            
            contenidoHTML += `
                    </div>
                </div>
                
                <!-- COLUMNA DERECHA: RESULTADOS DE APRENDIZAJE (RDA) -->
                <div class="columna-rda">
                    <div class="titulo-columna" style="color: #6c47c9; border-bottom-color: #6c47c9;">
                        RESULTADOS DE APRENDIZAJE (RDA)
                    </div>
                    
                    <div style="display: flex; flex-direction: column; gap: 3mm;">
            `;
            
            // Mostrar RdA solo para áreas seleccionadas
            if (areasUnicas.size > 0) {
                areasUnicas.forEach(area => {
                    const rda = RDA_POR_CICLO[ciclo] && RDA_POR_CICLO[ciclo][area] 
                        ? RDA_POR_CICLO[ciclo][area] 
                        : 'No definido para este ciclo/nivel';
                    
                    contenidoHTML += `
                        <div class="item-rda">
                            <div style="font-weight: 600; color: #333; margin-bottom: 1.5mm; font-size: 10pt;">
                                ${area}:
                            </div>
                            <div style="font-size: 9.5pt; line-height: 1.4; color: #555;">
                                ${rda}
                            </div>
                        </div>
                    `;
                });
            } else {
                contenidoHTML += `
                    <div style="padding: 4mm; text-align: center; color: #999; font-style: italic; font-size: 10pt;">
                        Seleccione áreas de conocimiento para ver los Resultados de Aprendizaje
                    </div>
                `;
            }
            
            contenidoHTML += `
                    </div>
                </div>
            </div> <!-- Fin del grid de 2 columnas -->
            
            <div style="text-align: center; font-size: 9pt; color: #666; margin-top: 3mm; font-style: italic;">
                Nota: Cada Área de Conocimiento tiene su correspondiente Resultado de Aprendizaje (RdA) según el ciclo seleccionado
            </div>
        </div>
    `;
        }
        
        // SABERES GLOBALES - CORREGIDO
        if (exportarSaberesGlobales) {
            contenidoHTML += `
        <div class="seccion">
            <div class="titulo-seccion">SABERES GLOBALES</div>
            
            <div class="grid-3">
                <!-- CONCEPTUALES -->
                <div class="tarjeta">
                    <div class="tarjeta-titulo">Saberes Conceptuales (Saber)</div>
                    <div class="tarjeta-contenido">
            `;
            
            if (saberesSeleccionados.size > 0) {
                contenidoHTML += Array.from(saberesSeleccionados).map(saber => 
                    `<div style="margin-bottom: 1mm; padding-left: 2mm; border-left: 2pt solid #45258F;">• ${saber}</div>`
                ).join('');
            } else {
                contenidoHTML += '<div style="color: #999; font-style: italic;">No se han seleccionado saberes conceptuales</div>';
            }
            
            contenidoHTML += `
                    </div>
                </div>
                
                <!-- PROCEDIMENTALES -->
                <div class="tarjeta">
                    <div class="tarjeta-titulo">Saberes Procedimentales (Saber Hacer)</div>
                    <div class="tarjeta-contenido">
            `;
            
            if (saberesProcedimentalesGlobales.size > 0) {
                const procMap = {
                    'reconoce': 'Reconoce patrones',
                    'abstrae': 'Abstrae',
                    'generaliza': 'Generaliza',
                    'transfiere': 'Transfiere',
                    'modulariza': 'Modulariza',
                    'formula': 'Formula algoritmos',
                    'remezcla': 'Remezcla',
                    'depura': 'Depura',
                    'programa': 'Programa',
                    'comunica': 'Comunica',
                    'colabora': 'Colabora',
                    'piensa': 'Piensa creativamente',
                    'maneja': 'Maneja tecnologías éticamente'
                };
                
                contenidoHTML += Array.from(saberesProcedimentalesGlobales).map(proc => 
                    `<div style="margin-bottom: 1mm; padding-left: 2mm; border-left: 2pt solid #6c47c9;">• ${procMap[proc] || proc}</div>`
                ).join('');
            } else {
                contenidoHTML += '<div style="color: #999; font-style: italic;">No se han seleccionado saberes procedimentales</div>';
            }
            
            contenidoHTML += `
                    </div>
                </div>
                
                <!-- ACTITUDINALES -->
                <div class="tarjeta">
                    <div class="tarjeta-titulo">Saberes Actitudinales (Saber Ser)</div>
                    <div class="tarjeta-contenido">
            `;
            
            if (saberesActitudinalesGlobales.size > 0) {
                const actMap = {
                    'gusto': 'Gusto por la precisión',
                    'aprender': 'Aprender del error',
                    'flexibilidad': 'Flexibilidad',
                    'tolerancia': 'Tolerancia a la frustración'
                };
                
                contenidoHTML += Array.from(saberesActitudinalesGlobales).map(act => 
                    `<div style="margin-bottom: 1mm; padding-left: 2mm; border-left: 2pt solid #28a745;">• ${actMap[act] || act}</div>`
                ).join('');
            } else {
                contenidoHTML += '<div style="color: #999; font-style: italic;">No se han seleccionado saberes actitudinales</div>';
            }
            
            contenidoHTML += `
                    </div>
                </div>
            </div> <!-- Fin del grid-3 -->
        </div>
    `;
        }
        
        // TRANSICIÓN
        contenidoHTML += `
        <div class="linea-transicion"></div>
        <div class="texto-transicion">Continuación: Aplicación de saberes en la planificación semanal</div>
`;
        
        // ✅ PLANIFICACIÓN POR SEMANAS - VERSIÓN MEJORADA CON AJUSTE AUTOMÁTICO
        if (exportarSemanas && semanas.length > 0) {
            contenidoHTML += `
        <div class="seccion" style="page-break-inside: avoid;">
            <div class="titulo-seccion" style="page-break-after: avoid;">PLANIFICACIÓN POR SEMANAS</div>
    `;
            
            semanas.forEach((semana, index) => {
                // ✅ Obtener contenido formateado con ajuste automático
                const proyecto=obtenerProyectoSemanaParaPDF(semana);
                const referencias=obtenerReferenciasSemanaParaPDF(semana);
                const contenidoConReferencias = formatearContenidoConProyecto(semana.indicadores, 'indicadores', 'Indicadores de referencia del currículo del PNFT', referencias);
                const contenidoIndicadores = formatearContenidoConProyecto(contenidoConReferencias.html, 'indicadores', 'Indicador de logro del Proyecto', proyecto.achievement);
                const contenidoEstrategias = formatearContenidoConAjuste(semana.actividades, 'estrategias');
                const contenidoEvaluacion = formatearContenidoConProyecto(semana.evaluacion, 'evaluacion', 'Indicadores de evaluación del Proyecto', proyecto.evaluation);
                
                contenidoHTML += `
            <!-- SEMANA ${index + 1} - CON AJUSTE DINÁMICO -->
            <div class="contenido-adaptable" style="margin-bottom: ${index < semanas.length - 1 ? '6mm' : '0'};">
            
                <!-- TÍTULO DE SEMANA - NO SE SEPARA DEL CONTENIDO -->
                <div class="encabezado-semana-mejorado" style="page-break-after: avoid;">
                    <span style="font-size: 11pt;">📅</span> ${semana.nombre} - ${semana.lecciones}
                </div>
                
                <!-- CONTENIDO: Se divide inteligentemente si es necesario -->
                <div style="
                    display: flex;
                    border: 0.5pt solid #ddd;
                    border-top: none;
                    border-radius: 0 0 1.5mm 1.5mm;
                    overflow: hidden;
                    min-height: ${Math.max(
                        contenidoIndicadores.minHeight,
                        contenidoEstrategias.minHeight,
                        contenidoEvaluacion.minHeight
                    )};
                ">
                
                    <!-- COLUMNA 1: INDICADORES DE LOGRO -->
                    <div style="
                        flex: 1;
                        border-right: 0.5pt solid #eee;
                        padding: 2.5mm;
                        display: flex;
                        flex-direction: column;
                    ">
                        <div class="encabezado-contenido">
                            Indicadores de logro
                        </div>
                        <div style="
                            flex-grow: 1;
                            overflow: hidden;
                        " class="texto-ajustado">
                            ${contenidoIndicadores.html}
                        </div>
                        <div style="
                            font-size: 7pt;
                            color: #999;
                            text-align: right;
                            margin-top: 1mm;
                            font-style: italic;
                        ">
                            Tamaño: ${contenidoIndicadores.fontSize}
                        </div>
                    </div>
                    
                    <!-- COLUMNA 2: ESTRATEGIAS DE MEDIACIÓN -->
                    <div style="
                        flex: 1;
                        border-right: 0.5pt solid #eee;
                        padding: 2.5mm;
                        display: flex;
                        flex-direction: column;
                    ">
                        <div class="encabezado-contenido">
                            Estrategias de Mediación
                        </div>
                        <div style="
                            flex-grow: 1;
                            overflow: hidden;
                        " class="texto-ajustado">
                            ${contenidoEstrategias.html}
                        </div>
                        <div style="
                            font-size: 7pt;
                            color: #999;
                            text-align: right;
                            margin-top: 1mm;
                            font-style: italic;
                        ">
                            Tamaño: ${contenidoEstrategias.fontSize}
                        </div>
                    </div>
                    
                    <!-- COLUMNA 3: INDICADORES DE EVALUACIÓN -->
                    <div style="
                        flex: 1;
                        padding: 2.5mm;
                        display: flex;
                        flex-direction: column;
                    ">
                        <div class="encabezado-contenido">
                            Indicadores de evaluación
                        </div>
                        <div style="
                            flex-grow: 1;
                            overflow: hidden;
                        " class="texto-ajustado">
                            ${contenidoEvaluacion.html}
                        </div>
                        <div style="
                            font-size: 7pt;
                            color: #999;
                            text-align: right;
                            margin-top: 1mm;
                            font-style: italic;
                        ">
                            Tamaño: ${contenidoEvaluacion.fontSize}
                        </div>
                    </div>
                    
                </div>
                
            </div>
            
            <!-- LÍNEA DIVISORIA (solo entre semanas) -->
            ${index < semanas.length - 1 ? `
                <div style="
                    height: 0.5pt;
                    background: linear-gradient(to right, transparent, #6c47c9, transparent);
                    margin: 3mm 0;
                "></div>
            ` : ''}
        `;
            });
            
            contenidoHTML += `
        </div>
    `;
        }
        
        // REFLEXIONES
        if (exportarReflexiones) {
            contenidoHTML += `
        <div class="seccion">
            <div class="titulo-seccion">REFLEXIONES DOCENTES</div>
            <div class="grid-3">
                <div class="tarjeta">
                    <div class="tarjeta-titulo" style="color: #28a745;">¿Qué funcionó?</div>
                    <div class="tarjeta-contenido">
                        ${formatearContenidoComoHTML(document.getElementById('queFunciono').value)}
                    </div>
                </div>
                
                <div class="tarjeta">
                    <div class="tarjeta-titulo" style="color: #ff6b6b;">¿Qué no funcionó?</div>
                    <div class="tarjeta-contenido">
                        ${formatearContenidoComoHTML(document.getElementById('queNoFunciono').value)}
                    </div>
                </div>
                
                <div class="tarjeta">
                    <div class="tarjeta-titulo" style="color: #ff9800;">¿Qué puedo mejorar?</div>
                    <div class="tarjeta-contenido">
                        ${formatearContenidoComoHTML(document.getElementById('queMejorar').value)}
                    </div>
                </div>
            </div>
        </div>
        
        <div class="seccion">
            <div class="titulo-seccion">OBSERVACIONES Y/O RECOMENDACIONES DIDÁCTICAS POR NIVEL</div>
            <div class="tarjeta">
                <div class="tarjeta-contenido">
                    ${formatearContenidoComoHTML(document.getElementById('observaciones').value)}
                </div>
            </div>
        </div>
`;
        }
        
        // NOTA IA
        contenidoHTML += `
        <div class="tarjeta" style="background-color: #e8f4fd; border-color: #bbdefb;">
            <div class="tarjeta-titulo" style="color: #0d47a1;">Nota importante sobre el uso de IA</div>
            <div class="tarjeta-contenido">
                Lo que brinda la IA debe ser contextualizado por el educador, quien decide, observa y ejecuta según su criterio y conocimiento del grupo. 
                La IA proporciona estrategias de mediación que deben ser definidas, reagrupadas y reestructuradas por el educador considerando el orden, 
                estructura y forma de implementación más adecuada.
            </div>
        
            <div class="tarjeta" style="background-color: #FFFFFFFF; border-color: #FFFFFFFF;">
            <div class="tarjeta-titulo" style="color: #0d47a1;">Nota de Licencia y de uso:</div>
            <div class="tarjeta-contenido">
            <p style="font-size: 12px; color: #555; text-align: justify; font-style: italic;">
            <strong>📄</strong> Este recurso de planificación didáctica fue elaborado utilizando la <strong>Plantilla de Planeamiento Didáctico del PNFT del Departamento de Investigación, Desarrollo e Implementación-MEP.</strong> <br><br>

            <strong>📄</strong>Este recurso y sus derivados se ofrecen bajo una <strong>Licencia de Uso Educativo</strong> que permite su uso, adaptación y distribución no comercial dentro del sistema educativo nacional, con la obligación de atribución al autor original. Queda <strong>prohibida su venta</strong> o inclusión en materiales comerciales.<br><br>
            </div>
        </div>
`;

        // PIE DE PÁGINA
        if (incluirPiePagina) {
            contenidoHTML += `
        <div class="texto-centrado" style="margin-top: 8mm; padding-top: 4mm; border-top: 1pt solid #45258F;">
            <div style="font-weight: bold; color: #45258F; margin-bottom: 2mm; font-size: 11pt;">
                DIDI - Departamento de Investigación, Desarrollo e Implementación
            </div>
            <div style="color: #6c47c9; margin-bottom: 2mm; font-size: 10pt;">
                Dirección de Recursos Tecnológicos en Educación
            </div>
            <div style="color: #888; font-size: 9pt;">
                Ministerio de Educación Pública - Gobierno de Costa Rica
            </div>
        </div>
`;
        }
        
        contenidoHTML += `
    </div>
</body>
</html>`;
        
        // ===== MÉTODO DEFINITIVO PARA GENERAR PDF =====
        try {
            // Crear ventana para vista previa
            const ventanaPreview = window.open('', '_blank');
            if (!ventanaPreview) {
                const blob = new Blob([contenidoHTML], {type: 'text/html'});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `${nombreArchivo}.html`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                alert('Se ha descargado un archivo HTML. Ábrelo en tu navegador y usa Ctrl+P para imprimir.');
                return;
            }
            
            ventanaPreview.document.write(contenidoHTML);
            ventanaPreview.document.close();
            
            setTimeout(() => {
                ventanaPreview.focus();
                
                // Instrucciones optimizadas
                ventanaPreview.document.body.innerHTML += `
                    <div class="no-imprimir" style="
                        position: fixed; 
                        top: 10px; 
                        right: 10px; 
                        background: #45258F; 
                        color: white; 
                        padding: 10px; 
                        border-radius: 5px; 
                        z-index: 10000;
                        font-size: 10pt;
                        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
                        max-width: 300px;
                    ">
                        <strong>📋 Instrucciones para imprimir:</strong><br>
                        1. Presione <strong>Ctrl+P</strong><br>
                        2. Seleccione <strong>"Guardar como PDF"</strong><br>
                        3. Ajuste márgenes a <strong>15mm</strong><br>
                        4. Active <strong>"Fondo gráfico"</strong><br>
                        5. Guarde el archivo
                    </div>
                `;
                
                const printButton = ventanaPreview.document.createElement('button');
                printButton.innerHTML = '🖨️ Imprimir Ahora';
                printButton.classList.add("no-imprimir");
                printButton.style.cssText = `
                    position: fixed;
                    bottom: 20px;
                    right: 10px;
                    background: #28a745;
                    color: white;
                    border: none;
                    padding: 10px 15px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-weight: bold;
                    z-index: 10000;
                    font-size: 11pt;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                `;
                printButton.onclick = () => ventanaPreview.print();
                ventanaPreview.document.body.appendChild(printButton);
                
            }, 1000);
            
        } catch (error) {
            console.error('Error al generar PDF:', error);
            
            const blob = new Blob([contenidoHTML], {type: 'text/html'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${nombreArchivo}_para_imprimir.html`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            alert('Se ha descargado un archivo HTML listo para imprimir. Ábrelo y usa Ctrl+P.');
        }
        
        cerrarExportModal();
        
    } catch (error) {
        console.error('Error general:', error);
        alert('Error: ' + error.message + '\n\nSe ha descargado un archivo HTML de respaldo.');
        
        const blob = new Blob(['<html><body><h1>Documento de respaldo</h1></body></html>'], {type: 'text/html'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${nombreArchivo}_respaldo.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
}

        // ✅ FUNCIÓN DEPURADA PARA PROMPT IA GENERAL
