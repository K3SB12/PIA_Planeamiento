        // ===== FUNCIÓN PARA VERSIÓN PORTABLE/OFFLINE =====
        function descargarVersionPortable() {
            try {
                // 1. Obtener el HTML completo
                const htmlCompleto = document.documentElement.outerHTML;
                
                // 2. Crear versión portable con CSS y JS incluidos
                const fecha = new Date().toLocaleDateString('es-CR');
                const nombreArchivo = `Planeamiento-Didáctico-Offline-${fecha.replace(/\//g, '-')}.html`;
                
                // 3. Crear y descargar el archivo
                const blob = new Blob([htmlCompleto], {type: 'text/html;charset=utf-8'});
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = nombreArchivo;
                
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
                
                // 4. Mostrar retroalimentación
                mostrarMensaje('✅ Versión offline descargada (funciona sin internet)');
                
            } catch (error) {
                console.error('Error al crear versión portable:', error);
                mostrarMensaje('❌ Error al crear versión offline', true);
            }
        }

