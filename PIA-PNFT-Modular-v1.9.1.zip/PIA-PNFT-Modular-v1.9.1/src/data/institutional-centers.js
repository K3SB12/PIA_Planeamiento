// PIA_INSTITUTIONAL_CENTERS_JS_START
// Generado por scripts/import-centers.mjs desde Asesores-Centros-sin-0000.xlsx.
// Datos públicos mínimos: no incluye personas asesoras, correos ni teléfonos.
const PIAInstitutionalCenters = Object.freeze([
  {
    "centro": "J.N. ANDRÉS BELLO LÓPEZ",
    "codPres": "0304",
    "codSaber": "100516-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "0306",
    "codSaber": "100517-00"
  },
  {
    "centro": "DAVID MARÍN HIDALGO",
    "codPres": "0307",
    "codSaber": "100518-00"
  },
  {
    "centro": "BELLO HORIZONTE",
    "codPres": "0308",
    "codSaber": "100519-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "0309",
    "codSaber": "100520-00"
  },
  {
    "centro": "BRASIL DE SANTA ANA",
    "codPres": "0310",
    "codSaber": "100521-00"
  },
  {
    "centro": "CARMEN LYRA",
    "codPres": "0311",
    "codSaber": "100522-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0312",
    "codSaber": "100523-00"
  },
  {
    "centro": "PATIO DE AGUA",
    "codPres": "0313",
    "codSaber": "100524-00"
  },
  {
    "centro": "MONTERREY VARGAS ARAYA",
    "codPres": "0314",
    "codSaber": "100525-00"
  },
  {
    "centro": "BUENAVENTURA CORRALES",
    "codPres": "0315",
    "codSaber": "100526-00"
  },
  {
    "centro": "LA PEREGRINA",
    "codPres": "0318",
    "codSaber": "100527-00"
  },
  {
    "centro": "JESÚS JIMÉNEZ ZAMORA",
    "codPres": "0319",
    "codSaber": "100528-00"
  },
  {
    "centro": "CARLOS SANABRIA MORA",
    "codPres": "0320",
    "codSaber": "100529-00"
  },
  {
    "centro": "CAROLINA DENT ALVARADO",
    "codPres": "0321",
    "codSaber": "100530-00"
  },
  {
    "centro": "PÍO XII",
    "codPres": "0322",
    "codSaber": "100531-00"
  },
  {
    "centro": "BARRIO LÁMPARAS",
    "codPres": "0323",
    "codSaber": "100532-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0324",
    "codSaber": "100533-00"
  },
  {
    "centro": "ESMERALDA OREAMUNO",
    "codPres": "0325",
    "codSaber": "100534-00"
  },
  {
    "centro": "J.N. ESMERALDA OREAMUNO",
    "codPres": "0326",
    "codSaber": "100535-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "0327",
    "codSaber": "100536-00"
  },
  {
    "centro": "CIUDADELA DE PAVAS",
    "codPres": "0328",
    "codSaber": "100537-00"
  },
  {
    "centro": "QUINCE DE SETIEMBRE",
    "codPres": "0329",
    "codSaber": "100538-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "0330",
    "codSaber": "100539-00"
  },
  {
    "centro": "J.N. CONCEPCIÓN",
    "codPres": "0331",
    "codSaber": "100540-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "0332",
    "codSaber": "100541-00"
  },
  {
    "centro": "PLATANARES",
    "codPres": "0333",
    "codSaber": "100542-00"
  },
  {
    "centro": "COSTA RICA",
    "codPres": "0334",
    "codSaber": "100543-00"
  },
  {
    "centro": "JUAN SANTAMARÍA",
    "codPres": "0335",
    "codSaber": "100544-00"
  },
  {
    "centro": "LEÓN XIII",
    "codPres": "0336",
    "codSaber": "100545-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "0337",
    "codSaber": "100546-00"
  },
  {
    "centro": "APOLINAR LOBO UMAÑA",
    "codPres": "0338",
    "codSaber": "100547-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "0339",
    "codSaber": "100548-00"
  },
  {
    "centro": "EL LLANO",
    "codPres": "0340",
    "codSaber": "100549-00"
  },
  {
    "centro": "PABELLÓN",
    "codPres": "0341",
    "codSaber": "100550-00"
  },
  {
    "centro": "LOMAS DEL RÍO",
    "codPres": "0342",
    "codSaber": "100551-00"
  },
  {
    "centro": "REPÚBLICA DE VENEZUELA",
    "codPres": "0343",
    "codSaber": "100552-00"
  },
  {
    "centro": "ESPAÑA",
    "codPres": "0344",
    "codSaber": "100553-00"
  },
  {
    "centro": "DOCTOR FERRAZ",
    "codPres": "0345",
    "codSaber": "100554-00"
  },
  {
    "centro": "CLAUDIO CORTÉS CASTRO",
    "codPres": "0346",
    "codSaber": "100555-00"
  },
  {
    "centro": "MARCELINO GARCIA FLAMENCO",
    "codPres": "0347",
    "codSaber": "100556-00"
  },
  {
    "centro": "LOS SITIOS",
    "codPres": "0348",
    "codSaber": "100557-00"
  },
  {
    "centro": "JOSÉ ÁNGEL VIETO RANGEL",
    "codPres": "0349",
    "codSaber": "100558-00"
  },
  {
    "centro": "GUACHIPELÍN",
    "codPres": "0350",
    "codSaber": "100559-00"
  },
  {
    "centro": "I.E.G.B. AMÉRICA CENTRAL",
    "codPres": "0351",
    "codSaber": "104813-00"
  },
  {
    "centro": "PILAR JIMÉNEZ SOLIS",
    "codPres": "0352",
    "codSaber": "100561-00"
  },
  {
    "centro": "TEJARCILLOS",
    "codPres": "0353",
    "codSaber": "100562-00"
  },
  {
    "centro": "HONDURAS",
    "codPres": "0354",
    "codSaber": "100563-00"
  },
  {
    "centro": "J.N. MIGUEL DE CERVANTES SAAVEDRA",
    "codPres": "0355",
    "codSaber": "100564-00"
  },
  {
    "centro": "CIUDADELAS UNIDAS",
    "codPres": "0356",
    "codSaber": "100565-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "0357",
    "codSaber": "100566-00"
  },
  {
    "centro": "ABRAHAM LINCOLN",
    "codPres": "0358",
    "codSaber": "100567-00"
  },
  {
    "centro": "MONSERRAT",
    "codPres": "0359",
    "codSaber": "100568-00"
  },
  {
    "centro": "LUIS DEMETRIO TINOCO CASTRO",
    "codPres": "0360",
    "codSaber": "100569-00"
  },
  {
    "centro": "I.E.G.B. ANDRÉS BELLO LÓPEZ",
    "codPres": "0361",
    "codSaber": "104812-00"
  },
  {
    "centro": "J.N. MIGUEL OBREGÓN LIZANO",
    "codPres": "0362",
    "codSaber": "100571-00"
  },
  {
    "centro": "REPÚBLICA DE PARAGUAY",
    "codPres": "0363",
    "codSaber": "100572-00"
  },
  {
    "centro": "J.N. REPÚBLICA DE PARAGUAY",
    "codPres": "0364",
    "codSaber": "100573-00"
  },
  {
    "centro": "JUAN FLORES UMAÑA",
    "codPres": "0366",
    "codSaber": "100574-00"
  },
  {
    "centro": "J.N. SARITA MONTEALEGRE",
    "codPres": "0367",
    "codSaber": "100575-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA JOSÉ FIDEL TRISTÁN",
    "codPres": "0368",
    "codSaber": "104033-00"
  },
  {
    "centro": "DR. JOSÉ MARÍA CASTRO MADRIZ",
    "codPres": "0369",
    "codSaber": "100577-00"
  },
  {
    "centro": "JUAN RAFAEL MORA PORRAS",
    "codPres": "0370",
    "codSaber": "100578-00"
  },
  {
    "centro": "J.N. OMAR DENGO GUERRERO",
    "codPres": "0371",
    "codSaber": "100579-00"
  },
  {
    "centro": "J.N. JOSÉ RAFAEL ARAYA ROJAS",
    "codPres": "0372",
    "codSaber": "100580-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA JOSÉ RAFAEL ARAYA ROJAS",
    "codPres": "0373",
    "codSaber": "104040-00"
  },
  {
    "centro": "LA ISLA",
    "codPres": "0374",
    "codSaber": "100582-00"
  },
  {
    "centro": "LA MINA",
    "codPres": "0375",
    "codSaber": "100583-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "0376",
    "codSaber": "100584-00"
  },
  {
    "centro": "ANTONIO JOSÉ DE SUCRE",
    "codPres": "0377",
    "codSaber": "100585-00"
  },
  {
    "centro": "ISABEL LA CATÓLICA",
    "codPres": "0378",
    "codSaber": "100586-00"
  },
  {
    "centro": "PACÍFICA FERNÁNDEZ OREAMUNO",
    "codPres": "0379",
    "codSaber": "100587-00"
  },
  {
    "centro": "ESTADO DE ISRAEL",
    "codPres": "0380",
    "codSaber": "100588-00"
  },
  {
    "centro": "LAS NUBES",
    "codPres": "0381",
    "codSaber": "100589-00"
  },
  {
    "centro": "MONSEÑOR ANSELMO LLORENTE Y LA FUENTE",
    "codPres": "0382",
    "codSaber": "100590-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "0383",
    "codSaber": "100591-00"
  },
  {
    "centro": "J.N. CRISTO REY",
    "codPres": "0384",
    "codSaber": "100592-00"
  },
  {
    "centro": "J.N. DANTE ALIGHIERI",
    "codPres": "0385",
    "codSaber": "100593-00"
  },
  {
    "centro": "DANTE ALIGHIERI",
    "codPres": "0386",
    "codSaber": "100594-00"
  },
  {
    "centro": "MAURO FERNÁNDEZ ACUÑA",
    "codPres": "0387",
    "codSaber": "100595-00"
  },
  {
    "centro": "GENERAL MANUEL BELGRANO GONZÁLEZ",
    "codPres": "0388",
    "codSaber": "100596-00"
  },
  {
    "centro": "JOSÉ CUBERO MUÑOZ",
    "codPres": "0390",
    "codSaber": "100598-00"
  },
  {
    "centro": "JUAN ÁLVAREZ AZOFEIFA",
    "codPres": "0391",
    "codSaber": "100599-00"
  },
  {
    "centro": "J.N. MATERNAL MONTESORIANO",
    "codPres": "0392",
    "codSaber": "100600-00"
  },
  {
    "centro": "CALLE EL ALTO",
    "codPres": "0393",
    "codSaber": "100601-00"
  },
  {
    "centro": "NACIONES UNIDAS",
    "codPres": "0394",
    "codSaber": "100602-00"
  },
  {
    "centro": "LABORATORIO U.C.R.",
    "codPres": "0396",
    "codSaber": "100604-00"
  },
  {
    "centro": "OMAR DENGO GUERRERO",
    "codPres": "0397",
    "codSaber": "100605-00"
  },
  {
    "centro": "RAFAEL FRANCISCO OSEJO",
    "codPres": "0398",
    "codSaber": "100606-00"
  },
  {
    "centro": "J.N. CARLOS SANABRIA MORA",
    "codPres": "0399",
    "codSaber": "100607-00"
  },
  {
    "centro": "EZEQUIEL MORALES AGUÍLAR",
    "codPres": "0400",
    "codSaber": "100608-00"
  },
  {
    "centro": "PORFIRIO BRENES CASTRO",
    "codPres": "0401",
    "codSaber": "100609-00"
  },
  {
    "centro": "J.N. PORFIRIO BRENES CASTRO",
    "codPres": "0402",
    "codSaber": "100610-00"
  },
  {
    "centro": "REPÚBLICA DE FRANCIA",
    "codPres": "0403",
    "codSaber": "100611-00"
  },
  {
    "centro": "LAGOS DE LINDORA",
    "codPres": "0404",
    "codSaber": "100612-00"
  },
  {
    "centro": "BENJAMÍN HERRERA ANGULO",
    "codPres": "0405",
    "codSaber": "100613-00"
  },
  {
    "centro": "I.E.G.B. PBRO. YANUARIO QUESADA",
    "codPres": "0406",
    "codSaber": "104805-00"
  },
  {
    "centro": "JOSÉ FABIO GARNIER UGALDE",
    "codPres": "0408",
    "codSaber": "100615-00"
  },
  {
    "centro": "REPÚBLICA DE ARGENTINA",
    "codPres": "0409",
    "codSaber": "100616-00"
  },
  {
    "centro": "REPÚBLICA DE CHILE",
    "codPres": "0410",
    "codSaber": "100617-00"
  },
  {
    "centro": "REPUBLICA DE NICARAGUA",
    "codPres": "0413",
    "codSaber": "100618-00"
  },
  {
    "centro": "RICARDO JIMÉNEZ OREAMUNO",
    "codPres": "0414",
    "codSaber": "100619-00"
  },
  {
    "centro": "QUINCE DE AGOSTO",
    "codPres": "0415",
    "codSaber": "100620-00"
  },
  {
    "centro": "J.N. REPÚBLICA POPULAR CHINA",
    "codPres": "0417",
    "codSaber": "100622-00"
  },
  {
    "centro": "ROBERTO CANTILLANO VINDAS",
    "codPres": "0418",
    "codSaber": "100623-00"
  },
  {
    "centro": "J.N. ROBERTO CANTILLANO VINDAS",
    "codPres": "0419",
    "codSaber": "100624-00"
  },
  {
    "centro": "J.N. JARDINES DE TIBÁS",
    "codPres": "0420",
    "codSaber": "100625-00"
  },
  {
    "centro": "JOSÉ FIGUERES FERRER",
    "codPres": "0421",
    "codSaber": "100626-00"
  },
  {
    "centro": "JORGE VOLIO JIMÉNEZ",
    "codPres": "0422",
    "codSaber": "100627-00"
  },
  {
    "centro": "JUAN XXIII",
    "codPres": "0423",
    "codSaber": "100628-00"
  },
  {
    "centro": "J.N. JUAN XXIII",
    "codPres": "0424",
    "codSaber": "100629-00"
  },
  {
    "centro": "SAN BLAS",
    "codPres": "0425",
    "codSaber": "100630-00"
  },
  {
    "centro": "REPÚBLICA DOMINICANA",
    "codPres": "0426",
    "codSaber": "100631-00"
  },
  {
    "centro": "J.N. REPÚBLICA DOMINICANA",
    "codPres": "0427",
    "codSaber": "100632-00"
  },
  {
    "centro": "SAN FELIPE",
    "codPres": "0428",
    "codSaber": "100633-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "0429",
    "codSaber": "100634-00"
  },
  {
    "centro": "J.N. ISMAEL COTO FERNÁNDEZ",
    "codPres": "0430",
    "codSaber": "100635-00"
  },
  {
    "centro": "ISMAEL COTO FERNÁNDEZ",
    "codPres": "0431",
    "codSaber": "100636-00"
  },
  {
    "centro": "FRANKLIN DELANO ROOSEVELT",
    "codPres": "0432",
    "codSaber": "100637-00"
  },
  {
    "centro": "MANUEL MARÍA GUTIÉRREZ ZAMORA",
    "codPres": "0433",
    "codSaber": "100638-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0434",
    "codSaber": "100639-00"
  },
  {
    "centro": "INGLATERRA",
    "codPres": "0435",
    "codSaber": "100640-00"
  },
  {
    "centro": "JOSEFITA JURADO DE ALVARADO",
    "codPres": "0436",
    "codSaber": "100641-00"
  },
  {
    "centro": "GRANADILLA NORTE",
    "codPres": "0438",
    "codSaber": "100642-00"
  },
  {
    "centro": "JOSÉ ANA MARÍN CUBERO",
    "codPres": "0439",
    "codSaber": "100643-00"
  },
  {
    "centro": "J.N. JOSÉ ANA MARÍN CUBERO",
    "codPres": "0440",
    "codSaber": "100644-00"
  },
  {
    "centro": "CENTRO AMÉRICA",
    "codPres": "0441",
    "codSaber": "100645-00"
  },
  {
    "centro": "OTTO HUBBE",
    "codPres": "0442",
    "codSaber": "100646-00"
  },
  {
    "centro": "LA CARPIO",
    "codPres": "0443",
    "codSaber": "100647-00"
  },
  {
    "centro": "FILOMENA BLANCO DE QUIRÓS",
    "codPres": "0444",
    "codSaber": "100648-00"
  },
  {
    "centro": "J.N. NAPOLEÓN QUESADA",
    "codPres": "0446",
    "codSaber": "100649-00"
  },
  {
    "centro": "NAPOLEÓN QUESADA SALAZAR",
    "codPres": "0447",
    "codSaber": "100650-00"
  },
  {
    "centro": "J.N. JUAN RAFAEL MORA",
    "codPres": "0448",
    "codSaber": "100651-00"
  },
  {
    "centro": "J.N. MARGARITA ESQUIVEL",
    "codPres": "0449",
    "codSaber": "100652-00"
  },
  {
    "centro": "J.N. FLORA CHACÓN CÓRDOBA",
    "codPres": "0450",
    "codSaber": "100653-00"
  },
  {
    "centro": "J.N. JUSTO A. FACIO",
    "codPres": "0451",
    "codSaber": "100654-00"
  },
  {
    "centro": "J.N. LILIA RAMOS VALVERDE",
    "codPres": "0452",
    "codSaber": "100655-00"
  },
  {
    "centro": "J.N. ARTURO URIÉN GALLOSO",
    "codPres": "0453",
    "codSaber": "100656-00"
  },
  {
    "centro": "MIGUEL DE CERVANTES SAAVEDRA",
    "codPres": "0454",
    "codSaber": "100657-00"
  },
  {
    "centro": "CEDROS",
    "codPres": "0455",
    "codSaber": "100658-00"
  },
  {
    "centro": "CIPRESES",
    "codPres": "0457",
    "codSaber": "100660-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA CUATRO REINAS",
    "codPres": "0458",
    "codSaber": "104037-00"
  },
  {
    "centro": "LA LÍA",
    "codPres": "0459",
    "codSaber": "100662-00"
  },
  {
    "centro": "BARRIO PINTO",
    "codPres": "0460",
    "codSaber": "100663-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0461",
    "codSaber": "100664-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0462",
    "codSaber": "100665-00"
  },
  {
    "centro": "HATILLO 2",
    "codPres": "0463",
    "codSaber": "100666-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA DANIEL ODUBER QUIRÓS",
    "codPres": "0464",
    "codSaber": "105046-00"
  },
  {
    "centro": "MIGUEL OBREGÓN LIZANO",
    "codPres": "0465",
    "codSaber": "100668-00"
  },
  {
    "centro": "FINCA SAN JUAN",
    "codPres": "0466",
    "codSaber": "100669-00"
  },
  {
    "centro": "J.N. JORGE DEBRAVO",
    "codPres": "0467",
    "codSaber": "100670-00"
  },
  {
    "centro": "J.N. RINCÓN GRANDE",
    "codPres": "0468",
    "codSaber": "100671-00"
  },
  {
    "centro": "JORGE DEBRAVO",
    "codPres": "0469",
    "codSaber": "100672-00"
  },
  {
    "centro": "RINCÓN GRANDE",
    "codPres": "0470",
    "codSaber": "100673-00"
  },
  {
    "centro": "JOSÉ MARÍA ZELEDÓN BRENES",
    "codPres": "0471",
    "codSaber": "100674-00"
  },
  {
    "centro": "LOS PINOS",
    "codPres": "0472",
    "codSaber": "100675-00"
  },
  {
    "centro": "HERBERT FARRER KNIGHTS",
    "codPres": "0473",
    "codSaber": "100676-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "0474",
    "codSaber": "100677-00"
  },
  {
    "centro": "AGUA BLANCA",
    "codPres": "0475",
    "codSaber": "100678-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "0476",
    "codSaber": "100679-00"
  },
  {
    "centro": "FINCA CAPRI",
    "codPres": "0477",
    "codSaber": "100680-00"
  },
  {
    "centro": "SAUREZ",
    "codPres": "0478",
    "codSaber": "100681-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0480",
    "codSaber": "100682-00"
  },
  {
    "centro": "TOMÁS DE ACOSTA",
    "codPres": "0481",
    "codSaber": "100683-00"
  },
  {
    "centro": "ILDEFONSO CAMACHO PORTUGUEZ",
    "codPres": "0484",
    "codSaber": "100685-00"
  },
  {
    "centro": "BAJO DE CEDRAL",
    "codPres": "0485",
    "codSaber": "100686-00"
  },
  {
    "centro": "J.N. COLONIA KENNEDY",
    "codPres": "0486",
    "codSaber": "100687-00"
  },
  {
    "centro": "BIJAGUAL NORTE",
    "codPres": "0487",
    "codSaber": "100688-00"
  },
  {
    "centro": "J.N. MARÍA JIMÉNEZ UREÑA",
    "codPres": "0488",
    "codSaber": "100689-00"
  },
  {
    "centro": "MARÍA TERESA OBREGÓN LORIA",
    "codPres": "0489",
    "codSaber": "100690-00"
  },
  {
    "centro": "HIGUITO",
    "codPres": "0490",
    "codSaber": "100691-00"
  },
  {
    "centro": "MARTÍN MORA ROJAS",
    "codPres": "0491",
    "codSaber": "100692-00"
  },
  {
    "centro": "JOSÉ TRINIDAD MORA VALVERDE",
    "codPres": "0492",
    "codSaber": "100693-00"
  },
  {
    "centro": "CANGREJAL",
    "codPres": "0493",
    "codSaber": "100694-00"
  },
  {
    "centro": "CARAGRAL",
    "codPres": "0494",
    "codSaber": "100695-00"
  },
  {
    "centro": "LA LAGUNA",
    "codPres": "0495",
    "codSaber": "100696-00"
  },
  {
    "centro": "CEIBA ALTA",
    "codPres": "0496",
    "codSaber": "100697-00"
  },
  {
    "centro": "JOSÉ ÁNGEL PADILLA SOLÍS",
    "codPres": "0497",
    "codSaber": "100698-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA JUAN CALDERÓN VALVERDE",
    "codPres": "0498",
    "codSaber": "104796-00"
  },
  {
    "centro": "ISABEL LA CATÓLICA",
    "codPres": "0499",
    "codSaber": "100700-00"
  },
  {
    "centro": "LAGUNILLAS",
    "codPres": "0500",
    "codSaber": "100701-00"
  },
  {
    "centro": "MANUEL HIDALGO MORA",
    "codPres": "0501",
    "codSaber": "100702-00"
  },
  {
    "centro": "SANTA TERESITA",
    "codPres": "0502",
    "codSaber": "100703-00"
  },
  {
    "centro": "TRANQUERILLAS",
    "codPres": "0503",
    "codSaber": "100704-00"
  },
  {
    "centro": "JOAQUÍN GARCÍA MONGE",
    "codPres": "0504",
    "codSaber": "100705-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "0505",
    "codSaber": "100706-00"
  },
  {
    "centro": "JOSÉ MARÍA ZELEDÓN BRENES",
    "codPres": "0506",
    "codSaber": "100707-00"
  },
  {
    "centro": "EL MANZANO",
    "codPres": "0507",
    "codSaber": "100708-00"
  },
  {
    "centro": "CIUDADELA FÁTIMA",
    "codPres": "0509",
    "codSaber": "100710-00"
  },
  {
    "centro": "CECILIO PIEDRA GUTIÉRREZ",
    "codPres": "0510",
    "codSaber": "100711-00"
  },
  {
    "centro": "LEANDRO FONSECA NARANJO",
    "codPres": "0511",
    "codSaber": "100712-00"
  },
  {
    "centro": "GUAITIL",
    "codPres": "0512",
    "codSaber": "100713-00"
  },
  {
    "centro": "EDWIN PORRAS ULLOA",
    "codPres": "0513",
    "codSaber": "100714-00"
  },
  {
    "centro": "DR. RAFAEL CALDERÓN MUÑOZ",
    "codPres": "0514",
    "codSaber": "100715-00"
  },
  {
    "centro": "AGUSTIN SEGURA",
    "codPres": "0516",
    "codSaber": "100716-00"
  },
  {
    "centro": "JOCOTAL ABAJO",
    "codPres": "0517",
    "codSaber": "100717-00"
  },
  {
    "centro": "LA URUCA",
    "codPres": "0518",
    "codSaber": "100718-00"
  },
  {
    "centro": "JUAN RUDÍN ISELIN",
    "codPres": "0519",
    "codSaber": "100719-00"
  },
  {
    "centro": "CEIBA BAJA",
    "codPres": "0520",
    "codSaber": "100720-00"
  },
  {
    "centro": "CEIBA ESTE",
    "codPres": "0521",
    "codSaber": "100721-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA LA CRUZ",
    "codPres": "0522",
    "codSaber": "104818-00"
  },
  {
    "centro": "LA ESCUADRA",
    "codPres": "0523",
    "codSaber": "100723-00"
  },
  {
    "centro": "LA JOYA",
    "codPres": "0524",
    "codSaber": "100724-00"
  },
  {
    "centro": "CECILIA ORLICH FIGUERES",
    "codPres": "0525",
    "codSaber": "100725-00"
  },
  {
    "centro": "CHIROGRES",
    "codPres": "0526",
    "codSaber": "100726-00"
  },
  {
    "centro": "LA MESA",
    "codPres": "0527",
    "codSaber": "100727-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "0528",
    "codSaber": "100728-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "0529",
    "codSaber": "100729-00"
  },
  {
    "centro": "JESÚS ROJAS CRUZ",
    "codPres": "0530",
    "codSaber": "100730-00"
  },
  {
    "centro": "LAS GRAVILIAS",
    "codPres": "0531",
    "codSaber": "100731-00"
  },
  {
    "centro": "LAS LIMAS",
    "codPres": "0532",
    "codSaber": "100732-00"
  },
  {
    "centro": "RICARDO JIMÉNEZ OREAMUNO",
    "codPres": "0533",
    "codSaber": "100733-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "0534",
    "codSaber": "100734-00"
  },
  {
    "centro": "MANUEL PADILLA UREÑA",
    "codPres": "0535",
    "codSaber": "100735-00"
  },
  {
    "centro": "FLORIA ZELEDÓN TREJOS",
    "codPres": "0536",
    "codSaber": "100736-00"
  },
  {
    "centro": "BRAULIO ODIO HERRERA",
    "codPres": "0537",
    "codSaber": "100737-00"
  },
  {
    "centro": "NARANJAL",
    "codPres": "0538",
    "codSaber": "100738-00"
  },
  {
    "centro": "BRAULIO CASTRO CHACÓN",
    "codPres": "0539",
    "codSaber": "100739-00"
  },
  {
    "centro": "PARRITA",
    "codPres": "0540",
    "codSaber": "100740-00"
  },
  {
    "centro": "J.N. REPÚBLICA DE HAITÍ",
    "codPres": "0541",
    "codSaber": "100741-00"
  },
  {
    "centro": "REPUBLICA DE HAITÍ",
    "codPres": "0542",
    "codSaber": "100742-00"
  },
  {
    "centro": "JUAN MONGE GUILLÉN",
    "codPres": "0543",
    "codSaber": "100743-00"
  },
  {
    "centro": "MARÍA GARCÍA ARAYA",
    "codPres": "0544",
    "codSaber": "100744-00"
  },
  {
    "centro": "ANDRES CORRALES MORA",
    "codPres": "0545",
    "codSaber": "100745-00"
  },
  {
    "centro": "PRAGA",
    "codPres": "0546",
    "codSaber": "100746-00"
  },
  {
    "centro": "REPÚBLICA FEDERAL DE ALEMANIA",
    "codPres": "0547",
    "codSaber": "100747-00"
  },
  {
    "centro": "FRANCISCO GAMBOA MORA",
    "codPres": "0548",
    "codSaber": "100748-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "0549",
    "codSaber": "100749-00"
  },
  {
    "centro": "LAS MERCEDES",
    "codPres": "0550",
    "codSaber": "100750-00"
  },
  {
    "centro": "EL ROSARIO",
    "codPres": "0551",
    "codSaber": "100751-00"
  },
  {
    "centro": "LA FILA",
    "codPres": "0552",
    "codSaber": "100752-00"
  },
  {
    "centro": "MATÍAS CAMACHO CASTRO",
    "codPres": "0553",
    "codSaber": "100753-00"
  },
  {
    "centro": "SABANILLAS",
    "codPres": "0554",
    "codSaber": "100754-00"
  },
  {
    "centro": "I.E.G.B. REPÚBLICA DE PANAMÁ",
    "codPres": "0556",
    "codSaber": "104806-00"
  },
  {
    "centro": "MIXTA SAN CRISTÓBAL SUR",
    "codPres": "0557",
    "codSaber": "100756-00"
  },
  {
    "centro": "GABRIEL BRENES ROBLES",
    "codPres": "0558",
    "codSaber": "100757-00"
  },
  {
    "centro": "CRISTÓBAL COLÓN",
    "codPres": "0559",
    "codSaber": "100758-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "0560",
    "codSaber": "100759-00"
  },
  {
    "centro": "SOTERO GONZÁLEZ BARQUERO",
    "codPres": "0561",
    "codSaber": "104722-00"
  },
  {
    "centro": "J.N. SOTERO GONZÁLEZ BARQUERO",
    "codPres": "0562",
    "codSaber": "100761-00"
  },
  {
    "centro": "SOLEDAD",
    "codPres": "0563",
    "codSaber": "100762-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "0564",
    "codSaber": "100763-00"
  },
  {
    "centro": "REPÚBLICA DE HONDURAS",
    "codPres": "0565",
    "codSaber": "100764-00"
  },
  {
    "centro": "J.N. MARÍA RETANA SALAZAR",
    "codPres": "0566",
    "codSaber": "100765-00"
  },
  {
    "centro": "ELÍAS JIMÉNEZ CASTRO",
    "codPres": "0567",
    "codSaber": "100766-00"
  },
  {
    "centro": "CENTRAL SAN SEBASTIÁN",
    "codPres": "0568",
    "codSaber": "100767-00"
  },
  {
    "centro": "J.N. SAN SEBASTIAN",
    "codPres": "0569",
    "codSaber": "100768-00"
  },
  {
    "centro": "BAJOS DE PRAGA",
    "codPres": "0570",
    "codSaber": "100769-00"
  },
  {
    "centro": "DR. MARIANO FIGUERES FORGES",
    "codPres": "0571",
    "codSaber": "100770-00"
  },
  {
    "centro": "SEVILLA",
    "codPres": "0572",
    "codSaber": "100771-00"
  },
  {
    "centro": "MANUEL ORTUÑO BOUTIN",
    "codPres": "0573",
    "codSaber": "100772-00"
  },
  {
    "centro": "J.N. MANUEL ORTUÑO BOUTIN",
    "codPres": "0574",
    "codSaber": "100773-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0575",
    "codSaber": "100774-00"
  },
  {
    "centro": "TERUEL",
    "codPres": "0576",
    "codSaber": "100775-00"
  },
  {
    "centro": "PAQUITA FERRER DE FIGUERES",
    "codPres": "0578",
    "codSaber": "100777-00"
  },
  {
    "centro": "JUSTO MARÍA PADILLA CASTRO",
    "codPres": "0579",
    "codSaber": "100778-00"
  },
  {
    "centro": "TOLEDO",
    "codPres": "0580",
    "codSaber": "100779-00"
  },
  {
    "centro": "LAS GRAVILIAS",
    "codPres": "0581",
    "codSaber": "100780-00"
  },
  {
    "centro": "FERNANDO DE ARAGÓN",
    "codPres": "0582",
    "codSaber": "100781-00"
  },
  {
    "centro": "ALEJANDRO RODRÍGUEZ RODRÍGUEZ",
    "codPres": "0583",
    "codSaber": "100782-00"
  },
  {
    "centro": "BAJOS DE PLOMO",
    "codPres": "0584",
    "codSaber": "100783-00"
  },
  {
    "centro": "ZONCUANO",
    "codPres": "0585",
    "codSaber": "100784-00"
  },
  {
    "centro": "CASPIROLA",
    "codPres": "0586",
    "codSaber": "100785-00"
  },
  {
    "centro": "LAS VEGAS",
    "codPres": "0587",
    "codSaber": "100786-00"
  },
  {
    "centro": "LA PACAYA",
    "codPres": "0588",
    "codSaber": "100787-00"
  },
  {
    "centro": "TABLAZO",
    "codPres": "0589",
    "codSaber": "100788-00"
  },
  {
    "centro": "GUATUSO",
    "codPres": "0590",
    "codSaber": "100789-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "0591",
    "codSaber": "100790-00"
  },
  {
    "centro": "JESÚS MORALES GARBANZO",
    "codPres": "0592",
    "codSaber": "100791-00"
  },
  {
    "centro": "DOS CERCAS",
    "codPres": "0593",
    "codSaber": "100792-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "0594",
    "codSaber": "100793-00"
  },
  {
    "centro": "SOR MARÍA ROMERO MENESES",
    "codPres": "0595",
    "codSaber": "100794-00"
  },
  {
    "centro": "LUIS AGUILAR",
    "codPres": "0596",
    "codSaber": "100795-00"
  },
  {
    "centro": "REVERENDO FRANCISCO SCHMITZ",
    "codPres": "0597",
    "codSaber": "100796-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "0598",
    "codSaber": "100797-00"
  },
  {
    "centro": "JOSÉ NAVARRO ARAYA",
    "codPres": "0599",
    "codSaber": "100798-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA LA VALENCIA",
    "codPres": "0600",
    "codSaber": "104658-00"
  },
  {
    "centro": "LAS LETRAS",
    "codPres": "0601",
    "codSaber": "100800-00"
  },
  {
    "centro": "LOS GUIDO",
    "codPres": "0602",
    "codSaber": "100801-00"
  },
  {
    "centro": "SECTOR SIETE",
    "codPres": "0603",
    "codSaber": "100802-00"
  },
  {
    "centro": "J.N. VALENCIA",
    "codPres": "0604",
    "codSaber": "100803-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "0605",
    "codSaber": "100804-00"
  },
  {
    "centro": "COLONIA GAMALOTILLO",
    "codPres": "0606",
    "codSaber": "100805-00"
  },
  {
    "centro": "MARCOS PÉREZ",
    "codPres": "0607",
    "codSaber": "100806-00"
  },
  {
    "centro": "BAJO LOS MURILLO",
    "codPres": "0608",
    "codSaber": "100807-00"
  },
  {
    "centro": "LOS ALTOS",
    "codPres": "0609",
    "codSaber": "100808-00"
  },
  {
    "centro": "BAJO LOAIZA",
    "codPres": "0610",
    "codSaber": "100809-00"
  },
  {
    "centro": "BAJO LOS BADILLA",
    "codPres": "0611",
    "codSaber": "100810-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "0612",
    "codSaber": "100811-00"
  },
  {
    "centro": "ROBERTO LÓPEZ VARELA",
    "codPres": "0613",
    "codSaber": "100812-00"
  },
  {
    "centro": "JUNQUILLO ARRIBA",
    "codPres": "0614",
    "codSaber": "100813-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "0615",
    "codSaber": "100814-00"
  },
  {
    "centro": "COLONIA SAN FRANCISCO",
    "codPres": "0616",
    "codSaber": "100815-00"
  },
  {
    "centro": "LA ANGOSTURA",
    "codPres": "0617",
    "codSaber": "100816-00"
  },
  {
    "centro": "BRASIL DE MORA",
    "codPres": "0618",
    "codSaber": "100817-00"
  },
  {
    "centro": "JESÚS QUESADA ALVARADO",
    "codPres": "0619",
    "codSaber": "100818-00"
  },
  {
    "centro": "JUNQUILLO ABAJO",
    "codPres": "0621",
    "codSaber": "100819-00"
  },
  {
    "centro": "CAÑALES ARRIBA",
    "codPres": "0622",
    "codSaber": "100820-00"
  },
  {
    "centro": "CANDELARITA",
    "codPres": "0623",
    "codSaber": "100821-00"
  },
  {
    "centro": "JUAN LUIS GARCÍA GONZÁLEZ",
    "codPres": "0624",
    "codSaber": "100822-00"
  },
  {
    "centro": "EL GALÁN",
    "codPres": "0625",
    "codSaber": "100823-00"
  },
  {
    "centro": "CERBATANA",
    "codPres": "0626",
    "codSaber": "100824-00"
  },
  {
    "centro": "I.D.A. BIJAGUAL",
    "codPres": "0627",
    "codSaber": "100825-00"
  },
  {
    "centro": "ALTOS DE PÉREZ ASTÚA",
    "codPres": "0628",
    "codSaber": "100826-00"
  },
  {
    "centro": "COLONIA PASO AGRES",
    "codPres": "0630",
    "codSaber": "100827-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "0631",
    "codSaber": "100828-00"
  },
  {
    "centro": "LLANO HERMOSO",
    "codPres": "0632",
    "codSaber": "100829-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "0633",
    "codSaber": "100830-00"
  },
  {
    "centro": "CORRALAR",
    "codPres": "0634",
    "codSaber": "100831-00"
  },
  {
    "centro": "CORTEZAL",
    "codPres": "0635",
    "codSaber": "100832-00"
  },
  {
    "centro": "JOSÉ SALAZAR ZÚÑIGA",
    "codPres": "0636",
    "codSaber": "100833-00"
  },
  {
    "centro": "GRIFO ALTO",
    "codPres": "0638",
    "codSaber": "100834-00"
  },
  {
    "centro": "GRIFO BAJO",
    "codPres": "0639",
    "codSaber": "100835-00"
  },
  {
    "centro": "LA PITA",
    "codPres": "0640",
    "codSaber": "100836-00"
  },
  {
    "centro": "EL SUR",
    "codPres": "0641",
    "codSaber": "100837-00"
  },
  {
    "centro": "TUFARES",
    "codPres": "0642",
    "codSaber": "100838-00"
  },
  {
    "centro": "REPÚBLICA DE PARAGUAY",
    "codPres": "0643",
    "codSaber": "100839-00"
  },
  {
    "centro": "EL PORÓ",
    "codPres": "0644",
    "codSaber": "100840-00"
  },
  {
    "centro": "ELOY MORUA CARRILLO",
    "codPres": "0645",
    "codSaber": "100841-00"
  },
  {
    "centro": "LA GLORIA",
    "codPres": "0647",
    "codSaber": "100843-00"
  },
  {
    "centro": "FLORALIA",
    "codPres": "0648",
    "codSaber": "100844-00"
  },
  {
    "centro": "GAMALOTILLO",
    "codPres": "0649",
    "codSaber": "100845-00"
  },
  {
    "centro": "GUARUMAL",
    "codPres": "0650",
    "codSaber": "100846-00"
  },
  {
    "centro": "JACINTO MORA GÓMEZ",
    "codPres": "0651",
    "codSaber": "100847-00"
  },
  {
    "centro": "SANTIAGO ALPÍZAR JIMÉNEZ",
    "codPres": "0652",
    "codSaber": "100848-00"
  },
  {
    "centro": "JILGUERAL",
    "codPres": "0653",
    "codSaber": "100849-00"
  },
  {
    "centro": "BOCANA",
    "codPres": "0654",
    "codSaber": "100850-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "0655",
    "codSaber": "100851-00"
  },
  {
    "centro": "ADELA RODRÍGUEZ VENEGAS",
    "codPres": "0656",
    "codSaber": "100852-00"
  },
  {
    "centro": "BAJO DE LA LEGUA",
    "codPres": "0658",
    "codSaber": "100854-00"
  },
  {
    "centro": "LA LEGÜITA",
    "codPres": "0659",
    "codSaber": "100855-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "0660",
    "codSaber": "100856-00"
  },
  {
    "centro": "ROGELIO QUIRÓS VALVERDE",
    "codPres": "0662",
    "codSaber": "100858-00"
  },
  {
    "centro": "POTENCIANA ARRIBA",
    "codPres": "0663",
    "codSaber": "100859-00"
  },
  {
    "centro": "SAN BOSCO DE MORA",
    "codPres": "0664",
    "codSaber": "100860-00"
  },
  {
    "centro": "LANAS",
    "codPres": "0665",
    "codSaber": "100861-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "0666",
    "codSaber": "100862-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "0667",
    "codSaber": "100863-00"
  },
  {
    "centro": "MANUEL BUSTAMANTE VARGAS",
    "codPres": "0668",
    "codSaber": "100864-00"
  },
  {
    "centro": "RAFAEL SOLÓRZANO SABORÍO",
    "codPres": "0669",
    "codSaber": "100865-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "0670",
    "codSaber": "100866-00"
  },
  {
    "centro": "MASTATAL",
    "codPres": "0671",
    "codSaber": "100867-00"
  },
  {
    "centro": "MAURO FERNÁNDEZ ACUÑA",
    "codPres": "0672",
    "codSaber": "100868-00"
  },
  {
    "centro": "MERCEDES NORTE",
    "codPres": "0673",
    "codSaber": "100869-00"
  },
  {
    "centro": "MERCEDES SUR",
    "codPres": "0674",
    "codSaber": "100870-00"
  },
  {
    "centro": "MONTELIMAR",
    "codPres": "0675",
    "codSaber": "100871-00"
  },
  {
    "centro": "MONTERREY",
    "codPres": "0676",
    "codSaber": "100872-00"
  },
  {
    "centro": "MORADO",
    "codPres": "0677",
    "codSaber": "100873-00"
  },
  {
    "centro": "PALMICHAL DE ACOSTA",
    "codPres": "0678",
    "codSaber": "100874-00"
  },
  {
    "centro": "PEDERNAL",
    "codPres": "0679",
    "codSaber": "100875-00"
  },
  {
    "centro": "LUIS MONGE MADRIGAL",
    "codPres": "0680",
    "codSaber": "100876-00"
  },
  {
    "centro": "NAZARIO VALVERDE JIMÉNEZ",
    "codPres": "0681",
    "codSaber": "100877-00"
  },
  {
    "centro": "JOSÉ MARÍA CAÑAS",
    "codPres": "0682",
    "codSaber": "100878-00"
  },
  {
    "centro": "ESTEBAN LORENZO DEL CORO",
    "codPres": "0683",
    "codSaber": "100879-00"
  },
  {
    "centro": "POLKA",
    "codPres": "0684",
    "codSaber": "100880-00"
  },
  {
    "centro": "PURIRES",
    "codPres": "0685",
    "codSaber": "100881-00"
  },
  {
    "centro": "QUEBRADA AZUL",
    "codPres": "0686",
    "codSaber": "100882-00"
  },
  {
    "centro": "QUEBRADA HONDA",
    "codPres": "0687",
    "codSaber": "100883-00"
  },
  {
    "centro": "NINFA CABEZAS GONZÁLEZ",
    "codPres": "0688",
    "codSaber": "100884-00"
  },
  {
    "centro": "JOSÉ ROJAS ALPÍZAR",
    "codPres": "0689",
    "codSaber": "100885-00"
  },
  {
    "centro": "EL RODEO",
    "codPres": "0690",
    "codSaber": "100886-00"
  },
  {
    "centro": "SALAZAR",
    "codPres": "0691",
    "codSaber": "100887-00"
  },
  {
    "centro": "ANICETO JIMÉNEZ BARBOZA",
    "codPres": "0692",
    "codSaber": "100888-00"
  },
  {
    "centro": "SALITRILLOS",
    "codPres": "0693",
    "codSaber": "100889-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "0694",
    "codSaber": "100890-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "0695",
    "codSaber": "100891-00"
  },
  {
    "centro": "MIXTA DE SAN JUAN",
    "codPres": "0696",
    "codSaber": "100892-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "0697",
    "codSaber": "100893-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "0698",
    "codSaber": "100894-00"
  },
  {
    "centro": "DR. CLODOMIRO PICADO TWIGHT",
    "codPres": "0699",
    "codSaber": "100895-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0700",
    "codSaber": "100896-00"
  },
  {
    "centro": "LAGUNAS",
    "codPres": "0701",
    "codSaber": "100897-00"
  },
  {
    "centro": "ROSARIO SALAZAR MARÍN",
    "codPres": "0702",
    "codSaber": "100898-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "0703",
    "codSaber": "100899-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0704",
    "codSaber": "100900-00"
  },
  {
    "centro": "DARIO FLORES HERNÁNDEZ",
    "codPres": "0705",
    "codSaber": "100901-00"
  },
  {
    "centro": "RAMÓN BEDOYA MONGE",
    "codPres": "0706",
    "codSaber": "100902-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "0707",
    "codSaber": "100903-00"
  },
  {
    "centro": "FILA NEGRA",
    "codPres": "0708",
    "codSaber": "100904-00"
  },
  {
    "centro": "LISÍMACO CHAVARRÍA PALMA",
    "codPres": "0709",
    "codSaber": "100905-00"
  },
  {
    "centro": "SAN PABLO DE PALMICHAL",
    "codPres": "0711",
    "codSaber": "100906-00"
  },
  {
    "centro": "VISTA DE MAR",
    "codPres": "0712",
    "codSaber": "100907-00"
  },
  {
    "centro": "ROGELIO FERNÁNDEZ GÜELL",
    "codPres": "0713",
    "codSaber": "100908-00"
  },
  {
    "centro": "ZAPATÓN",
    "codPres": "0714",
    "codSaber": "100909-00"
  },
  {
    "centro": "ARENAL",
    "codPres": "0715",
    "codSaber": "100910-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "0716",
    "codSaber": "100911-00"
  },
  {
    "centro": "MATA DE PLÁTANO",
    "codPres": "0717",
    "codSaber": "100912-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "0718",
    "codSaber": "100913-00"
  },
  {
    "centro": "BAJO BURGOS",
    "codPres": "0720",
    "codSaber": "100914-00"
  },
  {
    "centro": "NARANJAL",
    "codPres": "0721",
    "codSaber": "100915-00"
  },
  {
    "centro": "LABORATORIO",
    "codPres": "0722",
    "codSaber": "100916-00"
  },
  {
    "centro": "I.D.A. JORÓN",
    "codPres": "0723",
    "codSaber": "100917-00"
  },
  {
    "centro": "AGUAS BUENAS",
    "codPres": "0724",
    "codSaber": "100918-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "0725",
    "codSaber": "100919-00"
  },
  {
    "centro": "TSENE DIKOL",
    "codPres": "0726",
    "codSaber": "100920-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "0727",
    "codSaber": "100921-00"
  },
  {
    "centro": "LA COLONIA",
    "codPres": "0728",
    "codSaber": "100922-00"
  },
  {
    "centro": "LA NUEVA HORTENSIA",
    "codPres": "0729",
    "codSaber": "100923-00"
  },
  {
    "centro": "RENACER",
    "codPres": "0730",
    "codSaber": "100924-00"
  },
  {
    "centro": "SONADOR",
    "codPres": "0731",
    "codSaber": "100925-00"
  },
  {
    "centro": "ALTO DE LAS MORAS",
    "codPres": "0732",
    "codSaber": "100926-00"
  },
  {
    "centro": "LA AURORA",
    "codPres": "0733",
    "codSaber": "100927-00"
  },
  {
    "centro": "BIDYAN",
    "codPres": "0734",
    "codSaber": "100928-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "0735",
    "codSaber": "100929-00"
  },
  {
    "centro": "BÖKÖ BATA",
    "codPres": "0736",
    "codSaber": "100930-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "0737",
    "codSaber": "100931-00"
  },
  {
    "centro": "EL TIRRÁ",
    "codPres": "0738",
    "codSaber": "100932-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0739",
    "codSaber": "100933-00"
  },
  {
    "centro": "EL GUAYACÁN",
    "codPres": "0740",
    "codSaber": "100934-00"
  },
  {
    "centro": "LAS LOMAS",
    "codPres": "0741",
    "codSaber": "100935-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "0742",
    "codSaber": "100936-00"
  },
  {
    "centro": "ORATORIO",
    "codPres": "0743",
    "codSaber": "100937-00"
  },
  {
    "centro": "CRISTO REY",
    "codPres": "0744",
    "codSaber": "100938-00"
  },
  {
    "centro": "CEIBÓN",
    "codPres": "0745",
    "codSaber": "100939-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA DR. RAFAEL ÁNGEL CALDERÓN GUARDIA",
    "codPres": "0746",
    "codSaber": "104059-00"
  },
  {
    "centro": "LA SABANA",
    "codPres": "0747",
    "codSaber": "100941-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "0748",
    "codSaber": "100942-00"
  },
  {
    "centro": "LOS MADEROS",
    "codPres": "0749",
    "codSaber": "100943-00"
  },
  {
    "centro": "BAJO DE SÁBALO",
    "codPres": "0750",
    "codSaber": "100944-00"
  },
  {
    "centro": "YERI",
    "codPres": "0751",
    "codSaber": "100945-00"
  },
  {
    "centro": "I.D.A. SAN MARTÍN",
    "codPres": "0752",
    "codSaber": "100946-00"
  },
  {
    "centro": "PENSILVANIA",
    "codPres": "0753",
    "codSaber": "100947-00"
  },
  {
    "centro": "LA SHAMBA",
    "codPres": "0754",
    "codSaber": "100948-00"
  },
  {
    "centro": "ARTURO TINOCO JIMÉNEZ",
    "codPres": "0755",
    "codSaber": "100949-00"
  },
  {
    "centro": "TALARI",
    "codPres": "0756",
    "codSaber": "100950-00"
  },
  {
    "centro": "PLAYA HERMOSA",
    "codPres": "0757",
    "codSaber": "100951-00"
  },
  {
    "centro": "BAJO LAS BONITAS",
    "codPres": "0758",
    "codSaber": "100952-00"
  },
  {
    "centro": "VILLA HERMOSA",
    "codPres": "0759",
    "codSaber": "100953-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "0760",
    "codSaber": "100954-00"
  },
  {
    "centro": "JERUSALÉN 3M",
    "codPres": "0761",
    "codSaber": "100955-00"
  },
  {
    "centro": "HOLANDA",
    "codPres": "0762",
    "codSaber": "100956-00"
  },
  {
    "centro": "BOCA DE LIMÓN",
    "codPres": "0763",
    "codSaber": "100957-00"
  },
  {
    "centro": "LOS ALPES",
    "codPres": "0764",
    "codSaber": "100958-00"
  },
  {
    "centro": "ESCALERAS",
    "codPres": "0765",
    "codSaber": "100959-00"
  },
  {
    "centro": "EL CAMPO",
    "codPres": "0766",
    "codSaber": "100960-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "0767",
    "codSaber": "100961-00"
  },
  {
    "centro": "EL TORITO",
    "codPres": "0769",
    "codSaber": "100962-00"
  },
  {
    "centro": "PUERTO NUEVO",
    "codPres": "0770",
    "codSaber": "100963-00"
  },
  {
    "centro": "BARRIO NUEVO",
    "codPres": "0771",
    "codSaber": "100964-00"
  },
  {
    "centro": "PROVIDENCIA",
    "codPres": "0772",
    "codSaber": "100965-00"
  },
  {
    "centro": "TOLEDO",
    "codPres": "0773",
    "codSaber": "100966-00"
  },
  {
    "centro": "BARÚ",
    "codPres": "0774",
    "codSaber": "100967-00"
  },
  {
    "centro": "LA SUIZA",
    "codPres": "0776",
    "codSaber": "100968-00"
  },
  {
    "centro": "OASIS",
    "codPres": "0777",
    "codSaber": "100969-00"
  },
  {
    "centro": "NUEVA SANTA ANA",
    "codPres": "0778",
    "codSaber": "100970-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "0779",
    "codSaber": "100971-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "0780",
    "codSaber": "100972-00"
  },
  {
    "centro": "BOLAS",
    "codPres": "0781",
    "codSaber": "100973-00"
  },
  {
    "centro": "REPÚBLICA DE BOLIVIA",
    "codPres": "0782",
    "codSaber": "100974-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "0783",
    "codSaber": "100975-00"
  },
  {
    "centro": "CAÑAS",
    "codPres": "0785",
    "codSaber": "100976-00"
  },
  {
    "centro": "CORRALILLO",
    "codPres": "0786",
    "codSaber": "100977-00"
  },
  {
    "centro": "SAN ANDRÉS",
    "codPres": "0787",
    "codSaber": "100978-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "0788",
    "codSaber": "100979-00"
  },
  {
    "centro": "CAJÓN",
    "codPres": "0789",
    "codSaber": "100980-00"
  },
  {
    "centro": "ALTO DE VERAGUA",
    "codPres": "0790",
    "codSaber": "100981-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "0791",
    "codSaber": "100982-00"
  },
  {
    "centro": "CALLE MORA ARRIBA",
    "codPres": "0792",
    "codSaber": "100983-00"
  },
  {
    "centro": "CALLE MORA",
    "codPres": "0793",
    "codSaber": "100984-00"
  },
  {
    "centro": "VILLA MILLS",
    "codPres": "0794",
    "codSaber": "100985-00"
  },
  {
    "centro": "VILLA HERMOSA",
    "codPres": "0795",
    "codSaber": "100986-00"
  },
  {
    "centro": "LA FILA",
    "codPres": "0796",
    "codSaber": "100987-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "0797",
    "codSaber": "100988-00"
  },
  {
    "centro": "CANAÁN",
    "codPres": "0799",
    "codSaber": "100989-00"
  },
  {
    "centro": "BERLÍN",
    "codPres": "0800",
    "codSaber": "100990-00"
  },
  {
    "centro": "SAGRADA FAMILIA",
    "codPres": "0801",
    "codSaber": "100991-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "0803",
    "codSaber": "100993-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "0804",
    "codSaber": "100994-00"
  },
  {
    "centro": "PEDRO PÉREZ ZELEDÓN",
    "codPres": "0805",
    "codSaber": "100995-00"
  },
  {
    "centro": "CHÁNGUENA",
    "codPres": "0806",
    "codSaber": "100996-00"
  },
  {
    "centro": "CHIMIROL",
    "codPres": "0807",
    "codSaber": "100997-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "0808",
    "codSaber": "100998-00"
  },
  {
    "centro": "CHINA KICHÁ",
    "codPres": "0809",
    "codSaber": "100999-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "0810",
    "codSaber": "101000-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "0811",
    "codSaber": "101001-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "0812",
    "codSaber": "101002-00"
  },
  {
    "centro": "QUEBRADA DE VUELTAS",
    "codPres": "0813",
    "codSaber": "101003-00"
  },
  {
    "centro": "CONVENTO",
    "codPres": "0814",
    "codSaber": "101004-00"
  },
  {
    "centro": "COLORADO",
    "codPres": "0815",
    "codSaber": "101005-00"
  },
  {
    "centro": "EL VERGEL",
    "codPres": "0816",
    "codSaber": "101006-00"
  },
  {
    "centro": "CORDONCILLO",
    "codPres": "0817",
    "codSaber": "101007-00"
  },
  {
    "centro": "LA HORTENSIA",
    "codPres": "0818",
    "codSaber": "101008-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "0819",
    "codSaber": "101009-00"
  },
  {
    "centro": "ZARAGOZA",
    "codPres": "0820",
    "codSaber": "101010-00"
  },
  {
    "centro": "CURRÉ",
    "codPres": "0821",
    "codSaber": "101011-00"
  },
  {
    "centro": "BOQUETE",
    "codPres": "0822",
    "codSaber": "101012-00"
  },
  {
    "centro": "DANIEL FLORES ZAVALETA",
    "codPres": "0823",
    "codSaber": "101013-00"
  },
  {
    "centro": "BIJAGUAL",
    "codPres": "0824",
    "codSaber": "101014-00"
  },
  {
    "centro": "FÁTIMA",
    "codPres": "0825",
    "codSaber": "101015-00"
  },
  {
    "centro": "QUIZARRÁ",
    "codPres": "0826",
    "codSaber": "101016-00"
  },
  {
    "centro": "SANTA TERESA DE CAJÓN",
    "codPres": "0827",
    "codSaber": "101017-00"
  },
  {
    "centro": "BIKAKLA",
    "codPres": "0828",
    "codSaber": "101018-00"
  },
  {
    "centro": "DESAMPARADOS",
    "codPres": "0829",
    "codSaber": "101019-00"
  },
  {
    "centro": "DIVISIÓN",
    "codPres": "0830",
    "codSaber": "101020-00"
  },
  {
    "centro": "DOMINICAL",
    "codPres": "0831",
    "codSaber": "101021-00"
  },
  {
    "centro": "LA FORTUNA",
    "codPres": "0832",
    "codSaber": "101022-00"
  },
  {
    "centro": "DORIS Z. STONE",
    "codPres": "0833",
    "codSaber": "101023-00"
  },
  {
    "centro": "EL ÁGUILA",
    "codPres": "0834",
    "codSaber": "101024-00"
  },
  {
    "centro": "MARAVILLA",
    "codPres": "0835",
    "codSaber": "101025-00"
  },
  {
    "centro": "BAJO LAS ESPERANZAS",
    "codPres": "0836",
    "codSaber": "101026-00"
  },
  {
    "centro": "EL BRUJO",
    "codPres": "0837",
    "codSaber": "101027-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "0838",
    "codSaber": "101028-00"
  },
  {
    "centro": "EL QUEMADO",
    "codPres": "0839",
    "codSaber": "101029-00"
  },
  {
    "centro": "EL CEDRAL",
    "codPres": "0840",
    "codSaber": "101030-00"
  },
  {
    "centro": "EL CEIBO",
    "codPres": "0841",
    "codSaber": "101031-00"
  },
  {
    "centro": "TRES RÍOS",
    "codPres": "0842",
    "codSaber": "101032-00"
  },
  {
    "centro": "EL CEIBO",
    "codPres": "0843",
    "codSaber": "101033-00"
  },
  {
    "centro": "FERNANDO VALVERDE VEGA",
    "codPres": "0844",
    "codSaber": "101034-00"
  },
  {
    "centro": "EL NIVEL",
    "codPres": "0845",
    "codSaber": "101035-00"
  },
  {
    "centro": "EL PEJE",
    "codPres": "0846",
    "codSaber": "101036-00"
  },
  {
    "centro": "BRAZO DE ORO",
    "codPres": "0847",
    "codSaber": "101037-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "0848",
    "codSaber": "101038-00"
  },
  {
    "centro": "EL SOCORRO",
    "codPres": "0849",
    "codSaber": "101039-00"
  },
  {
    "centro": "EL SOCORRO",
    "codPres": "0850",
    "codSaber": "101040-00"
  },
  {
    "centro": "GUANACASTE",
    "codPres": "0851",
    "codSaber": "101041-00"
  },
  {
    "centro": "FILADELFIA",
    "codPres": "0852",
    "codSaber": "101042-00"
  },
  {
    "centro": "OCOCHOBI",
    "codPres": "0853",
    "codSaber": "101043-00"
  },
  {
    "centro": "GUÁCIMO",
    "codPres": "0854",
    "codSaber": "101044-00"
  },
  {
    "centro": "GUADALAJARA",
    "codPres": "0855",
    "codSaber": "101045-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "0856",
    "codSaber": "101046-00"
  },
  {
    "centro": "GUAGARAL",
    "codPres": "0857",
    "codSaber": "101047-00"
  },
  {
    "centro": "HERRADURA",
    "codPres": "0858",
    "codSaber": "101048-00"
  },
  {
    "centro": "EL HOYÓN",
    "codPres": "0859",
    "codSaber": "101049-00"
  },
  {
    "centro": "JOSÉ FABIO GÓNGORA UMAÑA",
    "codPres": "0860",
    "codSaber": "101050-00"
  },
  {
    "centro": "LA ALFOMBRA",
    "codPres": "0861",
    "codSaber": "101051-00"
  },
  {
    "centro": "LA ANGOSTURA",
    "codPres": "0862",
    "codSaber": "101052-00"
  },
  {
    "centro": "LA CENIZA",
    "codPres": "0863",
    "codSaber": "101053-00"
  },
  {
    "centro": "LA ESE",
    "codPres": "0864",
    "codSaber": "101054-00"
  },
  {
    "centro": "LAS ESPERANZAS",
    "codPres": "0865",
    "codSaber": "101055-00"
  },
  {
    "centro": "LA FLORIDA",
    "codPres": "0866",
    "codSaber": "101056-00"
  },
  {
    "centro": "LA FORTUNA",
    "codPres": "0867",
    "codSaber": "101057-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "0868",
    "codSaber": "101058-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "0869",
    "codSaber": "101059-00"
  },
  {
    "centro": "LA HERMOSA",
    "codPres": "0870",
    "codSaber": "101060-00"
  },
  {
    "centro": "HUACABATA",
    "codPres": "0871",
    "codSaber": "101061-00"
  },
  {
    "centro": "LA LINDA",
    "codPres": "0872",
    "codSaber": "101062-00"
  },
  {
    "centro": "REPÚBLICA DE MÉXICO",
    "codPres": "0873",
    "codSaber": "101063-00"
  },
  {
    "centro": "PALMITAL",
    "codPres": "0874",
    "codSaber": "101064-00"
  },
  {
    "centro": "CARLOS LUIS VALVERDE VEGA",
    "codPres": "0875",
    "codSaber": "101065-00"
  },
  {
    "centro": "LA PIÑERA",
    "codPres": "0876",
    "codSaber": "101066-00"
  },
  {
    "centro": "LA PIEDRA",
    "codPres": "0877",
    "codSaber": "101067-00"
  },
  {
    "centro": "LA REPUNTA",
    "codPres": "0878",
    "codSaber": "101068-00"
  },
  {
    "centro": "LA SIERRA",
    "codPres": "0879",
    "codSaber": "101069-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "0880",
    "codSaber": "101070-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "0881",
    "codSaber": "101071-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "0882",
    "codSaber": "101072-00"
  },
  {
    "centro": "LAGARTO",
    "codPres": "0883",
    "codSaber": "101073-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "0884",
    "codSaber": "101074-00"
  },
  {
    "centro": "LAGUNA",
    "codPres": "0885",
    "codSaber": "101075-00"
  },
  {
    "centro": "LAS BONITAS",
    "codPres": "0886",
    "codSaber": "101076-00"
  },
  {
    "centro": "COCORÍ",
    "codPres": "0887",
    "codSaber": "101077-00"
  },
  {
    "centro": "LAS JUNTAS DE PACUAR",
    "codPres": "0888",
    "codSaber": "101078-00"
  },
  {
    "centro": "LAS MERCEDES",
    "codPres": "0889",
    "codSaber": "101079-00"
  },
  {
    "centro": "LAS MESAS",
    "codPres": "0890",
    "codSaber": "101080-00"
  },
  {
    "centro": "LAS PILAS",
    "codPres": "0891",
    "codSaber": "101081-00"
  },
  {
    "centro": "LAS TUMBAS",
    "codPres": "0892",
    "codSaber": "101082-00"
  },
  {
    "centro": "SANTA FÉ",
    "codPres": "0893",
    "codSaber": "101083-00"
  },
  {
    "centro": "LAS VUELTAS",
    "codPres": "0894",
    "codSaber": "101084-00"
  },
  {
    "centro": "LA UVITA",
    "codPres": "0895",
    "codSaber": "101085-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "0896",
    "codSaber": "101086-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "0897",
    "codSaber": "101087-00"
  },
  {
    "centro": "EL LLANO",
    "codPres": "0898",
    "codSaber": "101088-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "0899",
    "codSaber": "101089-00"
  },
  {
    "centro": "IGNACIO DURÁN VEGA",
    "codPres": "0900",
    "codSaber": "101090-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA JOSÉ BREINDERHOFF",
    "codPres": "0901",
    "codSaber": "104060-00"
  },
  {
    "centro": "LOS NARANJOS",
    "codPres": "0902",
    "codSaber": "101092-00"
  },
  {
    "centro": "LOS REYES",
    "codPres": "0903",
    "codSaber": "101093-00"
  },
  {
    "centro": "LA LIRA",
    "codPres": "0904",
    "codSaber": "101094-00"
  },
  {
    "centro": "MAÍZ DE LOS BORUCAS",
    "codPres": "0905",
    "codSaber": "101095-00"
  },
  {
    "centro": "MAÍZ DE LOS UVA",
    "codPres": "0906",
    "codSaber": "101096-00"
  },
  {
    "centro": "LAS CAVERNAS",
    "codPres": "0907",
    "codSaber": "101097-00"
  },
  {
    "centro": "MIRAFLORES",
    "codPres": "0908",
    "codSaber": "101098-00"
  },
  {
    "centro": "MIRAVALLES",
    "codPres": "0909",
    "codSaber": "101099-00"
  },
  {
    "centro": "MOLLEJONES",
    "codPres": "0910",
    "codSaber": "101100-00"
  },
  {
    "centro": "MONTECARLO",
    "codPres": "0911",
    "codSaber": "101101-00"
  },
  {
    "centro": "FRANCISCO MORAZÁN QUESADA",
    "codPres": "0912",
    "codSaber": "101102-00"
  },
  {
    "centro": "MORETE",
    "codPres": "0913",
    "codSaber": "101103-00"
  },
  {
    "centro": "NARANJO",
    "codPres": "0914",
    "codSaber": "101104-00"
  },
  {
    "centro": "OLAN",
    "codPres": "0915",
    "codSaber": "101105-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "0916",
    "codSaber": "101106-00"
  },
  {
    "centro": "BAJO DE VERAGUA",
    "codPres": "0917",
    "codSaber": "101107-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "0919",
    "codSaber": "101109-00"
  },
  {
    "centro": "LAS LAGUNAS",
    "codPres": "0920",
    "codSaber": "101110-00"
  },
  {
    "centro": "ROSARIO ARRÓNIZ",
    "codPres": "0921",
    "codSaber": "101111-00"
  },
  {
    "centro": "HERNÁN RODRÍGUEZ RUÍZ",
    "codPres": "0922",
    "codSaber": "101112-00"
  },
  {
    "centro": "PALMITAL",
    "codPres": "0923",
    "codSaber": "101113-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "0924",
    "codSaber": "101114-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "0925",
    "codSaber": "101115-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "0926",
    "codSaber": "101116-00"
  },
  {
    "centro": "SANTA ANA",
    "codPres": "0927",
    "codSaber": "101117-00"
  },
  {
    "centro": "PAVONES",
    "codPres": "0928",
    "codSaber": "101118-00"
  },
  {
    "centro": "PEÑAS BLANCAS",
    "codPres": "0929",
    "codSaber": "101119-00"
  },
  {
    "centro": "MIXTA PEDREGOSO",
    "codPres": "0931",
    "codSaber": "101121-00"
  },
  {
    "centro": "PACUARITO",
    "codPres": "0933",
    "codSaber": "101122-00"
  },
  {
    "centro": "PLATANARES",
    "codPres": "0934",
    "codSaber": "101123-00"
  },
  {
    "centro": "POTRERO GRANDE",
    "codPres": "0935",
    "codSaber": "101124-00"
  },
  {
    "centro": "MARÍA MORA UREÑA",
    "codPres": "0936",
    "codSaber": "101125-00"
  },
  {
    "centro": "LA DIBUJADA",
    "codPres": "0937",
    "codSaber": "101126-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "0938",
    "codSaber": "101127-00"
  },
  {
    "centro": "PUNTO DE MIRA",
    "codPres": "0939",
    "codSaber": "101128-00"
  },
  {
    "centro": "QUEBRADAS",
    "codPres": "0940",
    "codSaber": "101129-00"
  },
  {
    "centro": "LA VIRGEN",
    "codPres": "0941",
    "codSaber": "101130-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0942",
    "codSaber": "101131-00"
  },
  {
    "centro": "PILÓN",
    "codPres": "0943",
    "codSaber": "101132-00"
  },
  {
    "centro": "RÍO GRANDE",
    "codPres": "0944",
    "codSaber": "101133-00"
  },
  {
    "centro": "RÍO GRANDE",
    "codPres": "0945",
    "codSaber": "101134-00"
  },
  {
    "centro": "ZAPOTAL",
    "codPres": "0946",
    "codSaber": "101135-00"
  },
  {
    "centro": "JUAN VALVERDE MORA",
    "codPres": "0947",
    "codSaber": "101136-00"
  },
  {
    "centro": "LA REINA",
    "codPres": "0948",
    "codSaber": "101137-00"
  },
  {
    "centro": "LAS JUNTAS",
    "codPres": "0949",
    "codSaber": "101138-00"
  },
  {
    "centro": "RÍO AZUL",
    "codPres": "0950",
    "codSaber": "101139-00"
  },
  {
    "centro": "SAN ANTONIO ABAJO",
    "codPres": "0951",
    "codSaber": "101140-00"
  },
  {
    "centro": "ALTO DE LA TRINIDAD",
    "codPres": "0952",
    "codSaber": "101141-00"
  },
  {
    "centro": "RODRIGO FACIO BRENES",
    "codPres": "0953",
    "codSaber": "101142-00"
  },
  {
    "centro": "LÍDER ROGELIO FERNÁNDEZ GÜELL",
    "codPres": "0954",
    "codSaber": "101143-00"
  },
  {
    "centro": "SAN AGUSTÍN",
    "codPres": "0955",
    "codSaber": "101144-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "0956",
    "codSaber": "101145-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "0957",
    "codSaber": "101146-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "0958",
    "codSaber": "101147-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "0959",
    "codSaber": "101148-00"
  },
  {
    "centro": "SAN BLAS",
    "codPres": "0960",
    "codSaber": "101149-00"
  },
  {
    "centro": "SAN JUAN BOSCO",
    "codPres": "0961",
    "codSaber": "101150-00"
  },
  {
    "centro": "SAN CARLOS",
    "codPres": "0962",
    "codSaber": "101151-00"
  },
  {
    "centro": "SAN CAYETANO",
    "codPres": "0963",
    "codSaber": "101152-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "0964",
    "codSaber": "101153-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "0965",
    "codSaber": "101154-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "0966",
    "codSaber": "101155-00"
  },
  {
    "centro": "SAN GERARDO DE PLATANARES",
    "codPres": "0967",
    "codSaber": "101156-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "0968",
    "codSaber": "101157-00"
  },
  {
    "centro": "SAN JUAN DE DIOS",
    "codPres": "0969",
    "codSaber": "101158-00"
  },
  {
    "centro": "SAN JUAN MIRAMAR",
    "codPres": "0970",
    "codSaber": "101159-00"
  },
  {
    "centro": "SAN JUAN NORTE",
    "codPres": "0971",
    "codSaber": "101160-00"
  },
  {
    "centro": "JOSÉ MARÍA CHAVERRI PICADO",
    "codPres": "0972",
    "codSaber": "101161-00"
  },
  {
    "centro": "SAN LORENZO",
    "codPres": "0973",
    "codSaber": "101162-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "0974",
    "codSaber": "101163-00"
  },
  {
    "centro": "SAN MARCOS",
    "codPres": "0975",
    "codSaber": "101164-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "0976",
    "codSaber": "101165-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "0977",
    "codSaber": "101166-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "0978",
    "codSaber": "101167-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "0980",
    "codSaber": "101169-00"
  },
  {
    "centro": "SAN PEDRITO",
    "codPres": "0981",
    "codSaber": "101170-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "0982",
    "codSaber": "101171-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "0983",
    "codSaber": "101172-00"
  },
  {
    "centro": "MELICO SALAZAR ZÚÑIGA",
    "codPres": "0984",
    "codSaber": "101173-00"
  },
  {
    "centro": "SAN RAMÓN NORTE",
    "codPres": "0985",
    "codSaber": "101174-00"
  },
  {
    "centro": "BAJO LAS BRISAS",
    "codPres": "0986",
    "codSaber": "101175-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "0987",
    "codSaber": "101176-00"
  },
  {
    "centro": "GUSTAVO AGÜERO BARRANTES",
    "codPres": "0988",
    "codSaber": "101177-00"
  },
  {
    "centro": "FLORENCIA DE MATAZANOS",
    "codPres": "0989",
    "codSaber": "101178-00"
  },
  {
    "centro": "SAN SALVADOR",
    "codPres": "0990",
    "codSaber": "101179-00"
  },
  {
    "centro": "SANTA EDUVIGES",
    "codPres": "0992",
    "codSaber": "101180-00"
  },
  {
    "centro": "SANTA CRUZ",
    "codPres": "0993",
    "codSaber": "101181-00"
  },
  {
    "centro": "EL PEJE",
    "codPres": "0994",
    "codSaber": "101182-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "0995",
    "codSaber": "101183-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "0996",
    "codSaber": "101184-00"
  },
  {
    "centro": "SANTA LUCÍA DE PEJIBAYE",
    "codPres": "0997",
    "codSaber": "101185-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "0998",
    "codSaber": "101186-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "0999",
    "codSaber": "101187-00"
  },
  {
    "centro": "JUAN RAFAEL MORA PORRAS",
    "codPres": "1000",
    "codSaber": "101188-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "1001",
    "codSaber": "101189-00"
  },
  {
    "centro": "LAS CRUCES",
    "codPres": "1002",
    "codSaber": "101190-00"
  },
  {
    "centro": "SANTIAGO",
    "codPres": "1003",
    "codSaber": "101191-00"
  },
  {
    "centro": "SANTO TOMÁS",
    "codPres": "1004",
    "codSaber": "101192-00"
  },
  {
    "centro": "SAVEGRE",
    "codPres": "1005",
    "codSaber": "101193-00"
  },
  {
    "centro": "SINAÍ",
    "codPres": "1006",
    "codSaber": "101194-00"
  },
  {
    "centro": "SAN JOSECITO",
    "codPres": "1007",
    "codSaber": "101195-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1008",
    "codSaber": "101196-00"
  },
  {
    "centro": "SAN RAFAEL DE PLATANARES",
    "codPres": "1009",
    "codSaber": "101197-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "1010",
    "codSaber": "101198-00"
  },
  {
    "centro": "TÉRRABA",
    "codPres": "1011",
    "codSaber": "101199-00"
  },
  {
    "centro": "TRES PIEDRAS",
    "codPres": "1012",
    "codSaber": "101200-00"
  },
  {
    "centro": "UJARRÁS",
    "codPres": "1013",
    "codSaber": "101201-00"
  },
  {
    "centro": "VALENCIA",
    "codPres": "1014",
    "codSaber": "101202-00"
  },
  {
    "centro": "VALLE DE LA CRUZ",
    "codPres": "1015",
    "codSaber": "101203-00"
  },
  {
    "centro": "VERACRUZ",
    "codPres": "1016",
    "codSaber": "101204-00"
  },
  {
    "centro": "VILLA ARGENTINA",
    "codPres": "1017",
    "codSaber": "101205-00"
  },
  {
    "centro": "VILLA BONITA",
    "codPres": "1018",
    "codSaber": "101206-00"
  },
  {
    "centro": "VILLA LIGIA",
    "codPres": "1019",
    "codSaber": "101207-00"
  },
  {
    "centro": "VILLA NUEVA",
    "codPres": "1020",
    "codSaber": "101208-00"
  },
  {
    "centro": "VISTA DE MAR",
    "codPres": "1021",
    "codSaber": "101209-00"
  },
  {
    "centro": "VOLCÁN",
    "codPres": "1022",
    "codSaber": "101210-00"
  },
  {
    "centro": "EL JORÓN",
    "codPres": "1023",
    "codSaber": "101211-00"
  },
  {
    "centro": "DOMINICALITO",
    "codPres": "1024",
    "codSaber": "101212-00"
  },
  {
    "centro": "QUEBRADA HONDA",
    "codPres": "1025",
    "codSaber": "101213-00"
  },
  {
    "centro": "EL ZAPOTE",
    "codPres": "1026",
    "codSaber": "101214-00"
  },
  {
    "centro": "LA ARENILLA",
    "codPres": "1027",
    "codSaber": "101215-00"
  },
  {
    "centro": "12 DE MARZO DE 1948",
    "codPres": "1028",
    "codSaber": "101216-00"
  },
  {
    "centro": "SAN IGNACIO",
    "codPres": "1029",
    "codSaber": "101217-00"
  },
  {
    "centro": "EL TRÉBOL",
    "codPres": "1030",
    "codSaber": "101218-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "1031",
    "codSaber": "101219-00"
  },
  {
    "centro": "CAPRI",
    "codPres": "1032",
    "codSaber": "101220-00"
  },
  {
    "centro": "CALDERÓN",
    "codPres": "1033",
    "codSaber": "101221-00"
  },
  {
    "centro": "BIOLLEY",
    "codPres": "1034",
    "codSaber": "101222-00"
  },
  {
    "centro": "SAN CARLOS",
    "codPres": "1035",
    "codSaber": "101223-00"
  },
  {
    "centro": "ALTAMIRA",
    "codPres": "1036",
    "codSaber": "101224-00"
  },
  {
    "centro": "ZAPOTAL",
    "codPres": "1037",
    "codSaber": "101225-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1038",
    "codSaber": "101226-00"
  },
  {
    "centro": "SAN RAFAEL ARRIBA",
    "codPres": "1039",
    "codSaber": "101227-00"
  },
  {
    "centro": "EL PUENTE",
    "codPres": "1040",
    "codSaber": "101228-00"
  },
  {
    "centro": "ALTAMIRA",
    "codPres": "1041",
    "codSaber": "101229-00"
  },
  {
    "centro": "CLAVERA",
    "codPres": "1043",
    "codSaber": "101231-00"
  },
  {
    "centro": "LA RIBERA",
    "codPres": "1044",
    "codSaber": "101232-00"
  },
  {
    "centro": "CHONTALES",
    "codPres": "1045",
    "codSaber": "101233-00"
  },
  {
    "centro": "EL PILAR",
    "codPres": "1046",
    "codSaber": "101234-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "1047",
    "codSaber": "101235-00"
  },
  {
    "centro": "JALISCO",
    "codPres": "1048",
    "codSaber": "101236-00"
  },
  {
    "centro": "MOCTEZUMA",
    "codPres": "1049",
    "codSaber": "101237-00"
  },
  {
    "centro": "LA TINTA",
    "codPres": "1050",
    "codSaber": "101238-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "1051",
    "codSaber": "101239-00"
  },
  {
    "centro": "LA GLORIA",
    "codPres": "1052",
    "codSaber": "101240-00"
  },
  {
    "centro": "YUAVIN",
    "codPres": "1053",
    "codSaber": "101241-00"
  },
  {
    "centro": "QUEBRADA BONITA",
    "codPres": "1054",
    "codSaber": "101242-00"
  },
  {
    "centro": "LA BONGA",
    "codPres": "1055",
    "codSaber": "101243-00"
  },
  {
    "centro": "BAJOS DE MAMEY",
    "codPres": "1056",
    "codSaber": "101244-00"
  },
  {
    "centro": "TIERRAS MORENAS",
    "codPres": "1057",
    "codSaber": "101245-00"
  },
  {
    "centro": "TINAMASTE",
    "codPres": "1059",
    "codSaber": "101246-00"
  },
  {
    "centro": "LA PUNA",
    "codPres": "1060",
    "codSaber": "101247-00"
  },
  {
    "centro": "EL CACAO",
    "codPres": "1061",
    "codSaber": "101248-00"
  },
  {
    "centro": "EL PÁRAMO",
    "codPres": "1062",
    "codSaber": "101249-00"
  },
  {
    "centro": "SIKÉBATA",
    "codPres": "1063",
    "codSaber": "101250-00"
  },
  {
    "centro": "ALTO DE LA PERLA",
    "codPres": "1064",
    "codSaber": "101251-00"
  },
  {
    "centro": "LAS VEGAS",
    "codPres": "1065",
    "codSaber": "101252-00"
  },
  {
    "centro": "EL CACIQUE",
    "codPres": "1066",
    "codSaber": "101253-00"
  },
  {
    "centro": "LOS VEGA",
    "codPres": "1067",
    "codSaber": "101254-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1068",
    "codSaber": "101255-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "1069",
    "codSaber": "101256-00"
  },
  {
    "centro": "TIERRA PROMETIDA",
    "codPres": "1070",
    "codSaber": "101257-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "1071",
    "codSaber": "101258-00"
  },
  {
    "centro": "SANTO DOMINGO",
    "codPres": "1072",
    "codSaber": "101259-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "1073",
    "codSaber": "101260-00"
  },
  {
    "centro": "PALMIRA",
    "codPres": "1074",
    "codSaber": "101261-00"
  },
  {
    "centro": "CALIFORNIA",
    "codPres": "1076",
    "codSaber": "101262-00"
  },
  {
    "centro": "LA FLOR DE BAHÍA",
    "codPres": "1077",
    "codSaber": "101263-00"
  },
  {
    "centro": "SÁBALO",
    "codPres": "1078",
    "codSaber": "101264-00"
  },
  {
    "centro": "LOS NARANJOS",
    "codPres": "1079",
    "codSaber": "101265-00"
  },
  {
    "centro": "MALLAL",
    "codPres": "1080",
    "codSaber": "101266-00"
  },
  {
    "centro": "GUATUSA",
    "codPres": "1081",
    "codSaber": "101267-00"
  },
  {
    "centro": "AEROPUERTO",
    "codPres": "1083",
    "codSaber": "101268-00"
  },
  {
    "centro": "ALFREDO GÓMEZ ZAMORA",
    "codPres": "1084",
    "codSaber": "101269-00"
  },
  {
    "centro": "MIGUEL HIDALGO BASTOS",
    "codPres": "1085",
    "codSaber": "101270-00"
  },
  {
    "centro": "I.D.A. SALINAS",
    "codPres": "1086",
    "codSaber": "101271-00"
  },
  {
    "centro": "DR. RAFAEL ÁNGEL CALDERÓN GUARDIA",
    "codPres": "1087",
    "codSaber": "101272-00"
  },
  {
    "centro": "GUADALAJARA",
    "codPres": "1088",
    "codSaber": "101273-00"
  },
  {
    "centro": "ALTO LÓPEZ",
    "codPres": "1089",
    "codSaber": "101274-00"
  },
  {
    "centro": "LA PRADERA",
    "codPres": "1090",
    "codSaber": "101275-00"
  },
  {
    "centro": "FÁTIMA",
    "codPres": "1091",
    "codSaber": "101276-00"
  },
  {
    "centro": "JOSÉ MIGUEL ZUMBADO SOTO",
    "codPres": "1092",
    "codSaber": "101277-00"
  },
  {
    "centro": "ALTOS DE NARANJO",
    "codPres": "1093",
    "codSaber": "101278-00"
  },
  {
    "centro": "JOSE MANUEL PERALTA QUESADA",
    "codPres": "1094",
    "codSaber": "101279-00"
  },
  {
    "centro": "EL ACHIOTE",
    "codPres": "1095",
    "codSaber": "101280-00"
  },
  {
    "centro": "LAGOS DEL COYOL",
    "codPres": "1096",
    "codSaber": "101281-00"
  },
  {
    "centro": "NICOLÁS CHACÓN VARGAS",
    "codPres": "1097",
    "codSaber": "101282-00"
  },
  {
    "centro": "LA LAGUNA",
    "codPres": "1098",
    "codSaber": "101283-00"
  },
  {
    "centro": "CALIFORNIA",
    "codPres": "1099",
    "codSaber": "101284-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "1100",
    "codSaber": "101285-00"
  },
  {
    "centro": "CALLE LILES",
    "codPres": "1101",
    "codSaber": "101286-00"
  },
  {
    "centro": "BARROETA",
    "codPres": "1102",
    "codSaber": "101287-00"
  },
  {
    "centro": "BARTOLOMÉ ANDROVETTO GARELLO",
    "codPres": "1103",
    "codSaber": "101288-00"
  },
  {
    "centro": "BERNARDO SOTO ALFARO",
    "codPres": "1104",
    "codSaber": "101289-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "1105",
    "codSaber": "101290-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1106",
    "codSaber": "101291-00"
  },
  {
    "centro": "PACTO DEL JOCOTE",
    "codPres": "1107",
    "codSaber": "101292-00"
  },
  {
    "centro": "RINCÓN DE HERRERA",
    "codPres": "1108",
    "codSaber": "101293-00"
  },
  {
    "centro": "CARLOS MARÍA RODRÍGUEZ",
    "codPres": "1109",
    "codSaber": "101294-00"
  },
  {
    "centro": "MANUEL FRANCISCO CARRILLO SABORÍO",
    "codPres": "1110",
    "codSaber": "101295-00"
  },
  {
    "centro": "JACINTO PANIAGUA RODRÍGUEZ",
    "codPres": "1111",
    "codSaber": "101296-00"
  },
  {
    "centro": "ASCENSIÓN ESQUIVEL IBARRA",
    "codPres": "1112",
    "codSaber": "101297-00"
  },
  {
    "centro": "SAN LUIS DE CARRILLOS",
    "codPres": "1113",
    "codSaber": "101298-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "1114",
    "codSaber": "101299-00"
  },
  {
    "centro": "RINCÓN DE CACAO",
    "codPres": "1115",
    "codSaber": "101300-00"
  },
  {
    "centro": "RICARDO BATALLA PÉREZ",
    "codPres": "1116",
    "codSaber": "101301-00"
  },
  {
    "centro": "LA CATALUÑA",
    "codPres": "1117",
    "codSaber": "101302-00"
  },
  {
    "centro": "VICTOR ARGÜELLO MURILLO",
    "codPres": "1118",
    "codSaber": "101303-00"
  },
  {
    "centro": "CENTRAL DE ATENAS",
    "codPres": "1119",
    "codSaber": "101304-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "1120",
    "codSaber": "101305-00"
  },
  {
    "centro": "CHILAMATE",
    "codPres": "1121",
    "codSaber": "101306-00"
  },
  {
    "centro": "MIGUEL RODRÍGUEZ VILLARREAL",
    "codPres": "1122",
    "codSaber": "101307-00"
  },
  {
    "centro": "CHUCAZ",
    "codPres": "1123",
    "codSaber": "101308-00"
  },
  {
    "centro": "I.E.G.B. MARÍA VARGAS RODRÍGUEZ",
    "codPres": "1124",
    "codSaber": "101309-00"
  },
  {
    "centro": "SANTA FE",
    "codPres": "1125",
    "codSaber": "101310-00"
  },
  {
    "centro": "THOMAS JEFFERSON",
    "codPres": "1126",
    "codSaber": "101311-00"
  },
  {
    "centro": "NUEVA SANTA RITA",
    "codPres": "1127",
    "codSaber": "101312-00"
  },
  {
    "centro": "ARTURO QUIRÓS CARRANZA",
    "codPres": "1128",
    "codSaber": "101313-00"
  },
  {
    "centro": "ROBERTO CASTRO VARGAS",
    "codPres": "1129",
    "codSaber": "101314-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "1130",
    "codSaber": "101315-00"
  },
  {
    "centro": "I.M.A.S.",
    "codPres": "1131",
    "codSaber": "101316-00"
  },
  {
    "centro": "MARIO AGÜERO GONZÁLEZ",
    "codPres": "1132",
    "codSaber": "101317-00"
  },
  {
    "centro": "RAFAEL ALBERTO LUNA HERRERA",
    "codPres": "1133",
    "codSaber": "101318-00"
  },
  {
    "centro": "FRAIJANES",
    "codPres": "1134",
    "codSaber": "101319-00"
  },
  {
    "centro": "CARBONAL",
    "codPres": "1135",
    "codSaber": "101320-00"
  },
  {
    "centro": "PAVAS",
    "codPres": "1136",
    "codSaber": "101321-00"
  },
  {
    "centro": "POASITO",
    "codPres": "1137",
    "codSaber": "101322-00"
  },
  {
    "centro": "DESAMPARADOS",
    "codPres": "1138",
    "codSaber": "101323-00"
  },
  {
    "centro": "MANUELA SANTAMARÍA",
    "codPres": "1139",
    "codSaber": "101324-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "1140",
    "codSaber": "101325-00"
  },
  {
    "centro": "SILVIA MONTERO ZAMORA",
    "codPres": "1141",
    "codSaber": "101326-00"
  },
  {
    "centro": "JESÚS MAGDALENO VARGAS AGUILAR",
    "codPres": "1142",
    "codSaber": "101327-00"
  },
  {
    "centro": "HOLANDA",
    "codPres": "1143",
    "codSaber": "101328-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "1144",
    "codSaber": "101329-00"
  },
  {
    "centro": "JULIO PEÑA MORUA",
    "codPres": "1146",
    "codSaber": "101331-00"
  },
  {
    "centro": "ALTOS DE CAJÓN",
    "codPres": "1147",
    "codSaber": "101332-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "1148",
    "codSaber": "101333-00"
  },
  {
    "centro": "CARLOS MANUEL ROJAS QUIRÓS",
    "codPres": "1149",
    "codSaber": "101334-00"
  },
  {
    "centro": "TOMÁS SANDOVAL",
    "codPres": "1150",
    "codSaber": "101335-00"
  },
  {
    "centro": "ESTANQUILLOS",
    "codPres": "1151",
    "codSaber": "101336-00"
  },
  {
    "centro": "EULOGIA RUIZ RUIZ",
    "codPres": "1152",
    "codSaber": "101337-00"
  },
  {
    "centro": "GUÁCIMO",
    "codPres": "1153",
    "codSaber": "101338-00"
  },
  {
    "centro": "JOSÉ MANUEL HERRERA SALAS",
    "codPres": "1154",
    "codSaber": "101339-00"
  },
  {
    "centro": "HACIENDA VIEJA",
    "codPres": "1155",
    "codSaber": "101340-00"
  },
  {
    "centro": "ITIQUÍS",
    "codPres": "1156",
    "codSaber": "101341-00"
  },
  {
    "centro": "JESÚS DE ATENAS",
    "codPres": "1157",
    "codSaber": "101342-00"
  },
  {
    "centro": "ROGELIO SOTELA BONILLA",
    "codPres": "1158",
    "codSaber": "101343-00"
  },
  {
    "centro": "JESÚS OCAÑA ROJAS",
    "codPres": "1159",
    "codSaber": "101344-00"
  },
  {
    "centro": "GENERAL JOSÉ DE SAN MARTÍN",
    "codPres": "1160",
    "codSaber": "101345-00"
  },
  {
    "centro": "J.N. JUAN RAFAEL MEOÑO HIDALGO",
    "codPres": "1161",
    "codSaber": "101346-00"
  },
  {
    "centro": "JUAN RAFAEL MEOÑO HIDALGO",
    "codPres": "1162",
    "codSaber": "101347-00"
  },
  {
    "centro": "JUAN SANTAMARÍA",
    "codPres": "1163",
    "codSaber": "101348-00"
  },
  {
    "centro": "JULIA FERNÁNDEZ DE CORTÉS",
    "codPres": "1164",
    "codSaber": "101349-00"
  },
  {
    "centro": "FRANCISCO ALFARO ROJAS",
    "codPres": "1165",
    "codSaber": "101350-00"
  },
  {
    "centro": "LA BALSA",
    "codPres": "1166",
    "codSaber": "101351-00"
  },
  {
    "centro": "GABRIELA MISTRAL",
    "codPres": "1167",
    "codSaber": "101352-00"
  },
  {
    "centro": "RAMÓN HERRERO VITORIA",
    "codPres": "1169",
    "codSaber": "101353-00"
  },
  {
    "centro": "LABRADOR",
    "codPres": "1170",
    "codSaber": "101354-00"
  },
  {
    "centro": "ENRIQUE RIBA MORELLA",
    "codPres": "1171",
    "codSaber": "101355-00"
  },
  {
    "centro": "TRANQUILINO VÍQUEZ RODRÍGUEZ",
    "codPres": "1172",
    "codSaber": "101356-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1173",
    "codSaber": "101357-00"
  },
  {
    "centro": "MADERAL",
    "codPres": "1174",
    "codSaber": "101358-00"
  },
  {
    "centro": "RAMONA SOSA MORENO",
    "codPres": "1175",
    "codSaber": "101359-00"
  },
  {
    "centro": "MONSEÑOR SANABRIA MARTÍNEZ",
    "codPres": "1176",
    "codSaber": "101360-00"
  },
  {
    "centro": "MIGUEL OBREGÓN LIZANO",
    "codPres": "1177",
    "codSaber": "101361-00"
  },
  {
    "centro": "MAURILIO SOTO ALFARO",
    "codPres": "1178",
    "codSaber": "101362-00"
  },
  {
    "centro": "MORAZÁN",
    "codPres": "1179",
    "codSaber": "101363-00"
  },
  {
    "centro": "ONCE DE ABRIL",
    "codPres": "1180",
    "codSaber": "101364-00"
  },
  {
    "centro": "PARCELAS DEL I.T.C.O.",
    "codPres": "1181",
    "codSaber": "101365-00"
  },
  {
    "centro": "EDUARDO PINTO HERNÁNDEZ",
    "codPres": "1182",
    "codSaber": "101366-00"
  },
  {
    "centro": "PRIMO VARGAS VALVERDE",
    "codPres": "1183",
    "codSaber": "101367-00"
  },
  {
    "centro": "PUENTE DE PIEDRA",
    "codPres": "1184",
    "codSaber": "101368-00"
  },
  {
    "centro": "QUEBRADAS",
    "codPres": "1185",
    "codSaber": "101369-00"
  },
  {
    "centro": "RAMADAS",
    "codPres": "1186",
    "codSaber": "101370-00"
  },
  {
    "centro": "REPÚBLICA DE GUATEMALA",
    "codPres": "1187",
    "codSaber": "101371-00"
  },
  {
    "centro": "J.N. REPÚBLICA DE GUATEMALA",
    "codPres": "1188",
    "codSaber": "101372-00"
  },
  {
    "centro": "RICARDO FERNÁNDEZ GUARDIA",
    "codPres": "1189",
    "codSaber": "101373-00"
  },
  {
    "centro": "JUAN ARRIETA MIRANDA",
    "codPres": "1190",
    "codSaber": "101374-00"
  },
  {
    "centro": "MARÍA TERESA OBREGÓN LORÍA",
    "codPres": "1191",
    "codSaber": "101375-00"
  },
  {
    "centro": "DAVID GONZÁLEZ ALFARO",
    "codPres": "1192",
    "codSaber": "101376-00"
  },
  {
    "centro": "ERMIDA BLANCO GONZÁLEZ",
    "codPres": "1193",
    "codSaber": "101377-00"
  },
  {
    "centro": "TIMOLEÓN MORERA SOTO",
    "codPres": "1194",
    "codSaber": "101378-00"
  },
  {
    "centro": "SABANA LARGA",
    "codPres": "1195",
    "codSaber": "101379-00"
  },
  {
    "centro": "MONSEÑOR DELFÍN QUESADA CASTRO",
    "codPres": "1196",
    "codSaber": "101380-00"
  },
  {
    "centro": "LUIS FELIPE GONZÁLEZ FLORES",
    "codPres": "1197",
    "codSaber": "101381-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "1198",
    "codSaber": "101382-00"
  },
  {
    "centro": "ALBERTO ECHANDI MONTERO",
    "codPres": "1199",
    "codSaber": "101383-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1200",
    "codSaber": "101384-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "1201",
    "codSaber": "101385-00"
  },
  {
    "centro": "SAN JOSÉ NORTE",
    "codPres": "1202",
    "codSaber": "101386-00"
  },
  {
    "centro": "SAN JOSÉ SUR",
    "codPres": "1203",
    "codSaber": "101387-00"
  },
  {
    "centro": "SAN JUAN SUR",
    "codPres": "1204",
    "codSaber": "101388-00"
  },
  {
    "centro": "SAN JUAN NORTE",
    "codPres": "1205",
    "codSaber": "101389-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "1206",
    "codSaber": "101390-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "1207",
    "codSaber": "101391-00"
  },
  {
    "centro": "JOSÉ JOAQUÍN MORA SIBAJA",
    "codPres": "1208",
    "codSaber": "101392-00"
  },
  {
    "centro": "SAN MIGUEL ABAJO",
    "codPres": "1209",
    "codSaber": "101393-00"
  },
  {
    "centro": "PEDRO AGUIRRE CERDA",
    "codPres": "1210",
    "codSaber": "101394-00"
  },
  {
    "centro": "LUIS RODRÍGUEZ SALAS",
    "codPres": "1211",
    "codSaber": "101395-00"
  },
  {
    "centro": "ENRIQUE PINTO FERNÁNDEZ",
    "codPres": "1212",
    "codSaber": "101396-00"
  },
  {
    "centro": "ALICE MOYA RODRÍGUEZ",
    "codPres": "1213",
    "codSaber": "101397-00"
  },
  {
    "centro": "OTTO KOPPER STEFFENS",
    "codPres": "1214",
    "codSaber": "101398-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "1215",
    "codSaber": "101399-00"
  },
  {
    "centro": "SANTA EULALIA",
    "codPres": "1216",
    "codSaber": "101400-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "1217",
    "codSaber": "101401-00"
  },
  {
    "centro": "SIMÓN BOLÍVAR PALACIOS",
    "codPres": "1218",
    "codSaber": "101402-00"
  },
  {
    "centro": "RAUL ROJAS RODRÍGUEZ",
    "codPres": "1219",
    "codSaber": "101403-00"
  },
  {
    "centro": "MIXTA DE SIQUIARES",
    "codPres": "1220",
    "codSaber": "101404-00"
  },
  {
    "centro": "JULIA FERNÁNDEZ RODRÍGUEZ",
    "codPres": "1221",
    "codSaber": "101405-00"
  },
  {
    "centro": "URBANO OVIEDO ALFARO",
    "codPres": "1222",
    "codSaber": "101406-00"
  },
  {
    "centro": "SANTA GERTRUDIS SUR",
    "codPres": "1223",
    "codSaber": "101407-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "1224",
    "codSaber": "101408-00"
  },
  {
    "centro": "LUIS SIBAJA GARCÍA",
    "codPres": "1225",
    "codSaber": "101409-00"
  },
  {
    "centro": "SILVESTRE ROJAS MURILLO",
    "codPres": "1226",
    "codSaber": "101410-00"
  },
  {
    "centro": "DR. ADOLFO JIMÉNEZ DE LA GUARDIA",
    "codPres": "1227",
    "codSaber": "101411-00"
  },
  {
    "centro": "TOBÍAS GUZMÁN BRENES",
    "codPres": "1228",
    "codSaber": "101412-00"
  },
  {
    "centro": "MARIANA MADRIGAL DE LA O.",
    "codPres": "1229",
    "codSaber": "101413-00"
  },
  {
    "centro": "TURRUCARES",
    "codPres": "1230",
    "codSaber": "101414-00"
  },
  {
    "centro": "NUEVA DE LOS ALTOS",
    "codPres": "1231",
    "codSaber": "101415-00"
  },
  {
    "centro": "CINCO ESQUINAS",
    "codPres": "1232",
    "codSaber": "101416-00"
  },
  {
    "centro": "EL CAJÓN",
    "codPres": "1233",
    "codSaber": "101417-00"
  },
  {
    "centro": "ALTO DEL MONTE",
    "codPres": "1234",
    "codSaber": "101418-00"
  },
  {
    "centro": "INVU LAS CAÑAS",
    "codPres": "1235",
    "codSaber": "101419-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "1236",
    "codSaber": "101420-00"
  },
  {
    "centro": "VILLA BONITA",
    "codPres": "1237",
    "codSaber": "101421-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1238",
    "codSaber": "101422-00"
  },
  {
    "centro": "TUETAL SUR",
    "codPres": "1239",
    "codSaber": "101423-00"
  },
  {
    "centro": "RINCÓN CHIQUITO",
    "codPres": "1240",
    "codSaber": "101424-00"
  },
  {
    "centro": "UNIÓN DE ROSALES",
    "codPres": "1241",
    "codSaber": "101425-00"
  },
  {
    "centro": "ALBERTO MANUEL BRENES MORA",
    "codPres": "1242",
    "codSaber": "101426-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "1243",
    "codSaber": "101427-00"
  },
  {
    "centro": "GERARDO BADILLA MORA",
    "codPres": "1244",
    "codSaber": "101428-00"
  },
  {
    "centro": "ALFONSO MONGE RAMÍREZ",
    "codPres": "1245",
    "codSaber": "101429-00"
  },
  {
    "centro": "SAN JORGE LAS ROCAS",
    "codPres": "1246",
    "codSaber": "101430-00"
  },
  {
    "centro": "BAJO TAPEZCO",
    "codPres": "1248",
    "codSaber": "101431-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "1249",
    "codSaber": "101432-00"
  },
  {
    "centro": "BARRIO EL CARMEN",
    "codPres": "1250",
    "codSaber": "101433-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1251",
    "codSaber": "101434-00"
  },
  {
    "centro": "ÁNGELES NORTE",
    "codPres": "1252",
    "codSaber": "101435-00"
  },
  {
    "centro": "FÉLIX ÁNGEL SALAS CABEZAS",
    "codPres": "1253",
    "codSaber": "101436-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1254",
    "codSaber": "101437-00"
  },
  {
    "centro": "ARNULFO ARIAS MADRID",
    "codPres": "1255",
    "codSaber": "101438-00"
  },
  {
    "centro": "DANIEL SOLÓRZANO MURILLO",
    "codPres": "1256",
    "codSaber": "101439-00"
  },
  {
    "centro": "BAJO MATAMOROS",
    "codPres": "1257",
    "codSaber": "101440-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA RURAL BAJOS DE TORO AMARILLO",
    "codPres": "1258",
    "codSaber": "104711-00"
  },
  {
    "centro": "BALBOA",
    "codPres": "1259",
    "codSaber": "101442-00"
  },
  {
    "centro": "EL LLANO",
    "codPres": "1260",
    "codSaber": "101443-00"
  },
  {
    "centro": "PATA DE GALLO",
    "codPres": "1261",
    "codSaber": "101444-00"
  },
  {
    "centro": "ABRAHAM PANIAGUA NÚÑEZ",
    "codPres": "1262",
    "codSaber": "101445-00"
  },
  {
    "centro": "LA LEGUA",
    "codPres": "1263",
    "codSaber": "101446-00"
  },
  {
    "centro": "FERNANDO CASTRO LÓPEZ",
    "codPres": "1264",
    "codSaber": "101447-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "1265",
    "codSaber": "101448-00"
  },
  {
    "centro": "BAJO CÓRDOBA",
    "codPres": "1266",
    "codSaber": "101449-00"
  },
  {
    "centro": "CAÑUELA",
    "codPres": "1267",
    "codSaber": "101450-00"
  },
  {
    "centro": "YADIRA GAMBOA ALFARO",
    "codPres": "1268",
    "codSaber": "101451-00"
  },
  {
    "centro": "GABINO ARAYA BLANCO",
    "codPres": "1269",
    "codSaber": "101452-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1270",
    "codSaber": "101453-00"
  },
  {
    "centro": "JACINTO ÁVILA ARAYA",
    "codPres": "1271",
    "codSaber": "101454-00"
  },
  {
    "centro": "EL CRUCE DE CIRRÍ",
    "codPres": "1272",
    "codSaber": "101455-00"
  },
  {
    "centro": "CARLOS MARÍA JIMÉNEZ ORTÍZ",
    "codPres": "1273",
    "codSaber": "101456-00"
  },
  {
    "centro": "DR. CARLOS LUIS VALVERDE VEGA",
    "codPres": "1274",
    "codSaber": "101457-00"
  },
  {
    "centro": "CAROLINA RODRÍGUEZ DE MIRAMBELL",
    "codPres": "1275",
    "codSaber": "101458-00"
  },
  {
    "centro": "CARRERA BUENA",
    "codPres": "1276",
    "codSaber": "101459-00"
  },
  {
    "centro": "COLONIA I.D.A. ANATERI",
    "codPres": "1278",
    "codSaber": "101460-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "1279",
    "codSaber": "101461-00"
  },
  {
    "centro": "VALLE AZUL",
    "codPres": "1280",
    "codSaber": "101462-00"
  },
  {
    "centro": "LOS JARDINES",
    "codPres": "1281",
    "codSaber": "101463-00"
  },
  {
    "centro": "FERMÍN RODRÍGUEZ CORDERO",
    "codPres": "1283",
    "codSaber": "101465-00"
  },
  {
    "centro": "LA PALMITA",
    "codPres": "1284",
    "codSaber": "101466-00"
  },
  {
    "centro": "EL ROSARIO",
    "codPres": "1285",
    "codSaber": "101467-00"
  },
  {
    "centro": "EL SALVADOR",
    "codPres": "1286",
    "codSaber": "101468-00"
  },
  {
    "centro": "ERMELINDA MORA CARVAJAL",
    "codPres": "1287",
    "codSaber": "101469-00"
  },
  {
    "centro": "ERMIDA BLANCO GONZÁLEZ",
    "codPres": "1288",
    "codSaber": "101470-00"
  },
  {
    "centro": "FEDERICO SALAS CARVAJAL",
    "codPres": "1289",
    "codSaber": "101471-00"
  },
  {
    "centro": "FÉLIX VILLALOBOS VARGAS",
    "codPres": "1290",
    "codSaber": "101472-00"
  },
  {
    "centro": "FRANCISCO JOSÉ ORLICH BOLMARCICH",
    "codPres": "1291",
    "codSaber": "101473-00"
  },
  {
    "centro": "GEORGINA BOLMARCICH DE ORLICH",
    "codPres": "1292",
    "codSaber": "101474-00"
  },
  {
    "centro": "HELÍ SANTAMARÍA NAVARRO",
    "codPres": "1293",
    "codSaber": "101475-00"
  },
  {
    "centro": "EIDA VARGAS CARRANZA",
    "codPres": "1294",
    "codSaber": "101476-00"
  },
  {
    "centro": "ALTO CASTRO",
    "codPres": "1295",
    "codSaber": "101477-00"
  },
  {
    "centro": "JOAQUÍN LORENZO SANCHO QUESADA",
    "codPres": "1296",
    "codSaber": "101478-00"
  },
  {
    "centro": "JORGE WASHINGTON",
    "codPres": "1297",
    "codSaber": "101479-00"
  },
  {
    "centro": "J.N. FELICITAS RAMÍREZ VEGA",
    "codPres": "1298",
    "codSaber": "101480-00"
  },
  {
    "centro": "PBRO. JOSÉ DEL OLMO",
    "codPres": "1299",
    "codSaber": "101481-00"
  },
  {
    "centro": "JOSÉ VALENCIANO ARRIETA",
    "codPres": "1300",
    "codSaber": "101482-00"
  },
  {
    "centro": "JUAN SANTAMARÍA",
    "codPres": "1301",
    "codSaber": "101483-00"
  },
  {
    "centro": "JUDAS TADEO CORRALES SAÉNZ",
    "codPres": "1302",
    "codSaber": "101484-00"
  },
  {
    "centro": "JULIA FERNÁNDEZ RODRÍGUEZ",
    "codPres": "1303",
    "codSaber": "101485-00"
  },
  {
    "centro": "LA BALSA",
    "codPres": "1304",
    "codSaber": "101486-00"
  },
  {
    "centro": "LA BRISA",
    "codPres": "1305",
    "codSaber": "101487-00"
  },
  {
    "centro": "LA CONSTANCIA",
    "codPres": "1306",
    "codSaber": "101488-00"
  },
  {
    "centro": "LA CUEVA",
    "codPres": "1307",
    "codSaber": "101489-00"
  },
  {
    "centro": "JULIÁN VOLIO LLORENTE",
    "codPres": "1308",
    "codSaber": "101490-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1309",
    "codSaber": "101491-00"
  },
  {
    "centro": "ÁLVARO TERÁN SECO",
    "codPres": "1310",
    "codSaber": "101492-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "1311",
    "codSaber": "101493-00"
  },
  {
    "centro": "ELISEO ARREDONDO BLANCO",
    "codPres": "1312",
    "codSaber": "101494-00"
  },
  {
    "centro": "RAMÓN BARQUERO SALAS",
    "codPres": "1313",
    "codSaber": "101495-00"
  },
  {
    "centro": "LA PICADA",
    "codPres": "1314",
    "codSaber": "101496-00"
  },
  {
    "centro": "SAN MIGUEL OESTE",
    "codPres": "1315",
    "codSaber": "101497-00"
  },
  {
    "centro": "JOSÉ JOAQUÍN SALAS PÉREZ",
    "codPres": "1316",
    "codSaber": "101498-00"
  },
  {
    "centro": "BAJO SAN ANTONIO",
    "codPres": "1317",
    "codSaber": "101499-00"
  },
  {
    "centro": "LISÍMACO CHAVARRÍA PALMA",
    "codPres": "1318",
    "codSaber": "101500-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "1319",
    "codSaber": "101501-00"
  },
  {
    "centro": "LLANO BRENES",
    "codPres": "1320",
    "codSaber": "101502-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "1321",
    "codSaber": "101503-00"
  },
  {
    "centro": "LORENZO GONZÁLEZ ARGUEDAS",
    "codPres": "1322",
    "codSaber": "101504-00"
  },
  {
    "centro": "LOS CRIQUES",
    "codPres": "1323",
    "codSaber": "101505-00"
  },
  {
    "centro": "LOS PINOS",
    "codPres": "1324",
    "codSaber": "101506-00"
  },
  {
    "centro": "LOS ROBLES",
    "codPres": "1325",
    "codSaber": "101507-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "1326",
    "codSaber": "101508-00"
  },
  {
    "centro": "MACARIO VALVERDE MADRIGAL",
    "codPres": "1327",
    "codSaber": "101509-00"
  },
  {
    "centro": "J.N. MANUEL BERNARDO GÓMEZ",
    "codPres": "1328",
    "codSaber": "101510-00"
  },
  {
    "centro": "PBRO. MANUEL BERNARDO GÓMEZ SALAZAR",
    "codPres": "1329",
    "codSaber": "101511-00"
  },
  {
    "centro": "MANUEL QUESADA BASTOS",
    "codPres": "1330",
    "codSaber": "101512-00"
  },
  {
    "centro": "MERCEDES QUESADA QUESADA",
    "codPres": "1331",
    "codSaber": "101513-00"
  },
  {
    "centro": "MIGUEL CARBALLO CORRALES",
    "codPres": "1332",
    "codSaber": "101514-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1333",
    "codSaber": "101515-00"
  },
  {
    "centro": "MONSEÑOR JUAN VICENTE SOLÍS FERNÁNDEZ",
    "codPres": "1334",
    "codSaber": "101516-00"
  },
  {
    "centro": "MONSEÑOR CLODOVEO HIDALGO SOLANO",
    "codPres": "1335",
    "codSaber": "101517-00"
  },
  {
    "centro": "MORELOS",
    "codPres": "1336",
    "codSaber": "101518-00"
  },
  {
    "centro": "NAUTILIO ACOSTA PIEPPER",
    "codPres": "1337",
    "codSaber": "101519-00"
  },
  {
    "centro": "RUPERTO ZÚÑIGA SANCHO",
    "codPres": "1338",
    "codSaber": "101520-00"
  },
  {
    "centro": "OTILIO ULATE BLANCO",
    "codPres": "1339",
    "codSaber": "101521-00"
  },
  {
    "centro": "SALUSTIO CAMACHO MUÑOZ",
    "codPres": "1340",
    "codSaber": "101522-00"
  },
  {
    "centro": "PALMITOS",
    "codPres": "1341",
    "codSaber": "101523-00"
  },
  {
    "centro": "PETERS",
    "codPres": "1342",
    "codSaber": "101524-00"
  },
  {
    "centro": "JUAN JOSÉ VALVERDE MADRIGAL",
    "codPres": "1343",
    "codSaber": "101525-00"
  },
  {
    "centro": "QUEBRADILLAS",
    "codPres": "1344",
    "codSaber": "101526-00"
  },
  {
    "centro": "REPÚBLICA DE URUGUAY",
    "codPres": "1345",
    "codSaber": "101527-00"
  },
  {
    "centro": "REPÚBLICA DE COLOMBIA",
    "codPres": "1346",
    "codSaber": "101528-00"
  },
  {
    "centro": "REPÚBLICA DE CUBA",
    "codPres": "1347",
    "codSaber": "101529-00"
  },
  {
    "centro": "REPÚBLICA DEL ECUADOR",
    "codPres": "1348",
    "codSaber": "101530-00"
  },
  {
    "centro": "DR. RICARDO MORENO CAÑAS",
    "codPres": "1349",
    "codSaber": "101531-00"
  },
  {
    "centro": "RINCÓN DE MORA",
    "codPres": "1350",
    "codSaber": "101532-00"
  },
  {
    "centro": "PABLO ALVARADO VARGAS",
    "codPres": "1351",
    "codSaber": "101533-00"
  },
  {
    "centro": "RÍO GRANDE",
    "codPres": "1352",
    "codSaber": "101534-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1353",
    "codSaber": "101535-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "1354",
    "codSaber": "101536-00"
  },
  {
    "centro": "MIXTA SAN RAFAEL",
    "codPres": "1355",
    "codSaber": "101537-00"
  },
  {
    "centro": "SAN ROQUE",
    "codPres": "1356",
    "codSaber": "101538-00"
  },
  {
    "centro": "SANTIAGO",
    "codPres": "1357",
    "codSaber": "101539-00"
  },
  {
    "centro": "SANTIAGO CRESPO CALVO",
    "codPres": "1358",
    "codSaber": "101540-00"
  },
  {
    "centro": "SARCHÍ NORTE",
    "codPres": "1359",
    "codSaber": "101541-00"
  },
  {
    "centro": "EULOGIO SALAZAR LARA",
    "codPres": "1360",
    "codSaber": "101542-00"
  },
  {
    "centro": "SIMÓN BOLÍVAR",
    "codPres": "1361",
    "codSaber": "101543-00"
  },
  {
    "centro": "JULIO ULATE GONZÁLEZ",
    "codPres": "1362",
    "codSaber": "101544-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1363",
    "codSaber": "101545-00"
  },
  {
    "centro": "SANTA MARGARITA",
    "codPres": "1364",
    "codSaber": "101546-00"
  },
  {
    "centro": "PBRO. VENANCIO DE OÑA Y MARTÍNEZ",
    "codPres": "1365",
    "codSaber": "101547-00"
  },
  {
    "centro": "COOPEZAMORA",
    "codPres": "1366",
    "codSaber": "101548-00"
  },
  {
    "centro": "CALLE SAN MIGUEL",
    "codPres": "1367",
    "codSaber": "101549-00"
  },
  {
    "centro": "ZAPOTE",
    "codPres": "1368",
    "codSaber": "101550-00"
  },
  {
    "centro": "LABORATORIO",
    "codPres": "1369",
    "codSaber": "101551-00"
  },
  {
    "centro": "ISABEL YGLESIAS CASTRO",
    "codPres": "1370",
    "codSaber": "101552-00"
  },
  {
    "centro": "RINCÓN DE OROZCO",
    "codPres": "1371",
    "codSaber": "101553-00"
  },
  {
    "centro": "SABANILLA",
    "codPres": "1372",
    "codSaber": "101554-00"
  },
  {
    "centro": "EL SOCORRO",
    "codPres": "1373",
    "codSaber": "101555-00"
  },
  {
    "centro": "POTRERILLOS",
    "codPres": "1374",
    "codSaber": "101556-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1375",
    "codSaber": "101557-00"
  },
  {
    "centro": "LA PERLA",
    "codPres": "1376",
    "codSaber": "101558-00"
  },
  {
    "centro": "EL CASTILLO",
    "codPres": "1377",
    "codSaber": "101559-00"
  },
  {
    "centro": "MONTECRISTO",
    "codPres": "1378",
    "codSaber": "101560-00"
  },
  {
    "centro": "ABELARDO ROJAS QUESADA",
    "codPres": "1379",
    "codSaber": "101561-00"
  },
  {
    "centro": "DOS AGUAS",
    "codPres": "1380",
    "codSaber": "101562-00"
  },
  {
    "centro": "EL CONCHITO",
    "codPres": "1381",
    "codSaber": "101563-00"
  },
  {
    "centro": "AGUA AZUL",
    "codPres": "1382",
    "codSaber": "101564-00"
  },
  {
    "centro": "LAS PALMAS",
    "codPres": "1383",
    "codSaber": "101565-00"
  },
  {
    "centro": "COLONIA PARÍS",
    "codPres": "1384",
    "codSaber": "101566-00"
  },
  {
    "centro": "PENJAMO",
    "codPres": "1385",
    "codSaber": "101567-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1386",
    "codSaber": "101568-00"
  },
  {
    "centro": "TRES Y TRES",
    "codPres": "1387",
    "codSaber": "101569-00"
  },
  {
    "centro": "MARIO SALAZAR MORA",
    "codPres": "1388",
    "codSaber": "101570-00"
  },
  {
    "centro": "BARRIO LOS ÁNGELES",
    "codPres": "1389",
    "codSaber": "101571-00"
  },
  {
    "centro": "CAÑO CASTILLA",
    "codPres": "1390",
    "codSaber": "101572-00"
  },
  {
    "centro": "ALTAMIRA",
    "codPres": "1391",
    "codSaber": "101573-00"
  },
  {
    "centro": "EL RECREO",
    "codPres": "1392",
    "codSaber": "101574-00"
  },
  {
    "centro": "COOPE SAN JUAN",
    "codPres": "1393",
    "codSaber": "101575-00"
  },
  {
    "centro": "SANGREGADO",
    "codPres": "1394",
    "codSaber": "101576-00"
  },
  {
    "centro": "LA PRADERA",
    "codPres": "1395",
    "codSaber": "101577-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "1396",
    "codSaber": "101578-00"
  },
  {
    "centro": "LUIS GAMBOA ARAYA",
    "codPres": "1397",
    "codSaber": "101579-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "1398",
    "codSaber": "101580-00"
  },
  {
    "centro": "COOPEVEGA",
    "codPres": "1399",
    "codSaber": "101581-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1400",
    "codSaber": "101582-00"
  },
  {
    "centro": "BOCA DE RÍO CUREÑA",
    "codPres": "1401",
    "codSaber": "101583-00"
  },
  {
    "centro": "EL FUTURO",
    "codPres": "1402",
    "codSaber": "101584-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "1403",
    "codSaber": "101585-00"
  },
  {
    "centro": "BONANZA",
    "codPres": "1404",
    "codSaber": "101586-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1405",
    "codSaber": "101587-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1406",
    "codSaber": "101588-00"
  },
  {
    "centro": "TRES AMIGOS",
    "codPres": "1407",
    "codSaber": "101589-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1408",
    "codSaber": "101590-00"
  },
  {
    "centro": "LA URRACA",
    "codPres": "1409",
    "codSaber": "101591-00"
  },
  {
    "centro": "ESCALERAS",
    "codPres": "1410",
    "codSaber": "101592-00"
  },
  {
    "centro": "HERNÁNDEZ",
    "codPres": "1411",
    "codSaber": "101593-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1412",
    "codSaber": "101594-00"
  },
  {
    "centro": "LA TROCHA",
    "codPres": "1413",
    "codSaber": "101595-00"
  },
  {
    "centro": "COLONIA NARANJEÑA",
    "codPres": "1414",
    "codSaber": "101596-00"
  },
  {
    "centro": "I.D.A. GARABITO",
    "codPres": "1415",
    "codSaber": "101597-00"
  },
  {
    "centro": "COOPE ISABEL",
    "codPres": "1416",
    "codSaber": "101598-00"
  },
  {
    "centro": "EL CAMPO",
    "codPres": "1417",
    "codSaber": "101599-00"
  },
  {
    "centro": "SANTA ESPERANZA",
    "codPres": "1418",
    "codSaber": "101600-00"
  },
  {
    "centro": "I.D.A. LOS LAGOS",
    "codPres": "1419",
    "codSaber": "101601-00"
  },
  {
    "centro": "CAIMITOS",
    "codPres": "1420",
    "codSaber": "101602-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1421",
    "codSaber": "101603-00"
  },
  {
    "centro": "EL ACHIOTE",
    "codPres": "1422",
    "codSaber": "101604-00"
  },
  {
    "centro": "LA CASCADA",
    "codPres": "1423",
    "codSaber": "101605-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "1424",
    "codSaber": "101606-00"
  },
  {
    "centro": "LA ESPAÑOLITA",
    "codPres": "1425",
    "codSaber": "101607-00"
  },
  {
    "centro": "YUCATAN",
    "codPres": "1426",
    "codSaber": "101608-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "1427",
    "codSaber": "101609-00"
  },
  {
    "centro": "TRECE DE NOVIEMBRE",
    "codPres": "1428",
    "codSaber": "101610-00"
  },
  {
    "centro": "CARRIZAL",
    "codPres": "1429",
    "codSaber": "101611-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1430",
    "codSaber": "101612-00"
  },
  {
    "centro": "SAN ALEJO",
    "codPres": "1431",
    "codSaber": "101613-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "1432",
    "codSaber": "101614-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "1433",
    "codSaber": "101615-00"
  },
  {
    "centro": "EL JAÚURI",
    "codPres": "1434",
    "codSaber": "101616-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "1435",
    "codSaber": "101617-00"
  },
  {
    "centro": "I.D.A. EL RUBÍ",
    "codPres": "1436",
    "codSaber": "101618-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "1437",
    "codSaber": "101619-00"
  },
  {
    "centro": "JUAN RAFAEL CHACÓN CASTRO",
    "codPres": "1438",
    "codSaber": "101620-00"
  },
  {
    "centro": "BOCA DEL RÍO SAN CARLOS",
    "codPres": "1439",
    "codSaber": "101621-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1441",
    "codSaber": "101622-00"
  },
  {
    "centro": "EL COROZO DE PATASTE",
    "codPres": "1443",
    "codSaber": "101623-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "1444",
    "codSaber": "101624-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "1445",
    "codSaber": "101625-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "1446",
    "codSaber": "101626-00"
  },
  {
    "centro": "EL BURIO",
    "codPres": "1447",
    "codSaber": "101627-00"
  },
  {
    "centro": "ACAPULCO",
    "codPres": "1448",
    "codSaber": "101628-00"
  },
  {
    "centro": "LA VIRGEN",
    "codPres": "1449",
    "codSaber": "101629-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "1450",
    "codSaber": "101630-00"
  },
  {
    "centro": "CAÑO CIEGO",
    "codPres": "1451",
    "codSaber": "101631-00"
  },
  {
    "centro": "LEÓNIDAS SEQUEIRA DUARTE",
    "codPres": "1452",
    "codSaber": "101632-00"
  },
  {
    "centro": "NUEVA ESPERANZA",
    "codPres": "1453",
    "codSaber": "101633-00"
  },
  {
    "centro": "MONTEALEGRE",
    "codPres": "1454",
    "codSaber": "101634-00"
  },
  {
    "centro": "SANTA FE",
    "codPres": "1455",
    "codSaber": "101635-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "1456",
    "codSaber": "101636-00"
  },
  {
    "centro": "CHAPARRÓN",
    "codPres": "1457",
    "codSaber": "101637-00"
  },
  {
    "centro": "SAN VITO",
    "codPres": "1458",
    "codSaber": "101638-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "1459",
    "codSaber": "101639-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1460",
    "codSaber": "101640-00"
  },
  {
    "centro": "LA PAZ",
    "codPres": "1461",
    "codSaber": "101641-00"
  },
  {
    "centro": "CANANEO",
    "codPres": "1462",
    "codSaber": "101642-00"
  },
  {
    "centro": "POCOSOL",
    "codPres": "1463",
    "codSaber": "101643-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "1464",
    "codSaber": "101644-00"
  },
  {
    "centro": "LOS CERRITOS",
    "codPres": "1465",
    "codSaber": "101645-00"
  },
  {
    "centro": "EL PINAR",
    "codPres": "1466",
    "codSaber": "101646-00"
  },
  {
    "centro": "CARIBLANCO",
    "codPres": "1467",
    "codSaber": "101647-00"
  },
  {
    "centro": "CARLOS MAROTO QUIRÓS",
    "codPres": "1468",
    "codSaber": "101648-00"
  },
  {
    "centro": "MORAZÁN",
    "codPres": "1469",
    "codSaber": "101649-00"
  },
  {
    "centro": "EL PLOMO",
    "codPres": "1470",
    "codSaber": "101650-00"
  },
  {
    "centro": "CERRO CORTÉS",
    "codPres": "1472",
    "codSaber": "101651-00"
  },
  {
    "centro": "SAMEN",
    "codPres": "1473",
    "codSaber": "101652-00"
  },
  {
    "centro": "ARCO IRIS",
    "codPres": "1474",
    "codSaber": "101653-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "1475",
    "codSaber": "101654-00"
  },
  {
    "centro": "CARRIZAL",
    "codPres": "1476",
    "codSaber": "101655-00"
  },
  {
    "centro": "LA FLOR",
    "codPres": "1477",
    "codSaber": "101656-00"
  },
  {
    "centro": "CHAMBACU",
    "codPres": "1478",
    "codSaber": "101657-00"
  },
  {
    "centro": "SANTA FE",
    "codPres": "1479",
    "codSaber": "101658-00"
  },
  {
    "centro": "VIENTO FRESCO",
    "codPres": "1480",
    "codSaber": "101659-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1481",
    "codSaber": "101660-00"
  },
  {
    "centro": "COCOBOLO",
    "codPres": "1482",
    "codSaber": "101661-00"
  },
  {
    "centro": "EL ENCANTO",
    "codPres": "1484",
    "codSaber": "101662-00"
  },
  {
    "centro": "MAJAGUA",
    "codPres": "1485",
    "codSaber": "101663-00"
  },
  {
    "centro": "CASTELMARE",
    "codPres": "1486",
    "codSaber": "101664-00"
  },
  {
    "centro": "LOS ALMENDROS",
    "codPres": "1487",
    "codSaber": "101665-00"
  },
  {
    "centro": "COLONIA TORO AMARILLO",
    "codPres": "1488",
    "codSaber": "101666-00"
  },
  {
    "centro": "EL ABÁNICO",
    "codPres": "1489",
    "codSaber": "101667-00"
  },
  {
    "centro": "SECTOR ÁNGELES",
    "codPres": "1490",
    "codSaber": "101668-00"
  },
  {
    "centro": "COQUITALES",
    "codPres": "1491",
    "codSaber": "101669-00"
  },
  {
    "centro": "CARLOS MARÍA VÁSQUEZ ROJAS",
    "codPres": "1492",
    "codSaber": "101670-00"
  },
  {
    "centro": "EL CONCHO",
    "codPres": "1493",
    "codSaber": "101671-00"
  },
  {
    "centro": "CURIRE",
    "codPres": "1494",
    "codSaber": "101672-00"
  },
  {
    "centro": "QUIJONGO",
    "codPres": "1495",
    "codSaber": "101673-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "1496",
    "codSaber": "101674-00"
  },
  {
    "centro": "SONAFLUCA",
    "codPres": "1497",
    "codSaber": "101675-00"
  },
  {
    "centro": "VILLA MARÍA",
    "codPres": "1498",
    "codSaber": "101676-00"
  },
  {
    "centro": "GERMÁN ROJAS ARAYA",
    "codPres": "1499",
    "codSaber": "101677-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "1500",
    "codSaber": "101678-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "1501",
    "codSaber": "101679-00"
  },
  {
    "centro": "EL CÓBANO",
    "codPres": "1502",
    "codSaber": "101680-00"
  },
  {
    "centro": "GUARUMAL",
    "codPres": "1503",
    "codSaber": "101681-00"
  },
  {
    "centro": "SAN ANDRÉS",
    "codPres": "1504",
    "codSaber": "101682-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "1506",
    "codSaber": "101684-00"
  },
  {
    "centro": "CUESTILLAS",
    "codPres": "1507",
    "codSaber": "101685-00"
  },
  {
    "centro": "PUERTO NUEVO",
    "codPres": "1508",
    "codSaber": "101686-00"
  },
  {
    "centro": "EL EDÉN",
    "codPres": "1509",
    "codSaber": "101687-00"
  },
  {
    "centro": "PITALITO SUR",
    "codPres": "1510",
    "codSaber": "101688-00"
  },
  {
    "centro": "LA ORQUÍDEA",
    "codPres": "1511",
    "codSaber": "101689-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "1512",
    "codSaber": "101690-00"
  },
  {
    "centro": "CEDRAL",
    "codPres": "1513",
    "codSaber": "101691-00"
  },
  {
    "centro": "EL COMBATE",
    "codPres": "1514",
    "codSaber": "101692-00"
  },
  {
    "centro": "SAN JOSÉ DE LA MONTAÑA",
    "codPres": "1515",
    "codSaber": "101693-00"
  },
  {
    "centro": "LA VICTORIA",
    "codPres": "1516",
    "codSaber": "101694-00"
  },
  {
    "centro": "ESTERITO",
    "codPres": "1517",
    "codSaber": "101695-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1518",
    "codSaber": "101696-00"
  },
  {
    "centro": "EL JOBO",
    "codPres": "1519",
    "codSaber": "101697-00"
  },
  {
    "centro": "EL MOLINO",
    "codPres": "1520",
    "codSaber": "101698-00"
  },
  {
    "centro": "EL PALMAR",
    "codPres": "1521",
    "codSaber": "101699-00"
  },
  {
    "centro": "EL PEJE",
    "codPres": "1522",
    "codSaber": "101700-00"
  },
  {
    "centro": "CARMEN LIDIA CASTRO RODRÍGUEZ",
    "codPres": "1523",
    "codSaber": "101701-00"
  },
  {
    "centro": "LOS ALPES",
    "codPres": "1524",
    "codSaber": "101702-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "1525",
    "codSaber": "101703-00"
  },
  {
    "centro": "EL TANQUE",
    "codPres": "1526",
    "codSaber": "101704-00"
  },
  {
    "centro": "EL SAINO",
    "codPres": "1527",
    "codSaber": "101705-00"
  },
  {
    "centro": "CLEMENTE MARÍN RODRÍGUEZ",
    "codPres": "1528",
    "codSaber": "101706-00"
  },
  {
    "centro": "ENTRE RÍOS",
    "codPres": "1529",
    "codSaber": "101707-00"
  },
  {
    "centro": "ERMIDA BLANCO GONZÁLEZ",
    "codPres": "1530",
    "codSaber": "101708-00"
  },
  {
    "centro": "JUANILAMA",
    "codPres": "1531",
    "codSaber": "101709-00"
  },
  {
    "centro": "ARISTIDES ROMAÍN",
    "codPres": "1532",
    "codSaber": "101710-00"
  },
  {
    "centro": "ANTONIO JOSÉ DE SUCRE",
    "codPres": "1533",
    "codSaber": "101711-00"
  },
  {
    "centro": "I.D.A. LAS MARÍAS",
    "codPres": "1534",
    "codSaber": "101712-00"
  },
  {
    "centro": "LAS NUBES",
    "codPres": "1535",
    "codSaber": "101713-00"
  },
  {
    "centro": "ULIMA",
    "codPres": "1537",
    "codSaber": "101715-00"
  },
  {
    "centro": "ISLA CHICA",
    "codPres": "1538",
    "codSaber": "101716-00"
  },
  {
    "centro": "JUAN BAUTISTA SOLÍS RODRÍGUEZ",
    "codPres": "1539",
    "codSaber": "101717-00"
  },
  {
    "centro": "JUAN CHAVES ROJAS",
    "codPres": "1540",
    "codSaber": "101718-00"
  },
  {
    "centro": "JUAN MANSO ESTÉVEZ",
    "codPres": "1541",
    "codSaber": "101719-00"
  },
  {
    "centro": "JUAN SANTAMARÍA",
    "codPres": "1542",
    "codSaber": "101720-00"
  },
  {
    "centro": "LA CABANGA",
    "codPres": "1543",
    "codSaber": "101721-00"
  },
  {
    "centro": "LA CEIBA",
    "codPres": "1544",
    "codSaber": "101722-00"
  },
  {
    "centro": "PROCOPIO GAMBOA VILLALOBOS",
    "codPres": "1545",
    "codSaber": "101723-00"
  },
  {
    "centro": "LA FLOR",
    "codPres": "1546",
    "codSaber": "101724-00"
  },
  {
    "centro": "CRUCITAS",
    "codPres": "1547",
    "codSaber": "101725-00"
  },
  {
    "centro": "LA FORTUNA",
    "codPres": "1548",
    "codSaber": "101726-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1549",
    "codSaber": "101727-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "1550",
    "codSaber": "101728-00"
  },
  {
    "centro": "LA LEGUA",
    "codPres": "1551",
    "codSaber": "101729-00"
  },
  {
    "centro": "LA PALMERA",
    "codPres": "1552",
    "codSaber": "101730-00"
  },
  {
    "centro": "LA NUEVA LUCHA",
    "codPres": "1553",
    "codSaber": "101731-00"
  },
  {
    "centro": "LA TABLA",
    "codPres": "1554",
    "codSaber": "101732-00"
  },
  {
    "centro": "ECOLÓGICA LA TIGRA",
    "codPres": "1555",
    "codSaber": "101733-00"
  },
  {
    "centro": "LA TIGRA",
    "codPres": "1556",
    "codSaber": "101734-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "1557",
    "codSaber": "101735-00"
  },
  {
    "centro": "BOCA TAPADA",
    "codPres": "1558",
    "codSaber": "101736-00"
  },
  {
    "centro": "EL PAVÓN",
    "codPres": "1559",
    "codSaber": "101737-00"
  },
  {
    "centro": "LAS BANDERAS",
    "codPres": "1560",
    "codSaber": "101738-00"
  },
  {
    "centro": "COQUITAL",
    "codPres": "1561",
    "codSaber": "101739-00"
  },
  {
    "centro": "RÍO TICO",
    "codPres": "1562",
    "codSaber": "101740-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1563",
    "codSaber": "101741-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "1564",
    "codSaber": "101742-00"
  },
  {
    "centro": "LA VEGA",
    "codPres": "1565",
    "codSaber": "101743-00"
  },
  {
    "centro": "JOSÉ RODRÍGUEZ MARTÍNEZ",
    "codPres": "1566",
    "codSaber": "101744-00"
  },
  {
    "centro": "LAS DELICIAS VENADO",
    "codPres": "1567",
    "codSaber": "101745-00"
  },
  {
    "centro": "LAS MERCEDES",
    "codPres": "1568",
    "codSaber": "101746-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "1570",
    "codSaber": "101747-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1571",
    "codSaber": "101748-00"
  },
  {
    "centro": "LA TIRICIA",
    "codPres": "1572",
    "codSaber": "101749-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1573",
    "codSaber": "101750-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA RÍO CELESTE",
    "codPres": "1574",
    "codSaber": "104839-00"
  },
  {
    "centro": "ÁNGELES DE LA COLONIA SUR",
    "codPres": "1575",
    "codSaber": "101752-00"
  },
  {
    "centro": "JOSÉ SÁNCHEZ CHAVARRÍA",
    "codPres": "1576",
    "codSaber": "101753-00"
  },
  {
    "centro": "CHIMURRIA",
    "codPres": "1577",
    "codSaber": "101754-00"
  },
  {
    "centro": "RICARDO VARGAS MURILLO",
    "codPres": "1578",
    "codSaber": "101755-00"
  },
  {
    "centro": "LOS CHILES",
    "codPres": "1579",
    "codSaber": "101756-00"
  },
  {
    "centro": "LOS CORRALES",
    "codPres": "1580",
    "codSaber": "101757-00"
  },
  {
    "centro": "LOS LLANOS",
    "codPres": "1581",
    "codSaber": "101758-00"
  },
  {
    "centro": "JUAN FÉLIX ESTRADA",
    "codPres": "1582",
    "codSaber": "101759-00"
  },
  {
    "centro": "MEDIO QUESO",
    "codPres": "1583",
    "codSaber": "101760-00"
  },
  {
    "centro": "MIRADOR",
    "codPres": "1585",
    "codSaber": "101761-00"
  },
  {
    "centro": "MONTERREY",
    "codPres": "1586",
    "codSaber": "101762-00"
  },
  {
    "centro": "SAN CRISTÓBAL",
    "codPres": "1587",
    "codSaber": "101763-00"
  },
  {
    "centro": "EL BOTIJO",
    "codPres": "1588",
    "codSaber": "101764-00"
  },
  {
    "centro": "MONTEALEGRE",
    "codPres": "1589",
    "codSaber": "101765-00"
  },
  {
    "centro": "EL CRUCE",
    "codPres": "1590",
    "codSaber": "101766-00"
  },
  {
    "centro": "PALENQUE MARGARITA",
    "codPres": "1591",
    "codSaber": "101767-00"
  },
  {
    "centro": "LAUREL GALÁN",
    "codPres": "1592",
    "codSaber": "101768-00"
  },
  {
    "centro": "FINCA ZETA TRECE",
    "codPres": "1593",
    "codSaber": "101769-00"
  },
  {
    "centro": "LLANO VERDE",
    "codPres": "1594",
    "codSaber": "101770-00"
  },
  {
    "centro": "PALMITAL",
    "codPres": "1595",
    "codSaber": "101771-00"
  },
  {
    "centro": "PATASTE",
    "codPres": "1596",
    "codSaber": "101772-00"
  },
  {
    "centro": "PATASTILLO",
    "codPres": "1597",
    "codSaber": "101773-00"
  },
  {
    "centro": "PEJIBAYE",
    "codPres": "1598",
    "codSaber": "101774-00"
  },
  {
    "centro": "CERRO BLANCO",
    "codPres": "1599",
    "codSaber": "101775-00"
  },
  {
    "centro": "GONZALO MONGE BERMÚDEZ",
    "codPres": "1600",
    "codSaber": "101776-00"
  },
  {
    "centro": "PLATANAR",
    "codPres": "1601",
    "codSaber": "101777-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "1602",
    "codSaber": "101778-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1603",
    "codSaber": "101779-00"
  },
  {
    "centro": "LA GLORIA",
    "codPres": "1604",
    "codSaber": "101780-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1605",
    "codSaber": "101781-00"
  },
  {
    "centro": "PORVENIR",
    "codPres": "1606",
    "codSaber": "101782-00"
  },
  {
    "centro": "ESQUIPULAS",
    "codPres": "1607",
    "codSaber": "101783-00"
  },
  {
    "centro": "PUENTE CASA",
    "codPres": "1608",
    "codSaber": "101784-00"
  },
  {
    "centro": "PUERTO SECO",
    "codPres": "1609",
    "codSaber": "101785-00"
  },
  {
    "centro": "PUNTA CORTÉS",
    "codPres": "1610",
    "codSaber": "101786-00"
  },
  {
    "centro": "QUEBRADÓN",
    "codPres": "1611",
    "codSaber": "101787-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "1612",
    "codSaber": "101788-00"
  },
  {
    "centro": "RÍO CUARTO",
    "codPres": "1613",
    "codSaber": "101789-00"
  },
  {
    "centro": "PATASTILLO",
    "codPres": "1614",
    "codSaber": "101790-00"
  },
  {
    "centro": "PUEBLO VIEJO",
    "codPres": "1615",
    "codSaber": "101791-00"
  },
  {
    "centro": "EL BOSQUE",
    "codPres": "1616",
    "codSaber": "101792-00"
  },
  {
    "centro": "LUIS DEMETRIO TINOCO",
    "codPres": "1617",
    "codSaber": "101793-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "1618",
    "codSaber": "101794-00"
  },
  {
    "centro": "SABALITO",
    "codPres": "1619",
    "codSaber": "101795-00"
  },
  {
    "centro": "SABOGAL",
    "codPres": "1620",
    "codSaber": "101796-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "1621",
    "codSaber": "101797-00"
  },
  {
    "centro": "MORAVIA VERDE",
    "codPres": "1622",
    "codSaber": "101798-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "1623",
    "codSaber": "101799-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "1624",
    "codSaber": "101800-00"
  },
  {
    "centro": "SAN CRISTÓBAL",
    "codPres": "1625",
    "codSaber": "101801-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA SAN FRANCISCO",
    "codPres": "1626",
    "codSaber": "101802-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1627",
    "codSaber": "101803-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1628",
    "codSaber": "101804-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "1629",
    "codSaber": "101805-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "1630",
    "codSaber": "101806-00"
  },
  {
    "centro": "HERNAN KOSCHNY CASCANTE",
    "codPres": "1631",
    "codSaber": "101807-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1632",
    "codSaber": "101808-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "1633",
    "codSaber": "101809-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "1634",
    "codSaber": "101810-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "1635",
    "codSaber": "101811-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "1636",
    "codSaber": "101812-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "1637",
    "codSaber": "101813-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "1638",
    "codSaber": "101814-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1639",
    "codSaber": "101815-00"
  },
  {
    "centro": "LAS CUACAS",
    "codPres": "1640",
    "codSaber": "101816-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "1641",
    "codSaber": "101817-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "1642",
    "codSaber": "101818-00"
  },
  {
    "centro": "EMILIO CASTRO GÓMEZ",
    "codPres": "1643",
    "codSaber": "101819-00"
  },
  {
    "centro": "SAN PEDRO DE CUTRIS",
    "codPres": "1644",
    "codSaber": "101820-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1645",
    "codSaber": "101821-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "1647",
    "codSaber": "101822-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "1648",
    "codSaber": "101823-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "1649",
    "codSaber": "101824-00"
  },
  {
    "centro": "REPÚBLICA DE ITALIA",
    "codPres": "1650",
    "codSaber": "101825-00"
  },
  {
    "centro": "SANTA EULALIA",
    "codPres": "1651",
    "codSaber": "101826-00"
  },
  {
    "centro": "SANTA FE",
    "codPres": "1652",
    "codSaber": "101827-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "1653",
    "codSaber": "101828-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "1654",
    "codSaber": "101829-00"
  },
  {
    "centro": "SANTA TERESA NORTE",
    "codPres": "1655",
    "codSaber": "101830-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "1656",
    "codSaber": "101831-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "1657",
    "codSaber": "101832-00"
  },
  {
    "centro": "SAN RAFAEL ABAJO",
    "codPres": "1658",
    "codSaber": "101833-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1659",
    "codSaber": "101834-00"
  },
  {
    "centro": "SAN RAFAEL ARRIBA",
    "codPres": "1660",
    "codSaber": "101835-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "1661",
    "codSaber": "101836-00"
  },
  {
    "centro": "SANTA ISABEL",
    "codPres": "1662",
    "codSaber": "101837-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "1663",
    "codSaber": "101838-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "1664",
    "codSaber": "101839-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "1665",
    "codSaber": "101840-00"
  },
  {
    "centro": "SANTA TERESA SUR",
    "codPres": "1666",
    "codSaber": "101841-00"
  },
  {
    "centro": "DOMINGO VARGAS AGUILAR",
    "codPres": "1667",
    "codSaber": "101842-00"
  },
  {
    "centro": "PALENQUE TONJIBE",
    "codPres": "1668",
    "codSaber": "101843-00"
  },
  {
    "centro": "UJARRÁS",
    "codPres": "1669",
    "codSaber": "101844-00"
  },
  {
    "centro": "VASCONIA",
    "codPres": "1670",
    "codSaber": "101845-00"
  },
  {
    "centro": "JOSÉ MARÍA VARGAS ARIAS",
    "codPres": "1671",
    "codSaber": "101846-00"
  },
  {
    "centro": "OSCAR RULAMÁN SALAS",
    "codPres": "1672",
    "codSaber": "101847-00"
  },
  {
    "centro": "VERACRUZ",
    "codPres": "1673",
    "codSaber": "101848-00"
  },
  {
    "centro": "RANCHO QUEMADO",
    "codPres": "1674",
    "codSaber": "101849-00"
  },
  {
    "centro": "TRES ESQUINAS",
    "codPres": "1675",
    "codSaber": "101850-00"
  },
  {
    "centro": "LA ALTURA",
    "codPres": "1676",
    "codSaber": "101851-00"
  },
  {
    "centro": "EL CACHITO",
    "codPres": "1677",
    "codSaber": "101852-00"
  },
  {
    "centro": "SANTIAGO",
    "codPres": "1678",
    "codSaber": "101853-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "1679",
    "codSaber": "101854-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1681",
    "codSaber": "101855-00"
  },
  {
    "centro": "SAN CAYETANO",
    "codPres": "1682",
    "codSaber": "101856-00"
  },
  {
    "centro": "CRISTO REY",
    "codPres": "1683",
    "codSaber": "101857-00"
  },
  {
    "centro": "COLONIA GUANACASTE",
    "codPres": "1684",
    "codSaber": "101858-00"
  },
  {
    "centro": "GALLO PINTO",
    "codPres": "1685",
    "codSaber": "101859-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "1686",
    "codSaber": "101860-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "1687",
    "codSaber": "101861-00"
  },
  {
    "centro": "PUERTO ESCONDIDO",
    "codPres": "1688",
    "codSaber": "101862-00"
  },
  {
    "centro": "LA CRUZ",
    "codPres": "1689",
    "codSaber": "101863-00"
  },
  {
    "centro": "I.D.A. LAS PARCELAS",
    "codPres": "1692",
    "codSaber": "101865-00"
  },
  {
    "centro": "EL PARQUE",
    "codPres": "1693",
    "codSaber": "101866-00"
  },
  {
    "centro": "SAN MARCOS",
    "codPres": "1694",
    "codSaber": "101867-00"
  },
  {
    "centro": "LA LUCHA",
    "codPres": "1695",
    "codSaber": "101868-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "1696",
    "codSaber": "101869-00"
  },
  {
    "centro": "LA ALDEA",
    "codPres": "1697",
    "codSaber": "101870-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1698",
    "codSaber": "101871-00"
  },
  {
    "centro": "QUEBRADA GRANDE",
    "codPres": "1699",
    "codSaber": "101872-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "1700",
    "codSaber": "101873-00"
  },
  {
    "centro": "EL COYOL",
    "codPres": "1701",
    "codSaber": "101874-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1702",
    "codSaber": "101875-00"
  },
  {
    "centro": "TIMACAR",
    "codPres": "1703",
    "codSaber": "101876-00"
  },
  {
    "centro": "SAN DIEGO",
    "codPres": "1704",
    "codSaber": "101877-00"
  },
  {
    "centro": "SAN FERNANDO",
    "codPres": "1705",
    "codSaber": "101878-00"
  },
  {
    "centro": "MONTELIMAR",
    "codPres": "1706",
    "codSaber": "101879-00"
  },
  {
    "centro": "PASO REAL",
    "codPres": "1707",
    "codSaber": "101880-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "1708",
    "codSaber": "101881-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "1709",
    "codSaber": "101882-00"
  },
  {
    "centro": "AGUAS NEGRAS",
    "codPres": "1710",
    "codSaber": "101883-00"
  },
  {
    "centro": "LAS NIEVES",
    "codPres": "1711",
    "codSaber": "101884-00"
  },
  {
    "centro": "LA TESALIA",
    "codPres": "1712",
    "codSaber": "101885-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "1713",
    "codSaber": "101886-00"
  },
  {
    "centro": "KOOPER MUELLE",
    "codPres": "1714",
    "codSaber": "101887-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "1715",
    "codSaber": "101888-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1716",
    "codSaber": "101889-00"
  },
  {
    "centro": "EL PORVENIR",
    "codPres": "1717",
    "codSaber": "101890-00"
  },
  {
    "centro": "TERRÓN COLORADO",
    "codPres": "1718",
    "codSaber": "101891-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "1719",
    "codSaber": "101892-00"
  },
  {
    "centro": "SAN HUMBERTO",
    "codPres": "1720",
    "codSaber": "101893-00"
  },
  {
    "centro": "RON RON ABAJO",
    "codPres": "1721",
    "codSaber": "101894-00"
  },
  {
    "centro": "LA LUISA",
    "codPres": "1722",
    "codSaber": "101895-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "1723",
    "codSaber": "101896-00"
  },
  {
    "centro": "WINSTON CHURCHILL SPENCER",
    "codPres": "1724",
    "codSaber": "101897-00"
  },
  {
    "centro": "NUESTRA SEÑORA DE FÁTIMA",
    "codPres": "1725",
    "codSaber": "101898-00"
  },
  {
    "centro": "CALLE MESÉN",
    "codPres": "1726",
    "codSaber": "101899-00"
  },
  {
    "centro": "PIEDRA AZUL",
    "codPres": "1727",
    "codSaber": "101900-00"
  },
  {
    "centro": "VILLAS DE AYARCO",
    "codPres": "1728",
    "codSaber": "101901-00"
  },
  {
    "centro": "PRIMO COGHI FERRARI",
    "codPres": "1729",
    "codSaber": "101902-00"
  },
  {
    "centro": "ALTO DE ARAYA",
    "codPres": "1730",
    "codSaber": "101903-00"
  },
  {
    "centro": "GUABATA",
    "codPres": "1731",
    "codSaber": "101904-00"
  },
  {
    "centro": "SAN JOSÉ OBRERO",
    "codPres": "1732",
    "codSaber": "101905-00"
  },
  {
    "centro": "LA SABANA",
    "codPres": "1733",
    "codSaber": "101906-00"
  },
  {
    "centro": "JABONCILLO",
    "codPres": "1734",
    "codSaber": "101907-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1735",
    "codSaber": "101908-00"
  },
  {
    "centro": "SAN BERNARDO",
    "codPres": "1736",
    "codSaber": "101909-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "1737",
    "codSaber": "101910-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1738",
    "codSaber": "101911-00"
  },
  {
    "centro": "RÍO REGADO",
    "codPres": "1739",
    "codSaber": "101912-00"
  },
  {
    "centro": "CALLE NARANJO",
    "codPres": "1740",
    "codSaber": "101913-00"
  },
  {
    "centro": "ALTO DE SAN JUAN",
    "codPres": "1741",
    "codSaber": "101914-00"
  },
  {
    "centro": "SAN MARTÍN DE SAN CARLOS",
    "codPres": "1742",
    "codSaber": "101915-00"
  },
  {
    "centro": "PASTOR BARQUERO OBANDO",
    "codPres": "1743",
    "codSaber": "101916-00"
  },
  {
    "centro": "SANTA ROSA ARRIBA",
    "codPres": "1744",
    "codSaber": "101917-00"
  },
  {
    "centro": "BAJO LOS ÁNGELES",
    "codPres": "1745",
    "codSaber": "101918-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "1746",
    "codSaber": "101919-00"
  },
  {
    "centro": "BAJO LA TRINIDAD",
    "codPres": "1747",
    "codSaber": "101920-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1748",
    "codSaber": "101921-00"
  },
  {
    "centro": "LA LUCHA",
    "codPres": "1749",
    "codSaber": "101922-00"
  },
  {
    "centro": "CASAMATA",
    "codPres": "1750",
    "codSaber": "101923-00"
  },
  {
    "centro": "SIXTO CORDERO MARTÍNEZ",
    "codPres": "1751",
    "codSaber": "101924-00"
  },
  {
    "centro": "RESCATE DE UJARRÁS",
    "codPres": "1752",
    "codSaber": "101925-00"
  },
  {
    "centro": "LA CIMA",
    "codPres": "1753",
    "codSaber": "101926-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "1754",
    "codSaber": "101927-00"
  },
  {
    "centro": "VICENTE LACHNER SANDOVAL",
    "codPres": "1755",
    "codSaber": "101928-00"
  },
  {
    "centro": "LA PASTORA",
    "codPres": "1756",
    "codSaber": "101929-00"
  },
  {
    "centro": "QUEBRADA SECA",
    "codPres": "1757",
    "codSaber": "101930-00"
  },
  {
    "centro": "PROCESO SOLANO RAMÍREZ",
    "codPres": "1758",
    "codSaber": "101931-00"
  },
  {
    "centro": "FLORENCIO DEL CASTILLO",
    "codPres": "1759",
    "codSaber": "101932-00"
  },
  {
    "centro": "CACIQUE GUARCO",
    "codPres": "1760",
    "codSaber": "101933-00"
  },
  {
    "centro": "LA PASTORA",
    "codPres": "1761",
    "codSaber": "101934-00"
  },
  {
    "centro": "ARGENTINA GONGORA DE ROBERT",
    "codPres": "1762",
    "codSaber": "101935-00"
  },
  {
    "centro": "LA ASUNCIÓN",
    "codPres": "1763",
    "codSaber": "101936-00"
  },
  {
    "centro": "ENCARNACIÓN GAMBOA PIEDRA",
    "codPres": "1764",
    "codSaber": "101937-00"
  },
  {
    "centro": "CARAGRAL",
    "codPres": "1765",
    "codSaber": "101938-00"
  },
  {
    "centro": "CARRIZAL",
    "codPres": "1766",
    "codSaber": "101939-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "1767",
    "codSaber": "101940-00"
  },
  {
    "centro": "GUAYABAL",
    "codPres": "1768",
    "codSaber": "101941-00"
  },
  {
    "centro": "VIRGEN DE SANTA JUANA",
    "codPres": "1769",
    "codSaber": "101942-00"
  },
  {
    "centro": "LUIS CRUZ MEZA",
    "codPres": "1770",
    "codSaber": "101943-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "1771",
    "codSaber": "101944-00"
  },
  {
    "centro": "SANTA JUANA",
    "codPres": "1772",
    "codSaber": "101945-00"
  },
  {
    "centro": "CIPRESES",
    "codPres": "1773",
    "codSaber": "101946-00"
  },
  {
    "centro": "ORATORIO",
    "codPres": "1774",
    "codSaber": "101947-00"
  },
  {
    "centro": "FERNANDO TERÁN VALLS",
    "codPres": "1776",
    "codSaber": "101948-00"
  },
  {
    "centro": "COPALCHI",
    "codPres": "1777",
    "codSaber": "101949-00"
  },
  {
    "centro": "CORIS",
    "codPres": "1778",
    "codSaber": "101950-00"
  },
  {
    "centro": "CORRALILLO",
    "codPres": "1779",
    "codSaber": "101951-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "1780",
    "codSaber": "101952-00"
  },
  {
    "centro": "SAN CRISTÓBAL NORTE",
    "codPres": "1781",
    "codSaber": "101953-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "1782",
    "codSaber": "101954-00"
  },
  {
    "centro": "YERBABUENA",
    "codPres": "1783",
    "codSaber": "101955-00"
  },
  {
    "centro": "JOSÉ JOAQUÍN PERALTA ESQUIVEL",
    "codPres": "1784",
    "codSaber": "101956-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "1785",
    "codSaber": "101957-00"
  },
  {
    "centro": "DOMINGO FAUSTINO SARMIENTO",
    "codPres": "1786",
    "codSaber": "101958-00"
  },
  {
    "centro": "MOISÉS COTO FERNÁNDEZ",
    "codPres": "1787",
    "codSaber": "101959-00"
  },
  {
    "centro": "EL BOSQUE",
    "codPres": "1788",
    "codSaber": "101960-00"
  },
  {
    "centro": "MANUEL ORTUÑO BOUTIN",
    "codPres": "1789",
    "codSaber": "101961-00"
  },
  {
    "centro": "JULIÁN VOLIO LLORENTE",
    "codPres": "1790",
    "codSaber": "101962-00"
  },
  {
    "centro": "EL CEDRAL",
    "codPres": "1791",
    "codSaber": "101963-00"
  },
  {
    "centro": "PEDRO PÉREZ ZELEDÓN",
    "codPres": "1792",
    "codSaber": "101964-00"
  },
  {
    "centro": "EL EMPALME",
    "codPres": "1793",
    "codSaber": "101965-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "1794",
    "codSaber": "101966-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "1795",
    "codSaber": "101967-00"
  },
  {
    "centro": "HÉCTOR MONESTEL SOLANO",
    "codPres": "1796",
    "codSaber": "101968-00"
  },
  {
    "centro": "ÁLVARO ESQUIVEL BONILLA",
    "codPres": "1797",
    "codSaber": "101969-00"
  },
  {
    "centro": "EL RODEO",
    "codPres": "1798",
    "codSaber": "101970-00"
  },
  {
    "centro": "VICTOR CAMPOS VALVERDE",
    "codPres": "1799",
    "codSaber": "101971-00"
  },
  {
    "centro": "OTTO MORA PÉREZ",
    "codPres": "1800",
    "codSaber": "101972-00"
  },
  {
    "centro": "ASCENSIÓN ESQUIVEL IBARRA",
    "codPres": "1801",
    "codSaber": "101973-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "1802",
    "codSaber": "101974-00"
  },
  {
    "centro": "CARLOS JOAQUÍN PERALTA ECHEVERRÍA",
    "codPres": "1803",
    "codSaber": "101975-00"
  },
  {
    "centro": "J.N. CARLOS JOAQUÍN PERALTA ECHEVERRÍA",
    "codPres": "1804",
    "codSaber": "101976-00"
  },
  {
    "centro": "J.N. ASCENSIÓN ESQUIVEL",
    "codPres": "1805",
    "codSaber": "101977-00"
  },
  {
    "centro": "JOSÉ MARÍA LORÍA VEGA",
    "codPres": "1806",
    "codSaber": "101978-00"
  },
  {
    "centro": "JUAN VÁZQUEZ DE CORONADO",
    "codPres": "1807",
    "codSaber": "101979-00"
  },
  {
    "centro": "ALBERTO GONZÁLEZ SOTO",
    "codPres": "1808",
    "codSaber": "101980-00"
  },
  {
    "centro": "JESÚS JIMÉNEZ",
    "codPres": "1809",
    "codSaber": "101981-00"
  },
  {
    "centro": "CUESTA DE MORAS",
    "codPres": "1810",
    "codSaber": "101982-00"
  },
  {
    "centro": "LA ANGOSTURA",
    "codPres": "1811",
    "codSaber": "101983-00"
  },
  {
    "centro": "ALEJANDRO AGUILAR MACHADO",
    "codPres": "1812",
    "codSaber": "101984-00"
  },
  {
    "centro": "LA CUESTA",
    "codPres": "1813",
    "codSaber": "101985-00"
  },
  {
    "centro": "JUAN MANUEL MONGE CEDEÑO",
    "codPres": "1814",
    "codSaber": "101986-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "1815",
    "codSaber": "101987-00"
  },
  {
    "centro": "LA ESTRELLA",
    "codPres": "1816",
    "codSaber": "101988-00"
  },
  {
    "centro": "J.N. JESÚS JIMÉNEZ ZAMORA",
    "codPres": "1817",
    "codSaber": "101989-00"
  },
  {
    "centro": "JUAN EVANGELISTA SOJO CARTÍN",
    "codPres": "1818",
    "codSaber": "101990-00"
  },
  {
    "centro": "LA PAZ",
    "codPres": "1819",
    "codSaber": "101991-00"
  },
  {
    "centro": "PROVIDENCIA",
    "codPres": "1820",
    "codSaber": "101992-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "1821",
    "codSaber": "101993-00"
  },
  {
    "centro": "MARIO PACHECO SÁENZ",
    "codPres": "1822",
    "codSaber": "101994-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "1823",
    "codSaber": "101995-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "1824",
    "codSaber": "101996-00"
  },
  {
    "centro": "LLANO GRANDE - PACAYAS",
    "codPres": "1825",
    "codSaber": "101997-00"
  },
  {
    "centro": "LOAIZA",
    "codPres": "1826",
    "codSaber": "101998-00"
  },
  {
    "centro": "SAN IGNACIO DE LOYOLA",
    "codPres": "1827",
    "codSaber": "101999-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "1828",
    "codSaber": "102000-00"
  },
  {
    "centro": "FILADELFO SALAS CÉSPEDES",
    "codPres": "1829",
    "codSaber": "102001-00"
  },
  {
    "centro": "MARIANO QUIRÓS SEGURA",
    "codPres": "1830",
    "codSaber": "102002-00"
  },
  {
    "centro": "FÉLIX MATA VALLE",
    "codPres": "1831",
    "codSaber": "102003-00"
  },
  {
    "centro": "NAPOLES",
    "codPres": "1832",
    "codSaber": "102004-00"
  },
  {
    "centro": "RUDECINDO VARGAS QUIRÓS",
    "codPres": "1833",
    "codSaber": "102005-00"
  },
  {
    "centro": "BAJO CANET",
    "codPres": "1834",
    "codSaber": "102006-00"
  },
  {
    "centro": "CARLOS MONGE ALFARO",
    "codPres": "1835",
    "codSaber": "102007-00"
  },
  {
    "centro": "OROSI",
    "codPres": "1836",
    "codSaber": "102008-00"
  },
  {
    "centro": "CALLE JUCÓ",
    "codPres": "1837",
    "codSaber": "102009-00"
  },
  {
    "centro": "PBRO. JUAN DE DIOS TREJOS",
    "codPres": "1838",
    "codSaber": "102010-00"
  },
  {
    "centro": "PADRE PERALTA",
    "codPres": "1839",
    "codSaber": "102011-00"
  },
  {
    "centro": "JOSEFA CALDERÓN NARANJO",
    "codPres": "1840",
    "codSaber": "102012-00"
  },
  {
    "centro": "PALMITAL SUR",
    "codPres": "1841",
    "codSaber": "102013-00"
  },
  {
    "centro": "CARMEN TAMES BRENES",
    "codPres": "1842",
    "codSaber": "102014-00"
  },
  {
    "centro": "PALOMO",
    "codPres": "1843",
    "codSaber": "102015-00"
  },
  {
    "centro": "LA ALEGRÍA",
    "codPres": "1844",
    "codSaber": "102016-00"
  },
  {
    "centro": "JOSÉ LIENDO Y GOICOECHEA",
    "codPres": "1845",
    "codSaber": "102017-00"
  },
  {
    "centro": "EUGENIO CORRALES BIANCHINI",
    "codPres": "1846",
    "codSaber": "102018-00"
  },
  {
    "centro": "LA LAGUNA",
    "codPres": "1847",
    "codSaber": "102019-00"
  },
  {
    "centro": "RAMÓN AGUILAR FERNÁNDEZ",
    "codPres": "1848",
    "codSaber": "102020-00"
  },
  {
    "centro": "PATIO DE AGUA",
    "codPres": "1849",
    "codSaber": "102021-00"
  },
  {
    "centro": "MANUEL ÁVILA CAMACHO",
    "codPres": "1851",
    "codSaber": "102022-00"
  },
  {
    "centro": "FELIPE ALVARADO ECHANDI",
    "codPres": "1852",
    "codSaber": "102023-00"
  },
  {
    "centro": "MARIANO GUARDIA CARAZO",
    "codPres": "1853",
    "codSaber": "102024-00"
  },
  {
    "centro": "PURISIL",
    "codPres": "1854",
    "codSaber": "102025-00"
  },
  {
    "centro": "QUEBRADILLA",
    "codPres": "1855",
    "codSaber": "102026-00"
  },
  {
    "centro": "EL ALTO DE QUEBRADILLA",
    "codPres": "1856",
    "codSaber": "102027-00"
  },
  {
    "centro": "QUIRCOT",
    "codPres": "1858",
    "codSaber": "102028-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA RAFAEL HERNÁNDEZ MADRIZ",
    "codPres": "1859",
    "codSaber": "104107-00"
  },
  {
    "centro": "LA FUENTE",
    "codPres": "1860",
    "codSaber": "102030-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "1862",
    "codSaber": "102031-00"
  },
  {
    "centro": "LAS DAMITAS",
    "codPres": "1863",
    "codSaber": "102032-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "1864",
    "codSaber": "102033-00"
  },
  {
    "centro": "ANTONIO CAMACHO ORTEGA",
    "codPres": "1865",
    "codSaber": "102034-00"
  },
  {
    "centro": "RICARDO ANDRÉ STRAUSS",
    "codPres": "1866",
    "codSaber": "102035-00"
  },
  {
    "centro": "RÍO BLANCO",
    "codPres": "1867",
    "codSaber": "102036-00"
  },
  {
    "centro": "SAN ANDRÉS",
    "codPres": "1868",
    "codSaber": "102037-00"
  },
  {
    "centro": "SAN BLAS",
    "codPres": "1869",
    "codSaber": "102038-00"
  },
  {
    "centro": "SAN CARLOS",
    "codPres": "1870",
    "codSaber": "102039-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA SAN DIEGO",
    "codPres": "1871",
    "codSaber": "104689-00"
  },
  {
    "centro": "RAUL GRANADOS GONZÁLEZ",
    "codPres": "1872",
    "codSaber": "102041-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "1873",
    "codSaber": "102042-00"
  },
  {
    "centro": "SAN GUILLERMO",
    "codPres": "1874",
    "codSaber": "102043-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "1875",
    "codSaber": "102044-00"
  },
  {
    "centro": "CARLOS LUIS VALVERDE VEGA",
    "codPres": "1876",
    "codSaber": "102045-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "1877",
    "codSaber": "102046-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "1878",
    "codSaber": "102047-00"
  },
  {
    "centro": "EMILIO ROBERT BROUCA",
    "codPres": "1879",
    "codSaber": "102048-00"
  },
  {
    "centro": "MARÍA AMELIA MONTEALEGRE",
    "codPres": "1880",
    "codSaber": "102049-00"
  },
  {
    "centro": "SAN LORENZO",
    "codPres": "1881",
    "codSaber": "102050-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "1882",
    "codSaber": "102051-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1883",
    "codSaber": "102052-00"
  },
  {
    "centro": "REPÚBLICA FRANCESA",
    "codPres": "1884",
    "codSaber": "102053-00"
  },
  {
    "centro": "MONSEÑOR SANABRIA MARTÍNEZ",
    "codPres": "1885",
    "codSaber": "102054-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "1886",
    "codSaber": "102055-00"
  },
  {
    "centro": "MANUEL CASTRO BLANCO",
    "codPres": "1887",
    "codSaber": "102056-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "1888",
    "codSaber": "102057-00"
  },
  {
    "centro": "SAN RAFAEL ABAJO",
    "codPres": "1889",
    "codSaber": "102058-00"
  },
  {
    "centro": "CAROLINA BELLELLI",
    "codPres": "1890",
    "codSaber": "102059-00"
  },
  {
    "centro": "DOMINGO FAUSTINO SARMIENTO",
    "codPres": "1891",
    "codSaber": "102060-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "1892",
    "codSaber": "102061-00"
  },
  {
    "centro": "GUATUSO",
    "codPres": "1893",
    "codSaber": "102062-00"
  },
  {
    "centro": "BARRIO EL CARMEN",
    "codPres": "1894",
    "codSaber": "102063-00"
  },
  {
    "centro": "CAMILO GAMBOA VARGAS",
    "codPres": "1895",
    "codSaber": "102064-00"
  },
  {
    "centro": "JULIO SANCHO JIMÉNEZ",
    "codPres": "1896",
    "codSaber": "102065-00"
  },
  {
    "centro": "SANTA ROSA ABAJO",
    "codPres": "1897",
    "codSaber": "102066-00"
  },
  {
    "centro": "GUILLERMO RODRÍGUEZ AGUILAR",
    "codPres": "1898",
    "codSaber": "102067-00"
  },
  {
    "centro": "MIGUEL PICADO BARQUERO",
    "codPres": "1899",
    "codSaber": "102068-00"
  },
  {
    "centro": "SANTIAGO DEL MONTE",
    "codPres": "1900",
    "codSaber": "102069-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1901",
    "codSaber": "102070-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "1902",
    "codSaber": "102071-00"
  },
  {
    "centro": "LA CONCEPCIÓN",
    "codPres": "1903",
    "codSaber": "102072-00"
  },
  {
    "centro": "SAN MARTÍN DE SAN LORENZO",
    "codPres": "1904",
    "codSaber": "102073-00"
  },
  {
    "centro": "MATA DE CAÑA",
    "codPres": "1905",
    "codSaber": "102074-00"
  },
  {
    "centro": "SAN RAFAEL DE IRAZÚ",
    "codPres": "1906",
    "codSaber": "102075-00"
  },
  {
    "centro": "REPÚBLICA DE BOLIVIA",
    "codPres": "1907",
    "codSaber": "102076-00"
  },
  {
    "centro": "REPÚBLICA DE BRASIL",
    "codPres": "1908",
    "codSaber": "102077-00"
  },
  {
    "centro": "RICARDO JIMÉNEZ OREAMUNO",
    "codPres": "1909",
    "codSaber": "102078-00"
  },
  {
    "centro": "J.N. RICARDO JIMÉNEZ OREAMUNO",
    "codPres": "1910",
    "codSaber": "102079-00"
  },
  {
    "centro": "MANUEL DE JESÚS JIMÉNEZ",
    "codPres": "1911",
    "codSaber": "102080-00"
  },
  {
    "centro": "JUAN RAMÍREZ RAMÍREZ",
    "codPres": "1912",
    "codSaber": "102081-00"
  },
  {
    "centro": "CENTRAL DE TRES RÍOS",
    "codPres": "1913",
    "codSaber": "102082-00"
  },
  {
    "centro": "CLEMENTE AVENDAÑO ÁENZ",
    "codPres": "1914",
    "codSaber": "102083-00"
  },
  {
    "centro": "URASCA",
    "codPres": "1915",
    "codSaber": "102084-00"
  },
  {
    "centro": "VARA DEL ROBLE",
    "codPres": "1916",
    "codSaber": "102085-00"
  },
  {
    "centro": "CALLE GIRALES",
    "codPres": "1917",
    "codSaber": "102086-00"
  },
  {
    "centro": "ZAPOTAL",
    "codPres": "1918",
    "codSaber": "102087-00"
  },
  {
    "centro": "J.N. EL CONEJITO FELIZ",
    "codPres": "1919",
    "codSaber": "102088-00"
  },
  {
    "centro": "QUEBRADA DEL FIERRO",
    "codPres": "1921",
    "codSaber": "102090-00"
  },
  {
    "centro": "LA LIDIA",
    "codPres": "1922",
    "codSaber": "102091-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "1923",
    "codSaber": "102092-00"
  },
  {
    "centro": "EL HIGUERÓN",
    "codPres": "1924",
    "codSaber": "102093-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "1925",
    "codSaber": "102094-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA BARRIO NUEVO",
    "codPres": "1926",
    "codSaber": "104764-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1927",
    "codSaber": "102096-00"
  },
  {
    "centro": "J.N. CENTRAL DE TRES RÍOS",
    "codPres": "1928",
    "codSaber": "102097-00"
  },
  {
    "centro": "LA PITAHAYA",
    "codPres": "1929",
    "codSaber": "102098-00"
  },
  {
    "centro": "WILLIAM BRENES FONSECA",
    "codPres": "1930",
    "codSaber": "102099-00"
  },
  {
    "centro": "ARTURO VOLIO JIMÉNEZ",
    "codPres": "1931",
    "codSaber": "102100-00"
  },
  {
    "centro": "JAPÓN",
    "codPres": "1932",
    "codSaber": "102101-00"
  },
  {
    "centro": "COCORÍ",
    "codPres": "1933",
    "codSaber": "102102-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "1934",
    "codSaber": "102103-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1935",
    "codSaber": "102104-00"
  },
  {
    "centro": "ALTO DE VARAS",
    "codPres": "1936",
    "codSaber": "102105-00"
  },
  {
    "centro": "AQUIARES",
    "codPres": "1937",
    "codSaber": "102106-00"
  },
  {
    "centro": "SAN JUAN BOSCO",
    "codPres": "1938",
    "codSaber": "102107-00"
  },
  {
    "centro": "CALLE VARGAS",
    "codPres": "1939",
    "codSaber": "102108-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "1940",
    "codSaber": "102109-00"
  },
  {
    "centro": "ATIRRO",
    "codPres": "1941",
    "codSaber": "102110-00"
  },
  {
    "centro": "AZUL",
    "codPres": "1942",
    "codSaber": "102111-00"
  },
  {
    "centro": "CARLOS LUIS CASTRO ARCE",
    "codPres": "1943",
    "codSaber": "102112-00"
  },
  {
    "centro": "JÄKUI",
    "codPres": "1944",
    "codSaber": "102113-00"
  },
  {
    "centro": "BLÖRIÑAK",
    "codPres": "1945",
    "codSaber": "102114-00"
  },
  {
    "centro": "SIKUA DITZÄ",
    "codPres": "1946",
    "codSaber": "102115-00"
  },
  {
    "centro": "SANTÍSIMA TRINIDAD",
    "codPres": "1947",
    "codSaber": "102116-00"
  },
  {
    "centro": "CARMEN LYRA",
    "codPres": "1948",
    "codSaber": "102117-00"
  },
  {
    "centro": "CANADÁ",
    "codPres": "1949",
    "codSaber": "102118-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "1950",
    "codSaber": "102119-00"
  },
  {
    "centro": "SHARABATA",
    "codPres": "1951",
    "codSaber": "102120-00"
  },
  {
    "centro": "KABEBATA",
    "codPres": "1952",
    "codSaber": "102121-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "1953",
    "codSaber": "102122-00"
  },
  {
    "centro": "LA FLOR",
    "codPres": "1954",
    "codSaber": "102123-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "1955",
    "codSaber": "102124-00"
  },
  {
    "centro": "EL PILÓN",
    "codPres": "1956",
    "codSaber": "102125-00"
  },
  {
    "centro": "CHITARÍA",
    "codPres": "1957",
    "codSaber": "102126-00"
  },
  {
    "centro": "CIEN MANZANAS",
    "codPres": "1958",
    "codSaber": "102127-00"
  },
  {
    "centro": "CIMARRÓN",
    "codPres": "1959",
    "codSaber": "102128-00"
  },
  {
    "centro": "COLONIA DE GUAYABO",
    "codPres": "1960",
    "codSaber": "102129-00"
  },
  {
    "centro": "FRANCISCO BONILLA WEPOL",
    "codPres": "1961",
    "codSaber": "102130-00"
  },
  {
    "centro": "SHIKIARI",
    "codPres": "1962",
    "codSaber": "102131-00"
  },
  {
    "centro": "BÄYËI",
    "codPres": "1963",
    "codSaber": "102132-00"
  },
  {
    "centro": "ALTO ALMIRANTE",
    "codPres": "1964",
    "codSaber": "102133-00"
  },
  {
    "centro": "TSIPIRI",
    "codPres": "1965",
    "codSaber": "102134-00"
  },
  {
    "centro": "TSINICLARI",
    "codPres": "1966",
    "codSaber": "102135-00"
  },
  {
    "centro": "SARCLI",
    "codPres": "1967",
    "codSaber": "102136-00"
  },
  {
    "centro": "BONILLA",
    "codPres": "1968",
    "codSaber": "102137-00"
  },
  {
    "centro": "EL SEIS",
    "codPres": "1969",
    "codSaber": "102138-00"
  },
  {
    "centro": "LA ORIETTA",
    "codPres": "1970",
    "codSaber": "102139-00"
  },
  {
    "centro": "GUAYABO",
    "codPres": "1971",
    "codSaber": "102140-00"
  },
  {
    "centro": "RAFAEL ARAYA SEGURA",
    "codPres": "1972",
    "codSaber": "102141-00"
  },
  {
    "centro": "DOMINICA",
    "codPres": "1973",
    "codSaber": "102142-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "1974",
    "codSaber": "102143-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "1975",
    "codSaber": "102144-00"
  },
  {
    "centro": "JAKTAIN",
    "codPres": "1976",
    "codSaber": "102145-00"
  },
  {
    "centro": "SINOLI",
    "codPres": "1977",
    "codSaber": "102146-00"
  },
  {
    "centro": "BAYEIÑAK",
    "codPres": "1978",
    "codSaber": "102147-00"
  },
  {
    "centro": "ÑARIÑAK",
    "codPres": "1979",
    "codSaber": "102148-00"
  },
  {
    "centro": "KSARIÑAK",
    "codPres": "1980",
    "codSaber": "102149-00"
  },
  {
    "centro": "CARLOS LUIS VALVERDE VEGA",
    "codPres": "1981",
    "codSaber": "102150-00"
  },
  {
    "centro": "EL HUMO",
    "codPres": "1982",
    "codSaber": "102151-00"
  },
  {
    "centro": "EL RECREO",
    "codPres": "1983",
    "codSaber": "102152-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "1984",
    "codSaber": "102153-00"
  },
  {
    "centro": "EL SITIO",
    "codPres": "1985",
    "codSaber": "102154-00"
  },
  {
    "centro": "EL SOL",
    "codPres": "1986",
    "codSaber": "102155-00"
  },
  {
    "centro": "ESLABÓN",
    "codPres": "1987",
    "codSaber": "102156-00"
  },
  {
    "centro": "DR. VALERIANO FERNÁNDEZ FERRAZ",
    "codPres": "1988",
    "codSaber": "102157-00"
  },
  {
    "centro": "ENRIQUE PACHECO AGUILAR",
    "codPres": "1989",
    "codSaber": "102158-00"
  },
  {
    "centro": "GRANO DE ORO",
    "codPres": "1990",
    "codSaber": "102159-00"
  },
  {
    "centro": "KOIYABA",
    "codPres": "1992",
    "codSaber": "102161-00"
  },
  {
    "centro": "JOKBATA",
    "codPres": "1993",
    "codSaber": "102162-00"
  },
  {
    "centro": "JABILLOS",
    "codPres": "1994",
    "codSaber": "102163-00"
  },
  {
    "centro": "ASENTAMIENTO YAMA",
    "codPres": "1995",
    "codSaber": "102164-00"
  },
  {
    "centro": "JICOTEA",
    "codPres": "1997",
    "codSaber": "102165-00"
  },
  {
    "centro": "CECILIO LINDO MORALES",
    "codPres": "1998",
    "codSaber": "102166-00"
  },
  {
    "centro": "EL SITIO DE LAS ABRAS",
    "codPres": "1999",
    "codSaber": "102167-00"
  },
  {
    "centro": "LA ESMERALDA",
    "codPres": "2000",
    "codSaber": "102168-00"
  },
  {
    "centro": "LA GLORIA",
    "codPres": "2001",
    "codSaber": "102169-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "2002",
    "codSaber": "102170-00"
  },
  {
    "centro": "LA MARGOT",
    "codPres": "2003",
    "codSaber": "102171-00"
  },
  {
    "centro": "LA PASTORA",
    "codPres": "2004",
    "codSaber": "102172-00"
  },
  {
    "centro": "LA REUNIÓN",
    "codPres": "2005",
    "codSaber": "102173-00"
  },
  {
    "centro": "RODOLFO HERZOG MULLER",
    "codPres": "2006",
    "codSaber": "102174-00"
  },
  {
    "centro": "VERBENA NORTE",
    "codPres": "2007",
    "codSaber": "102175-00"
  },
  {
    "centro": "YOLANDA",
    "codPres": "2008",
    "codSaber": "102176-00"
  },
  {
    "centro": "LAS AMÉRICAS",
    "codPres": "2009",
    "codSaber": "102177-00"
  },
  {
    "centro": "LAS COLONIAS",
    "codPres": "2010",
    "codSaber": "102178-00"
  },
  {
    "centro": "LAS NUBES",
    "codPres": "2011",
    "codSaber": "102179-00"
  },
  {
    "centro": "MARÍA AUXILIADORA",
    "codPres": "2012",
    "codSaber": "102180-00"
  },
  {
    "centro": "EL CAS",
    "codPres": "2013",
    "codSaber": "102181-00"
  },
  {
    "centro": "MARIANO CORTÉS CORTÉS",
    "codPres": "2014",
    "codSaber": "102182-00"
  },
  {
    "centro": "MATA DE GUINEO",
    "codPres": "2015",
    "codSaber": "102183-00"
  },
  {
    "centro": "MOLLEJONES",
    "codPres": "2016",
    "codSaber": "102184-00"
  },
  {
    "centro": "MURCIA",
    "codPres": "2017",
    "codSaber": "102185-00"
  },
  {
    "centro": "MANUEL JIMÉNEZ DE LA GUARDIA",
    "codPres": "2018",
    "codSaber": "102186-00"
  },
  {
    "centro": "JENARO BONILLA AGUILAR",
    "codPres": "2019",
    "codSaber": "102187-00"
  },
  {
    "centro": "JUANA DENNIS VIVES",
    "codPres": "2021",
    "codSaber": "102188-00"
  },
  {
    "centro": "ORIENTE",
    "codPres": "2023",
    "codSaber": "102189-00"
  },
  {
    "centro": "PACAYITAS",
    "codPres": "2024",
    "codSaber": "102190-00"
  },
  {
    "centro": "PACUARE",
    "codPres": "2025",
    "codSaber": "102191-00"
  },
  {
    "centro": "PACUARE",
    "codPres": "2026",
    "codSaber": "102192-00"
  },
  {
    "centro": "PALOMO",
    "codPres": "2027",
    "codSaber": "102193-00"
  },
  {
    "centro": "LAS PAVAS",
    "codPres": "2028",
    "codSaber": "102194-00"
  },
  {
    "centro": "BLAS SOLANO PÉREZ",
    "codPres": "2029",
    "codSaber": "102195-00"
  },
  {
    "centro": "DR. JOSÉ MARÍA CASTRO MADRIZ",
    "codPres": "2030",
    "codSaber": "102196-00"
  },
  {
    "centro": "PERALTA",
    "codPres": "2031",
    "codSaber": "102197-00"
  },
  {
    "centro": "TAYUTIC",
    "codPres": "2032",
    "codSaber": "102198-00"
  },
  {
    "centro": "SANTUBAL",
    "codPres": "2033",
    "codSaber": "102199-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2034",
    "codSaber": "102200-00"
  },
  {
    "centro": "SAN AGUSTÍN",
    "codPres": "2035",
    "codSaber": "102201-00"
  },
  {
    "centro": "JULIA FERNÁNDEZ RODRÍGUEZ",
    "codPres": "2036",
    "codSaber": "102202-00"
  },
  {
    "centro": "IGNACIO FUENTES MOLINA",
    "codPres": "2037",
    "codSaber": "102203-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "2038",
    "codSaber": "102204-00"
  },
  {
    "centro": "RAFAEL FUENTES PIEDRA",
    "codPres": "2039",
    "codSaber": "102205-00"
  },
  {
    "centro": "SAN JUAN SUR",
    "codPres": "2040",
    "codSaber": "102206-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "2041",
    "codSaber": "102207-00"
  },
  {
    "centro": "LA FUENTE",
    "codPres": "2042",
    "codSaber": "102208-00"
  },
  {
    "centro": "SANTA CRISTINA",
    "codPres": "2043",
    "codSaber": "102209-00"
  },
  {
    "centro": "SANTA CRUZ",
    "codPres": "2044",
    "codSaber": "102210-00"
  },
  {
    "centro": "NIMARIÑAK",
    "codPres": "2045",
    "codSaber": "102211-00"
  },
  {
    "centro": "SANTA TERESITA",
    "codPres": "2047",
    "codSaber": "102213-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "2048",
    "codSaber": "102214-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA EL TORITO",
    "codPres": "2049",
    "codSaber": "104835-00"
  },
  {
    "centro": "EDUARDO PERALTA JIMÉNEZ",
    "codPres": "2050",
    "codSaber": "102216-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2051",
    "codSaber": "102217-00"
  },
  {
    "centro": "VERBENA SUR",
    "codPres": "2052",
    "codSaber": "102218-00"
  },
  {
    "centro": "MARCO AURELIO PEREIRA RAMÍREZ",
    "codPres": "2053",
    "codSaber": "102219-00"
  },
  {
    "centro": "EL VOLCÁN",
    "codPres": "2054",
    "codSaber": "102220-00"
  },
  {
    "centro": "BAJO PACUARE",
    "codPres": "2055",
    "codSaber": "102221-00"
  },
  {
    "centro": "J.N. TURRIALBA",
    "codPres": "2056",
    "codSaber": "102222-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "2057",
    "codSaber": "102223-00"
  },
  {
    "centro": "GUAYABO ABAJO",
    "codPres": "2058",
    "codSaber": "102224-00"
  },
  {
    "centro": "LAS VIRTUDES",
    "codPres": "2059",
    "codSaber": "102225-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "2060",
    "codSaber": "102226-00"
  },
  {
    "centro": "EL CARMEN LA SUIZA",
    "codPres": "2061",
    "codSaber": "102227-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "2062",
    "codSaber": "102228-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "2063",
    "codSaber": "102229-00"
  },
  {
    "centro": "TICARÍ",
    "codPres": "2064",
    "codSaber": "102230-00"
  },
  {
    "centro": "LA TIRIMBINA",
    "codPres": "2065",
    "codSaber": "102231-00"
  },
  {
    "centro": "LA ISLA",
    "codPres": "2066",
    "codSaber": "102232-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "2067",
    "codSaber": "102233-00"
  },
  {
    "centro": "LUCILA GURDIÁN MORALES",
    "codPres": "2068",
    "codSaber": "102234-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2069",
    "codSaber": "102235-00"
  },
  {
    "centro": "I.D.A. LA PAZ",
    "codPres": "2070",
    "codSaber": "102236-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "2071",
    "codSaber": "102237-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "2072",
    "codSaber": "102238-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2073",
    "codSaber": "102239-00"
  },
  {
    "centro": "FÁTIMA",
    "codPres": "2074",
    "codSaber": "102240-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "2075",
    "codSaber": "102241-00"
  },
  {
    "centro": "ALFREDO MIRANDA GARCÍA",
    "codPres": "2076",
    "codSaber": "102242-00"
  },
  {
    "centro": "LOS LIRIOS",
    "codPres": "2077",
    "codSaber": "102243-00"
  },
  {
    "centro": "LAS VEGAS DEL RÍO SUCIO",
    "codPres": "2078",
    "codSaber": "102244-00"
  },
  {
    "centro": "NOGAL",
    "codPres": "2079",
    "codSaber": "102245-00"
  },
  {
    "centro": "MALINCHE",
    "codPres": "2080",
    "codSaber": "102246-00"
  },
  {
    "centro": "BARRIO FÁTIMA",
    "codPres": "2081",
    "codSaber": "102247-00"
  },
  {
    "centro": "COLONIA NAZARETH",
    "codPres": "2082",
    "codSaber": "102248-00"
  },
  {
    "centro": "MANUEL DEL PILAR ZUMBADO GONZÁLEZ",
    "codPres": "2084",
    "codSaber": "102249-00"
  },
  {
    "centro": "I.D.A. CAÑO NEGRO",
    "codPres": "2085",
    "codSaber": "102250-00"
  },
  {
    "centro": "EL ÁLAMO",
    "codPres": "2086",
    "codSaber": "102251-00"
  },
  {
    "centro": "ALFREDO GONZÁLEZ FLORES",
    "codPres": "2087",
    "codSaber": "102252-00"
  },
  {
    "centro": "COYOL",
    "codPres": "2089",
    "codSaber": "102254-00"
  },
  {
    "centro": "JAVILLOS",
    "codPres": "2090",
    "codSaber": "102255-00"
  },
  {
    "centro": "ASENTAMIENTO CHIRRIPÓ",
    "codPres": "2091",
    "codSaber": "102256-00"
  },
  {
    "centro": "EL CRUCE",
    "codPres": "2092",
    "codSaber": "102257-00"
  },
  {
    "centro": "CHILAMATE",
    "codPres": "2093",
    "codSaber": "102258-00"
  },
  {
    "centro": "SANTA CRUZ",
    "codPres": "2094",
    "codSaber": "102259-00"
  },
  {
    "centro": "BAJOS DE CHILAMATE",
    "codPres": "2095",
    "codSaber": "102260-00"
  },
  {
    "centro": "MANUEL CAMACHO HERNÁNDEZ",
    "codPres": "2096",
    "codSaber": "102261-00"
  },
  {
    "centro": "SONORA",
    "codPres": "2097",
    "codSaber": "102262-00"
  },
  {
    "centro": "RAMÓN BARRANTES HERRERA",
    "codPres": "2098",
    "codSaber": "102263-00"
  },
  {
    "centro": "I.D.A. OTOYA",
    "codPres": "2099",
    "codSaber": "102264-00"
  },
  {
    "centro": "LA COOPERATIVA",
    "codPres": "2100",
    "codSaber": "102265-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "2101",
    "codSaber": "102266-00"
  },
  {
    "centro": "FÉLIX ARCADIO MONTERO MONGE",
    "codPres": "2102",
    "codSaber": "102267-00"
  },
  {
    "centro": "ALFREDO VOLIO JIMÉNEZ",
    "codPres": "2103",
    "codSaber": "102268-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "2104",
    "codSaber": "102269-00"
  },
  {
    "centro": "BARRIO EL SOCORRO",
    "codPres": "2105",
    "codSaber": "102270-00"
  },
  {
    "centro": "BOCA DE LA CEIBA",
    "codPres": "2106",
    "codSaber": "102271-00"
  },
  {
    "centro": "REMOLINITOS",
    "codPres": "2107",
    "codSaber": "102272-00"
  },
  {
    "centro": "CRISTO REY",
    "codPres": "2108",
    "codSaber": "102273-00"
  },
  {
    "centro": "BRAULIO MORALES CERVANTES",
    "codPres": "2109",
    "codSaber": "102274-00"
  },
  {
    "centro": "EL PALENQUE",
    "codPres": "2110",
    "codSaber": "102275-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "2111",
    "codSaber": "102276-00"
  },
  {
    "centro": "ESTERO GRANDE",
    "codPres": "2113",
    "codSaber": "102278-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2114",
    "codSaber": "102279-00"
  },
  {
    "centro": "I.D.A. LINDO SOL",
    "codPres": "2115",
    "codSaber": "102280-00"
  },
  {
    "centro": "EL ACHIOTE",
    "codPres": "2116",
    "codSaber": "102281-00"
  },
  {
    "centro": "CASTILLA",
    "codPres": "2117",
    "codSaber": "102282-00"
  },
  {
    "centro": "I.D.A. SARAPIQUÍ",
    "codPres": "2118",
    "codSaber": "102283-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2119",
    "codSaber": "102284-00"
  },
  {
    "centro": "FLAMINIA",
    "codPres": "2120",
    "codSaber": "102285-00"
  },
  {
    "centro": "CLETO GONZÁLEZ VÍQUEZ",
    "codPres": "2121",
    "codSaber": "102286-00"
  },
  {
    "centro": "FINCA GUARARÍ",
    "codPres": "2122",
    "codSaber": "102287-00"
  },
  {
    "centro": "JUAN SANTAMARÍA",
    "codPres": "2123",
    "codSaber": "102288-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "2124",
    "codSaber": "102289-00"
  },
  {
    "centro": "LA DELIA",
    "codPres": "2125",
    "codSaber": "102290-00"
  },
  {
    "centro": "COLONIA VILLALOBOS",
    "codPres": "2126",
    "codSaber": "102291-00"
  },
  {
    "centro": "COLONIA ISIDREÑA",
    "codPres": "2127",
    "codSaber": "102292-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "2128",
    "codSaber": "102293-00"
  },
  {
    "centro": "LOS LAGOS",
    "codPres": "2129",
    "codSaber": "102294-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "2130",
    "codSaber": "102295-00"
  },
  {
    "centro": "SANTIAGO",
    "codPres": "2131",
    "codSaber": "102296-00"
  },
  {
    "centro": "MIRAFLORES",
    "codPres": "2133",
    "codSaber": "102298-00"
  },
  {
    "centro": "I.D.A. CARTAGENA",
    "codPres": "2134",
    "codSaber": "102299-00"
  },
  {
    "centro": "CUBUJUQUÍ",
    "codPres": "2135",
    "codSaber": "102300-00"
  },
  {
    "centro": "NUEVO HORIZONTE",
    "codPres": "2136",
    "codSaber": "102301-00"
  },
  {
    "centro": "I.D.A. LA GATA",
    "codPres": "2137",
    "codSaber": "102302-00"
  },
  {
    "centro": "LA AURORA",
    "codPres": "2138",
    "codSaber": "102303-00"
  },
  {
    "centro": "LA GRAN SAMARIA",
    "codPres": "2139",
    "codSaber": "102304-00"
  },
  {
    "centro": "PEDRO MURILLO PÉREZ",
    "codPres": "2140",
    "codSaber": "102305-00"
  },
  {
    "centro": "J.N. PEDRO MURILLO PÉREZ",
    "codPres": "2141",
    "codSaber": "102306-00"
  },
  {
    "centro": "I.D.A. EL PALMAR",
    "codPres": "2142",
    "codSaber": "102307-00"
  },
  {
    "centro": "SAN BERNARDINO",
    "codPres": "2143",
    "codSaber": "102308-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "2144",
    "codSaber": "102309-00"
  },
  {
    "centro": "LOURDES DE SACRAMENTO",
    "codPres": "2145",
    "codSaber": "102310-00"
  },
  {
    "centro": "ALBERTO PANIAGUA CHAVARRÍA",
    "codPres": "2146",
    "codSaber": "102311-00"
  },
  {
    "centro": "ULLOA",
    "codPres": "2147",
    "codSaber": "102312-00"
  },
  {
    "centro": "LA ALDEA",
    "codPres": "2148",
    "codSaber": "102313-00"
  },
  {
    "centro": "LA UNIÓN DEL TORO",
    "codPres": "2149",
    "codSaber": "102314-00"
  },
  {
    "centro": "BOCA DEL TORO",
    "codPres": "2150",
    "codSaber": "102315-00"
  },
  {
    "centro": "KAY RICA",
    "codPres": "2151",
    "codSaber": "102316-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA LICEO EL ROBLE",
    "codPres": "2152",
    "codSaber": "104136-00"
  },
  {
    "centro": "J.N. BENITO SÁENZ Y REYES",
    "codPres": "2153",
    "codSaber": "102318-00"
  },
  {
    "centro": "LA PLATANERA",
    "codPres": "2154",
    "codSaber": "102319-00"
  },
  {
    "centro": "JESÚS",
    "codPres": "2155",
    "codSaber": "102320-00"
  },
  {
    "centro": "JOAQUÍN LIZANO GUTIÉRREZ",
    "codPres": "2156",
    "codSaber": "102321-00"
  },
  {
    "centro": "LA PUEBLA",
    "codPres": "2157",
    "codSaber": "102322-00"
  },
  {
    "centro": "FINCA DOS",
    "codPres": "2158",
    "codSaber": "102323-00"
  },
  {
    "centro": "FIDEL CHAVES MURILLO",
    "codPres": "2159",
    "codSaber": "102324-00"
  },
  {
    "centro": "LA TIGRA",
    "codPres": "2160",
    "codSaber": "102325-00"
  },
  {
    "centro": "I.D.A. HUETAR",
    "codPres": "2161",
    "codSaber": "102326-00"
  },
  {
    "centro": "LABORATORIO",
    "codPres": "2162",
    "codSaber": "102327-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "2163",
    "codSaber": "102328-00"
  },
  {
    "centro": "LLORENTE DE FLORES",
    "codPres": "2164",
    "codSaber": "102329-00"
  },
  {
    "centro": "EL GASPAR",
    "codPres": "2165",
    "codSaber": "102330-00"
  },
  {
    "centro": "CHIMURRIA",
    "codPres": "2166",
    "codSaber": "102331-00"
  },
  {
    "centro": "LOS ÁNGELES DE LA VIRGEN",
    "codPres": "2167",
    "codSaber": "102332-00"
  },
  {
    "centro": "LOS ÁNGELES DEL RÍO",
    "codPres": "2168",
    "codSaber": "102333-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2169",
    "codSaber": "102334-00"
  },
  {
    "centro": "LOS ARBOLITOS",
    "codPres": "2170",
    "codSaber": "102335-00"
  },
  {
    "centro": "LOS CARTAGOS",
    "codPres": "2171",
    "codSaber": "102336-00"
  },
  {
    "centro": "ANICETO ESQUIVEL SÁENZ",
    "codPres": "2172",
    "codSaber": "102337-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "2173",
    "codSaber": "102338-00"
  },
  {
    "centro": "JOSÉ FIGUERES FERRER",
    "codPres": "2174",
    "codSaber": "102339-00"
  },
  {
    "centro": "EL MONTECITO",
    "codPres": "2175",
    "codSaber": "102340-00"
  },
  {
    "centro": "ARTURO MORALES GUTIÉRREZ",
    "codPres": "2176",
    "codSaber": "102341-00"
  },
  {
    "centro": "EL MUELLE",
    "codPres": "2177",
    "codSaber": "102342-00"
  },
  {
    "centro": "I.M.A.S. DE ULLOA",
    "codPres": "2178",
    "codSaber": "102343-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "2179",
    "codSaber": "102344-00"
  },
  {
    "centro": "ZAPOTE",
    "codPres": "2180",
    "codSaber": "102345-00"
  },
  {
    "centro": "LAS PALMITAS",
    "codPres": "2181",
    "codSaber": "102346-00"
  },
  {
    "centro": "PORROSATÍ",
    "codPres": "2182",
    "codSaber": "102347-00"
  },
  {
    "centro": "PUERTO VIEJO",
    "codPres": "2183",
    "codSaber": "102348-00"
  },
  {
    "centro": "EL NARANJAL",
    "codPres": "2184",
    "codSaber": "102349-00"
  },
  {
    "centro": "LA TRINIDAD",
    "codPres": "2185",
    "codSaber": "102350-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2186",
    "codSaber": "102351-00"
  },
  {
    "centro": "PUENTE SALAS",
    "codPres": "2187",
    "codSaber": "102352-00"
  },
  {
    "centro": "RAFAEL MOYA MURILLO",
    "codPres": "2188",
    "codSaber": "102353-00"
  },
  {
    "centro": "J.N. RAFAEL MOYA MURILLO",
    "codPres": "2189",
    "codSaber": "102354-00"
  },
  {
    "centro": "NEFTALÍ VILLALOBOS GUTIÉRREZ",
    "codPres": "2190",
    "codSaber": "102355-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "2191",
    "codSaber": "102356-00"
  },
  {
    "centro": "TRANQUILINO SÁENZ ROJAS",
    "codPres": "2192",
    "codSaber": "102357-00"
  },
  {
    "centro": "SAN RAFAEL DE VARA BLANCA",
    "codPres": "2193",
    "codSaber": "102358-00"
  },
  {
    "centro": "I.D.A. LA CHIRIPA",
    "codPres": "2194",
    "codSaber": "102359-00"
  },
  {
    "centro": "ESPAÑA",
    "codPres": "2195",
    "codSaber": "102360-00"
  },
  {
    "centro": "J.N. ESPAÑA",
    "codPres": "2196",
    "codSaber": "102361-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2197",
    "codSaber": "102362-00"
  },
  {
    "centro": "JOSÉ MARTÍ",
    "codPres": "2198",
    "codSaber": "102363-00"
  },
  {
    "centro": "J.N. JOSÉ MARTÍ",
    "codPres": "2199",
    "codSaber": "102364-00"
  },
  {
    "centro": "ESTADOS UNIDOS DE AMÉRICA",
    "codPres": "2200",
    "codSaber": "102365-00"
  },
  {
    "centro": "J.N. ESTADOS UNIDOS DE AMÉRICA",
    "codPres": "2201",
    "codSaber": "102366-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "2202",
    "codSaber": "102367-00"
  },
  {
    "centro": "JESÚS ARGÜELLO VILLALOBOS",
    "codPres": "2203",
    "codSaber": "102368-00"
  },
  {
    "centro": "SAN LUIS GONZAGA",
    "codPres": "2204",
    "codSaber": "102369-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2205",
    "codSaber": "102370-00"
  },
  {
    "centro": "CRISTÓBAL COLÓN",
    "codPres": "2206",
    "codSaber": "102371-00"
  },
  {
    "centro": "PBRO. RICARDO SALAS CAMPOS",
    "codPres": "2207",
    "codSaber": "102372-00"
  },
  {
    "centro": "JOAQUÍN CAMACHO ULATE",
    "codPres": "2208",
    "codSaber": "102373-00"
  },
  {
    "centro": "PEDRO MARÍA BADILLA BOLAÑOS",
    "codPres": "2209",
    "codSaber": "102374-00"
  },
  {
    "centro": "J.N. PEDRO MARÍA BADILLA BOLAÑOS",
    "codPres": "2210",
    "codSaber": "102375-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "2211",
    "codSaber": "102376-00"
  },
  {
    "centro": "CALLE QUIRÓS",
    "codPres": "2212",
    "codSaber": "102377-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "2213",
    "codSaber": "102378-00"
  },
  {
    "centro": "RAFAEL ARGUEDAS GUTIÉRREZ",
    "codPres": "2214",
    "codSaber": "102379-00"
  },
  {
    "centro": "J.N. JUAN MORA FERNÁNDEZ",
    "codPres": "2215",
    "codSaber": "102380-00"
  },
  {
    "centro": "JUAN MORA FERNÁNDEZ",
    "codPres": "2216",
    "codSaber": "102381-00"
  },
  {
    "centro": "CALLE HERNÁNDEZ",
    "codPres": "2217",
    "codSaber": "102382-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "2218",
    "codSaber": "102383-00"
  },
  {
    "centro": "RUBÉN DARÍO",
    "codPres": "2219",
    "codSaber": "102384-00"
  },
  {
    "centro": "SANTO TOMÁS",
    "codPres": "2220",
    "codSaber": "102385-00"
  },
  {
    "centro": "JOSÉ EZEQUIEL GONZÁLEZ VINDAS",
    "codPres": "2221",
    "codSaber": "102386-00"
  },
  {
    "centro": "J.N. JOSE EZEQUIEL GONZÁLEZ VINDAS",
    "codPres": "2222",
    "codSaber": "102387-00"
  },
  {
    "centro": "ELISA SOTO JIMÉNEZ",
    "codPres": "2223",
    "codSaber": "102388-00"
  },
  {
    "centro": "DOMINGO GONZÁLEZ PÉREZ",
    "codPres": "2224",
    "codSaber": "102389-00"
  },
  {
    "centro": "JULIA FERNÁNDEZ RODRÍGUEZ",
    "codPres": "2225",
    "codSaber": "102390-00"
  },
  {
    "centro": "VILLALOBOS",
    "codPres": "2226",
    "codSaber": "102391-00"
  },
  {
    "centro": "CLAUDIO LARA CAMPOS",
    "codPres": "2227",
    "codSaber": "102392-00"
  },
  {
    "centro": "VIRGEN DEL SOCORRO",
    "codPres": "2228",
    "codSaber": "102393-00"
  },
  {
    "centro": "RODOLFO PETERS SCHEIDER",
    "codPres": "2229",
    "codSaber": "102394-00"
  },
  {
    "centro": "J.N. CLETO GONZÁLEZ VÍQUEZ",
    "codPres": "2230",
    "codSaber": "102395-00"
  },
  {
    "centro": "FINCA AGUA",
    "codPres": "2231",
    "codSaber": "102396-00"
  },
  {
    "centro": "FINCA UNO",
    "codPres": "2232",
    "codSaber": "102397-00"
  },
  {
    "centro": "CUBUJUQUÍ",
    "codPres": "2233",
    "codSaber": "102398-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "2234",
    "codSaber": "102399-00"
  },
  {
    "centro": "JOSÉ RAMÓN HERNÁNDEZ BADILLA",
    "codPres": "2235",
    "codSaber": "102400-00"
  },
  {
    "centro": "FINCA SEIS",
    "codPres": "2236",
    "codSaber": "102401-00"
  },
  {
    "centro": "FINCA CUATRO",
    "codPres": "2237",
    "codSaber": "102402-00"
  },
  {
    "centro": "FINCA OCHO",
    "codPres": "2238",
    "codSaber": "102403-00"
  },
  {
    "centro": "FINCA DIEZ",
    "codPres": "2239",
    "codSaber": "102404-00"
  },
  {
    "centro": "SANTA EDUVIGES",
    "codPres": "2240",
    "codSaber": "102405-00"
  },
  {
    "centro": "LA CONQUISTA",
    "codPres": "2241",
    "codSaber": "102406-00"
  },
  {
    "centro": "FINCA TRES",
    "codPres": "2242",
    "codSaber": "102407-00"
  },
  {
    "centro": "FINCA CINCO",
    "codPres": "2243",
    "codSaber": "102408-00"
  },
  {
    "centro": "FINCA SIETE",
    "codPres": "2244",
    "codSaber": "102409-00"
  },
  {
    "centro": "FINCA ONCE",
    "codPres": "2245",
    "codSaber": "102410-00"
  },
  {
    "centro": "SAN JOSÉ DE RÍO SUCIO",
    "codPres": "2246",
    "codSaber": "102411-00"
  },
  {
    "centro": "BAJO DEL VIRILLA",
    "codPres": "2247",
    "codSaber": "102412-00"
  },
  {
    "centro": "MERCEDES SUR",
    "codPres": "2248",
    "codSaber": "102413-00"
  },
  {
    "centro": "MIGUEL AGUILAR BONILLA",
    "codPres": "2249",
    "codSaber": "102414-00"
  },
  {
    "centro": "I.D.A. SAN RAMÓN",
    "codPres": "2250",
    "codSaber": "102415-00"
  },
  {
    "centro": "AGUA CALIENTE",
    "codPres": "2251",
    "codSaber": "102416-00"
  },
  {
    "centro": "TEMPATAL",
    "codPres": "2252",
    "codSaber": "102417-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2253",
    "codSaber": "102418-00"
  },
  {
    "centro": "MAQUENCAL",
    "codPres": "2254",
    "codSaber": "102419-00"
  },
  {
    "centro": "ALBA OCAMPO ALVARADO",
    "codPres": "2255",
    "codSaber": "102420-00"
  },
  {
    "centro": "EL PORVENIR",
    "codPres": "2256",
    "codSaber": "102421-00"
  },
  {
    "centro": "GENERAL TOMÁS GUARDIA GUTIÉRREZ",
    "codPres": "2257",
    "codSaber": "102422-00"
  },
  {
    "centro": "AGUA CALIENTE",
    "codPres": "2258",
    "codSaber": "102423-00"
  },
  {
    "centro": "BARRIO GUADALUPE",
    "codPres": "2259",
    "codSaber": "102424-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "2260",
    "codSaber": "102425-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "2261",
    "codSaber": "102426-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "2262",
    "codSaber": "102427-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "2263",
    "codSaber": "102428-00"
  },
  {
    "centro": "GIL TABLADA COREA",
    "codPres": "2264",
    "codSaber": "102429-00"
  },
  {
    "centro": "CAÑAS DULCES",
    "codPres": "2265",
    "codSaber": "102430-00"
  },
  {
    "centro": "I.D.A. BAGATZI",
    "codPres": "2266",
    "codSaber": "102431-00"
  },
  {
    "centro": "I.D.A. LAS PLAYITAS",
    "codPres": "2267",
    "codSaber": "102432-00"
  },
  {
    "centro": "EL ARBOLITO",
    "codPres": "2268",
    "codSaber": "102433-00"
  },
  {
    "centro": "RODEITO",
    "codPres": "2269",
    "codSaber": "102434-00"
  },
  {
    "centro": "J.N. LIBERIA",
    "codPres": "2270",
    "codSaber": "102435-00"
  },
  {
    "centro": "NUEVA GENERACIÓN",
    "codPres": "2271",
    "codSaber": "102436-00"
  },
  {
    "centro": "BARRIO IRVIN",
    "codPres": "2273",
    "codSaber": "102437-00"
  },
  {
    "centro": "EL CAPULÍN",
    "codPres": "2274",
    "codSaber": "102438-00"
  },
  {
    "centro": "COLONIA BOLAÑOS",
    "codPres": "2275",
    "codSaber": "102439-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "2276",
    "codSaber": "102440-00"
  },
  {
    "centro": "COPALCHI",
    "codPres": "2277",
    "codSaber": "102441-00"
  },
  {
    "centro": "CUAJINIQUIL",
    "codPres": "2278",
    "codSaber": "102442-00"
  },
  {
    "centro": "CUIPILAPA",
    "codPres": "2279",
    "codSaber": "102443-00"
  },
  {
    "centro": "CURUBANDE",
    "codPres": "2280",
    "codSaber": "102444-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "2281",
    "codSaber": "102445-00"
  },
  {
    "centro": "GUARDIA",
    "codPres": "2282",
    "codSaber": "102446-00"
  },
  {
    "centro": "PIJIJE",
    "codPres": "2283",
    "codSaber": "102447-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2285",
    "codSaber": "102448-00"
  },
  {
    "centro": "LAS VUELTAS",
    "codPres": "2286",
    "codSaber": "102449-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "2287",
    "codSaber": "102450-00"
  },
  {
    "centro": "MARCELINO GARCÍA FLAMENCO",
    "codPres": "2288",
    "codSaber": "102451-00"
  },
  {
    "centro": "EL CONSUELO",
    "codPres": "2289",
    "codSaber": "102452-00"
  },
  {
    "centro": "GUAPINOL",
    "codPres": "2290",
    "codSaber": "102453-00"
  },
  {
    "centro": "EL GUAYABO",
    "codPres": "2291",
    "codSaber": "102454-00"
  },
  {
    "centro": "IRIGARAY",
    "codPres": "2292",
    "codSaber": "102455-00"
  },
  {
    "centro": "SALVADOR VILLAR MUÑOZ",
    "codPres": "2293",
    "codSaber": "102456-00"
  },
  {
    "centro": "RINCÓN DE LA VIEJA",
    "codPres": "2294",
    "codSaber": "102457-00"
  },
  {
    "centro": "FALCONIANA",
    "codPres": "2295",
    "codSaber": "102458-00"
  },
  {
    "centro": "FAUSTO GUZMÁN CALVO",
    "codPres": "2296",
    "codSaber": "102459-00"
  },
  {
    "centro": "LA GARITA",
    "codPres": "2297",
    "codSaber": "102460-00"
  },
  {
    "centro": "LA VIRGEN",
    "codPres": "2298",
    "codSaber": "102461-00"
  },
  {
    "centro": "LABORATORIO JOHN FITGERALD KENNEDY",
    "codPres": "2299",
    "codSaber": "102462-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "2300",
    "codSaber": "102463-00"
  },
  {
    "centro": "LAS LILAS",
    "codPres": "2301",
    "codSaber": "102464-00"
  },
  {
    "centro": "LIMONAL",
    "codPres": "2302",
    "codSaber": "102465-00"
  },
  {
    "centro": "LOS ANDES",
    "codPres": "2303",
    "codSaber": "102466-00"
  },
  {
    "centro": "CELESTINO ALVAREZ RUÍZ",
    "codPres": "2305",
    "codSaber": "102468-00"
  },
  {
    "centro": "MONTENEGRO",
    "codPres": "2306",
    "codSaber": "102469-00"
  },
  {
    "centro": "LLANOS DE CORTÉS",
    "codPres": "2307",
    "codSaber": "102470-00"
  },
  {
    "centro": "MORACIA",
    "codPres": "2308",
    "codSaber": "102471-00"
  },
  {
    "centro": "ASCENSIÓN ESQUIVEL IBARRA",
    "codPres": "2309",
    "codSaber": "102472-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2310",
    "codSaber": "102473-00"
  },
  {
    "centro": "RINCÓN DE LA CRUZ",
    "codPres": "2311",
    "codSaber": "102474-00"
  },
  {
    "centro": "SAN FERNANDO",
    "codPres": "2312",
    "codSaber": "102475-00"
  },
  {
    "centro": "SALITRAL",
    "codPres": "2313",
    "codSaber": "102476-00"
  },
  {
    "centro": "SAN BERNARDO",
    "codPres": "2314",
    "codSaber": "102477-00"
  },
  {
    "centro": "SAN DIMAS",
    "codPres": "2315",
    "codSaber": "102478-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2316",
    "codSaber": "102479-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "2317",
    "codSaber": "102480-00"
  },
  {
    "centro": "SAN PEDRO DE MOGOTE",
    "codPres": "2318",
    "codSaber": "102481-00"
  },
  {
    "centro": "ISABEL BROWN BROWN",
    "codPres": "2319",
    "codSaber": "102482-00"
  },
  {
    "centro": "J.N. SAN ROQUE",
    "codPres": "2320",
    "codSaber": "102483-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "2321",
    "codSaber": "102484-00"
  },
  {
    "centro": "SANTA FE",
    "codPres": "2322",
    "codSaber": "102485-00"
  },
  {
    "centro": "JESÚS DE NAZARETH",
    "codPres": "2323",
    "codSaber": "102486-00"
  },
  {
    "centro": "EL TRIUNFO",
    "codPres": "2324",
    "codSaber": "102487-00"
  },
  {
    "centro": "BELLO HORIZONTE",
    "codPres": "2325",
    "codSaber": "102488-00"
  },
  {
    "centro": "ADOLFO BERGER FAERRON",
    "codPres": "2326",
    "codSaber": "102489-00"
  },
  {
    "centro": "SONZAPOTE",
    "codPres": "2327",
    "codSaber": "102490-00"
  },
  {
    "centro": "LA VICTORIA",
    "codPres": "2328",
    "codSaber": "102491-00"
  },
  {
    "centro": "BARRIO LA CRUZ",
    "codPres": "2329",
    "codSaber": "102492-00"
  },
  {
    "centro": "PELÓN DE LA BAJURA",
    "codPres": "2330",
    "codSaber": "102493-00"
  },
  {
    "centro": "ACOYAPA",
    "codPres": "2331",
    "codSaber": "102494-00"
  },
  {
    "centro": "PUERTO JESÚS",
    "codPres": "2332",
    "codSaber": "102495-00"
  },
  {
    "centro": "MATAMBAS",
    "codPres": "2333",
    "codSaber": "102496-00"
  },
  {
    "centro": "SAN FERNANDO",
    "codPres": "2335",
    "codSaber": "102497-00"
  },
  {
    "centro": "CUESTA ROJA",
    "codPres": "2336",
    "codSaber": "102498-00"
  },
  {
    "centro": "CAIMITALITO",
    "codPres": "2337",
    "codSaber": "102499-00"
  },
  {
    "centro": "CHINAMPAS",
    "codPres": "2338",
    "codSaber": "102500-00"
  },
  {
    "centro": "PUERTO MORENO",
    "codPres": "2339",
    "codSaber": "102501-00"
  },
  {
    "centro": "ALTOS DEL SOCORRO",
    "codPres": "2340",
    "codSaber": "102502-00"
  },
  {
    "centro": "ANTONIO MACEO Y GRAJALES",
    "codPres": "2341",
    "codSaber": "102503-00"
  },
  {
    "centro": "ARBOLITO",
    "codPres": "2342",
    "codSaber": "102504-00"
  },
  {
    "centro": "ULISES DELGADO AGUILERA",
    "codPres": "2344",
    "codSaber": "102506-00"
  },
  {
    "centro": "COLONIA DE VALLE",
    "codPres": "2345",
    "codSaber": "102507-00"
  },
  {
    "centro": "BARCO QUEBRADO",
    "codPres": "2347",
    "codSaber": "102509-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "2349",
    "codSaber": "102510-00"
  },
  {
    "centro": "BEJUCO",
    "codPres": "2350",
    "codSaber": "102511-00"
  },
  {
    "centro": "BELÉN",
    "codPres": "2352",
    "codSaber": "102512-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "2353",
    "codSaber": "102513-00"
  },
  {
    "centro": "CAMARONAL",
    "codPres": "2354",
    "codSaber": "102514-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "2355",
    "codSaber": "102515-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2356",
    "codSaber": "102516-00"
  },
  {
    "centro": "SERAPIO LÓPEZ FAJARDO",
    "codPres": "2358",
    "codSaber": "102517-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "2359",
    "codSaber": "102518-00"
  },
  {
    "centro": "CABALLITO",
    "codPres": "2360",
    "codSaber": "102519-00"
  },
  {
    "centro": "CACAO",
    "codPres": "2361",
    "codSaber": "102520-00"
  },
  {
    "centro": "CUPERTINO BRICEÑO BALTODANO",
    "codPres": "2362",
    "codSaber": "102521-00"
  },
  {
    "centro": "TORTUGUERO",
    "codPres": "2363",
    "codSaber": "102522-00"
  },
  {
    "centro": "SANTOS CARRILLO",
    "codPres": "2364",
    "codSaber": "102523-00"
  },
  {
    "centro": "CERRO NEGRO",
    "codPres": "2365",
    "codSaber": "102524-00"
  },
  {
    "centro": "LA ESPERANZA DE GARZA",
    "codPres": "2366",
    "codSaber": "102525-00"
  },
  {
    "centro": "COLAS DE GALLO",
    "codPres": "2367",
    "codSaber": "102526-00"
  },
  {
    "centro": "PBRO. JOSÉ DANIEL CARMONA BRICEÑO",
    "codPres": "2368",
    "codSaber": "102527-00"
  },
  {
    "centro": "CERRILLOS",
    "codPres": "2369",
    "codSaber": "102528-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "2370",
    "codSaber": "102529-00"
  },
  {
    "centro": "BLAS MONTES LEAL",
    "codPres": "2371",
    "codSaber": "102530-00"
  },
  {
    "centro": "COROZALITO",
    "codPres": "2372",
    "codSaber": "102531-00"
  },
  {
    "centro": "CORRAL DE PIEDRA",
    "codPres": "2373",
    "codSaber": "102532-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "2374",
    "codSaber": "102533-00"
  },
  {
    "centro": "CUAJINIQUIL",
    "codPres": "2375",
    "codSaber": "102534-00"
  },
  {
    "centro": "CUESTA GRANDE",
    "codPres": "2376",
    "codSaber": "102535-00"
  },
  {
    "centro": "CERRO AZUL",
    "codPres": "2377",
    "codSaber": "102536-00"
  },
  {
    "centro": "JUAN DE LEÓN",
    "codPres": "2378",
    "codSaber": "102537-00"
  },
  {
    "centro": "NOSARITA",
    "codPres": "2379",
    "codSaber": "102538-00"
  },
  {
    "centro": "ABRAHAN FARAH MATA",
    "codPres": "2380",
    "codSaber": "102539-00"
  },
  {
    "centro": "ESTERONES",
    "codPres": "2381",
    "codSaber": "102540-00"
  },
  {
    "centro": "CAÑAL",
    "codPres": "2382",
    "codSaber": "102541-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "2383",
    "codSaber": "102542-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "2384",
    "codSaber": "102543-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "2385",
    "codSaber": "102544-00"
  },
  {
    "centro": "EL FLOR",
    "codPres": "2386",
    "codSaber": "102545-00"
  },
  {
    "centro": "EL JOBO NORTE",
    "codPres": "2387",
    "codSaber": "102546-00"
  },
  {
    "centro": "MADRE TERESA DE CALCUTA",
    "codPres": "2388",
    "codSaber": "102547-00"
  },
  {
    "centro": "EL ZAPOTE",
    "codPres": "2389",
    "codSaber": "102548-00"
  },
  {
    "centro": "JUAN ESTRADA RAVAGO",
    "codPres": "2390",
    "codSaber": "102549-00"
  },
  {
    "centro": "GARCIMUÑOZ",
    "codPres": "2391",
    "codSaber": "102550-00"
  },
  {
    "centro": "GARZA",
    "codPres": "2392",
    "codSaber": "102551-00"
  },
  {
    "centro": "GAMALOTAL",
    "codPres": "2393",
    "codSaber": "102552-00"
  },
  {
    "centro": "GUASTOMATAL",
    "codPres": "2394",
    "codSaber": "102553-00"
  },
  {
    "centro": "LA ISLITA",
    "codPres": "2395",
    "codSaber": "102554-00"
  },
  {
    "centro": "JABILLOS",
    "codPres": "2396",
    "codSaber": "102555-00"
  },
  {
    "centro": "JUAN DÍAZ",
    "codPres": "2397",
    "codSaber": "102556-00"
  },
  {
    "centro": "JUNTAS DE NOSARA",
    "codPres": "2398",
    "codSaber": "102557-00"
  },
  {
    "centro": "25 DE JULIO",
    "codPres": "2399",
    "codSaber": "102558-00"
  },
  {
    "centro": "IGUANITA",
    "codPres": "2400",
    "codSaber": "102559-00"
  },
  {
    "centro": "LA JAVILLA",
    "codPres": "2401",
    "codSaber": "102560-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "2402",
    "codSaber": "102561-00"
  },
  {
    "centro": "LA MONTAÑITA",
    "codPres": "2403",
    "codSaber": "102562-00"
  },
  {
    "centro": "GUILLERMO MORALES PÉREZ",
    "codPres": "2405",
    "codSaber": "102563-00"
  },
  {
    "centro": "LAJAS",
    "codPres": "2406",
    "codSaber": "102564-00"
  },
  {
    "centro": "VIRGILIO CAAMAÑO ARAUZ",
    "codPres": "2408",
    "codSaber": "102566-00"
  },
  {
    "centro": "LAS PAMPAS",
    "codPres": "2409",
    "codSaber": "102567-00"
  },
  {
    "centro": "LEÓNIDAS BRICEÑO BALTODANO",
    "codPres": "2410",
    "codSaber": "102568-00"
  },
  {
    "centro": "LUCAS BRICEÑO FONSECA",
    "codPres": "2411",
    "codSaber": "102569-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2412",
    "codSaber": "102570-00"
  },
  {
    "centro": "PUERTO SAN PABLO",
    "codPres": "2413",
    "codSaber": "102571-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2414",
    "codSaber": "102572-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "2415",
    "codSaber": "102573-00"
  },
  {
    "centro": "26 DE FEBRERO DE 1886",
    "codPres": "2416",
    "codSaber": "102574-00"
  },
  {
    "centro": "MATAMBUGUITO",
    "codPres": "2417",
    "codSaber": "102575-00"
  },
  {
    "centro": "MIRAMAR",
    "codPres": "2420",
    "codSaber": "102576-00"
  },
  {
    "centro": "MONTE GALÁN",
    "codPres": "2421",
    "codSaber": "102577-00"
  },
  {
    "centro": "MANUEL CARDENAS CARDENAS",
    "codPres": "2422",
    "codSaber": "102578-00"
  },
  {
    "centro": "RECAREDO BRICEÑO ARAUZ",
    "codPres": "2423",
    "codSaber": "102579-00"
  },
  {
    "centro": "FRAY BARTOLOMÉ DE LAS CASAS",
    "codPres": "2424",
    "codSaber": "102580-00"
  },
  {
    "centro": "NARANJAL",
    "codPres": "2425",
    "codSaber": "102581-00"
  },
  {
    "centro": "NARANJALITO",
    "codPres": "2426",
    "codSaber": "102582-00"
  },
  {
    "centro": "VICTORIANO MENA MENA",
    "codPres": "2427",
    "codSaber": "102583-00"
  },
  {
    "centro": "ORIENTE",
    "codPres": "2428",
    "codSaber": "102584-00"
  },
  {
    "centro": "PAVONES",
    "codPres": "2429",
    "codSaber": "102585-00"
  },
  {
    "centro": "ARTURO SOLANO MONGE",
    "codPres": "2430",
    "codSaber": "102586-00"
  },
  {
    "centro": "PILANGOSTA",
    "codPres": "2431",
    "codSaber": "102587-00"
  },
  {
    "centro": "PILAS BLANCAS",
    "codPres": "2432",
    "codSaber": "102588-00"
  },
  {
    "centro": "PILAS DE BEJUCO",
    "codPres": "2433",
    "codSaber": "102589-00"
  },
  {
    "centro": "BILLO ZELEDÓN",
    "codPres": "2434",
    "codSaber": "102590-00"
  },
  {
    "centro": "PITA RAYADA",
    "codPres": "2435",
    "codSaber": "102591-00"
  },
  {
    "centro": "POLVAZALES",
    "codPres": "2436",
    "codSaber": "102592-00"
  },
  {
    "centro": "PORTAL DE GARZA",
    "codPres": "2437",
    "codSaber": "102593-00"
  },
  {
    "centro": "POZO DE AGUA",
    "codPres": "2438",
    "codSaber": "102594-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2439",
    "codSaber": "102595-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2440",
    "codSaber": "102596-00"
  },
  {
    "centro": "CARLOS MILLER",
    "codPres": "2441",
    "codSaber": "102597-00"
  },
  {
    "centro": "PUERTO HUMO",
    "codPres": "2442",
    "codSaber": "102598-00"
  },
  {
    "centro": "PUERTO THIEL",
    "codPres": "2443",
    "codSaber": "102599-00"
  },
  {
    "centro": "QUEBRADA BONITA",
    "codPres": "2444",
    "codSaber": "102600-00"
  },
  {
    "centro": "QUEBRADA DE NANDO",
    "codPres": "2445",
    "codSaber": "102601-00"
  },
  {
    "centro": "QUEBRADA GRANDE",
    "codPres": "2446",
    "codSaber": "102602-00"
  },
  {
    "centro": "ANDRÉS BRICEÑO ACEVEDO",
    "codPres": "2447",
    "codSaber": "102603-00"
  },
  {
    "centro": "ANSELMO GUTIÉRREZ BRICEÑO",
    "codPres": "2448",
    "codSaber": "102604-00"
  },
  {
    "centro": "RÍO MONTAÑA",
    "codPres": "2450",
    "codSaber": "102606-00"
  },
  {
    "centro": "RÍO DE ORA",
    "codPres": "2451",
    "codSaber": "102607-00"
  },
  {
    "centro": "RUFINO CARRILLO TORRES",
    "codPres": "2452",
    "codSaber": "102608-00"
  },
  {
    "centro": "ROSARIO",
    "codPres": "2453",
    "codSaber": "102609-00"
  },
  {
    "centro": "20 DE MARZO DE 1856",
    "codPres": "2454",
    "codSaber": "102610-00"
  },
  {
    "centro": "SAMARA",
    "codPres": "2455",
    "codSaber": "102611-00"
  },
  {
    "centro": "LUIS DOBLES SEGREDA",
    "codPres": "2456",
    "codSaber": "102612-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2457",
    "codSaber": "102613-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "2458",
    "codSaber": "102614-00"
  },
  {
    "centro": "SAN JOSECITO",
    "codPres": "2459",
    "codSaber": "102615-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "2460",
    "codSaber": "102616-00"
  },
  {
    "centro": "ELÍAS AIZA RÍOS",
    "codPres": "2461",
    "codSaber": "102617-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "2462",
    "codSaber": "102618-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "2463",
    "codSaber": "102619-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2464",
    "codSaber": "102620-00"
  },
  {
    "centro": "NANDAYURE",
    "codPres": "2465",
    "codSaber": "102621-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "2466",
    "codSaber": "102622-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "2468",
    "codSaber": "102623-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "2469",
    "codSaber": "102624-00"
  },
  {
    "centro": "OTILIO ULATE BLANCO",
    "codPres": "2470",
    "codSaber": "102625-00"
  },
  {
    "centro": "OMAR DENGO GUERRERO",
    "codPres": "2471",
    "codSaber": "102626-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "2472",
    "codSaber": "102627-00"
  },
  {
    "centro": "GUILLERMO ALVARADO HERNÁNDEZ",
    "codPres": "2473",
    "codSaber": "102628-00"
  },
  {
    "centro": "SANTO DOMINGO",
    "codPres": "2474",
    "codSaber": "102629-00"
  },
  {
    "centro": "LA SOLEDAD",
    "codPres": "2475",
    "codSaber": "102630-00"
  },
  {
    "centro": "TACANI",
    "codPres": "2476",
    "codSaber": "102631-00"
  },
  {
    "centro": "TALOLINGA",
    "codPres": "2477",
    "codSaber": "102632-00"
  },
  {
    "centro": "TERCIOPELO",
    "codPres": "2478",
    "codSaber": "102633-00"
  },
  {
    "centro": "VALEDOR MARTÍNEZ MARTÍNEZ",
    "codPres": "2479",
    "codSaber": "102634-00"
  },
  {
    "centro": "GIL GONZÁLEZ DÁVILA",
    "codPres": "2480",
    "codSaber": "102635-00"
  },
  {
    "centro": "VISTA DE MAR",
    "codPres": "2481",
    "codSaber": "102636-00"
  },
  {
    "centro": "CESAR FLORES ZÚÑIGA",
    "codPres": "2482",
    "codSaber": "102637-00"
  },
  {
    "centro": "ZAPOTE",
    "codPres": "2483",
    "codSaber": "102638-00"
  },
  {
    "centro": "ZARAGOZA",
    "codPres": "2484",
    "codSaber": "102639-00"
  },
  {
    "centro": "CERRO EL CHOMPIPE",
    "codPres": "2485",
    "codSaber": "102640-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "2486",
    "codSaber": "102641-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "2487",
    "codSaber": "102642-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "2488",
    "codSaber": "102643-00"
  },
  {
    "centro": "RÍO DE ORO",
    "codPres": "2489",
    "codSaber": "102644-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2490",
    "codSaber": "102645-00"
  },
  {
    "centro": "EL TORITO",
    "codPres": "2491",
    "codSaber": "102646-00"
  },
  {
    "centro": "CACIQUE NICOA",
    "codPres": "2492",
    "codSaber": "102647-00"
  },
  {
    "centro": "LA Y GRIEGA",
    "codPres": "2493",
    "codSaber": "102648-00"
  },
  {
    "centro": "POCHOTE",
    "codPres": "2494",
    "codSaber": "102649-00"
  },
  {
    "centro": "ALEMANIA",
    "codPres": "2496",
    "codSaber": "102650-00"
  },
  {
    "centro": "BARRIO LAJAS",
    "codPres": "2497",
    "codSaber": "102651-00"
  },
  {
    "centro": "ARTOLA",
    "codPres": "2498",
    "codSaber": "102652-00"
  },
  {
    "centro": "PLAYA HERMOSA",
    "codPres": "2499",
    "codSaber": "102653-00"
  },
  {
    "centro": "BEJUCO",
    "codPres": "2500",
    "codSaber": "102654-00"
  },
  {
    "centro": "LOS RANCHOS",
    "codPres": "2501",
    "codSaber": "102655-00"
  },
  {
    "centro": "ALTOS DEL ROBLE",
    "codPres": "2503",
    "codSaber": "102657-00"
  },
  {
    "centro": "CAÑAFÍSTULA",
    "codPres": "2504",
    "codSaber": "102658-00"
  },
  {
    "centro": "CACIQUE",
    "codPres": "2505",
    "codSaber": "102659-00"
  },
  {
    "centro": "CASTILLA DE ORO",
    "codPres": "2506",
    "codSaber": "102660-00"
  },
  {
    "centro": "PACÍFICA GARCÍA FERNÁNDEZ",
    "codPres": "2507",
    "codSaber": "102661-00"
  },
  {
    "centro": "COYOLITO",
    "codPres": "2508",
    "codSaber": "102662-00"
  },
  {
    "centro": "CHIRCÓ",
    "codPres": "2509",
    "codSaber": "102663-00"
  },
  {
    "centro": "BENITO JUÁREZ GARCÍA",
    "codPres": "2510",
    "codSaber": "102664-00"
  },
  {
    "centro": "CARTAGENA",
    "codPres": "2511",
    "codSaber": "102665-00"
  },
  {
    "centro": "BELÉN",
    "codPres": "2512",
    "codSaber": "102666-00"
  },
  {
    "centro": "LA VILLITA",
    "codPres": "2513",
    "codSaber": "102667-00"
  },
  {
    "centro": "FRANCISCO CHAVES CHAVES",
    "codPres": "2514",
    "codSaber": "102668-00"
  },
  {
    "centro": "BOLSÓN",
    "codPres": "2515",
    "codSaber": "102669-00"
  },
  {
    "centro": "BRASILITO",
    "codPres": "2516",
    "codSaber": "102670-00"
  },
  {
    "centro": "MONTE VERDE",
    "codPres": "2517",
    "codSaber": "102671-00"
  },
  {
    "centro": "MATÍAS DUARTE SOTELA",
    "codPres": "2518",
    "codSaber": "102672-00"
  },
  {
    "centro": "CORRALILLOS",
    "codPres": "2519",
    "codSaber": "102673-00"
  },
  {
    "centro": "DIRIÁ",
    "codPres": "2520",
    "codSaber": "102674-00"
  },
  {
    "centro": "FILADELFIA",
    "codPres": "2521",
    "codSaber": "102675-00"
  },
  {
    "centro": "J.N. FILADELFIA",
    "codPres": "2522",
    "codSaber": "102676-00"
  },
  {
    "centro": "FLORIDA",
    "codPres": "2523",
    "codSaber": "102677-00"
  },
  {
    "centro": "HUACAS",
    "codPres": "2524",
    "codSaber": "102678-00"
  },
  {
    "centro": "LINDEROS",
    "codPres": "2525",
    "codSaber": "102679-00"
  },
  {
    "centro": "MERCEDES ORTEGA HERNÁNDEZ",
    "codPres": "2526",
    "codSaber": "102680-00"
  },
  {
    "centro": "PALMIRA",
    "codPres": "2527",
    "codSaber": "102681-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "2528",
    "codSaber": "102682-00"
  },
  {
    "centro": "PLAYA JUNQUILLAL",
    "codPres": "2529",
    "codSaber": "102683-00"
  },
  {
    "centro": "PORTEGOLPE",
    "codPres": "2530",
    "codSaber": "102684-00"
  },
  {
    "centro": "PUERTO POTRERO",
    "codPres": "2531",
    "codSaber": "102685-00"
  },
  {
    "centro": "RÍO SECO",
    "codPres": "2532",
    "codSaber": "102686-00"
  },
  {
    "centro": "RÍO TABACO",
    "codPres": "2533",
    "codSaber": "102687-00"
  },
  {
    "centro": "MARÍA MARÍN GALAGARZA",
    "codPres": "2534",
    "codSaber": "102688-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "2535",
    "codSaber": "102689-00"
  },
  {
    "centro": "DIONISIO LEAL VALLEJOS",
    "codPres": "2536",
    "codSaber": "102690-00"
  },
  {
    "centro": "VERACRUZ",
    "codPres": "2537",
    "codSaber": "102691-00"
  },
  {
    "centro": "VILLARREAL",
    "codPres": "2538",
    "codSaber": "102692-00"
  },
  {
    "centro": "EL LLANO",
    "codPres": "2539",
    "codSaber": "102693-00"
  },
  {
    "centro": "PASO HONDO",
    "codPres": "2540",
    "codSaber": "102694-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "2541",
    "codSaber": "102695-00"
  },
  {
    "centro": "ESPABELAR",
    "codPres": "2542",
    "codSaber": "102696-00"
  },
  {
    "centro": "EL SOCORRO",
    "codPres": "2543",
    "codSaber": "102697-00"
  },
  {
    "centro": "GUAITIL",
    "codPres": "2544",
    "codSaber": "102698-00"
  },
  {
    "centro": "HATILLO",
    "codPres": "2545",
    "codSaber": "102699-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2547",
    "codSaber": "102701-00"
  },
  {
    "centro": "HERNÁNDEZ",
    "codPres": "2548",
    "codSaber": "102702-00"
  },
  {
    "centro": "RICARDO ANGULO VALLEJOS",
    "codPres": "2549",
    "codSaber": "102703-00"
  },
  {
    "centro": "GARITA VIEJA",
    "codPres": "2550",
    "codSaber": "102704-00"
  },
  {
    "centro": "LA GUINEA",
    "codPres": "2551",
    "codSaber": "102705-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "2552",
    "codSaber": "102706-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "2553",
    "codSaber": "102707-00"
  },
  {
    "centro": "LAGARTO",
    "codPres": "2554",
    "codSaber": "102708-00"
  },
  {
    "centro": "PUERTO RICO",
    "codPres": "2555",
    "codSaber": "102709-00"
  },
  {
    "centro": "RÍO CAÑAS",
    "codPres": "2556",
    "codSaber": "102710-00"
  },
  {
    "centro": "RÍO CAÑAS VIEJO",
    "codPres": "2557",
    "codSaber": "102711-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "2558",
    "codSaber": "102712-00"
  },
  {
    "centro": "LORENA",
    "codPres": "2559",
    "codSaber": "102713-00"
  },
  {
    "centro": "LOS JOCOTES",
    "codPres": "2563",
    "codSaber": "102714-00"
  },
  {
    "centro": "LOS PLANES",
    "codPres": "2564",
    "codSaber": "102715-00"
  },
  {
    "centro": "MARBELLA",
    "codPres": "2565",
    "codSaber": "102716-00"
  },
  {
    "centro": "MATAPALO",
    "codPres": "2566",
    "codSaber": "102717-00"
  },
  {
    "centro": "MARÍA LEAL RODRÍGUEZ",
    "codPres": "2567",
    "codSaber": "102718-00"
  },
  {
    "centro": "ESTOCOLMO",
    "codPres": "2568",
    "codSaber": "102719-00"
  },
  {
    "centro": "NUEVO COLÓN",
    "codPres": "2569",
    "codSaber": "102720-00"
  },
  {
    "centro": "OSTIONAL",
    "codPres": "2570",
    "codSaber": "102721-00"
  },
  {
    "centro": "PALESTINA",
    "codPres": "2571",
    "codSaber": "102722-00"
  },
  {
    "centro": "PASO TEMPISQUE",
    "codPres": "2572",
    "codSaber": "102723-00"
  },
  {
    "centro": "EL COCO",
    "codPres": "2573",
    "codSaber": "102724-00"
  },
  {
    "centro": "IGNACIO GUTIÉRREZ",
    "codPres": "2574",
    "codSaber": "102725-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2575",
    "codSaber": "102726-00"
  },
  {
    "centro": "SAN JOSÉ DE LA MONTAÑA",
    "codPres": "2576",
    "codSaber": "102727-00"
  },
  {
    "centro": "SAN JOSÉ DE PINILLA",
    "codPres": "2577",
    "codSaber": "102728-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "2578",
    "codSaber": "102729-00"
  },
  {
    "centro": "SAN JUANILLO",
    "codPres": "2579",
    "codSaber": "102730-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "2580",
    "codSaber": "102731-00"
  },
  {
    "centro": "OMAR DENGO GUERRERO",
    "codPres": "2581",
    "codSaber": "102732-00"
  },
  {
    "centro": "SANTO DOMINGO",
    "codPres": "2582",
    "codSaber": "102733-00"
  },
  {
    "centro": "BERNARDO GUTIÉRREZ",
    "codPres": "2583",
    "codSaber": "102734-00"
  },
  {
    "centro": "OBANDITO",
    "codPres": "2584",
    "codSaber": "102735-00"
  },
  {
    "centro": "JOSEFINA LÓPEZ BONILLA",
    "codPres": "2585",
    "codSaber": "102736-00"
  },
  {
    "centro": "TALOLINGUITA",
    "codPres": "2586",
    "codSaber": "102737-00"
  },
  {
    "centro": "VENADO",
    "codPres": "2587",
    "codSaber": "102738-00"
  },
  {
    "centro": "27 DE ABRIL",
    "codPres": "2588",
    "codSaber": "102739-00"
  },
  {
    "centro": "LOS PARGOS",
    "codPres": "2589",
    "codSaber": "102740-00"
  },
  {
    "centro": "GUAYABAL",
    "codPres": "2590",
    "codSaber": "102741-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "2591",
    "codSaber": "102742-00"
  },
  {
    "centro": "EL TRAPICHE",
    "codPres": "2592",
    "codSaber": "102743-00"
  },
  {
    "centro": "BARRIO LIMÓN",
    "codPres": "2593",
    "codSaber": "102744-00"
  },
  {
    "centro": "AGUA CALIENTE",
    "codPres": "2594",
    "codSaber": "102745-00"
  },
  {
    "centro": "MATAPALO",
    "codPres": "2595",
    "codSaber": "102746-00"
  },
  {
    "centro": "SAN JUAN CHIQUITO",
    "codPres": "2596",
    "codSaber": "102747-00"
  },
  {
    "centro": "RÍO COROBICÍ",
    "codPres": "2597",
    "codSaber": "102748-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "2598",
    "codSaber": "102749-00"
  },
  {
    "centro": "ARENAL",
    "codPres": "2599",
    "codSaber": "102750-00"
  },
  {
    "centro": "ARIZONA",
    "codPres": "2600",
    "codSaber": "102751-00"
  },
  {
    "centro": "LAS PALMAS",
    "codPres": "2601",
    "codSaber": "102752-00"
  },
  {
    "centro": "ALTOS DE CEBADILLA",
    "codPres": "2602",
    "codSaber": "102753-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2603",
    "codSaber": "102754-00"
  },
  {
    "centro": "ANTONIO OBANDO ESPINOZA",
    "codPres": "2604",
    "codSaber": "102755-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "2605",
    "codSaber": "102756-00"
  },
  {
    "centro": "BEBEDERO",
    "codPres": "2606",
    "codSaber": "102757-00"
  },
  {
    "centro": "VIEJO ARENAL",
    "codPres": "2607",
    "codSaber": "102758-00"
  },
  {
    "centro": "MONSEÑOR MORERA VEGA",
    "codPres": "2608",
    "codSaber": "102759-00"
  },
  {
    "centro": "CEDROS",
    "codPres": "2609",
    "codSaber": "102760-00"
  },
  {
    "centro": "ASENTAMIENTO NUEVO ARENAL",
    "codPres": "2610",
    "codSaber": "102761-00"
  },
  {
    "centro": "LOS TORNOS",
    "codPres": "2611",
    "codSaber": "102762-00"
  },
  {
    "centro": "PEÑAS BLANCAS",
    "codPres": "2612",
    "codSaber": "102763-00"
  },
  {
    "centro": "MONSEÑOR LUIS LEIPOLD",
    "codPres": "2613",
    "codSaber": "102764-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2614",
    "codSaber": "102765-00"
  },
  {
    "centro": "CABECERA DE CAÑAS",
    "codPres": "2615",
    "codSaber": "102766-00"
  },
  {
    "centro": "CAMPOS DE ORO",
    "codPres": "2616",
    "codSaber": "102767-00"
  },
  {
    "centro": "EL NISPERO",
    "codPres": "2617",
    "codSaber": "102768-00"
  },
  {
    "centro": "I.D.A. SAN LUIS",
    "codPres": "2618",
    "codSaber": "102769-00"
  },
  {
    "centro": "PASO LAJAS",
    "codPres": "2619",
    "codSaber": "102770-00"
  },
  {
    "centro": "COLORADO",
    "codPres": "2620",
    "codSaber": "102771-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "2621",
    "codSaber": "102772-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "2622",
    "codSaber": "102773-00"
  },
  {
    "centro": "COROBICÍ",
    "codPres": "2623",
    "codSaber": "102774-00"
  },
  {
    "centro": "INVU LAS CAÑAS",
    "codPres": "2625",
    "codSaber": "102776-00"
  },
  {
    "centro": "BARRIO JESÚS",
    "codPres": "2626",
    "codSaber": "102777-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "2627",
    "codSaber": "102778-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2628",
    "codSaber": "102779-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "2629",
    "codSaber": "102780-00"
  },
  {
    "centro": "RÍO CHIQUITO",
    "codPres": "2630",
    "codSaber": "102781-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "2631",
    "codSaber": "102782-00"
  },
  {
    "centro": "RAIZAL",
    "codPres": "2632",
    "codSaber": "102783-00"
  },
  {
    "centro": "EL AGUACATE",
    "codPres": "2633",
    "codSaber": "102784-00"
  },
  {
    "centro": "CERRO SAN JOSÉ",
    "codPres": "2634",
    "codSaber": "102785-00"
  },
  {
    "centro": "EL DOS",
    "codPres": "2635",
    "codSaber": "102786-00"
  },
  {
    "centro": "EL DOS",
    "codPres": "2636",
    "codSaber": "102787-00"
  },
  {
    "centro": "MONTE LOS OLIVOS",
    "codPres": "2637",
    "codSaber": "102788-00"
  },
  {
    "centro": "JERÓNIMO FERNÁNDEZ ROJAS",
    "codPres": "2638",
    "codSaber": "102789-00"
  },
  {
    "centro": "ROSITA CHAVEZ DE CABEZAS",
    "codPres": "2639",
    "codSaber": "102790-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "2640",
    "codSaber": "102791-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "2641",
    "codSaber": "102792-00"
  },
  {
    "centro": "EL VERGEL",
    "codPres": "2642",
    "codSaber": "102793-00"
  },
  {
    "centro": "BELLO HORIZONTE",
    "codPres": "2643",
    "codSaber": "102794-00"
  },
  {
    "centro": "HACIENDA TABOGA",
    "codPres": "2645",
    "codSaber": "102795-00"
  },
  {
    "centro": "HIGUERÓN",
    "codPres": "2647",
    "codSaber": "102796-00"
  },
  {
    "centro": "LA CRUZ",
    "codPres": "2648",
    "codSaber": "102797-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "2649",
    "codSaber": "102798-00"
  },
  {
    "centro": "JOAQUÍN ARROYO",
    "codPres": "2650",
    "codSaber": "102799-00"
  },
  {
    "centro": "PIEDRA VERDE",
    "codPres": "2651",
    "codSaber": "102800-00"
  },
  {
    "centro": "TRES AMIGOS",
    "codPres": "2652",
    "codSaber": "102801-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "2654",
    "codSaber": "102802-00"
  },
  {
    "centro": "DELIA OVIEDO DE ACUÑA",
    "codPres": "2655",
    "codSaber": "102803-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "2656",
    "codSaber": "102804-00"
  },
  {
    "centro": "LAS NUBES",
    "codPres": "2657",
    "codSaber": "102805-00"
  },
  {
    "centro": "LIMONAL",
    "codPres": "2658",
    "codSaber": "102806-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2659",
    "codSaber": "102807-00"
  },
  {
    "centro": "RANCHITOS",
    "codPres": "2660",
    "codSaber": "102808-00"
  },
  {
    "centro": "LOS PATIOS",
    "codPres": "2661",
    "codSaber": "102809-00"
  },
  {
    "centro": "MATA DE CAÑA",
    "codPres": "2662",
    "codSaber": "102810-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "2663",
    "codSaber": "102811-00"
  },
  {
    "centro": "SAN CRISTOBAL",
    "codPres": "2664",
    "codSaber": "102812-00"
  },
  {
    "centro": "POROZAL",
    "codPres": "2665",
    "codSaber": "102813-00"
  },
  {
    "centro": "POZO AZUL",
    "codPres": "2666",
    "codSaber": "102814-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2667",
    "codSaber": "102815-00"
  },
  {
    "centro": "QUEBRADA GRANDE",
    "codPres": "2668",
    "codSaber": "102816-00"
  },
  {
    "centro": "RÍO CHIQUITO",
    "codPres": "2669",
    "codSaber": "102817-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2670",
    "codSaber": "102818-00"
  },
  {
    "centro": "RÍO PIEDRAS",
    "codPres": "2671",
    "codSaber": "102819-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "2672",
    "codSaber": "102820-00"
  },
  {
    "centro": "SABALITO",
    "codPres": "2674",
    "codSaber": "102821-00"
  },
  {
    "centro": "CANDELARIA",
    "codPres": "2675",
    "codSaber": "102822-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "2676",
    "codSaber": "102823-00"
  },
  {
    "centro": "SAN BUENAVENTURA",
    "codPres": "2677",
    "codSaber": "102824-00"
  },
  {
    "centro": "LAS PARCELAS",
    "codPres": "2678",
    "codSaber": "102825-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2679",
    "codSaber": "102826-00"
  },
  {
    "centro": "SAN JUAN GRANDE",
    "codPres": "2680",
    "codSaber": "102827-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "2681",
    "codSaber": "102828-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2682",
    "codSaber": "102829-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2683",
    "codSaber": "102830-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "2685",
    "codSaber": "102831-00"
  },
  {
    "centro": "SANDIAL",
    "codPres": "2686",
    "codSaber": "102832-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "2687",
    "codSaber": "102833-00"
  },
  {
    "centro": "NUEVA GUATEMALA",
    "codPres": "2688",
    "codSaber": "102834-00"
  },
  {
    "centro": "SOLANIA",
    "codPres": "2689",
    "codSaber": "102835-00"
  },
  {
    "centro": "JAIME GUTIÉRREZ BRAUN",
    "codPres": "2690",
    "codSaber": "102836-00"
  },
  {
    "centro": "JOSÉ MARÍA CALDERÓN",
    "codPres": "2691",
    "codSaber": "102837-00"
  },
  {
    "centro": "TRES HERMANOS",
    "codPres": "2692",
    "codSaber": "102838-00"
  },
  {
    "centro": "TRONADORA",
    "codPres": "2693",
    "codSaber": "102839-00"
  },
  {
    "centro": "TURÍN",
    "codPres": "2694",
    "codSaber": "102840-00"
  },
  {
    "centro": "CAÑITAS",
    "codPres": "2695",
    "codSaber": "102841-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "2696",
    "codSaber": "102842-00"
  },
  {
    "centro": "HIGUERILLAS",
    "codPres": "2697",
    "codSaber": "102843-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "2698",
    "codSaber": "102844-00"
  },
  {
    "centro": "RIOJALANDIA",
    "codPres": "2699",
    "codSaber": "102845-00"
  },
  {
    "centro": "ABANGARITOS",
    "codPres": "2700",
    "codSaber": "102846-00"
  },
  {
    "centro": "LA ABUELA",
    "codPres": "2701",
    "codSaber": "102847-00"
  },
  {
    "centro": "LA FLORIDA",
    "codPres": "2702",
    "codSaber": "102848-00"
  },
  {
    "centro": "PLAYA BLANCA",
    "codPres": "2703",
    "codSaber": "102849-00"
  },
  {
    "centro": "BELLO HORIZONTE",
    "codPres": "2704",
    "codSaber": "102850-00"
  },
  {
    "centro": "SANTA TERESA",
    "codPres": "2705",
    "codSaber": "102851-00"
  },
  {
    "centro": "I.D.A. VALLE AZUL",
    "codPres": "2706",
    "codSaber": "102852-00"
  },
  {
    "centro": "DIEGO DE ARTIEDA CHIRINO",
    "codPres": "2708",
    "codSaber": "102853-00"
  },
  {
    "centro": "GUARDIANES DE LA PIEDRA",
    "codPres": "2709",
    "codSaber": "102854-00"
  },
  {
    "centro": "LA COLINA",
    "codPres": "2710",
    "codSaber": "102855-00"
  },
  {
    "centro": "ARANJUECITO",
    "codPres": "2711",
    "codSaber": "102856-00"
  },
  {
    "centro": "ARANJUEZ",
    "codPres": "2712",
    "codSaber": "102857-00"
  },
  {
    "centro": "EL CHAGÜITE",
    "codPres": "2714",
    "codSaber": "102858-00"
  },
  {
    "centro": "AUGUSTO COLOMBARI CHICOLI",
    "codPres": "2715",
    "codSaber": "102859-00"
  },
  {
    "centro": "ISLA DE CEDROS",
    "codPres": "2717",
    "codSaber": "102860-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "2718",
    "codSaber": "102861-00"
  },
  {
    "centro": "LOS LLANOS",
    "codPres": "2719",
    "codSaber": "102862-00"
  },
  {
    "centro": "BAJO CALIENTE",
    "codPres": "2720",
    "codSaber": "102863-00"
  },
  {
    "centro": "BAJOS DE ARIO",
    "codPres": "2721",
    "codSaber": "102864-00"
  },
  {
    "centro": "BAJOS NEGROS",
    "codPres": "2722",
    "codSaber": "102865-00"
  },
  {
    "centro": "JUANITO MORA PORRAS",
    "codPres": "2723",
    "codSaber": "102866-00"
  },
  {
    "centro": "ACAPULCO",
    "codPres": "2724",
    "codSaber": "102867-00"
  },
  {
    "centro": "BOCANA",
    "codPres": "2725",
    "codSaber": "102868-00"
  },
  {
    "centro": "VILLA BRUSELAS",
    "codPres": "2726",
    "codSaber": "102869-00"
  },
  {
    "centro": "BRISAS DEL GOLFO",
    "codPres": "2727",
    "codSaber": "102870-00"
  },
  {
    "centro": "BRUSELAS",
    "codPres": "2728",
    "codSaber": "102871-00"
  },
  {
    "centro": "ARTURO TORRES MARTÍNEZ",
    "codPres": "2729",
    "codSaber": "102872-00"
  },
  {
    "centro": "CONFEDERACIÓN SUIZA",
    "codPres": "2730",
    "codSaber": "102873-00"
  },
  {
    "centro": "SAN JUAN CHIQUITO",
    "codPres": "2731",
    "codSaber": "102874-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "2732",
    "codSaber": "102875-00"
  },
  {
    "centro": "CALDERA",
    "codPres": "2734",
    "codSaber": "102876-00"
  },
  {
    "centro": "RÍO BARRANCA",
    "codPres": "2735",
    "codSaber": "102877-00"
  },
  {
    "centro": "SAN AGUSTÍN",
    "codPres": "2736",
    "codSaber": "102878-00"
  },
  {
    "centro": "CARMEN LYRA",
    "codPres": "2737",
    "codSaber": "102879-00"
  },
  {
    "centro": "J.N. RIOJALANDIA",
    "codPres": "2738",
    "codSaber": "102880-00"
  },
  {
    "centro": "CERRILLOS",
    "codPres": "2739",
    "codSaber": "102881-00"
  },
  {
    "centro": "JOSÉ FRANCISCO PÉREZ MUÑOZ",
    "codPres": "2740",
    "codSaber": "102882-00"
  },
  {
    "centro": "TIVIVES",
    "codPres": "2741",
    "codSaber": "102883-00"
  },
  {
    "centro": "CIRUELAS",
    "codPres": "2742",
    "codSaber": "102884-00"
  },
  {
    "centro": "MONTERO Y PALITO",
    "codPres": "2743",
    "codSaber": "102885-00"
  },
  {
    "centro": "CIUDADELA KENNEDY",
    "codPres": "2744",
    "codSaber": "102886-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "2745",
    "codSaber": "102887-00"
  },
  {
    "centro": "CONCEPCIÓN DE PAQUERA",
    "codPres": "2746",
    "codSaber": "102888-00"
  },
  {
    "centro": "CORAZÓN DE JESÚS",
    "codPres": "2748",
    "codSaber": "102889-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2749",
    "codSaber": "102890-00"
  },
  {
    "centro": "EL MALINCHE",
    "codPres": "2750",
    "codSaber": "102891-00"
  },
  {
    "centro": "PUNTA CUCHILLO",
    "codPres": "2751",
    "codSaber": "102892-00"
  },
  {
    "centro": "CABO BLANCO",
    "codPres": "2752",
    "codSaber": "102893-00"
  },
  {
    "centro": "CABUYA",
    "codPres": "2753",
    "codSaber": "102894-00"
  },
  {
    "centro": "CAMARONAL",
    "codPres": "2754",
    "codSaber": "102895-00"
  },
  {
    "centro": "CAMBALACHE",
    "codPres": "2755",
    "codSaber": "102896-00"
  },
  {
    "centro": "CEDRAL",
    "codPres": "2756",
    "codSaber": "102897-00"
  },
  {
    "centro": "CERRO FRÍO",
    "codPres": "2757",
    "codSaber": "102898-00"
  },
  {
    "centro": "RAFAEL ARGUEDAS HERRERA",
    "codPres": "2758",
    "codSaber": "102899-00"
  },
  {
    "centro": "CHAPERNAL",
    "codPres": "2759",
    "codSaber": "102900-00"
  },
  {
    "centro": "ISLA DE CHIRA",
    "codPres": "2760",
    "codSaber": "102901-00"
  },
  {
    "centro": "NORA MARÍA QUESADA CHAVARRÍA",
    "codPres": "2761",
    "codSaber": "102902-00"
  },
  {
    "centro": "TOBÍAS MONTERO CASCANTE",
    "codPres": "2762",
    "codSaber": "102903-00"
  },
  {
    "centro": "COYOLITO",
    "codPres": "2763",
    "codSaber": "102904-00"
  },
  {
    "centro": "I.D.A. EL BARÓN",
    "codPres": "2764",
    "codSaber": "102905-00"
  },
  {
    "centro": "CUAJINIQUIL",
    "codPres": "2765",
    "codSaber": "102906-00"
  },
  {
    "centro": "DOMINICA",
    "codPres": "2766",
    "codSaber": "102907-00"
  },
  {
    "centro": "FERNÁNDEZ",
    "codPres": "2767",
    "codSaber": "102908-00"
  },
  {
    "centro": "PANICA DOS",
    "codPres": "2768",
    "codSaber": "102909-00"
  },
  {
    "centro": "JARQUÍN",
    "codPres": "2769",
    "codSaber": "102910-00"
  },
  {
    "centro": "ROSARIO VÁSQUEZ MONGE",
    "codPres": "2770",
    "codSaber": "102911-00"
  },
  {
    "centro": "LINDORA",
    "codPres": "2771",
    "codSaber": "102912-00"
  },
  {
    "centro": "LA PITA",
    "codPres": "2772",
    "codSaber": "102913-00"
  },
  {
    "centro": "LEPANTO",
    "codPres": "2773",
    "codSaber": "102914-00"
  },
  {
    "centro": "MAL PAÍS",
    "codPres": "2774",
    "codSaber": "102915-00"
  },
  {
    "centro": "MESETAS ABAJO",
    "codPres": "2775",
    "codSaber": "102916-00"
  },
  {
    "centro": "MONTAÑA GRANDE",
    "codPres": "2776",
    "codSaber": "102917-00"
  },
  {
    "centro": "MOCTEZUMA",
    "codPres": "2777",
    "codSaber": "102918-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "2778",
    "codSaber": "102919-00"
  },
  {
    "centro": "PEÑAS BLANCAS",
    "codPres": "2779",
    "codSaber": "102920-00"
  },
  {
    "centro": "SALINAS",
    "codPres": "2780",
    "codSaber": "102921-00"
  },
  {
    "centro": "SAN BLAS",
    "codPres": "2781",
    "codSaber": "102922-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "2782",
    "codSaber": "102923-00"
  },
  {
    "centro": "SANTA CLEMENCIA",
    "codPres": "2783",
    "codSaber": "102924-00"
  },
  {
    "centro": "JORGE BORBÓN CASTRO",
    "codPres": "2784",
    "codSaber": "102925-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2785",
    "codSaber": "102926-00"
  },
  {
    "centro": "TEODORO SALAMANCA",
    "codPres": "2786",
    "codSaber": "102927-00"
  },
  {
    "centro": "ZAPOTAL",
    "codPres": "2787",
    "codSaber": "102928-00"
  },
  {
    "centro": "DELIA URBINA DE GUEVARA",
    "codPres": "2788",
    "codSaber": "102929-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "2789",
    "codSaber": "102930-00"
  },
  {
    "centro": "EL BARÓN",
    "codPres": "2790",
    "codSaber": "102931-00"
  },
  {
    "centro": "EL BRILLANTE",
    "codPres": "2791",
    "codSaber": "102932-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "2792",
    "codSaber": "102933-00"
  },
  {
    "centro": "VILLA NUEVA",
    "codPres": "2793",
    "codSaber": "102934-00"
  },
  {
    "centro": "EL COTO",
    "codPres": "2794",
    "codSaber": "102935-00"
  },
  {
    "centro": "EL MOJÓN",
    "codPres": "2795",
    "codSaber": "102936-00"
  },
  {
    "centro": "EL NÍSPERO",
    "codPres": "2796",
    "codSaber": "102937-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2797",
    "codSaber": "102938-00"
  },
  {
    "centro": "JUSTO ANTONIO FACIO",
    "codPres": "2798",
    "codSaber": "102939-00"
  },
  {
    "centro": "GIGANTE",
    "codPres": "2799",
    "codSaber": "102940-00"
  },
  {
    "centro": "GIL GONZÁLEZ DÁVILA",
    "codPres": "2800",
    "codSaber": "102941-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "2802",
    "codSaber": "102943-00"
  },
  {
    "centro": "ISLA DE VENADO",
    "codPres": "2803",
    "codSaber": "102944-00"
  },
  {
    "centro": "JOSÉ MARÍA ZELEDÓN BRENES",
    "codPres": "2804",
    "codSaber": "102945-00"
  },
  {
    "centro": "JOSÉ RICARDO ORLICH ZAMORA",
    "codPres": "2805",
    "codSaber": "102946-00"
  },
  {
    "centro": "JUAN RAFAEL JIMÉNEZ GRANADOS",
    "codPres": "2806",
    "codSaber": "102947-00"
  },
  {
    "centro": "JUDAS",
    "codPres": "2807",
    "codSaber": "102948-00"
  },
  {
    "centro": "JULIO ACOSTA GARCÍA",
    "codPres": "2808",
    "codSaber": "102949-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "2809",
    "codSaber": "102950-00"
  },
  {
    "centro": "LA FRESCA",
    "codPres": "2811",
    "codSaber": "102951-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "2813",
    "codSaber": "102953-00"
  },
  {
    "centro": "PLAYA TORRES",
    "codPres": "2814",
    "codSaber": "102954-00"
  },
  {
    "centro": "LOS MANGOS",
    "codPres": "2815",
    "codSaber": "102955-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "2816",
    "codSaber": "102956-00"
  },
  {
    "centro": "LA ILUSION",
    "codPres": "2818",
    "codSaber": "102957-00"
  },
  {
    "centro": "LA ISLA",
    "codPres": "2819",
    "codSaber": "102958-00"
  },
  {
    "centro": "LAGUNA",
    "codPres": "2820",
    "codSaber": "102959-00"
  },
  {
    "centro": "LA TIGRA",
    "codPres": "2821",
    "codSaber": "102960-00"
  },
  {
    "centro": "PEDRO ROSALES REYES",
    "codPres": "2823",
    "codSaber": "102961-00"
  },
  {
    "centro": "LAGARTOS",
    "codPres": "2824",
    "codSaber": "102962-00"
  },
  {
    "centro": "LAS MILPAS",
    "codPres": "2825",
    "codSaber": "102963-00"
  },
  {
    "centro": "BARRIO SAN LUIS",
    "codPres": "2826",
    "codSaber": "102964-00"
  },
  {
    "centro": "LAS VENTANAS",
    "codPres": "2827",
    "codSaber": "102965-00"
  },
  {
    "centro": "ALTOS DE SAN LUIS",
    "codPres": "2828",
    "codSaber": "102966-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2829",
    "codSaber": "102967-00"
  },
  {
    "centro": "MANZANILLO",
    "codPres": "2831",
    "codSaber": "102968-00"
  },
  {
    "centro": "MARAÑONAL",
    "codPres": "2832",
    "codSaber": "102969-00"
  },
  {
    "centro": "MARATÓN",
    "codPres": "2833",
    "codSaber": "102970-00"
  },
  {
    "centro": "FLORA GUEVARA BARAHONA",
    "codPres": "2834",
    "codSaber": "102971-00"
  },
  {
    "centro": "MOJONCITO",
    "codPres": "2835",
    "codSaber": "102972-00"
  },
  {
    "centro": "MORA Y CAÑAS",
    "codPres": "2836",
    "codSaber": "102973-00"
  },
  {
    "centro": "COCOROCAS",
    "codPres": "2837",
    "codSaber": "102974-00"
  },
  {
    "centro": "ARTURO GARCÍA GOLCHER",
    "codPres": "2838",
    "codSaber": "102975-00"
  },
  {
    "centro": "MORALES",
    "codPres": "2839",
    "codSaber": "102976-00"
  },
  {
    "centro": "HERIBERTO ZELEDÓN RODRÍGUEZ",
    "codPres": "2840",
    "codSaber": "102977-00"
  },
  {
    "centro": "PUNTA DEL RÍO",
    "codPres": "2841",
    "codSaber": "102978-00"
  },
  {
    "centro": "SAN MIGUELITO",
    "codPres": "2843",
    "codSaber": "102979-00"
  },
  {
    "centro": "EL PALMAR",
    "codPres": "2844",
    "codSaber": "102980-00"
  },
  {
    "centro": "PALMITAL",
    "codPres": "2845",
    "codSaber": "102981-00"
  },
  {
    "centro": "PAVÓN",
    "codPres": "2846",
    "codSaber": "102982-00"
  },
  {
    "centro": "PELAYO MARCET CASAJUANA",
    "codPres": "2847",
    "codSaber": "102983-00"
  },
  {
    "centro": "PITAHAYA",
    "codPres": "2848",
    "codSaber": "102984-00"
  },
  {
    "centro": "POCHOTE",
    "codPres": "2849",
    "codSaber": "102985-00"
  },
  {
    "centro": "DR. RICARDO MORENO CAÑAS",
    "codPres": "2851",
    "codSaber": "102986-00"
  },
  {
    "centro": "RÍO FRÍO",
    "codPres": "2852",
    "codSaber": "102987-00"
  },
  {
    "centro": "RÍO GRANDE",
    "codPres": "2853",
    "codSaber": "102988-00"
  },
  {
    "centro": "RÍO NEGRO",
    "codPres": "2854",
    "codSaber": "102989-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "2855",
    "codSaber": "102990-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2856",
    "codSaber": "102991-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "2857",
    "codSaber": "102992-00"
  },
  {
    "centro": "SAN BUENAVENTURA",
    "codPres": "2858",
    "codSaber": "102993-00"
  },
  {
    "centro": "SABANA BONITA",
    "codPres": "2859",
    "codSaber": "102994-00"
  },
  {
    "centro": "SAN FERNANDO",
    "codPres": "2860",
    "codSaber": "102995-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "2861",
    "codSaber": "102996-00"
  },
  {
    "centro": "SAN MARTÍN SUR",
    "codPres": "2862",
    "codSaber": "102997-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "2863",
    "codSaber": "102998-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "2864",
    "codSaber": "102999-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "2865",
    "codSaber": "103000-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "2866",
    "codSaber": "103001-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "2867",
    "codSaber": "103002-00"
  },
  {
    "centro": "DOMINGO FAUSTINO SARMIENTO",
    "codPres": "2868",
    "codSaber": "103003-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2869",
    "codSaber": "103004-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "2870",
    "codSaber": "103005-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "2871",
    "codSaber": "103006-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "2872",
    "codSaber": "103007-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "2873",
    "codSaber": "103008-00"
  },
  {
    "centro": "TAJO ALTO",
    "codPres": "2874",
    "codSaber": "103009-00"
  },
  {
    "centro": "ANTONIO VALLERRIESTRA",
    "codPres": "2875",
    "codSaber": "103010-00"
  },
  {
    "centro": "ZAGALA VIEJA",
    "codPres": "2876",
    "codSaber": "103011-00"
  },
  {
    "centro": "J.N. ESPARZA",
    "codPres": "2878",
    "codSaber": "103013-00"
  },
  {
    "centro": "J.N. PUNTARENAS",
    "codPres": "2879",
    "codSaber": "103014-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA ISLA CABALLO",
    "codPres": "2880",
    "codSaber": "105047-00"
  },
  {
    "centro": "MATA LIMÓN",
    "codPres": "2881",
    "codSaber": "103016-00"
  },
  {
    "centro": "VEINTE DE NOVIEMBRE",
    "codPres": "2883",
    "codSaber": "103017-00"
  },
  {
    "centro": "FRAY CASIANO DE MADRID",
    "codPres": "2884",
    "codSaber": "103018-00"
  },
  {
    "centro": "J.N. FRAY CASIANO DE MADRID",
    "codPres": "2885",
    "codSaber": "103019-00"
  },
  {
    "centro": "ROSA BARQUERO AZOFEIFA",
    "codPres": "2886",
    "codSaber": "103020-00"
  },
  {
    "centro": "VILLA BONITA",
    "codPres": "2887",
    "codSaber": "103021-00"
  },
  {
    "centro": "ALTOS DEL BRUJO",
    "codPres": "2888",
    "codSaber": "103022-00"
  },
  {
    "centro": "LA BOTA",
    "codPres": "2889",
    "codSaber": "103023-00"
  },
  {
    "centro": "LA CHIVA",
    "codPres": "2891",
    "codSaber": "103025-00"
  },
  {
    "centro": "FEDERICO GUTIÉRREZ BRAUN",
    "codPres": "2892",
    "codSaber": "103026-00"
  },
  {
    "centro": "VIQUILLA DOS",
    "codPres": "2893",
    "codSaber": "103027-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "2894",
    "codSaber": "103028-00"
  },
  {
    "centro": "LA ORQUÍDEA",
    "codPres": "2895",
    "codSaber": "103029-00"
  },
  {
    "centro": "BRUNCA",
    "codPres": "2896",
    "codSaber": "103030-00"
  },
  {
    "centro": "ALBERTO ECHANDI MONTERO",
    "codPres": "2898",
    "codSaber": "103032-00"
  },
  {
    "centro": "CENIZO",
    "codPres": "2899",
    "codSaber": "103033-00"
  },
  {
    "centro": "LA FORTUNA",
    "codPres": "2900",
    "codSaber": "103034-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "2901",
    "codSaber": "103035-00"
  },
  {
    "centro": "BARRIO NUEVO",
    "codPres": "2902",
    "codSaber": "103036-00"
  },
  {
    "centro": "ALTO LOS MOGOS",
    "codPres": "2903",
    "codSaber": "103037-00"
  },
  {
    "centro": "BELLO ORIENTE",
    "codPres": "2904",
    "codSaber": "103038-00"
  },
  {
    "centro": "VILLA ROMA",
    "codPres": "2907",
    "codSaber": "103039-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "2908",
    "codSaber": "103040-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "2910",
    "codSaber": "103041-00"
  },
  {
    "centro": "ÁLVARO PARÍS STEFFENS",
    "codPres": "2911",
    "codSaber": "103042-00"
  },
  {
    "centro": "SANTA CLARA",
    "codPres": "2912",
    "codSaber": "103043-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "2913",
    "codSaber": "103044-00"
  },
  {
    "centro": "PALMIRA",
    "codPres": "2915",
    "codSaber": "103045-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2916",
    "codSaber": "103046-00"
  },
  {
    "centro": "VALLE HERMOSO",
    "codPres": "2918",
    "codSaber": "103048-00"
  },
  {
    "centro": "VALLE LOS CEDROS",
    "codPres": "2919",
    "codSaber": "103049-00"
  },
  {
    "centro": "ALTAMIRA",
    "codPres": "2920",
    "codSaber": "103050-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "2922",
    "codSaber": "103052-00"
  },
  {
    "centro": "AJUNTADERAS",
    "codPres": "2923",
    "codSaber": "103053-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "2927",
    "codSaber": "103056-00"
  },
  {
    "centro": "LA HACIENDA",
    "codPres": "2928",
    "codSaber": "103057-00"
  },
  {
    "centro": "ALPHA",
    "codPres": "2929",
    "codSaber": "103058-00"
  },
  {
    "centro": "LA RIVIERA",
    "codPres": "2930",
    "codSaber": "103059-00"
  },
  {
    "centro": "BRASILIA",
    "codPres": "2931",
    "codSaber": "103060-00"
  },
  {
    "centro": "KOGOKEAIBTA",
    "codPres": "2932",
    "codSaber": "103061-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "2933",
    "codSaber": "103062-00"
  },
  {
    "centro": "NGÖBEGÜE",
    "codPres": "2934",
    "codSaber": "103063-00"
  },
  {
    "centro": "EL TRIUNFO",
    "codPres": "2935",
    "codSaber": "103064-00"
  },
  {
    "centro": "BAHÍA DE PAVÓN",
    "codPres": "2936",
    "codSaber": "103065-00"
  },
  {
    "centro": "GUAYMÍ",
    "codPres": "2937",
    "codSaber": "103066-00"
  },
  {
    "centro": "VALLE DE EL DIQUIS",
    "codPres": "2938",
    "codSaber": "103067-00"
  },
  {
    "centro": "LINDA MAR",
    "codPres": "2939",
    "codSaber": "103068-00"
  },
  {
    "centro": "RESIDENCIAL UREÑA",
    "codPres": "2940",
    "codSaber": "103069-00"
  },
  {
    "centro": "BAJO DE REYES",
    "codPres": "2941",
    "codSaber": "103070-00"
  },
  {
    "centro": "LA HIERBA",
    "codPres": "2942",
    "codSaber": "103071-00"
  },
  {
    "centro": "SIETE COLINAS",
    "codPres": "2943",
    "codSaber": "103072-00"
  },
  {
    "centro": "RÍO NUEVO",
    "codPres": "2944",
    "codSaber": "103073-00"
  },
  {
    "centro": "LA AMISTAD",
    "codPres": "2945",
    "codSaber": "103074-00"
  },
  {
    "centro": "BALSAR",
    "codPres": "2946",
    "codSaber": "103075-00"
  },
  {
    "centro": "BAJO DE LOS INDIOS",
    "codPres": "2947",
    "codSaber": "103076-00"
  },
  {
    "centro": "VALLE AZUL",
    "codPres": "2948",
    "codSaber": "103077-00"
  },
  {
    "centro": "LAS GEMELAS",
    "codPres": "2949",
    "codSaber": "103078-00"
  },
  {
    "centro": "TRES RÍOS",
    "codPres": "2950",
    "codSaber": "103079-00"
  },
  {
    "centro": "LA VIRGEN",
    "codPres": "2951",
    "codSaber": "103080-00"
  },
  {
    "centro": "I.D.A. PORTO LLANO",
    "codPres": "2952",
    "codSaber": "103081-00"
  },
  {
    "centro": "CUERVITO",
    "codPres": "2954",
    "codSaber": "103083-00"
  },
  {
    "centro": "GUAYACÁN",
    "codPres": "2955",
    "codSaber": "103084-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "2956",
    "codSaber": "103085-00"
  },
  {
    "centro": "MIRAFLORES",
    "codPres": "2957",
    "codSaber": "103086-00"
  },
  {
    "centro": "LA BALSA",
    "codPres": "2958",
    "codSaber": "103087-00"
  },
  {
    "centro": "BRUS MALIS",
    "codPres": "2959",
    "codSaber": "103088-00"
  },
  {
    "centro": "KOGORIBTDA",
    "codPres": "2960",
    "codSaber": "103089-00"
  },
  {
    "centro": "BOCA GALLARDO",
    "codPres": "2961",
    "codSaber": "103090-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "2962",
    "codSaber": "103091-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "2963",
    "codSaber": "103092-00"
  },
  {
    "centro": "CARBONERA",
    "codPres": "2964",
    "codSaber": "103093-00"
  },
  {
    "centro": "LA FUENTE",
    "codPres": "2965",
    "codSaber": "103094-00"
  },
  {
    "centro": "CAÑA BLANCA",
    "codPres": "2966",
    "codSaber": "103095-00"
  },
  {
    "centro": "EL ÑEQUE",
    "codPres": "2967",
    "codSaber": "103096-00"
  },
  {
    "centro": "ALTO MONTERREY",
    "codPres": "2968",
    "codSaber": "103097-00"
  },
  {
    "centro": "CAÑAS GORDAS",
    "codPres": "2969",
    "codSaber": "103098-00"
  },
  {
    "centro": "RÍO MARZO",
    "codPres": "2970",
    "codSaber": "103099-00"
  },
  {
    "centro": "LA JUANITA",
    "codPres": "2971",
    "codSaber": "103100-00"
  },
  {
    "centro": "CAÑAZA",
    "codPres": "2972",
    "codSaber": "103101-00"
  },
  {
    "centro": "LA NUBIA",
    "codPres": "2973",
    "codSaber": "103102-00"
  },
  {
    "centro": "KAMAKIRI",
    "codPres": "2974",
    "codSaber": "103103-00"
  },
  {
    "centro": "COTO SUR",
    "codPres": "2975",
    "codSaber": "103104-00"
  },
  {
    "centro": "SURIK",
    "codPres": "2976",
    "codSaber": "103105-00"
  },
  {
    "centro": "MIRAMAR",
    "codPres": "2977",
    "codSaber": "103106-00"
  },
  {
    "centro": "SAN RAMÓN DE RÍO CLARO",
    "codPres": "2981",
    "codSaber": "103107-00"
  },
  {
    "centro": "QUEBRADA LA TARDE",
    "codPres": "2982",
    "codSaber": "103108-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "2983",
    "codSaber": "103109-00"
  },
  {
    "centro": "CAMPO DOS Y MEDIO",
    "codPres": "2984",
    "codSaber": "103110-00"
  },
  {
    "centro": "CAMPO TRES",
    "codPres": "2985",
    "codSaber": "103111-00"
  },
  {
    "centro": "SALAMÁ",
    "codPres": "2986",
    "codSaber": "103112-00"
  },
  {
    "centro": "LA NAVIDAD",
    "codPres": "2988",
    "codSaber": "103113-00"
  },
  {
    "centro": "CARACOL NORTE",
    "codPres": "2989",
    "codSaber": "103114-00"
  },
  {
    "centro": "SANTA ELENA",
    "codPres": "2990",
    "codSaber": "103115-00"
  },
  {
    "centro": "GUAYABI",
    "codPres": "2991",
    "codSaber": "103116-00"
  },
  {
    "centro": "CIUDADELA GONZÁLEZ",
    "codPres": "2992",
    "codSaber": "103117-00"
  },
  {
    "centro": "FINCA NARANJO",
    "codPres": "2993",
    "codSaber": "103118-00"
  },
  {
    "centro": "ALTO LAGUNA",
    "codPres": "2994",
    "codSaber": "103119-00"
  },
  {
    "centro": "LA PRIMAVERA",
    "codPres": "2995",
    "codSaber": "103120-00"
  },
  {
    "centro": "MIRAMAR",
    "codPres": "2996",
    "codSaber": "103121-00"
  },
  {
    "centro": "CACORAGUA",
    "codPres": "2998",
    "codSaber": "103123-00"
  },
  {
    "centro": "CARIARE",
    "codPres": "2999",
    "codSaber": "103124-00"
  },
  {
    "centro": "LA INDEPENDENCIA",
    "codPres": "3000",
    "codSaber": "103125-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "3001",
    "codSaber": "103126-00"
  },
  {
    "centro": "ESTERO GUERRA",
    "codPres": "3002",
    "codSaber": "103127-00"
  },
  {
    "centro": "LA AMAPOLA",
    "codPres": "3004",
    "codSaber": "103129-00"
  },
  {
    "centro": "LAS NUBES",
    "codPres": "3005",
    "codSaber": "103130-00"
  },
  {
    "centro": "JAIME GUTIÉRREZ BROWN",
    "codPres": "3006",
    "codSaber": "103131-00"
  },
  {
    "centro": "LA ESCUADRA",
    "codPres": "3007",
    "codSaber": "103132-00"
  },
  {
    "centro": "LAUREL",
    "codPres": "3008",
    "codSaber": "103133-00"
  },
  {
    "centro": "FINCA CAUCHO",
    "codPres": "3009",
    "codSaber": "103134-00"
  },
  {
    "centro": "FINCA CAIMITO",
    "codPres": "3010",
    "codSaber": "103135-00"
  },
  {
    "centro": "FINCA TAMARINDO",
    "codPres": "3011",
    "codSaber": "103136-00"
  },
  {
    "centro": "FINCA BAMBITO",
    "codPres": "3012",
    "codSaber": "103137-00"
  },
  {
    "centro": "LA CAMPIÑA",
    "codPres": "3013",
    "codSaber": "103138-00"
  },
  {
    "centro": "LÍDER COMTE",
    "codPres": "3014",
    "codSaber": "103139-00"
  },
  {
    "centro": "BELLA LUZ",
    "codPres": "3015",
    "codSaber": "103140-00"
  },
  {
    "centro": "COPAL",
    "codPres": "3016",
    "codSaber": "103141-00"
  },
  {
    "centro": "LOS CASTAÑOS",
    "codPres": "3017",
    "codSaber": "103142-00"
  },
  {
    "centro": "EL LABRADOR",
    "codPres": "3018",
    "codSaber": "103143-00"
  },
  {
    "centro": "BARRIO CANADÁ",
    "codPres": "3019",
    "codSaber": "103144-00"
  },
  {
    "centro": "LA JULIETA",
    "codPres": "3020",
    "codSaber": "103145-00"
  },
  {
    "centro": "CORONADO",
    "codPres": "3021",
    "codSaber": "103146-00"
  },
  {
    "centro": "AGUAS FRESCAS",
    "codPres": "3022",
    "codSaber": "103147-00"
  },
  {
    "centro": "VILLA PALACIOS",
    "codPres": "3023",
    "codSaber": "103148-00"
  },
  {
    "centro": "NIBIRIBOTDA",
    "codPres": "3024",
    "codSaber": "103149-00"
  },
  {
    "centro": "COCORÍ",
    "codPres": "3025",
    "codSaber": "103150-00"
  },
  {
    "centro": "AGUAS CALIENTES",
    "codPres": "3026",
    "codSaber": "103151-00"
  },
  {
    "centro": "RÍO SALTO",
    "codPres": "3027",
    "codSaber": "103152-00"
  },
  {
    "centro": "VEREH",
    "codPres": "3028",
    "codSaber": "103153-00"
  },
  {
    "centro": "BARRIO ALEMANIA",
    "codPres": "3029",
    "codSaber": "103154-00"
  },
  {
    "centro": "CHOCUACO",
    "codPres": "3031",
    "codSaber": "103155-00"
  },
  {
    "centro": "COLORADO",
    "codPres": "3032",
    "codSaber": "103156-00"
  },
  {
    "centro": "SAN JOSECITO",
    "codPres": "3033",
    "codSaber": "103157-00"
  },
  {
    "centro": "NAZARETH",
    "codPres": "3035",
    "codSaber": "103158-00"
  },
  {
    "centro": "LA ESTRELLA",
    "codPres": "3036",
    "codSaber": "103159-00"
  },
  {
    "centro": "PUNTA BANCO",
    "codPres": "3037",
    "codSaber": "103160-00"
  },
  {
    "centro": "VISTA DE TÉRRABA",
    "codPres": "3038",
    "codSaber": "103161-00"
  },
  {
    "centro": "JABILLO",
    "codPres": "3039",
    "codSaber": "103162-00"
  },
  {
    "centro": "LA SANSI",
    "codPres": "3040",
    "codSaber": "103163-00"
  },
  {
    "centro": "MARÍA AUXILIADORA",
    "codPres": "3041",
    "codSaber": "103164-00"
  },
  {
    "centro": "CURIME",
    "codPres": "3042",
    "codSaber": "103165-00"
  },
  {
    "centro": "LA FLOR DEL ROBLE",
    "codPres": "3043",
    "codSaber": "103166-00"
  },
  {
    "centro": "RÍO INCENDIO",
    "codPres": "3044",
    "codSaber": "103167-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "3045",
    "codSaber": "103168-00"
  },
  {
    "centro": "SIERPE",
    "codPres": "3046",
    "codSaber": "103169-00"
  },
  {
    "centro": "ABROJO GUAYMÍ",
    "codPres": "3047",
    "codSaber": "103170-00"
  },
  {
    "centro": "DOS BRAZOS DE RÍO TIGRE",
    "codPres": "3048",
    "codSaber": "103171-00"
  },
  {
    "centro": "DRAKE",
    "codPres": "3049",
    "codSaber": "103172-00"
  },
  {
    "centro": "EL REFUGIO",
    "codPres": "3050",
    "codSaber": "103173-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "3051",
    "codSaber": "103174-00"
  },
  {
    "centro": "EDUARDO GARNIER UGALDE",
    "codPres": "3052",
    "codSaber": "103175-00"
  },
  {
    "centro": "EL DANTO",
    "codPres": "3053",
    "codSaber": "103176-00"
  },
  {
    "centro": "MÄDÄRíBOTDÄ",
    "codPres": "3054",
    "codSaber": "103177-00"
  },
  {
    "centro": "ELOY MORÚA CARRILLO",
    "codPres": "3056",
    "codSaber": "103179-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "3057",
    "codSaber": "103180-00"
  },
  {
    "centro": "JOBO CIVIL",
    "codPres": "3058",
    "codSaber": "103181-00"
  },
  {
    "centro": "COQUITO",
    "codPres": "3059",
    "codSaber": "103182-00"
  },
  {
    "centro": "FILA GUINEA",
    "codPres": "3061",
    "codSaber": "103184-00"
  },
  {
    "centro": "FILA DE MÉNDEZ",
    "codPres": "3062",
    "codSaber": "103185-00"
  },
  {
    "centro": "FILA DE TRUCHO",
    "codPres": "3063",
    "codSaber": "103186-00"
  },
  {
    "centro": "LA FLORIDA",
    "codPres": "3064",
    "codSaber": "103187-00"
  },
  {
    "centro": "JOSÉ GONZÁLO ACUÑA HERNÁNDEZ",
    "codPres": "3065",
    "codSaber": "103188-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3066",
    "codSaber": "103189-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "3067",
    "codSaber": "103190-00"
  },
  {
    "centro": "ANA MARÍA GUARDIA MORA",
    "codPres": "3068",
    "codSaber": "103191-00"
  },
  {
    "centro": "JUAN LARA ALFARO",
    "codPres": "3069",
    "codSaber": "103192-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3070",
    "codSaber": "103193-00"
  },
  {
    "centro": "I.D.A. AGUJAS",
    "codPres": "3071",
    "codSaber": "103194-00"
  },
  {
    "centro": "KILÓMETRO 16",
    "codPres": "3072",
    "codSaber": "103195-00"
  },
  {
    "centro": "KILÓMETRO 20",
    "codPres": "3073",
    "codSaber": "103196-00"
  },
  {
    "centro": "KILÓMETRO 24",
    "codPres": "3074",
    "codSaber": "103197-00"
  },
  {
    "centro": "KILÓMETRO 29",
    "codPres": "3075",
    "codSaber": "103198-00"
  },
  {
    "centro": "KILÓMETRO SIETE",
    "codPres": "3076",
    "codSaber": "103199-00"
  },
  {
    "centro": "CONFRATERNIDAD",
    "codPres": "3077",
    "codSaber": "103200-00"
  },
  {
    "centro": "LA FUENTE",
    "codPres": "3078",
    "codSaber": "103201-00"
  },
  {
    "centro": "LA GAMBA",
    "codPres": "3079",
    "codSaber": "103202-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "3080",
    "codSaber": "103203-00"
  },
  {
    "centro": "QUIABDO",
    "codPres": "3081",
    "codSaber": "103204-00"
  },
  {
    "centro": "FILA SAN RAFAEL",
    "codPres": "3082",
    "codSaber": "103205-00"
  },
  {
    "centro": "META PONTO",
    "codPres": "3083",
    "codSaber": "103206-00"
  },
  {
    "centro": "LA ISLA",
    "codPres": "3084",
    "codSaber": "103207-00"
  },
  {
    "centro": "LA LUCHA",
    "codPres": "3085",
    "codSaber": "103208-00"
  },
  {
    "centro": "LA MANCHURIA",
    "codPres": "3086",
    "codSaber": "103209-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "3087",
    "codSaber": "103210-00"
  },
  {
    "centro": "LA MARIPOSA",
    "codPres": "3088",
    "codSaber": "103211-00"
  },
  {
    "centro": "IRIGUI",
    "codPres": "3089",
    "codSaber": "103212-00"
  },
  {
    "centro": "LA MONA",
    "codPres": "3090",
    "codSaber": "103213-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "3091",
    "codSaber": "103214-00"
  },
  {
    "centro": "LA PEÑA",
    "codPres": "3092",
    "codSaber": "103215-00"
  },
  {
    "centro": "ADELE CLARINI",
    "codPres": "3093",
    "codSaber": "103216-00"
  },
  {
    "centro": "BAHÍA CHAL",
    "codPres": "3094",
    "codSaber": "103217-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "3095",
    "codSaber": "103218-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "3096",
    "codSaber": "103219-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3097",
    "codSaber": "103220-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3098",
    "codSaber": "103221-00"
  },
  {
    "centro": "RIYITO",
    "codPres": "3099",
    "codSaber": "103222-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "3100",
    "codSaber": "103223-00"
  },
  {
    "centro": "LAS MELLIZAS",
    "codPres": "3101",
    "codSaber": "103224-00"
  },
  {
    "centro": "LAS TRENZAS",
    "codPres": "3103",
    "codSaber": "103226-00"
  },
  {
    "centro": "LAS VEGAS DE RÍO ABROJO",
    "codPres": "3104",
    "codSaber": "103227-00"
  },
  {
    "centro": "ALTO DE COMTE",
    "codPres": "3105",
    "codSaber": "103228-00"
  },
  {
    "centro": "LEONOR CHINCHILLA DE FIGUEROA",
    "codPres": "3106",
    "codSaber": "103229-00"
  },
  {
    "centro": "LIMONCITO",
    "codPres": "3107",
    "codSaber": "103230-00"
  },
  {
    "centro": "LA VICTORIA",
    "codPres": "3108",
    "codSaber": "103231-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3109",
    "codSaber": "103232-00"
  },
  {
    "centro": "LOS PLANES",
    "codPres": "3110",
    "codSaber": "103233-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "3111",
    "codSaber": "103234-00"
  },
  {
    "centro": "MOISÉS VINCENZI PACHECO",
    "codPres": "3112",
    "codSaber": "103235-00"
  },
  {
    "centro": "FILA TIGRE",
    "codPres": "3113",
    "codSaber": "103236-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "3114",
    "codSaber": "103237-00"
  },
  {
    "centro": "PASO CANOAS",
    "codPres": "3115",
    "codSaber": "103238-00"
  },
  {
    "centro": "SANTA MARÍA DE PITTIER",
    "codPres": "3116",
    "codSaber": "103239-00"
  },
  {
    "centro": "MARÍA ROSA GÁMEZ SOLANO",
    "codPres": "3117",
    "codSaber": "103240-00"
  },
  {
    "centro": "EL ROBLE ARRIBA",
    "codPres": "3118",
    "codSaber": "103241-00"
  },
  {
    "centro": "FINCA JALACA",
    "codPres": "3119",
    "codSaber": "103242-00"
  },
  {
    "centro": "DARIZARA",
    "codPres": "3120",
    "codSaber": "103243-00"
  },
  {
    "centro": "POTREROS DE SIERPE",
    "codPres": "3123",
    "codSaber": "103244-00"
  },
  {
    "centro": "VILLA NUEVA",
    "codPres": "3124",
    "codSaber": "103245-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3125",
    "codSaber": "103246-00"
  },
  {
    "centro": "EL MANZANO",
    "codPres": "3126",
    "codSaber": "103247-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "3127",
    "codSaber": "103248-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3128",
    "codSaber": "103249-00"
  },
  {
    "centro": "PUERTO ESCONDIDO",
    "codPres": "3129",
    "codSaber": "103250-00"
  },
  {
    "centro": "PUNTA MALA",
    "codPres": "3130",
    "codSaber": "103251-00"
  },
  {
    "centro": "PUNTA ZANCUDO",
    "codPres": "3131",
    "codSaber": "103252-00"
  },
  {
    "centro": "MONTELIMAR",
    "codPres": "3132",
    "codSaber": "103253-00"
  },
  {
    "centro": "I.D.A. ALTO DE SAN JUAN",
    "codPres": "3133",
    "codSaber": "103254-00"
  },
  {
    "centro": "NUEVA ZELANDIA",
    "codPres": "3134",
    "codSaber": "103255-00"
  },
  {
    "centro": "CENTRAL RÍO CLARO",
    "codPres": "3135",
    "codSaber": "103256-00"
  },
  {
    "centro": "SANTIAGO",
    "codPres": "3136",
    "codSaber": "103257-00"
  },
  {
    "centro": "RÍO ORO",
    "codPres": "3137",
    "codSaber": "103258-00"
  },
  {
    "centro": "RÍO ESQUINAS",
    "codPres": "3138",
    "codSaber": "103259-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "3139",
    "codSaber": "103260-00"
  },
  {
    "centro": "LA CHACARITA",
    "codPres": "3140",
    "codSaber": "103261-00"
  },
  {
    "centro": "COYOCHE",
    "codPres": "3141",
    "codSaber": "103262-00"
  },
  {
    "centro": "FINCA MANGO",
    "codPres": "3142",
    "codSaber": "103263-00"
  },
  {
    "centro": "ESTRELLA DEL SUR",
    "codPres": "3144",
    "codSaber": "103264-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "3145",
    "codSaber": "103265-00"
  },
  {
    "centro": "TIGRITO",
    "codPres": "3146",
    "codSaber": "103266-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "3147",
    "codSaber": "103267-00"
  },
  {
    "centro": "CANGREJO VERDE",
    "codPres": "3148",
    "codSaber": "103268-00"
  },
  {
    "centro": "VISTA DEL MAR",
    "codPres": "3149",
    "codSaber": "103269-00"
  },
  {
    "centro": "LA CONCORDIA",
    "codPres": "3151",
    "codSaber": "103271-00"
  },
  {
    "centro": "SÁBALO DE SIERPE",
    "codPres": "3152",
    "codSaber": "103272-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3153",
    "codSaber": "103273-00"
  },
  {
    "centro": "SABANILLAS",
    "codPres": "3154",
    "codSaber": "103274-00"
  },
  {
    "centro": "SAN ANTONIO DE SABALITO",
    "codPres": "3155",
    "codSaber": "103275-00"
  },
  {
    "centro": "SAN BUENAVENTURA",
    "codPres": "3156",
    "codSaber": "103276-00"
  },
  {
    "centro": "RANCHO QUEMADO",
    "codPres": "3157",
    "codSaber": "103277-00"
  },
  {
    "centro": "SAN CARLOS",
    "codPres": "3158",
    "codSaber": "103278-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "3159",
    "codSaber": "103279-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "3160",
    "codSaber": "103280-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3161",
    "codSaber": "103281-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "3162",
    "codSaber": "103282-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "3163",
    "codSaber": "103283-00"
  },
  {
    "centro": "LUIS WACHONG LEE",
    "codPres": "3164",
    "codSaber": "103284-00"
  },
  {
    "centro": "I.D.A. GUADALUPE",
    "codPres": "3165",
    "codSaber": "103285-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3166",
    "codSaber": "103286-00"
  },
  {
    "centro": "FINCA DIEZ",
    "codPres": "3167",
    "codSaber": "103287-00"
  },
  {
    "centro": "FINCA DOCE",
    "codPres": "3168",
    "codSaber": "103288-00"
  },
  {
    "centro": "FINCA SEIS-ONCE",
    "codPres": "3169",
    "codSaber": "103289-00"
  },
  {
    "centro": "PALMAR SUR",
    "codPres": "3170",
    "codSaber": "103290-00"
  },
  {
    "centro": "FINCA 2-4",
    "codPres": "3171",
    "codSaber": "103291-00"
  },
  {
    "centro": "FINCA TRES",
    "codPres": "3172",
    "codSaber": "103292-00"
  },
  {
    "centro": "FINCA CINCO",
    "codPres": "3173",
    "codSaber": "103293-00"
  },
  {
    "centro": "FINCA SIETE",
    "codPres": "3174",
    "codSaber": "103294-00"
  },
  {
    "centro": "23 DE MAYO",
    "codPres": "3175",
    "codSaber": "103295-00"
  },
  {
    "centro": "FINCA OCHO",
    "codPres": "3176",
    "codSaber": "103296-00"
  },
  {
    "centro": "FINCA NUEVE",
    "codPres": "3177",
    "codSaber": "103297-00"
  },
  {
    "centro": "CENTRAL SAN JOSÉ",
    "codPres": "3178",
    "codSaber": "103298-00"
  },
  {
    "centro": "KILÓMETRO UNO",
    "codPres": "3179",
    "codSaber": "103299-00"
  },
  {
    "centro": "COTO 45",
    "codPres": "3180",
    "codSaber": "103300-00"
  },
  {
    "centro": "CENTRAL COTO 47",
    "codPres": "3181",
    "codSaber": "103301-00"
  },
  {
    "centro": "COTO 58-59",
    "codPres": "3182",
    "codSaber": "103302-00"
  },
  {
    "centro": "COTO 56-57",
    "codPres": "3183",
    "codSaber": "103303-00"
  },
  {
    "centro": "COTO 52",
    "codPres": "3184",
    "codSaber": "103304-00"
  },
  {
    "centro": "COTO 54-55",
    "codPres": "3185",
    "codSaber": "103305-00"
  },
  {
    "centro": "COTO 44",
    "codPres": "3186",
    "codSaber": "103306-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "3187",
    "codSaber": "103307-00"
  },
  {
    "centro": "COTO 50-51",
    "codPres": "3188",
    "codSaber": "103308-00"
  },
  {
    "centro": "COTO 42",
    "codPres": "3189",
    "codSaber": "103309-00"
  },
  {
    "centro": "COTO 62-63",
    "codPres": "3190",
    "codSaber": "103310-00"
  },
  {
    "centro": "SAN MARCOS",
    "codPres": "3191",
    "codSaber": "103311-00"
  },
  {
    "centro": "LAS JUNTAS",
    "codPres": "3192",
    "codSaber": "103312-00"
  },
  {
    "centro": "EL SÁNDALO",
    "codPres": "3193",
    "codSaber": "103313-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "3194",
    "codSaber": "103314-00"
  },
  {
    "centro": "SANTA CONSTANZA",
    "codPres": "3195",
    "codSaber": "103315-00"
  },
  {
    "centro": "SANTA EDUVIGES",
    "codPres": "3196",
    "codSaber": "103316-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "3197",
    "codSaber": "103317-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "3198",
    "codSaber": "103318-00"
  },
  {
    "centro": "SANTIAGO DE CARACOL",
    "codPres": "3199",
    "codSaber": "103319-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "3200",
    "codSaber": "103320-00"
  },
  {
    "centro": "SATURNINO CEDEÑO CEDEÑO",
    "codPres": "3201",
    "codSaber": "103321-00"
  },
  {
    "centro": "FINCA GUANACASTE",
    "codPres": "3202",
    "codSaber": "103322-00"
  },
  {
    "centro": "SINAÍ",
    "codPres": "3203",
    "codSaber": "103323-00"
  },
  {
    "centro": "SAN MARCOS",
    "codPres": "3204",
    "codSaber": "103324-00"
  },
  {
    "centro": "RÍO SERENO",
    "codPres": "3205",
    "codSaber": "103325-00"
  },
  {
    "centro": "LA UNIÓN DEL SUR",
    "codPres": "3206",
    "codSaber": "103326-00"
  },
  {
    "centro": "SANTA CLARA",
    "codPres": "3208",
    "codSaber": "103328-00"
  },
  {
    "centro": "COOPA BUENA",
    "codPres": "3209",
    "codSaber": "103329-00"
  },
  {
    "centro": "SANTA TERESITA",
    "codPres": "3210",
    "codSaber": "103330-00"
  },
  {
    "centro": "TRES RÍOS",
    "codPres": "3211",
    "codSaber": "103331-00"
  },
  {
    "centro": "TORTUGA",
    "codPres": "3212",
    "codSaber": "103332-00"
  },
  {
    "centro": "TORRE ALTA",
    "codPres": "3213",
    "codSaber": "103333-00"
  },
  {
    "centro": "ROBERTO SANDI AZOFEIFA",
    "codPres": "3214",
    "codSaber": "103334-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3215",
    "codSaber": "103335-00"
  },
  {
    "centro": "LAS VEGAS DE ABROJO NORTE",
    "codPres": "3216",
    "codSaber": "103336-00"
  },
  {
    "centro": "VENECIA",
    "codPres": "3217",
    "codSaber": "103337-00"
  },
  {
    "centro": "VILLA COLÓN",
    "codPres": "3218",
    "codSaber": "103338-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "3219",
    "codSaber": "103339-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "3220",
    "codSaber": "103340-00"
  },
  {
    "centro": "SANTA FÉ",
    "codPres": "3221",
    "codSaber": "103341-00"
  },
  {
    "centro": "I.D.A. AGROINDUSTRIAL",
    "codPres": "3222",
    "codSaber": "103342-00"
  },
  {
    "centro": "ALMIRANTE",
    "codPres": "3223",
    "codSaber": "103343-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "3224",
    "codSaber": "103344-00"
  },
  {
    "centro": "LA LIBERTAD",
    "codPres": "3225",
    "codSaber": "103345-00"
  },
  {
    "centro": "PLAYA CACAO",
    "codPres": "3227",
    "codSaber": "103346-00"
  },
  {
    "centro": "MIRAMAR",
    "codPres": "3228",
    "codSaber": "103347-00"
  },
  {
    "centro": "SAN RAFAEL NORTE",
    "codPres": "3229",
    "codSaber": "103348-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "3230",
    "codSaber": "103349-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "3231",
    "codSaber": "103350-00"
  },
  {
    "centro": "LA FLORIDA",
    "codPres": "3233",
    "codSaber": "103351-00"
  },
  {
    "centro": "EL CAMPO",
    "codPres": "3234",
    "codSaber": "103352-00"
  },
  {
    "centro": "RÍO BONITO",
    "codPres": "3235",
    "codSaber": "103353-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3236",
    "codSaber": "103354-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3237",
    "codSaber": "103355-00"
  },
  {
    "centro": "LA FORTUNA",
    "codPres": "3238",
    "codSaber": "103356-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "3240",
    "codSaber": "103357-00"
  },
  {
    "centro": "EL CEIBO",
    "codPres": "3241",
    "codSaber": "103358-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3242",
    "codSaber": "103359-00"
  },
  {
    "centro": "ONCE DE ABRIL",
    "codPres": "3244",
    "codSaber": "103360-00"
  },
  {
    "centro": "FILA NARANJO",
    "codPres": "3245",
    "codSaber": "103361-00"
  },
  {
    "centro": "EL VALLE",
    "codPres": "3246",
    "codSaber": "103362-00"
  },
  {
    "centro": "ESTERO REAL",
    "codPres": "3247",
    "codSaber": "103363-00"
  },
  {
    "centro": "LAS MARÍAS",
    "codPres": "3248",
    "codSaber": "103364-00"
  },
  {
    "centro": "CARACOL DE LA VACA",
    "codPres": "3249",
    "codSaber": "103365-00"
  },
  {
    "centro": "LOS PILARES",
    "codPres": "3250",
    "codSaber": "103366-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "3252",
    "codSaber": "103367-00"
  },
  {
    "centro": "LAS VEGUITAS",
    "codPres": "3253",
    "codSaber": "103368-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3254",
    "codSaber": "103369-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "3255",
    "codSaber": "103370-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "3257",
    "codSaber": "103371-00"
  },
  {
    "centro": "RINCÓN DE OSA",
    "codPres": "3258",
    "codSaber": "103372-00"
  },
  {
    "centro": "FRAY CASIANO DE MADRID",
    "codPres": "3259",
    "codSaber": "103373-00"
  },
  {
    "centro": "PUESTO LA PLAYA",
    "codPres": "3260",
    "codSaber": "103374-00"
  },
  {
    "centro": "ALTOS DE SAN ANTONIO",
    "codPres": "3261",
    "codSaber": "103375-00"
  },
  {
    "centro": "COTO 49",
    "codPres": "3262",
    "codSaber": "103376-00"
  },
  {
    "centro": "NIEBOROWSKY",
    "codPres": "3263",
    "codSaber": "103377-00"
  },
  {
    "centro": "GAVILÁN CANTA",
    "codPres": "3266",
    "codSaber": "103378-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3267",
    "codSaber": "103379-00"
  },
  {
    "centro": "DAVAO",
    "codPres": "3268",
    "codSaber": "103380-00"
  },
  {
    "centro": "ALTO COHEN",
    "codPres": "3269",
    "codSaber": "103381-00"
  },
  {
    "centro": "ALTOS DE BONILLA",
    "codPres": "3271",
    "codSaber": "103382-00"
  },
  {
    "centro": "LAS BRISAS DE ZENT",
    "codPres": "3272",
    "codSaber": "103383-00"
  },
  {
    "centro": "TROCHA LOS CEIBOS",
    "codPres": "3273",
    "codSaber": "103384-00"
  },
  {
    "centro": "LA JOSEFINA",
    "codPres": "3274",
    "codSaber": "103385-00"
  },
  {
    "centro": "BERNARDO DRÜG INGERMAN",
    "codPres": "3275",
    "codSaber": "103386-00"
  },
  {
    "centro": "LOS ALMENDROS",
    "codPres": "3276",
    "codSaber": "103387-00"
  },
  {
    "centro": "EL PORVENIR",
    "codPres": "3277",
    "codSaber": "103388-00"
  },
  {
    "centro": "CEDAR CREEK",
    "codPres": "3278",
    "codSaber": "103389-00"
  },
  {
    "centro": "VILLA HERMOSA",
    "codPres": "3279",
    "codSaber": "103390-00"
  },
  {
    "centro": "UNIÓN CAMPESINA",
    "codPres": "3280",
    "codSaber": "103391-00"
  },
  {
    "centro": "PATIÑO",
    "codPres": "3281",
    "codSaber": "103392-00"
  },
  {
    "centro": "I.D.A. LOUISIANA",
    "codPres": "3282",
    "codSaber": "103393-00"
  },
  {
    "centro": "GANDOCA",
    "codPres": "3283",
    "codSaber": "103394-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3284",
    "codSaber": "103395-00"
  },
  {
    "centro": "ARMENIA",
    "codPres": "3285",
    "codSaber": "103396-00"
  },
  {
    "centro": "LAS BRISAS DEL REVENTAZÓN",
    "codPres": "3286",
    "codSaber": "103397-00"
  },
  {
    "centro": "CATARINA",
    "codPres": "3288",
    "codSaber": "103398-00"
  },
  {
    "centro": "LA AMELIA",
    "codPres": "3289",
    "codSaber": "103399-00"
  },
  {
    "centro": "SIQUIRRITO",
    "codPres": "3290",
    "codSaber": "103400-00"
  },
  {
    "centro": "LLANO GRANDE",
    "codPres": "3291",
    "codSaber": "103401-00"
  },
  {
    "centro": "EL CRUCE",
    "codPres": "3292",
    "codSaber": "103402-00"
  },
  {
    "centro": "SANTO TOMÁS",
    "codPres": "3293",
    "codSaber": "103403-00"
  },
  {
    "centro": "EL PARQUE",
    "codPres": "3294",
    "codSaber": "103404-00"
  },
  {
    "centro": "DUCHÄBLI",
    "codPres": "3295",
    "codSaber": "103405-00"
  },
  {
    "centro": "ALTOS KACHABLI",
    "codPres": "3296",
    "codSaber": "103406-00"
  },
  {
    "centro": "PARAÍSO DE BANANITO",
    "codPres": "3297",
    "codSaber": "103407-00"
  },
  {
    "centro": "TOBÍAS VAGLIO",
    "codPres": "3298",
    "codSaber": "103408-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "3299",
    "codSaber": "103409-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3300",
    "codSaber": "103410-00"
  },
  {
    "centro": "BARRA DE PACUARE",
    "codPres": "3301",
    "codSaber": "103411-00"
  },
  {
    "centro": "KATUIR",
    "codPres": "3302",
    "codSaber": "103412-00"
  },
  {
    "centro": "BALVANERO VARGAS MOLINA",
    "codPres": "3303",
    "codSaber": "103413-00"
  },
  {
    "centro": "BAMBÚ",
    "codPres": "3304",
    "codSaber": "103414-00"
  },
  {
    "centro": "BANANITO NORTE",
    "codPres": "3305",
    "codSaber": "103415-00"
  },
  {
    "centro": "BARRA DE PARISMINA",
    "codPres": "3306",
    "codSaber": "103416-00"
  },
  {
    "centro": "ATILIA MATA FRESES",
    "codPres": "3307",
    "codSaber": "103417-00"
  },
  {
    "centro": "BEVERLY",
    "codPres": "3308",
    "codSaber": "103418-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "3309",
    "codSaber": "103419-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "3310",
    "codSaber": "103420-00"
  },
  {
    "centro": "CUATRO MILLAS",
    "codPres": "3311",
    "codSaber": "103421-00"
  },
  {
    "centro": "LINEA B",
    "codPres": "3312",
    "codSaber": "103422-00"
  },
  {
    "centro": "LA CATALINA",
    "codPres": "3313",
    "codSaber": "103423-00"
  },
  {
    "centro": "BORDÓN LILAN",
    "codPres": "3314",
    "codSaber": "103424-00"
  },
  {
    "centro": "BOSTÓN",
    "codPres": "3315",
    "codSaber": "103425-00"
  },
  {
    "centro": "SUIRI",
    "codPres": "3316",
    "codSaber": "103426-00"
  },
  {
    "centro": "SECTOR NORTE",
    "codPres": "3317",
    "codSaber": "103427-00"
  },
  {
    "centro": "PUEBLO CIVIL",
    "codPres": "3318",
    "codSaber": "103428-00"
  },
  {
    "centro": "INDIANA DOS",
    "codPres": "3319",
    "codSaber": "103429-00"
  },
  {
    "centro": "BÚFALO",
    "codPres": "3320",
    "codSaber": "103430-00"
  },
  {
    "centro": "BURRÍCO",
    "codPres": "3321",
    "codSaber": "103431-00"
  },
  {
    "centro": "I.D.A. LOS ÁNGELES",
    "codPres": "3322",
    "codSaber": "103432-00"
  },
  {
    "centro": "CIUDADELA FLORES",
    "codPres": "3323",
    "codSaber": "103433-00"
  },
  {
    "centro": "CAHUITA",
    "codPres": "3324",
    "codSaber": "103434-00"
  },
  {
    "centro": "DONDONIA 1",
    "codPres": "3326",
    "codSaber": "103435-00"
  },
  {
    "centro": "CARBÓN #1",
    "codPres": "3327",
    "codSaber": "103436-00"
  },
  {
    "centro": "SEIS AMIGOS",
    "codPres": "3328",
    "codSaber": "103437-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "3329",
    "codSaber": "103438-00"
  },
  {
    "centro": "FINCA OCHO",
    "codPres": "3330",
    "codSaber": "103439-00"
  },
  {
    "centro": "CAÑO NEGRO",
    "codPres": "3331",
    "codSaber": "103440-00"
  },
  {
    "centro": "CASORLA",
    "codPres": "3333",
    "codSaber": "103442-00"
  },
  {
    "centro": "PALESTINA DE ZENT",
    "codPres": "3334",
    "codSaber": "103443-00"
  },
  {
    "centro": "RÍO DURUY",
    "codPres": "3335",
    "codSaber": "103444-00"
  },
  {
    "centro": "KATSI",
    "codPres": "3336",
    "codSaber": "103445-00"
  },
  {
    "centro": "SIBUJÚ",
    "codPres": "3337",
    "codSaber": "103446-00"
  },
  {
    "centro": "GAVILÁN",
    "codPres": "3338",
    "codSaber": "103447-00"
  },
  {
    "centro": "CELINA",
    "codPres": "3339",
    "codSaber": "103448-00"
  },
  {
    "centro": "RÍO VICTORIA",
    "codPres": "3340",
    "codSaber": "103449-00"
  },
  {
    "centro": "CHASE",
    "codPres": "3341",
    "codSaber": "103450-00"
  },
  {
    "centro": "CIMARRONES",
    "codPres": "3342",
    "codSaber": "103451-00"
  },
  {
    "centro": "SURETKA",
    "codPres": "3343",
    "codSaber": "103452-00"
  },
  {
    "centro": "MARYLAND",
    "codPres": "3344",
    "codSaber": "103453-00"
  },
  {
    "centro": "BARRIO LIMONCITO",
    "codPres": "3345",
    "codSaber": "103454-00"
  },
  {
    "centro": "SIBÖDI",
    "codPres": "3346",
    "codSaber": "103455-00"
  },
  {
    "centro": "CHINA KICHÁ",
    "codPres": "3347",
    "codSaber": "103456-00"
  },
  {
    "centro": "MELERUK",
    "codPres": "3348",
    "codSaber": "103457-00"
  },
  {
    "centro": "SAN VICENTE",
    "codPres": "3349",
    "codSaber": "103458-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "3350",
    "codSaber": "103459-00"
  },
  {
    "centro": "CONCEPCIÓN",
    "codPres": "3351",
    "codSaber": "103460-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3352",
    "codSaber": "103461-00"
  },
  {
    "centro": "BONIFACIO",
    "codPres": "3353",
    "codSaber": "103462-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3355",
    "codSaber": "103463-00"
  },
  {
    "centro": "CORINA",
    "codPres": "3356",
    "codSaber": "103464-00"
  },
  {
    "centro": "RÍO BANANO",
    "codPres": "3357",
    "codSaber": "103465-00"
  },
  {
    "centro": "COROMA",
    "codPres": "3358",
    "codSaber": "103466-00"
  },
  {
    "centro": "BAJO COÉN",
    "codPres": "3359",
    "codSaber": "103467-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA RÍO CUBA",
    "codPres": "3360",
    "codSaber": "104623-00"
  },
  {
    "centro": "CALVERI",
    "codPres": "3361",
    "codSaber": "103469-00"
  },
  {
    "centro": "DURURPE",
    "codPres": "3362",
    "codSaber": "103470-00"
  },
  {
    "centro": "CULTIVÉZ",
    "codPres": "3363",
    "codSaber": "103471-00"
  },
  {
    "centro": "DAYTONIA",
    "codPres": "3364",
    "codSaber": "103472-00"
  },
  {
    "centro": "MONTEVERDE",
    "codPres": "3365",
    "codSaber": "103473-00"
  },
  {
    "centro": "DINDIRÍ",
    "codPres": "3366",
    "codSaber": "103474-00"
  },
  {
    "centro": "BATAÁN",
    "codPres": "3367",
    "codSaber": "103475-00"
  },
  {
    "centro": "VEINTISÉIS MILLAS",
    "codPres": "3368",
    "codSaber": "103476-00"
  },
  {
    "centro": "BRISTOL",
    "codPres": "3370",
    "codSaber": "103477-00"
  },
  {
    "centro": "MONTECRISTO",
    "codPres": "3371",
    "codSaber": "103478-00"
  },
  {
    "centro": "MONTEVERDE",
    "codPres": "3372",
    "codSaber": "103479-00"
  },
  {
    "centro": "HONE CREEK",
    "codPres": "3373",
    "codSaber": "103480-00"
  },
  {
    "centro": "PALACIOS",
    "codPres": "3374",
    "codSaber": "103481-00"
  },
  {
    "centro": "LIVERPOOL",
    "codPres": "3375",
    "codSaber": "103482-00"
  },
  {
    "centro": "LUZÓN",
    "codPres": "3376",
    "codSaber": "103483-00"
  },
  {
    "centro": "MATINA",
    "codPres": "3379",
    "codSaber": "103484-00"
  },
  {
    "centro": "MOÍN",
    "codPres": "3380",
    "codSaber": "103485-00"
  },
  {
    "centro": "PACUARITO",
    "codPres": "3382",
    "codSaber": "103486-00"
  },
  {
    "centro": "PENSHURT",
    "codPres": "3383",
    "codSaber": "103487-00"
  },
  {
    "centro": "PUERTO VIEJO",
    "codPres": "3384",
    "codSaber": "103488-00"
  },
  {
    "centro": "I.E.G.B. LIMÓN 2000",
    "codPres": "3385",
    "codSaber": "104934-00"
  },
  {
    "centro": "SAN CLEMENTE",
    "codPres": "3386",
    "codSaber": "103490-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "3387",
    "codSaber": "103491-00"
  },
  {
    "centro": "BOCA URÉN",
    "codPres": "3388",
    "codSaber": "103492-00"
  },
  {
    "centro": "ZENT",
    "codPres": "3389",
    "codSaber": "103493-00"
  },
  {
    "centro": "BARBILLA",
    "codPres": "3390",
    "codSaber": "103494-00"
  },
  {
    "centro": "TUBA CREEK #1",
    "codPres": "3391",
    "codSaber": "103495-00"
  },
  {
    "centro": "RÍO NEGRO",
    "codPres": "3392",
    "codSaber": "103496-00"
  },
  {
    "centro": "SILVESTRE GRANT GRIFFITH",
    "codPres": "3393",
    "codSaber": "103497-00"
  },
  {
    "centro": "GOLY",
    "codPres": "3394",
    "codSaber": "103498-00"
  },
  {
    "centro": "BOCA COHEN",
    "codPres": "3395",
    "codSaber": "103499-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "3396",
    "codSaber": "103500-00"
  },
  {
    "centro": "LA LUCHA",
    "codPres": "3397",
    "codSaber": "103501-00"
  },
  {
    "centro": "NUEVA ESPERANZA",
    "codPres": "3399",
    "codSaber": "103502-00"
  },
  {
    "centro": "NUEVA VIRGINIA",
    "codPres": "3400",
    "codSaber": "103503-00"
  },
  {
    "centro": "EL TRÉBOL",
    "codPres": "3401",
    "codSaber": "103504-00"
  },
  {
    "centro": "ESTRADA",
    "codPres": "3402",
    "codSaber": "103505-00"
  },
  {
    "centro": "BRIBRÍ",
    "codPres": "3403",
    "codSaber": "103506-00"
  },
  {
    "centro": "FINCA COSTA RICA",
    "codPres": "3404",
    "codSaber": "103507-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "3405",
    "codSaber": "103508-00"
  },
  {
    "centro": "VILLA DEL MAR # 2",
    "codPres": "3406",
    "codSaber": "103509-00"
  },
  {
    "centro": "LOS CORALES",
    "codPres": "3407",
    "codSaber": "103510-00"
  },
  {
    "centro": "VILLA DEL MAR # 1",
    "codPres": "3408",
    "codSaber": "103511-00"
  },
  {
    "centro": "AKBERIE",
    "codPres": "3409",
    "codSaber": "103512-00"
  },
  {
    "centro": "RÍO QUITO",
    "codPres": "3411",
    "codSaber": "103513-00"
  },
  {
    "centro": "GERMANIA",
    "codPres": "3412",
    "codSaber": "103514-00"
  },
  {
    "centro": "LOS LIRIOS",
    "codPres": "3413",
    "codSaber": "103515-00"
  },
  {
    "centro": "GENERAL TOMÁS GUARDIA GUTIÉRREZ",
    "codPres": "3414",
    "codSaber": "103516-00"
  },
  {
    "centro": "GUAYACÁN",
    "codPres": "3415",
    "codSaber": "103517-00"
  },
  {
    "centro": "INDIANA TRES",
    "codPres": "3416",
    "codSaber": "103518-00"
  },
  {
    "centro": "JUSTO ANTONIO FACIO",
    "codPres": "3417",
    "codSaber": "103519-00"
  },
  {
    "centro": "ANTONIO FERNÁNDEZ GAMBOA",
    "codPres": "3418",
    "codSaber": "103520-00"
  },
  {
    "centro": "LAS LOMAS",
    "codPres": "3419",
    "codSaber": "103521-00"
  },
  {
    "centro": "ISLA COHEN",
    "codPres": "3420",
    "codSaber": "103522-00"
  },
  {
    "centro": "JABUY KEKOLDY",
    "codPres": "3421",
    "codSaber": "103523-00"
  },
  {
    "centro": "NAMALDI",
    "codPres": "3422",
    "codSaber": "103524-00"
  },
  {
    "centro": "LA BOMBA",
    "codPres": "3423",
    "codSaber": "103525-00"
  },
  {
    "centro": "DONDONIA 2",
    "codPres": "3424",
    "codSaber": "103526-00"
  },
  {
    "centro": "FLORIDA",
    "codPres": "3425",
    "codSaber": "103527-00"
  },
  {
    "centro": "LA FRANCIA",
    "codPres": "3426",
    "codSaber": "103528-00"
  },
  {
    "centro": "LA HEREDIANA",
    "codPres": "3427",
    "codSaber": "103529-00"
  },
  {
    "centro": "VEGAS DE IMPERIO",
    "codPres": "3428",
    "codSaber": "103530-00"
  },
  {
    "centro": "LA MARGARITA",
    "codPres": "3429",
    "codSaber": "103531-00"
  },
  {
    "centro": "RAMAL SIETE",
    "codPres": "3430",
    "codSaber": "103532-00"
  },
  {
    "centro": "FINCA MARGARITA",
    "codPres": "3432",
    "codSaber": "103533-00"
  },
  {
    "centro": "CAÑO BLANCO",
    "codPres": "3433",
    "codSaber": "103534-00"
  },
  {
    "centro": "LA COLONIA",
    "codPres": "3435",
    "codSaber": "103535-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "3436",
    "codSaber": "103536-00"
  },
  {
    "centro": "LARGA DISTANCIA",
    "codPres": "3437",
    "codSaber": "103537-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3438",
    "codSaber": "103538-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "3439",
    "codSaber": "103539-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "3440",
    "codSaber": "103540-00"
  },
  {
    "centro": "ZEPHANIAH FARGUHARSON VASSELL",
    "codPres": "3441",
    "codSaber": "103541-00"
  },
  {
    "centro": "MANZANILLO",
    "codPres": "3442",
    "codSaber": "103542-00"
  },
  {
    "centro": "MARÍA LUISA",
    "codPres": "3443",
    "codSaber": "103543-00"
  },
  {
    "centro": "MATA DE LIMÓN",
    "codPres": "3444",
    "codSaber": "103544-00"
  },
  {
    "centro": "KËKÖLDI",
    "codPres": "3445",
    "codSaber": "103545-00"
  },
  {
    "centro": "UNIÓN RÍO PEJE",
    "codPres": "3446",
    "codSaber": "103546-00"
  },
  {
    "centro": "SOKI",
    "codPres": "3447",
    "codSaber": "103547-00"
  },
  {
    "centro": "EL PEJE",
    "codPres": "3448",
    "codSaber": "103548-00"
  },
  {
    "centro": "CASTILLO NUEVO",
    "codPres": "3449",
    "codSaber": "103549-00"
  },
  {
    "centro": "KENT DE BANANITO NORTE",
    "codPres": "3450",
    "codSaber": "103550-00"
  },
  {
    "centro": "SAN CECILIO",
    "codPres": "3451",
    "codSaber": "103551-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "3452",
    "codSaber": "103552-00"
  },
  {
    "centro": "LAS PALMIRAS",
    "codPres": "3453",
    "codSaber": "103553-00"
  },
  {
    "centro": "OLYMPIA TREJOS LÓPEZ",
    "codPres": "3454",
    "codSaber": "103554-00"
  },
  {
    "centro": "OLIVIA",
    "codPres": "3455",
    "codSaber": "103555-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3456",
    "codSaber": "103556-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "3457",
    "codSaber": "103557-00"
  },
  {
    "centro": "LA COLINA",
    "codPres": "3458",
    "codSaber": "103558-00"
  },
  {
    "centro": "MOJONCITO",
    "codPres": "3459",
    "codSaber": "103559-00"
  },
  {
    "centro": "PANDORA OESTE",
    "codPres": "3460",
    "codSaber": "103560-00"
  },
  {
    "centro": "PARAÍSO",
    "codPres": "3461",
    "codSaber": "103561-00"
  },
  {
    "centro": "LA PASCUA",
    "codPres": "3462",
    "codSaber": "103562-00"
  },
  {
    "centro": "EL BOSQUE",
    "codPres": "3463",
    "codSaber": "103563-00"
  },
  {
    "centro": "BANANITO SUR",
    "codPres": "3464",
    "codSaber": "103564-00"
  },
  {
    "centro": "PORTETE",
    "codPres": "3465",
    "codSaber": "103565-00"
  },
  {
    "centro": "MARGARITA ROJAS ZÚÑIGA",
    "codPres": "3466",
    "codSaber": "103566-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "3467",
    "codSaber": "103567-00"
  },
  {
    "centro": "NAMÚ WOKIR",
    "codPres": "3468",
    "codSaber": "103568-00"
  },
  {
    "centro": "RAFAEL YGLESIAS CASTRO",
    "codPres": "3469",
    "codSaber": "103569-00"
  },
  {
    "centro": "RÍO BLANCO",
    "codPres": "3470",
    "codSaber": "103570-00"
  },
  {
    "centro": "EL MILANO",
    "codPres": "3471",
    "codSaber": "103571-00"
  },
  {
    "centro": "SANTA RITA",
    "codPres": "3472",
    "codSaber": "103572-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3474",
    "codSaber": "103573-00"
  },
  {
    "centro": "SAN ISIDRO DE FLORIDA",
    "codPres": "3475",
    "codSaber": "103574-00"
  },
  {
    "centro": "SABORÍO",
    "codPres": "3476",
    "codSaber": "103575-00"
  },
  {
    "centro": "SAHARA",
    "codPres": "3477",
    "codSaber": "103576-00"
  },
  {
    "centro": "SAN ALBERTO",
    "codPres": "3478",
    "codSaber": "103577-00"
  },
  {
    "centro": "SAN ANDRÉS",
    "codPres": "3479",
    "codSaber": "103578-00"
  },
  {
    "centro": "AGUAS ZARCAS",
    "codPres": "3480",
    "codSaber": "103579-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "3481",
    "codSaber": "103580-00"
  },
  {
    "centro": "LA PERLITA",
    "codPres": "3482",
    "codSaber": "103581-00"
  },
  {
    "centro": "EL ENCANTO",
    "codPres": "3483",
    "codSaber": "103582-00"
  },
  {
    "centro": "VALLE LA AURORA",
    "codPres": "3484",
    "codSaber": "103583-00"
  },
  {
    "centro": "CERERE",
    "codPres": "3485",
    "codSaber": "103584-00"
  },
  {
    "centro": "SANTA EDUVIGES",
    "codPres": "3486",
    "codSaber": "103585-00"
  },
  {
    "centro": "EL COCO",
    "codPres": "3487",
    "codSaber": "103586-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "3488",
    "codSaber": "103587-00"
  },
  {
    "centro": "SEPECUE",
    "codPres": "3489",
    "codSaber": "103588-00"
  },
  {
    "centro": "SHIROLES",
    "codPres": "3490",
    "codSaber": "103589-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3491",
    "codSaber": "103590-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "3492",
    "codSaber": "103591-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "3493",
    "codSaber": "103592-00"
  },
  {
    "centro": "VENECIA",
    "codPres": "3495",
    "codSaber": "103593-00"
  },
  {
    "centro": "VESTA",
    "codPres": "3496",
    "codSaber": "103594-00"
  },
  {
    "centro": "WATSI - VOLIO",
    "codPres": "3497",
    "codSaber": "103595-00"
  },
  {
    "centro": "RANCHO GRANDE",
    "codPres": "3498",
    "codSaber": "103596-00"
  },
  {
    "centro": "YORKIN",
    "codPres": "3500",
    "codSaber": "103598-00"
  },
  {
    "centro": "MIRAVALLES",
    "codPres": "3501",
    "codSaber": "103599-00"
  },
  {
    "centro": "LA IBERIA",
    "codPres": "3502",
    "codSaber": "103600-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3503",
    "codSaber": "103601-00"
  },
  {
    "centro": "EL COCAL",
    "codPres": "3504",
    "codSaber": "103602-00"
  },
  {
    "centro": "VEINTIOCHO MILLAS",
    "codPres": "3505",
    "codSaber": "103603-00"
  },
  {
    "centro": "CUATRO MILLAS",
    "codPres": "3506",
    "codSaber": "103604-00"
  },
  {
    "centro": "FAUSTO HERRERA CORDERO",
    "codPres": "3507",
    "codSaber": "103605-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "3508",
    "codSaber": "103606-00"
  },
  {
    "centro": "LOMAS DEL TORO",
    "codPres": "3509",
    "codSaber": "103607-00"
  },
  {
    "centro": "BOCUARE",
    "codPres": "3511",
    "codSaber": "103608-00"
  },
  {
    "centro": "VALLE DE LAS ROSAS",
    "codPres": "3513",
    "codSaber": "103609-00"
  },
  {
    "centro": "LA UNIÓN RÍO PERLA",
    "codPres": "3514",
    "codSaber": "103610-00"
  },
  {
    "centro": "VEGAS DE MADRE DE DIOS",
    "codPres": "3515",
    "codSaber": "103611-00"
  },
  {
    "centro": "SAN JOAQUÍN",
    "codPres": "3516",
    "codSaber": "103612-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "3517",
    "codSaber": "103613-00"
  },
  {
    "centro": "SHUABB",
    "codPres": "3518",
    "codSaber": "103614-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "3519",
    "codSaber": "103615-00"
  },
  {
    "centro": "LA PERLA",
    "codPres": "3520",
    "codSaber": "103616-00"
  },
  {
    "centro": "SAN CARLOS",
    "codPres": "3521",
    "codSaber": "103617-00"
  },
  {
    "centro": "IMPERIO",
    "codPres": "3522",
    "codSaber": "103618-00"
  },
  {
    "centro": "LA CELIA",
    "codPres": "3523",
    "codSaber": "103619-00"
  },
  {
    "centro": "FREEMAN",
    "codPres": "3525",
    "codSaber": "103620-00"
  },
  {
    "centro": "ASUNCIÓN",
    "codPres": "3526",
    "codSaber": "103621-00"
  },
  {
    "centro": "LA MARINA",
    "codPres": "3527",
    "codSaber": "103622-00"
  },
  {
    "centro": "DUACARÍ",
    "codPres": "3528",
    "codSaber": "103623-00"
  },
  {
    "centro": "ZURQUÍ",
    "codPres": "3529",
    "codSaber": "103624-00"
  },
  {
    "centro": "TÁMARA",
    "codPres": "3530",
    "codSaber": "103625-00"
  },
  {
    "centro": "DÚRIKA",
    "codPres": "3531",
    "codSaber": "103626-00"
  },
  {
    "centro": "AFRICA",
    "codPres": "3532",
    "codSaber": "103627-00"
  },
  {
    "centro": "POCORA SUR",
    "codPres": "3533",
    "codSaber": "103628-00"
  },
  {
    "centro": "LOS PINOS",
    "codPres": "3534",
    "codSaber": "103629-00"
  },
  {
    "centro": "TARIRE",
    "codPres": "3535",
    "codSaber": "103630-00"
  },
  {
    "centro": "LOMAS",
    "codPres": "3536",
    "codSaber": "103631-00"
  },
  {
    "centro": "I.D.A. NAYURIBE",
    "codPres": "3537",
    "codSaber": "103632-00"
  },
  {
    "centro": "NUEVO AMANECER",
    "codPres": "3538",
    "codSaber": "103633-00"
  },
  {
    "centro": "I.D.A. LA TRINIDAD",
    "codPres": "3539",
    "codSaber": "103634-00"
  },
  {
    "centro": "LAS BRISAS TORO AMARILLO",
    "codPres": "3540",
    "codSaber": "103635-00"
  },
  {
    "centro": "ANITA GRANDE",
    "codPres": "3541",
    "codSaber": "103636-00"
  },
  {
    "centro": "EL CEDRAL",
    "codPres": "3542",
    "codSaber": "103637-00"
  },
  {
    "centro": "ASTÚA PIRIE",
    "codPres": "3543",
    "codSaber": "103638-00"
  },
  {
    "centro": "LAS COLINAS",
    "codPres": "3544",
    "codSaber": "103639-00"
  },
  {
    "centro": "LAS BRISAS DEL RÍO BLANCO",
    "codPres": "3545",
    "codSaber": "103640-00"
  },
  {
    "centro": "LA AURORA",
    "codPres": "3546",
    "codSaber": "103641-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "3547",
    "codSaber": "103642-00"
  },
  {
    "centro": "IRLANDA",
    "codPres": "3548",
    "codSaber": "103643-00"
  },
  {
    "centro": "PATIO SAN CRISTÓBAL",
    "codPres": "3550",
    "codSaber": "103645-00"
  },
  {
    "centro": "LA VICTORIA",
    "codPres": "3551",
    "codSaber": "103646-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "3552",
    "codSaber": "103647-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "3553",
    "codSaber": "103648-00"
  },
  {
    "centro": "BARRA DEL COLORADO NORTE",
    "codPres": "3554",
    "codSaber": "103649-00"
  },
  {
    "centro": "LA GUARIA",
    "codPres": "3555",
    "codSaber": "103650-00"
  },
  {
    "centro": "BARRA DEL COLORADO SUR",
    "codPres": "3556",
    "codSaber": "103651-00"
  },
  {
    "centro": "BARRA DE TORTUGUERO",
    "codPres": "3557",
    "codSaber": "103652-00"
  },
  {
    "centro": "LAS LOMAS",
    "codPres": "3558",
    "codSaber": "103653-00"
  },
  {
    "centro": "CAMPO TRES OESTE",
    "codPres": "3559",
    "codSaber": "103654-00"
  },
  {
    "centro": "LA TERESA",
    "codPres": "3560",
    "codSaber": "103655-00"
  },
  {
    "centro": "JESÚS JIMÉNEZ ZAMORA",
    "codPres": "3561",
    "codSaber": "103656-00"
  },
  {
    "centro": "LUIS XV",
    "codPres": "3562",
    "codSaber": "103657-00"
  },
  {
    "centro": "HOJANCHA",
    "codPres": "3563",
    "codSaber": "103658-00"
  },
  {
    "centro": "OJO DE AGUA",
    "codPres": "3564",
    "codSaber": "103659-00"
  },
  {
    "centro": "LOS LIRIOS",
    "codPres": "3565",
    "codSaber": "103660-00"
  },
  {
    "centro": "DELTA",
    "codPres": "3566",
    "codSaber": "103661-00"
  },
  {
    "centro": "LAS COLINAS",
    "codPres": "3567",
    "codSaber": "103662-00"
  },
  {
    "centro": "CAMPO DE ATERRIZAJE",
    "codPres": "3568",
    "codSaber": "103663-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "3569",
    "codSaber": "103664-00"
  },
  {
    "centro": "AGRIMAGA",
    "codPres": "3570",
    "codSaber": "103665-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "3571",
    "codSaber": "103666-00"
  },
  {
    "centro": "COROBICÍ",
    "codPres": "3572",
    "codSaber": "103667-00"
  },
  {
    "centro": "CAMPO KENNEDY",
    "codPres": "3573",
    "codSaber": "103668-00"
  },
  {
    "centro": "CAMPO CINCO",
    "codPres": "3574",
    "codSaber": "103669-00"
  },
  {
    "centro": "PALERMO",
    "codPres": "3575",
    "codSaber": "103670-00"
  },
  {
    "centro": "HUETAR",
    "codPres": "3576",
    "codSaber": "103671-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "3577",
    "codSaber": "103672-00"
  },
  {
    "centro": "SAN CRISTÓBAL",
    "codPres": "3578",
    "codSaber": "103673-00"
  },
  {
    "centro": "CALLE UNO",
    "codPres": "3579",
    "codSaber": "103674-00"
  },
  {
    "centro": "CARTAGENA",
    "codPres": "3580",
    "codSaber": "103675-00"
  },
  {
    "centro": "LAS PALMITAS",
    "codPres": "3581",
    "codSaber": "103676-00"
  },
  {
    "centro": "LA CARLOTA",
    "codPres": "3582",
    "codSaber": "103677-00"
  },
  {
    "centro": "CAROLINA",
    "codPres": "3583",
    "codSaber": "103678-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "3584",
    "codSaber": "103679-00"
  },
  {
    "centro": "EL PORVENIR",
    "codPres": "3585",
    "codSaber": "103680-00"
  },
  {
    "centro": "EL CEIBO",
    "codPres": "3586",
    "codSaber": "103681-00"
  },
  {
    "centro": "POCOCÍ",
    "codPres": "3587",
    "codSaber": "103682-00"
  },
  {
    "centro": "GUARANÍ",
    "codPres": "3588",
    "codSaber": "103683-00"
  },
  {
    "centro": "LA GUAIRA",
    "codPres": "3589",
    "codSaber": "103684-00"
  },
  {
    "centro": "LAS VEGAS",
    "codPres": "3590",
    "codSaber": "103685-00"
  },
  {
    "centro": "LA VICTORIA",
    "codPres": "3591",
    "codSaber": "103686-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "3592",
    "codSaber": "103687-00"
  },
  {
    "centro": "LA PRIMAVERA",
    "codPres": "3593",
    "codSaber": "103688-00"
  },
  {
    "centro": "EL CRUCE",
    "codPres": "3594",
    "codSaber": "103689-00"
  },
  {
    "centro": "CASCADAS",
    "codPres": "3595",
    "codSaber": "103690-00"
  },
  {
    "centro": "BOCA DEL RÍO SILENCIO",
    "codPres": "3596",
    "codSaber": "103691-00"
  },
  {
    "centro": "FINCA DOS",
    "codPres": "3597",
    "codSaber": "103692-00"
  },
  {
    "centro": "EL AGUACATE",
    "codPres": "3598",
    "codSaber": "103693-00"
  },
  {
    "centro": "AGUA FRÍA",
    "codPres": "3599",
    "codSaber": "103694-00"
  },
  {
    "centro": "BARRIOS UNIDOS",
    "codPres": "3600",
    "codSaber": "103695-00"
  },
  {
    "centro": "CENTRAL DE GUÁPILES",
    "codPres": "3601",
    "codSaber": "103696-00"
  },
  {
    "centro": "LLANO BONITO",
    "codPres": "3602",
    "codSaber": "103697-00"
  },
  {
    "centro": "LAGUNILLA",
    "codPres": "3603",
    "codSaber": "103698-00"
  },
  {
    "centro": "LA MANUDITA",
    "codPres": "3604",
    "codSaber": "103699-00"
  },
  {
    "centro": "EL BOSQUE",
    "codPres": "3605",
    "codSaber": "103700-00"
  },
  {
    "centro": "MATA DE LIMÓN",
    "codPres": "3606",
    "codSaber": "103701-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3607",
    "codSaber": "103702-00"
  },
  {
    "centro": "EL EDÉN",
    "codPres": "3608",
    "codSaber": "103703-00"
  },
  {
    "centro": "LÍNEA VIEJA",
    "codPres": "3609",
    "codSaber": "103704-00"
  },
  {
    "centro": "BUENOS AIRES SUR",
    "codPres": "3610",
    "codSaber": "103705-00"
  },
  {
    "centro": "EL HOGAR",
    "codPres": "3611",
    "codSaber": "103706-00"
  },
  {
    "centro": "EL MOLINO",
    "codPres": "3612",
    "codSaber": "103707-00"
  },
  {
    "centro": "LONDRES",
    "codPres": "3613",
    "codSaber": "103708-00"
  },
  {
    "centro": "FINCA EL PARQUE",
    "codPres": "3614",
    "codSaber": "103709-00"
  },
  {
    "centro": "EL BALASTRE",
    "codPres": "3615",
    "codSaber": "103710-00"
  },
  {
    "centro": "PUERTO LINDO",
    "codPres": "3616",
    "codSaber": "103711-00"
  },
  {
    "centro": "EXCELENCIA JUAN FERRARO DOBLES",
    "codPres": "3617",
    "codSaber": "103712-00"
  },
  {
    "centro": "IROQUOIS",
    "codPres": "3618",
    "codSaber": "103713-00"
  },
  {
    "centro": "JIMÉNEZ",
    "codPres": "3619",
    "codSaber": "103714-00"
  },
  {
    "centro": "EL TRIÁNGULO",
    "codPres": "3620",
    "codSaber": "103715-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "3621",
    "codSaber": "103716-00"
  },
  {
    "centro": "VEGA",
    "codPres": "3622",
    "codSaber": "103717-00"
  },
  {
    "centro": "SANTA CLARA",
    "codPres": "3623",
    "codSaber": "103718-00"
  },
  {
    "centro": "LAS LOMAS",
    "codPres": "3625",
    "codSaber": "103720-00"
  },
  {
    "centro": "EL CAMARÓN",
    "codPres": "3626",
    "codSaber": "103721-00"
  },
  {
    "centro": "CAÑO ZAPOTA",
    "codPres": "3627",
    "codSaber": "103722-00"
  },
  {
    "centro": "LA RITA",
    "codPres": "3628",
    "codSaber": "103723-00"
  },
  {
    "centro": "MARÍA HIDALGO HIDALGO",
    "codPres": "3629",
    "codSaber": "103724-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "3630",
    "codSaber": "103725-00"
  },
  {
    "centro": "CUATRO ESQUINAS",
    "codPres": "3631",
    "codSaber": "103726-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "3632",
    "codSaber": "103727-00"
  },
  {
    "centro": "LOS LAGOS",
    "codPres": "3633",
    "codSaber": "103728-00"
  },
  {
    "centro": "FINCA FORMOSA",
    "codPres": "3634",
    "codSaber": "103729-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3635",
    "codSaber": "103730-00"
  },
  {
    "centro": "LOS DIAMANTES",
    "codPres": "3636",
    "codSaber": "103731-00"
  },
  {
    "centro": "EL SOTA",
    "codPres": "3637",
    "codSaber": "103732-00"
  },
  {
    "centro": "MANUEL MARÍA GUTIÉRREZ ZAMORA",
    "codPres": "3638",
    "codSaber": "103733-00"
  },
  {
    "centro": "SECTOR NUEVE",
    "codPres": "3639",
    "codSaber": "103734-00"
  },
  {
    "centro": "LA LUCHA",
    "codPres": "3640",
    "codSaber": "103735-00"
  },
  {
    "centro": "EL RÓTULO",
    "codPres": "3641",
    "codSaber": "103736-00"
  },
  {
    "centro": "PARISMINA",
    "codPres": "3642",
    "codSaber": "103737-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "3643",
    "codSaber": "103738-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "3644",
    "codSaber": "103739-00"
  },
  {
    "centro": "POCORA",
    "codPres": "3645",
    "codSaber": "103740-00"
  },
  {
    "centro": "CARLOS CHACÓN CHAVARRÍA",
    "codPres": "3646",
    "codSaber": "103741-00"
  },
  {
    "centro": "DR. LUIS SHAPIRO",
    "codPres": "3647",
    "codSaber": "103742-00"
  },
  {
    "centro": "BALSAVILLE",
    "codPres": "3648",
    "codSaber": "103743-00"
  },
  {
    "centro": "EL TAJO",
    "codPres": "3649",
    "codSaber": "103744-00"
  },
  {
    "centro": "CAMPO TRES ESTE",
    "codPres": "3650",
    "codSaber": "103745-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "3652",
    "codSaber": "103746-00"
  },
  {
    "centro": "CARTAGENA",
    "codPres": "3653",
    "codSaber": "103747-00"
  },
  {
    "centro": "NAZARETH",
    "codPres": "3654",
    "codSaber": "103748-00"
  },
  {
    "centro": "MATA DE LIMÓN ESTE",
    "codPres": "3655",
    "codSaber": "103749-00"
  },
  {
    "centro": "ROXANA",
    "codPres": "3656",
    "codSaber": "103750-00"
  },
  {
    "centro": "LEESVILLE",
    "codPres": "3657",
    "codSaber": "103751-00"
  },
  {
    "centro": "SAGRADA FAMILIA",
    "codPres": "3658",
    "codSaber": "103752-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3659",
    "codSaber": "103753-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "3660",
    "codSaber": "103754-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "3661",
    "codSaber": "103755-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3662",
    "codSaber": "103756-00"
  },
  {
    "centro": "BARRIO LOS ÁNGELES",
    "codPres": "3663",
    "codSaber": "103757-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "3665",
    "codSaber": "103758-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "3666",
    "codSaber": "103759-00"
  },
  {
    "centro": "RÍO CASCADAS",
    "codPres": "3667",
    "codSaber": "103760-00"
  },
  {
    "centro": "SUERRE",
    "codPres": "3668",
    "codSaber": "103761-00"
  },
  {
    "centro": "TORO AMARILLO",
    "codPres": "3669",
    "codSaber": "103762-00"
  },
  {
    "centro": "COOPEMALANGA",
    "codPres": "3670",
    "codSaber": "103763-00"
  },
  {
    "centro": "LA PERLA",
    "codPres": "3671",
    "codSaber": "103764-00"
  },
  {
    "centro": "AGUAS FRÍAS",
    "codPres": "3672",
    "codSaber": "103765-00"
  },
  {
    "centro": "EL LIMBO",
    "codPres": "3673",
    "codSaber": "103766-00"
  },
  {
    "centro": "CERRO NEGRO",
    "codPres": "3674",
    "codSaber": "103767-00"
  },
  {
    "centro": "SAN JULIÁN",
    "codPres": "3675",
    "codSaber": "103768-00"
  },
  {
    "centro": "SAN IGNACIO",
    "codPres": "3676",
    "codSaber": "103769-00"
  },
  {
    "centro": "CARAMBOLA",
    "codPres": "3677",
    "codSaber": "103770-00"
  },
  {
    "centro": "LA SUERTE",
    "codPres": "3678",
    "codSaber": "103771-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3679",
    "codSaber": "103772-00"
  },
  {
    "centro": "LA SIRENA",
    "codPres": "3680",
    "codSaber": "103773-00"
  },
  {
    "centro": "TICABÁN",
    "codPres": "3681",
    "codSaber": "103774-00"
  },
  {
    "centro": "LAS MERCEDES",
    "codPres": "3682",
    "codSaber": "103775-00"
  },
  {
    "centro": "BANAMOLA",
    "codPres": "3683",
    "codSaber": "103776-00"
  },
  {
    "centro": "CAMPO DOS",
    "codPres": "3684",
    "codSaber": "103777-00"
  },
  {
    "centro": "COCORÍ",
    "codPres": "3686",
    "codSaber": "103779-00"
  },
  {
    "centro": "EL PRADO",
    "codPres": "3687",
    "codSaber": "103780-00"
  },
  {
    "centro": "CAMPO CUATRO",
    "codPres": "3688",
    "codSaber": "103781-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3689",
    "codSaber": "103782-00"
  },
  {
    "centro": "IZTARÚ",
    "codPres": "3690",
    "codSaber": "103783-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3691",
    "codSaber": "103784-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "3692",
    "codSaber": "103785-00"
  },
  {
    "centro": "EL MILLÓN",
    "codPres": "3693",
    "codSaber": "103786-00"
  },
  {
    "centro": "LAGUNILLAS",
    "codPres": "3697",
    "codSaber": "103787-00"
  },
  {
    "centro": "GUAPINOL NORTE",
    "codPres": "3698",
    "codSaber": "103788-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "3699",
    "codSaber": "103789-00"
  },
  {
    "centro": "LA INMACULADA",
    "codPres": "3700",
    "codSaber": "103790-00"
  },
  {
    "centro": "EL COCAL",
    "codPres": "3701",
    "codSaber": "103791-00"
  },
  {
    "centro": "DAMITAS",
    "codPres": "3702",
    "codSaber": "103792-00"
  },
  {
    "centro": "SANTO DOMINGO",
    "codPres": "3703",
    "codSaber": "103793-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3704",
    "codSaber": "103794-00"
  },
  {
    "centro": "BARBUDAL DE PARRITA",
    "codPres": "3705",
    "codSaber": "103795-00"
  },
  {
    "centro": "BIJAGUAL SUR",
    "codPres": "3706",
    "codSaber": "103796-00"
  },
  {
    "centro": "EL BAMBÚ",
    "codPres": "3707",
    "codSaber": "103797-00"
  },
  {
    "centro": "INVU LA GUARIA",
    "codPres": "3708",
    "codSaber": "103798-00"
  },
  {
    "centro": "CERRITOS",
    "codPres": "3710",
    "codSaber": "103799-00"
  },
  {
    "centro": "CERROS ARRIBA",
    "codPres": "3711",
    "codSaber": "103800-00"
  },
  {
    "centro": "CERROS",
    "codPres": "3712",
    "codSaber": "103801-00"
  },
  {
    "centro": "CHIRES",
    "codPres": "3714",
    "codSaber": "103802-00"
  },
  {
    "centro": "BAJAMAR",
    "codPres": "3715",
    "codSaber": "103803-00"
  },
  {
    "centro": "CUARROS",
    "codPres": "3716",
    "codSaber": "103804-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "3717",
    "codSaber": "103805-00"
  },
  {
    "centro": "EL JICOTE",
    "codPres": "3718",
    "codSaber": "103806-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "3719",
    "codSaber": "103807-00"
  },
  {
    "centro": "ESTERILLOS OESTE",
    "codPres": "3720",
    "codSaber": "103808-00"
  },
  {
    "centro": "EL SUKIA",
    "codPres": "3721",
    "codSaber": "103809-00"
  },
  {
    "centro": "PALO SECO",
    "codPres": "3722",
    "codSaber": "103810-00"
  },
  {
    "centro": "HACIENDA JACÓ",
    "codPres": "3723",
    "codSaber": "103811-00"
  },
  {
    "centro": "PORTALÓN",
    "codPres": "3724",
    "codSaber": "103812-00"
  },
  {
    "centro": "PORTÓN DE NARANJO",
    "codPres": "3725",
    "codSaber": "103813-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "3726",
    "codSaber": "103814-00"
  },
  {
    "centro": "TÁRCOLES",
    "codPres": "3727",
    "codSaber": "103815-00"
  },
  {
    "centro": "DOS BOCAS",
    "codPres": "3728",
    "codSaber": "103816-00"
  },
  {
    "centro": "EL HIGUITO",
    "codPres": "3729",
    "codSaber": "103817-00"
  },
  {
    "centro": "EL PASITO",
    "codPres": "3730",
    "codSaber": "103818-00"
  },
  {
    "centro": "EL REY",
    "codPres": "3731",
    "codSaber": "103819-00"
  },
  {
    "centro": "EL SILENCIO",
    "codPres": "3732",
    "codSaber": "103820-00"
  },
  {
    "centro": "EL TIGRE",
    "codPres": "3733",
    "codSaber": "103821-00"
  },
  {
    "centro": "ESTERILLOS ANEXA",
    "codPres": "3735",
    "codSaber": "103822-00"
  },
  {
    "centro": "FINCA NICOYA",
    "codPres": "3736",
    "codSaber": "103823-00"
  },
  {
    "centro": "HERRADURA",
    "codPres": "3737",
    "codSaber": "103824-00"
  },
  {
    "centro": "ISLA PALO SECO",
    "codPres": "3738",
    "codSaber": "103825-00"
  },
  {
    "centro": "CENTRAL DE JACÓ",
    "codPres": "3739",
    "codSaber": "103826-00"
  },
  {
    "centro": "JUNTA DE CACAO",
    "codPres": "3740",
    "codSaber": "103827-00"
  },
  {
    "centro": "LA CHIRRACA",
    "codPres": "3741",
    "codSaber": "103828-00"
  },
  {
    "centro": "LA GALLEGA",
    "codPres": "3742",
    "codSaber": "103829-00"
  },
  {
    "centro": "LA JULIETA",
    "codPres": "3743",
    "codSaber": "103830-00"
  },
  {
    "centro": "LA LOMA",
    "codPres": "3744",
    "codSaber": "103831-00"
  },
  {
    "centro": "LAS MESAS",
    "codPres": "3746",
    "codSaber": "103832-00"
  },
  {
    "centro": "ISLA DAMAS N°2",
    "codPres": "3747",
    "codSaber": "103833-00"
  },
  {
    "centro": "LAS VUELTAS",
    "codPres": "3748",
    "codSaber": "103834-00"
  },
  {
    "centro": "LONDRES",
    "codPres": "3749",
    "codSaber": "103835-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3750",
    "codSaber": "103836-00"
  },
  {
    "centro": "MANUEL ANTONIO",
    "codPres": "3751",
    "codSaber": "103837-00"
  },
  {
    "centro": "FINCA MARITIMA",
    "codPres": "3752",
    "codSaber": "103838-00"
  },
  {
    "centro": "JUAN BAUTISTA SANTAMARÍA",
    "codPres": "3753",
    "codSaber": "103839-00"
  },
  {
    "centro": "PAQUITA",
    "codPres": "3754",
    "codSaber": "103840-00"
  },
  {
    "centro": "PARRITA",
    "codPres": "3755",
    "codSaber": "103841-00"
  },
  {
    "centro": "PIRRIS",
    "codPres": "3757",
    "codSaber": "103842-00"
  },
  {
    "centro": "PLAYA PALMA",
    "codPres": "3758",
    "codSaber": "103843-00"
  },
  {
    "centro": "PLAYA HERMOSA",
    "codPres": "3759",
    "codSaber": "103844-00"
  },
  {
    "centro": "POCHOTAL",
    "codPres": "3760",
    "codSaber": "103845-00"
  },
  {
    "centro": "PLAYÓN SAN ISIDRO",
    "codPres": "3761",
    "codSaber": "103846-00"
  },
  {
    "centro": "PLAYÓN SUR",
    "codPres": "3762",
    "codSaber": "103847-00"
  },
  {
    "centro": "QUEBRADA AMARILLA",
    "codPres": "3763",
    "codSaber": "103848-00"
  },
  {
    "centro": "QUEBRADA GANADO",
    "codPres": "3764",
    "codSaber": "103849-00"
  },
  {
    "centro": "REPÚBLICA DE COREA",
    "codPres": "3765",
    "codSaber": "103850-00"
  },
  {
    "centro": "SABALO",
    "codPres": "3766",
    "codSaber": "103851-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3767",
    "codSaber": "103852-00"
  },
  {
    "centro": "LA VASCONIA",
    "codPres": "3768",
    "codSaber": "103853-00"
  },
  {
    "centro": "SAN JUAN",
    "codPres": "3769",
    "codSaber": "103854-00"
  },
  {
    "centro": "MARÍA LUISA DE CASTRO",
    "codPres": "3772",
    "codSaber": "103856-00"
  },
  {
    "centro": "DAMAS",
    "codPres": "3773",
    "codSaber": "103857-00"
  },
  {
    "centro": "FINCA LLORONA",
    "codPres": "3774",
    "codSaber": "103858-00"
  },
  {
    "centro": "FINCA MONA",
    "codPres": "3775",
    "codSaber": "103859-00"
  },
  {
    "centro": "FINCA POCARES",
    "codPres": "3776",
    "codSaber": "103860-00"
  },
  {
    "centro": "RONCADOR",
    "codPres": "3777",
    "codSaber": "103861-00"
  },
  {
    "centro": "SARDINAL",
    "codPres": "3778",
    "codSaber": "103862-00"
  },
  {
    "centro": "SARDINAL SUR",
    "codPres": "3779",
    "codSaber": "103863-00"
  },
  {
    "centro": "SAN RAFAEL NORTE",
    "codPres": "3780",
    "codSaber": "103864-00"
  },
  {
    "centro": "VILLA NUEVA",
    "codPres": "3781",
    "codSaber": "103865-00"
  },
  {
    "centro": "VISTA DE MAR",
    "codPres": "3782",
    "codSaber": "103866-00"
  },
  {
    "centro": "CAPULÍN",
    "codPres": "3783",
    "codSaber": "103867-00"
  },
  {
    "centro": "QUEBRADA ARROYO",
    "codPres": "3786",
    "codSaber": "103868-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3787",
    "codSaber": "103869-00"
  },
  {
    "centro": "FINCA ANITA",
    "codPres": "3788",
    "codSaber": "103870-00"
  },
  {
    "centro": "SAN CRISTÓBAL",
    "codPres": "3789",
    "codSaber": "103871-00"
  },
  {
    "centro": "SAN ANDRÉS",
    "codPres": "3790",
    "codSaber": "103872-00"
  },
  {
    "centro": "EL NEGRO",
    "codPres": "3791",
    "codSaber": "103873-00"
  },
  {
    "centro": "SAN PABLO",
    "codPres": "3793",
    "codSaber": "103874-00"
  },
  {
    "centro": "PORFIRIO RUIZ NAVARRO",
    "codPres": "3794",
    "codSaber": "103875-00"
  },
  {
    "centro": "LOS JAZMINES",
    "codPres": "3795",
    "codSaber": "103876-00"
  },
  {
    "centro": "LOS PALMARES",
    "codPres": "3796",
    "codSaber": "103877-00"
  },
  {
    "centro": "EL CRUCE",
    "codPres": "3797",
    "codSaber": "103878-00"
  },
  {
    "centro": "PORFIRIO CAMPOS MUÑOZ",
    "codPres": "3798",
    "codSaber": "103879-00"
  },
  {
    "centro": "LA RESERVA",
    "codPres": "3799",
    "codSaber": "103880-00"
  },
  {
    "centro": "EL VALLE",
    "codPres": "3801",
    "codSaber": "103881-00"
  },
  {
    "centro": "TUJANKIR # 1",
    "codPres": "3802",
    "codSaber": "103882-00"
  },
  {
    "centro": "LAS LETRAS",
    "codPres": "3803",
    "codSaber": "103883-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3804",
    "codSaber": "103884-00"
  },
  {
    "centro": "VALLE VERDE",
    "codPres": "3805",
    "codSaber": "103885-00"
  },
  {
    "centro": "LOS LEDEZMA",
    "codPres": "3806",
    "codSaber": "103886-00"
  },
  {
    "centro": "TUJANKIR # 2",
    "codPres": "3807",
    "codSaber": "103887-00"
  },
  {
    "centro": "EL PARAÍSO",
    "codPres": "3808",
    "codSaber": "103888-00"
  },
  {
    "centro": "BETANIA",
    "codPres": "3809",
    "codSaber": "103889-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "3810",
    "codSaber": "103890-00"
  },
  {
    "centro": "COSTA ANA",
    "codPres": "3811",
    "codSaber": "103891-00"
  },
  {
    "centro": "LÍDER DE BIJAGUA",
    "codPres": "3812",
    "codSaber": "103892-00"
  },
  {
    "centro": "BIRMANIA",
    "codPres": "3813",
    "codSaber": "103893-00"
  },
  {
    "centro": "I.D.A. EL GAVILÁN",
    "codPres": "3814",
    "codSaber": "103894-00"
  },
  {
    "centro": "EL ENCANTO",
    "codPres": "3815",
    "codSaber": "103895-00"
  },
  {
    "centro": "LA PALMERA",
    "codPres": "3816",
    "codSaber": "103896-00"
  },
  {
    "centro": "ARGENDORA",
    "codPres": "3817",
    "codSaber": "103897-00"
  },
  {
    "centro": "BRASILIA",
    "codPres": "3818",
    "codSaber": "103898-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3820",
    "codSaber": "103899-00"
  },
  {
    "centro": "CAÑO BLANCO",
    "codPres": "3821",
    "codSaber": "103900-00"
  },
  {
    "centro": "CAÑO RITO",
    "codPres": "3822",
    "codSaber": "103901-00"
  },
  {
    "centro": "BUENOS AIRES",
    "codPres": "3823",
    "codSaber": "103902-00"
  },
  {
    "centro": "LLANO BONITO #1",
    "codPres": "3824",
    "codSaber": "103903-00"
  },
  {
    "centro": "COLONIA BLANCA",
    "codPres": "3826",
    "codSaber": "103905-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "3827",
    "codSaber": "103906-00"
  },
  {
    "centro": "SOR MARÍA ROMERO MENESES",
    "codPres": "3828",
    "codSaber": "103907-00"
  },
  {
    "centro": "EL DELIRIO",
    "codPres": "3829",
    "codSaber": "103908-00"
  },
  {
    "centro": "I.D.A. SAN LUIS",
    "codPres": "3831",
    "codSaber": "103909-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3832",
    "codSaber": "103910-00"
  },
  {
    "centro": "LAS GARZAS",
    "codPres": "3833",
    "codSaber": "103911-00"
  },
  {
    "centro": "CHIMURRIA",
    "codPres": "3834",
    "codSaber": "103912-00"
  },
  {
    "centro": "COLONIA PUNTARENAS",
    "codPres": "3835",
    "codSaber": "103913-00"
  },
  {
    "centro": "COLONIA LA LIBERTAD",
    "codPres": "3836",
    "codSaber": "103914-00"
  },
  {
    "centro": "LOS INGENIEROS",
    "codPres": "3837",
    "codSaber": "103915-00"
  },
  {
    "centro": "LOS TIJOS",
    "codPres": "3838",
    "codSaber": "103916-00"
  },
  {
    "centro": "NAHUATL",
    "codPres": "3839",
    "codSaber": "103917-00"
  },
  {
    "centro": "CUATRO BOCAS",
    "codPres": "3840",
    "codSaber": "103918-00"
  },
  {
    "centro": "LA KATIRA",
    "codPres": "3841",
    "codSaber": "103919-00"
  },
  {
    "centro": "SAN MARCOS",
    "codPres": "3842",
    "codSaber": "103920-00"
  },
  {
    "centro": "DOS RIOS",
    "codPres": "3843",
    "codSaber": "103921-00"
  },
  {
    "centro": "EL HIGUERÓN",
    "codPres": "3844",
    "codSaber": "103922-00"
  },
  {
    "centro": "EL CARMEN # 1",
    "codPres": "3845",
    "codSaber": "103923-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "3846",
    "codSaber": "103924-00"
  },
  {
    "centro": "EL PORVENIR",
    "codPres": "3847",
    "codSaber": "103925-00"
  },
  {
    "centro": "EL ROSARIO",
    "codPres": "3848",
    "codSaber": "103926-00"
  },
  {
    "centro": "EL SALTO",
    "codPres": "3849",
    "codSaber": "103927-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "3850",
    "codSaber": "103928-00"
  },
  {
    "centro": "FÁTIMA",
    "codPres": "3851",
    "codSaber": "103929-00"
  },
  {
    "centro": "EL FÓSFORO",
    "codPres": "3852",
    "codSaber": "103930-00"
  },
  {
    "centro": "GUAYABITO",
    "codPres": "3853",
    "codSaber": "103931-00"
  },
  {
    "centro": "LLANO BONITO #2",
    "codPres": "3854",
    "codSaber": "103932-00"
  },
  {
    "centro": "JESÚS DE POPOYOAPA",
    "codPres": "3855",
    "codSaber": "103933-00"
  },
  {
    "centro": "LA MARAVILLA",
    "codPres": "3856",
    "codSaber": "103934-00"
  },
  {
    "centro": "LA CRUZ",
    "codPres": "3857",
    "codSaber": "103935-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "3858",
    "codSaber": "103936-00"
  },
  {
    "centro": "MONSEÑOR BERNARDO AUGUSTO THIEL",
    "codPres": "3859",
    "codSaber": "103937-00"
  },
  {
    "centro": "LA VERBENA",
    "codPres": "3861",
    "codSaber": "103939-00"
  },
  {
    "centro": "I.E.G.B. LA VICTORIA",
    "codPres": "3862",
    "codSaber": "104834-00"
  },
  {
    "centro": "LAS ARMENIAS",
    "codPres": "3863",
    "codSaber": "103941-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "3864",
    "codSaber": "103942-00"
  },
  {
    "centro": "LAS FLORES",
    "codPres": "3865",
    "codSaber": "103943-00"
  },
  {
    "centro": "LAS MILPAS",
    "codPres": "3866",
    "codSaber": "103944-00"
  },
  {
    "centro": "LOS CARTAGOS",
    "codPres": "3867",
    "codSaber": "103945-00"
  },
  {
    "centro": "RAFAEL ÁNGEL SÁNCHEZ ARRIETA",
    "codPres": "3868",
    "codSaber": "103946-00"
  },
  {
    "centro": "CUATRO CRUCES",
    "codPres": "3869",
    "codSaber": "103947-00"
  },
  {
    "centro": "MIRAMAR",
    "codPres": "3870",
    "codSaber": "103948-00"
  },
  {
    "centro": "MONICO",
    "codPres": "3871",
    "codSaber": "103949-00"
  },
  {
    "centro": "DR. RICARDO MORENO CAÑAS",
    "codPres": "3872",
    "codSaber": "103950-00"
  },
  {
    "centro": "NAZARETH",
    "codPres": "3873",
    "codSaber": "103951-00"
  },
  {
    "centro": "LOS CARTAGOS SUR",
    "codPres": "3874",
    "codSaber": "103952-00"
  },
  {
    "centro": "EL CARMEN # 2",
    "codPres": "3875",
    "codSaber": "103953-00"
  },
  {
    "centro": "LAS PAVAS",
    "codPres": "3876",
    "codSaber": "103954-00"
  },
  {
    "centro": "GUACALITO",
    "codPres": "3877",
    "codSaber": "103955-00"
  },
  {
    "centro": "EL RECREO",
    "codPres": "3878",
    "codSaber": "103956-00"
  },
  {
    "centro": "LOS LAURELES",
    "codPres": "3879",
    "codSaber": "103957-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "3880",
    "codSaber": "103958-00"
  },
  {
    "centro": "QUEBRADA GRANDE",
    "codPres": "3881",
    "codSaber": "103959-00"
  },
  {
    "centro": "QUEBRADÓN",
    "codPres": "3882",
    "codSaber": "103960-00"
  },
  {
    "centro": "JUNTAS DE CAOBA",
    "codPres": "3883",
    "codSaber": "103961-00"
  },
  {
    "centro": "CAMPO VERDE",
    "codPres": "3884",
    "codSaber": "103962-00"
  },
  {
    "centro": "LOS CEIBOS",
    "codPres": "3885",
    "codSaber": "103963-00"
  },
  {
    "centro": "LA FLORIDA",
    "codPres": "3886",
    "codSaber": "103964-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3887",
    "codSaber": "103965-00"
  },
  {
    "centro": "SAN CRISTÓBAL",
    "codPres": "3888",
    "codSaber": "103966-00"
  },
  {
    "centro": "I.D.A. SAN JOSÉ",
    "codPres": "3889",
    "codSaber": "103967-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "3890",
    "codSaber": "103968-00"
  },
  {
    "centro": "SAN ISIDRO YOLILLAL",
    "codPres": "3892",
    "codSaber": "103970-00"
  },
  {
    "centro": "RÍO NEGRO",
    "codPres": "3893",
    "codSaber": "103971-00"
  },
  {
    "centro": "SAN JORGE",
    "codPres": "3894",
    "codSaber": "103972-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "3895",
    "codSaber": "103973-00"
  },
  {
    "centro": "PARCELAS DE PARÍS",
    "codPres": "3896",
    "codSaber": "103974-00"
  },
  {
    "centro": "SAN MIGUEL",
    "codPres": "3897",
    "codSaber": "103975-00"
  },
  {
    "centro": "I.D.A. LA JABALINA",
    "codPres": "3898",
    "codSaber": "103976-00"
  },
  {
    "centro": "SAN RAMÓN",
    "codPres": "3899",
    "codSaber": "103977-00"
  },
  {
    "centro": "SANTA CLARA",
    "codPres": "3900",
    "codSaber": "103978-00"
  },
  {
    "centro": "SUAMPITO",
    "codPres": "3901",
    "codSaber": "103979-00"
  },
  {
    "centro": "SANTA ROSA",
    "codPres": "3902",
    "codSaber": "103980-00"
  },
  {
    "centro": "SANTO DOMINGO",
    "codPres": "3903",
    "codSaber": "103981-00"
  },
  {
    "centro": "SAN ANTONIO",
    "codPres": "3904",
    "codSaber": "103982-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "3905",
    "codSaber": "103983-00"
  },
  {
    "centro": "SAN JOSÉ",
    "codPres": "3906",
    "codSaber": "103984-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "3907",
    "codSaber": "103985-00"
  },
  {
    "centro": "TEODORO PICADO MICHALSKY",
    "codPres": "3908",
    "codSaber": "103986-00"
  },
  {
    "centro": "EL JARDÍN",
    "codPres": "3909",
    "codSaber": "103987-00"
  },
  {
    "centro": "VILLA HERMOSA",
    "codPres": "3910",
    "codSaber": "103988-00"
  },
  {
    "centro": "VILLA NUEVA",
    "codPres": "3911",
    "codSaber": "103989-00"
  },
  {
    "centro": "ZAPOTE",
    "codPres": "3912",
    "codSaber": "103990-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "3913",
    "codSaber": "103991-00"
  },
  {
    "centro": "PIZOTILLO",
    "codPres": "3914",
    "codSaber": "103992-00"
  },
  {
    "centro": "THIALES",
    "codPres": "3915",
    "codSaber": "103993-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "3916",
    "codSaber": "103994-00"
  },
  {
    "centro": "LLANO AZUL",
    "codPres": "3917",
    "codSaber": "103995-00"
  },
  {
    "centro": "SAN FERNANDO",
    "codPres": "3918",
    "codSaber": "103996-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "3919",
    "codSaber": "103997-00"
  },
  {
    "centro": "SAN GABRIEL",
    "codPres": "3921",
    "codSaber": "103998-00"
  },
  {
    "centro": "SANTA CECILIA",
    "codPres": "3922",
    "codSaber": "103999-00"
  },
  {
    "centro": "BELICE",
    "codPres": "3923",
    "codSaber": "104000-00"
  },
  {
    "centro": "LA UNIÓN",
    "codPres": "3924",
    "codSaber": "104001-00"
  },
  {
    "centro": "LA CABAÑA",
    "codPres": "3925",
    "codSaber": "104002-00"
  },
  {
    "centro": "EL PROGRESO",
    "codPres": "3926",
    "codSaber": "104003-00"
  },
  {
    "centro": "LA ÁMERICA",
    "codPres": "3927",
    "codSaber": "104004-00"
  },
  {
    "centro": "SAN BOSCO",
    "codPres": "3929",
    "codSaber": "104005-00"
  },
  {
    "centro": "PIEDRAS AZULES",
    "codPres": "3931",
    "codSaber": "104006-00"
  },
  {
    "centro": "COLEGIO SUPERIOR DE SEÑORITAS",
    "codPres": "3938",
    "codSaber": "104009-00"
  },
  {
    "centro": "LICEO ANASTASIO ALFARO",
    "codPres": "3939",
    "codSaber": "104010-00"
  },
  {
    "centro": "LICEO DE COSTA RICA",
    "codPres": "3940",
    "codSaber": "104011-00"
  },
  {
    "centro": "LICEO DE SAN JOSÉ",
    "codPres": "3941",
    "codSaber": "104012-00"
  },
  {
    "centro": "LICEO DEL SUR",
    "codPres": "3942",
    "codSaber": "104013-00"
  },
  {
    "centro": "LICEO LUIS DOBLES SEGREDA",
    "codPres": "3943",
    "codSaber": "104014-00"
  },
  {
    "centro": "LICEO JOSÉ JOAQUÍN VARGAS CALVO",
    "codPres": "3944",
    "codSaber": "104015-00"
  },
  {
    "centro": "LICEO NAPOLEÓN QUESADA SALAZAR",
    "codPres": "3945",
    "codSaber": "104016-00"
  },
  {
    "centro": "LICEO MAURO FERNÁNDEZ ACUÑA",
    "codPres": "3946",
    "codSaber": "104017-00"
  },
  {
    "centro": "LICEO RODRIGO FACIO BRENES",
    "codPres": "3947",
    "codSaber": "104018-00"
  },
  {
    "centro": "LICEO ROBERTO BRENES MESÉN",
    "codPres": "3948",
    "codSaber": "104019-00"
  },
  {
    "centro": "LICEO DE MORAVIA",
    "codPres": "3949",
    "codSaber": "104020-00"
  },
  {
    "centro": "LICEO DR. JOSÉ MARÍA CASTRO MADRIZ",
    "codPres": "3950",
    "codSaber": "104021-00"
  },
  {
    "centro": "LICEO FRANCO COSTARRICENSE",
    "codPres": "3951",
    "codSaber": "104022-00"
  },
  {
    "centro": "LICEO DE ESCAZÚ",
    "codPres": "3952",
    "codSaber": "104023-00"
  },
  {
    "centro": "LICEO DE CORONADO",
    "codPres": "3953",
    "codSaber": "104024-00"
  },
  {
    "centro": "LICEO SALVADOR UMAÑA CASTRO",
    "codPres": "3955",
    "codSaber": "104025-00"
  },
  {
    "centro": "LICEO EDGAR CERVANTES VILLALTA",
    "codPres": "3956",
    "codSaber": "104026-00"
  },
  {
    "centro": "COLEGIO REPÚBLICA DE MÉXICO",
    "codPres": "3957",
    "codSaber": "104027-00"
  },
  {
    "centro": "LICEO LABORATORIO EMMA GAMBOA UCR",
    "codPres": "3958",
    "codSaber": "104028-00"
  },
  {
    "centro": "LICEO SANTA ANA",
    "codPres": "3959",
    "codSaber": "104029-00"
  },
  {
    "centro": "LICEO DE CURRIDABAT",
    "codPres": "3960",
    "codSaber": "104030-00"
  },
  {
    "centro": "LICEO ALAJUELITA",
    "codPres": "3961",
    "codSaber": "104031-00"
  },
  {
    "centro": "COLEGIO CEDROS",
    "codPres": "3962",
    "codSaber": "104032-00"
  },
  {
    "centro": "LICEO JULIO FONSECA GUTIÉRREZ",
    "codPres": "3964",
    "codSaber": "104034-00"
  },
  {
    "centro": "LICEO PAVAS",
    "codPres": "3968",
    "codSaber": "104035-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE LA TRINIDAD",
    "codPres": "3973",
    "codSaber": "104039-00"
  },
  {
    "centro": "LICEO SAN ANTONIO",
    "codPres": "3977",
    "codSaber": "104041-00"
  },
  {
    "centro": "COLEGIO RINCÓN GRANDE",
    "codPres": "3978",
    "codSaber": "104042-00"
  },
  {
    "centro": "LICEO TEODORO PICADO",
    "codPres": "3979",
    "codSaber": "104043-00"
  },
  {
    "centro": "LICEO HERNÁN ZAMORA ELIZONDO",
    "codPres": "3980",
    "codSaber": "104044-00"
  },
  {
    "centro": "LICEO MONSEÑOR RUBEN ODIO HERRERA",
    "codPres": "3982",
    "codSaber": "104045-00"
  },
  {
    "centro": "LICEO DE CALLE FALLAS",
    "codPres": "3983",
    "codSaber": "104046-00"
  },
  {
    "centro": "LICEO SAN MIGUEL",
    "codPres": "3985",
    "codSaber": "104047-00"
  },
  {
    "centro": "LICEO RICARDO FERNÁNDEZ GUARDIA",
    "codPres": "3986",
    "codSaber": "104048-00"
  },
  {
    "centro": "LICEO SAN ANTONIO",
    "codPres": "3988",
    "codSaber": "104049-00"
  },
  {
    "centro": "LICEO DE ASERRÍ",
    "codPres": "3989",
    "codSaber": "104050-00"
  },
  {
    "centro": "LICEO DE FRAILES",
    "codPres": "3990",
    "codSaber": "104051-00"
  },
  {
    "centro": "LICEO SAN GABRIEL DE ASERRÍ",
    "codPres": "3991",
    "codSaber": "104052-00"
  },
  {
    "centro": "LICEO DE SABANILLAS",
    "codPres": "3993",
    "codSaber": "104053-00"
  },
  {
    "centro": "LICEO JOAQUÍN GUTIÉRREZ MANGEL",
    "codPres": "3995",
    "codSaber": "104054-00"
  },
  {
    "centro": "LICEO DIURNO CIUDAD COLÓN",
    "codPres": "3996",
    "codSaber": "104055-00"
  },
  {
    "centro": "LICEO DE PURISCAL",
    "codPres": "3997",
    "codSaber": "104056-00"
  },
  {
    "centro": "COLEGIO DE TABARCIA",
    "codPres": "3998",
    "codSaber": "104057-00"
  },
  {
    "centro": "LICEO SINAÍ",
    "codPres": "3999",
    "codSaber": "104058-00"
  },
  {
    "centro": "LICEO POTRERO GRANDE",
    "codPres": "4002",
    "codSaber": "104061-00"
  },
  {
    "centro": "LICEO EL CARMEN",
    "codPres": "4003",
    "codSaber": "104062-00"
  },
  {
    "centro": "LICEO BORUCA",
    "codPres": "4004",
    "codSaber": "104063-00"
  },
  {
    "centro": "LICEO YOLANDA OREAMUNO UNGER",
    "codPres": "4006",
    "codSaber": "104064-00"
  },
  {
    "centro": "LICEO FERNANDO VOLIO JIMÉNEZ",
    "codPres": "4008",
    "codSaber": "104065-00"
  },
  {
    "centro": "LICEO UNESCO",
    "codPres": "4009",
    "codSaber": "104066-00"
  },
  {
    "centro": "LICEO SAN PEDRO",
    "codPres": "4010",
    "codSaber": "104067-00"
  },
  {
    "centro": "LICEO DE SANTA GERTRUDIS",
    "codPres": "4011",
    "codSaber": "104068-00"
  },
  {
    "centro": "LICEO CARRILLOS DE POÁS",
    "codPres": "4012",
    "codSaber": "104069-00"
  },
  {
    "centro": "COLEGIO TUETAL NORTE",
    "codPres": "4013",
    "codSaber": "104070-00"
  },
  {
    "centro": "LICEO SAN ROQUE",
    "codPres": "4014",
    "codSaber": "104071-00"
  },
  {
    "centro": "COLEGIO AMBIENTALISTA EL ROBLE",
    "codPres": "4015",
    "codSaber": "104072-00"
  },
  {
    "centro": "INSTITUTO DE ALAJUELA",
    "codPres": "4018",
    "codSaber": "104073-00"
  },
  {
    "centro": "LICEO DE ATENAS MARTHA MIRAMBELL UMAÑA",
    "codPres": "4019",
    "codSaber": "104074-00"
  },
  {
    "centro": "LICEO LEÓN CORTÉS CASTRO",
    "codPres": "4020",
    "codSaber": "104075-00"
  },
  {
    "centro": "LICEO DE POÁS",
    "codPres": "4021",
    "codSaber": "104076-00"
  },
  {
    "centro": "COLEGIO GREGORIO JOSÉ RAMÍREZ CASTRO",
    "codPres": "4022",
    "codSaber": "104077-00"
  },
  {
    "centro": "COLEGIO EL CARMEN",
    "codPres": "4023",
    "codSaber": "104078-00"
  },
  {
    "centro": "LICEO SAN JOSÉ",
    "codPres": "4024",
    "codSaber": "104079-00"
  },
  {
    "centro": "LICEO OTILIO ULATE BLANCO",
    "codPres": "4025",
    "codSaber": "104080-00"
  },
  {
    "centro": "LICEO SAN RAFAEL",
    "codPres": "4027",
    "codSaber": "104081-00"
  },
  {
    "centro": "COLEGIO REDENTORISTA SAN ALFONSO",
    "codPres": "4028",
    "codSaber": "104082-00"
  },
  {
    "centro": "LICEO DE TURRÚCARES",
    "codPres": "4029",
    "codSaber": "104083-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE GRECIA",
    "codPres": "4030",
    "codSaber": "104084-00"
  },
  {
    "centro": "LICEO DE TAMBOR",
    "codPres": "4031",
    "codSaber": "104085-00"
  },
  {
    "centro": "LICEO NUESTRA SEÑORA DE LOS ÁNGELES",
    "codPres": "4032",
    "codSaber": "104086-00"
  },
  {
    "centro": "INSTITUTO JULIO ACOSTA GARCÍA",
    "codPres": "4033",
    "codSaber": "104087-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE PALMARES",
    "codPres": "4034",
    "codSaber": "104088-00"
  },
  {
    "centro": "COLEGIO DE NARANJO",
    "codPres": "4035",
    "codSaber": "104089-00"
  },
  {
    "centro": "COLEGIO VALLE AZUL",
    "codPres": "4036",
    "codSaber": "104090-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE NARANJO",
    "codPres": "4038",
    "codSaber": "104091-00"
  },
  {
    "centro": "COLEGIO DR. RICARDO MORENO CAÑAS",
    "codPres": "4039",
    "codSaber": "104092-00"
  },
  {
    "centro": "LICEO DE ALFARO RUIZ",
    "codPres": "4040",
    "codSaber": "104093-00"
  },
  {
    "centro": "LICEO SUCRE",
    "codPres": "4041",
    "codSaber": "104094-00"
  },
  {
    "centro": "LICEO DE FLORENCIA",
    "codPres": "4042",
    "codSaber": "104095-00"
  },
  {
    "centro": "LICEO PAVÓN",
    "codPres": "4043",
    "codSaber": "104096-00"
  },
  {
    "centro": "LICEO SANTA RITA",
    "codPres": "4044",
    "codSaber": "104097-00"
  },
  {
    "centro": "LICEO DE SAN CARLOS",
    "codPres": "4045",
    "codSaber": "104098-00"
  },
  {
    "centro": "LICEO CHACHAGUA",
    "codPres": "4047",
    "codSaber": "104100-00"
  },
  {
    "centro": "LICEO ENRIQUE GUIER SAENZ",
    "codPres": "4048",
    "codSaber": "104101-00"
  },
  {
    "centro": "LICEO MANUEL EMILIO RODRÍGUEZ",
    "codPres": "4049",
    "codSaber": "104102-00"
  },
  {
    "centro": "LICEO VICENTE LACHNER SANDOVAL",
    "codPres": "4050",
    "codSaber": "104103-00"
  },
  {
    "centro": "COLEGIO SAN LUIS GONZAGA",
    "codPres": "4051",
    "codSaber": "104104-00"
  },
  {
    "centro": "LICEO DE PARAÍSO",
    "codPres": "4052",
    "codSaber": "104105-00"
  },
  {
    "centro": "COLEGIO ELÍAS LEIVA QUIRÓS",
    "codPres": "4053",
    "codSaber": "104106-00"
  },
  {
    "centro": "LICEO DE TARRAZÚ",
    "codPres": "4057",
    "codSaber": "104108-00"
  },
  {
    "centro": "LICEO DE COT",
    "codPres": "4058",
    "codSaber": "104109-00"
  },
  {
    "centro": "LICEO SAN DIEGO",
    "codPres": "4059",
    "codSaber": "104110-00"
  },
  {
    "centro": "COLEGIO SAN FRANCISCO",
    "codPres": "4060",
    "codSaber": "104111-00"
  },
  {
    "centro": "LICEO DE CORRALILLO",
    "codPres": "4061",
    "codSaber": "104112-00"
  },
  {
    "centro": "COLEGIO FRANCISCA CARRASCO JIMÉNEZ",
    "codPres": "4064",
    "codSaber": "104113-00"
  },
  {
    "centro": "COLEGIO ALEJANDRO QUESADA R.",
    "codPres": "4065",
    "codSaber": "104114-00"
  },
  {
    "centro": "LICEO BRAULIO CARRILLO COLINA",
    "codPres": "4067",
    "codSaber": "104116-00"
  },
  {
    "centro": "LICEO LLANO BONITO",
    "codPres": "4068",
    "codSaber": "104117-00"
  },
  {
    "centro": "COLEGIO DR. CLODOMIRO PICADO TWIGHT",
    "codPres": "4069",
    "codSaber": "104118-00"
  },
  {
    "centro": "LICEO HERNÁN VARGAS RAMÍREZ",
    "codPres": "4070",
    "codSaber": "104119-00"
  },
  {
    "centro": "LICEO TUCURRIQUE",
    "codPres": "4071",
    "codSaber": "104120-00"
  },
  {
    "centro": "LICEO SANTA TERESITA",
    "codPres": "4072",
    "codSaber": "104121-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE TURRIALBA",
    "codPres": "4073",
    "codSaber": "104122-00"
  },
  {
    "centro": "LICEO TRES EQUIS",
    "codPres": "4074",
    "codSaber": "104123-00"
  },
  {
    "centro": "COLEGIO AMBIENTALISTA DE PEJIBAYE",
    "codPres": "4075",
    "codSaber": "104124-00"
  },
  {
    "centro": "LICEO SAN JOSÉ DE LA MONTAÑA",
    "codPres": "4076",
    "codSaber": "104125-00"
  },
  {
    "centro": "LICEO ING. SAMUEL SÁENZ FLORES",
    "codPres": "4077",
    "codSaber": "104126-00"
  },
  {
    "centro": "LICEO DE HEREDIA",
    "codPres": "4078",
    "codSaber": "104127-00"
  },
  {
    "centro": "LICEO REGIONAL DE FLORES",
    "codPres": "4079",
    "codSaber": "104128-00"
  },
  {
    "centro": "LICEO ING. CARLOS PASCUA ZÚÑIGA",
    "codPres": "4080",
    "codSaber": "104129-00"
  },
  {
    "centro": "LICEO MARIO VINDAS SALAZAR",
    "codPres": "4082",
    "codSaber": "104130-00"
  },
  {
    "centro": "CONSERVATORIO CASTELLA",
    "codPres": "4083",
    "codSaber": "104131-00"
  },
  {
    "centro": "LICEO DE SANTA BÁRBARA",
    "codPres": "4084",
    "codSaber": "104132-00"
  },
  {
    "centro": "LICEO ING. MANUEL BENAVIDES RODRÍGUEZ",
    "codPres": "4085",
    "codSaber": "104133-00"
  },
  {
    "centro": "LICEO DE SAN ISIDRO",
    "codPres": "4086",
    "codSaber": "104134-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE BELÉN",
    "codPres": "4087",
    "codSaber": "104135-00"
  },
  {
    "centro": "LICEO SANTO DOMINGO",
    "codPres": "4090",
    "codSaber": "104138-00"
  },
  {
    "centro": "LICEO DE RÍO FRÍO",
    "codPres": "4091",
    "codSaber": "104139-00"
  },
  {
    "centro": "LICEO LOS LAGOS",
    "codPres": "4092",
    "codSaber": "104140-00"
  },
  {
    "centro": "COLEGIO LA AURORA",
    "codPres": "4093",
    "codSaber": "104141-00"
  },
  {
    "centro": "LICEO LA VIRGEN",
    "codPres": "4095",
    "codSaber": "104142-00"
  },
  {
    "centro": "COLEGIO FELIPE PÉREZ PÉREZ",
    "codPres": "4096",
    "codSaber": "104143-00"
  },
  {
    "centro": "COLEGIO JOSÉ MARÍA GUTIÉRREZ",
    "codPres": "4097",
    "codSaber": "104144-00"
  },
  {
    "centro": "COLEGIO CAÑAS DULCES",
    "codPres": "4098",
    "codSaber": "104145-00"
  },
  {
    "centro": "COLEGIO SANTA CECILIA",
    "codPres": "4099",
    "codSaber": "104146-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE LA CRUZ",
    "codPres": "4100",
    "codSaber": "104147-00"
  },
  {
    "centro": "LICEO DE BAGACES",
    "codPres": "4101",
    "codSaber": "104148-00"
  },
  {
    "centro": "INSTITUTO DE GUANACASTE",
    "codPres": "4102",
    "codSaber": "104149-00"
  },
  {
    "centro": "LICEO LABORATORIO DE LIBERIA",
    "codPres": "4103",
    "codSaber": "104150-00"
  },
  {
    "centro": "COLEGIO BOCAS DE NOSARA",
    "codPres": "4104",
    "codSaber": "104151-00"
  },
  {
    "centro": "LICEO DE NICOYA",
    "codPres": "4105",
    "codSaber": "104152-00"
  },
  {
    "centro": "LICEO SAN FRANCISCO DE COYOTE",
    "codPres": "4106",
    "codSaber": "104153-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE SANTA CRUZ",
    "codPres": "4107",
    "codSaber": "104154-00"
  },
  {
    "centro": "LICEO SANTA CRUZ, CLÍMACO A. PÉREZ",
    "codPres": "4108",
    "codSaber": "104155-00"
  },
  {
    "centro": "LICEO BELÉN",
    "codPres": "4109",
    "codSaber": "104156-00"
  },
  {
    "centro": "LICEO MAURILIO ALVARADO VARGAS",
    "codPres": "4110",
    "codSaber": "104157-00"
  },
  {
    "centro": "LICEO MIGUEL ARAYA VENEGAS",
    "codPres": "4111",
    "codSaber": "104158-00"
  },
  {
    "centro": "COLEGIO SAN RAFAEL",
    "codPres": "4112",
    "codSaber": "104159-00"
  },
  {
    "centro": "LICEO DE COLORADO",
    "codPres": "4113",
    "codSaber": "104160-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE NUEVO ARENAL",
    "codPres": "4114",
    "codSaber": "104161-00"
  },
  {
    "centro": "LICEO EMILIANO ODIO MADRIGAL",
    "codPres": "4115",
    "codSaber": "104162-00"
  },
  {
    "centro": "BENEMERITO LICEO JOSÉ MARTÍ",
    "codPres": "4116",
    "codSaber": "104163-00"
  },
  {
    "centro": "LICEO DE ESPARZA",
    "codPres": "4117",
    "codSaber": "104164-00"
  },
  {
    "centro": "LICEO DE MIRAMAR",
    "codPres": "4118",
    "codSaber": "104165-00"
  },
  {
    "centro": "LICEO DE CHACARITA",
    "codPres": "4119",
    "codSaber": "104166-00"
  },
  {
    "centro": "LICEO ANTONIO OBANDO CHAN",
    "codPres": "4120",
    "codSaber": "104167-00"
  },
  {
    "centro": "LICEO JUDAS DE CHOMES",
    "codPres": "4121",
    "codSaber": "104168-00"
  },
  {
    "centro": "LICEO ISLA DE CHIRA",
    "codPres": "4122",
    "codSaber": "104169-00"
  },
  {
    "centro": "LICEO COMTE",
    "codPres": "4123",
    "codSaber": "104170-00"
  },
  {
    "centro": "LICEO PACÍFICO SUR",
    "codPres": "4124",
    "codSaber": "104171-00"
  },
  {
    "centro": "LICEO CIUDAD NEILY",
    "codPres": "4125",
    "codSaber": "104172-00"
  },
  {
    "centro": "COLEGIO REPÚBLICA DE ITALIA",
    "codPres": "4126",
    "codSaber": "104173-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE AGUA BUENA",
    "codPres": "4127",
    "codSaber": "104174-00"
  },
  {
    "centro": "LICEO RÍO BANANO",
    "codPres": "4128",
    "codSaber": "104175-00"
  },
  {
    "centro": "LICEO SIXAOLA",
    "codPres": "4129",
    "codSaber": "104176-00"
  },
  {
    "centro": "LICEO RODRIGO SOLANO QUIRÓS",
    "codPres": "4130",
    "codSaber": "104177-00"
  },
  {
    "centro": "LICEO DE MATINA",
    "codPres": "4131",
    "codSaber": "104178-00"
  },
  {
    "centro": "LICEO MARYLAND",
    "codPres": "4132",
    "codSaber": "104179-00"
  },
  {
    "centro": "COLEGIO DE LIMÓN",
    "codPres": "4133",
    "codSaber": "104180-00"
  },
  {
    "centro": "LICEO MARIO BOURNE BOURNE",
    "codPres": "4134",
    "codSaber": "104181-00"
  },
  {
    "centro": "COLEGIO SULÁYÖM",
    "codPres": "4135",
    "codSaber": "104182-00"
  },
  {
    "centro": "LICEO LA ALEGRÍA",
    "codPres": "4137",
    "codSaber": "104183-00"
  },
  {
    "centro": "LICEO DE TICABÁN",
    "codPres": "4138",
    "codSaber": "104184-00"
  },
  {
    "centro": "LICEO DE POCORA",
    "codPres": "4139",
    "codSaber": "104185-00"
  },
  {
    "centro": "LICEO AMBIENTALISTA LLANO BONITO",
    "codPres": "4140",
    "codSaber": "104186-00"
  },
  {
    "centro": "LICEO DE CARIARI",
    "codPres": "4141",
    "codSaber": "104187-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE POCOCÍ",
    "codPres": "4142",
    "codSaber": "104188-00"
  },
  {
    "centro": "LICEO DUACARÍ",
    "codPres": "4143",
    "codSaber": "104189-00"
  },
  {
    "centro": "COLEGIO DE JIMÉNEZ",
    "codPres": "4144",
    "codSaber": "104190-00"
  },
  {
    "centro": "LICEO LA RITA",
    "codPres": "4145",
    "codSaber": "104191-00"
  },
  {
    "centro": "LICEO BRASILIA",
    "codPres": "4147",
    "codSaber": "104192-00"
  },
  {
    "centro": "LICEO AGUAS CLARAS",
    "codPres": "4148",
    "codSaber": "104193-00"
  },
  {
    "centro": "LICEO KATIRA",
    "codPres": "4149",
    "codSaber": "104194-00"
  },
  {
    "centro": "LICEO BIJAGUA",
    "codPres": "4150",
    "codSaber": "104195-00"
  },
  {
    "centro": "LICEO SAN JOSÉ",
    "codPres": "4151",
    "codSaber": "104196-00"
  },
  {
    "centro": "C.T.P. CALLE BLANCOS",
    "codPres": "4155",
    "codSaber": "104197-00"
  },
  {
    "centro": "C.T.P. EDUCACIÓN COMERCIAL Y DE SERVICIOS",
    "codPres": "4156",
    "codSaber": "104198-00"
  },
  {
    "centro": "C.T.P. SAN SEBASTIAN",
    "codPres": "4157",
    "codSaber": "104199-00"
  },
  {
    "centro": "C.T.P. DOS CERCAS",
    "codPres": "4158",
    "codSaber": "104200-00"
  },
  {
    "centro": "C.T.P. MONSEÑOR SANABRIA",
    "codPres": "4159",
    "codSaber": "104201-00"
  },
  {
    "centro": "C.T.P. JOSÉ FIGUERES FERRER",
    "codPres": "4160",
    "codSaber": "104202-00"
  },
  {
    "centro": "C.T.P. SAN JUAN SUR",
    "codPres": "4161",
    "codSaber": "104203-00"
  },
  {
    "centro": "C.T.P. DE ACOSTA",
    "codPres": "4162",
    "codSaber": "104204-00"
  },
  {
    "centro": "C.T.P. DE PURISCAL",
    "codPres": "4163",
    "codSaber": "104205-00"
  },
  {
    "centro": "C.T.P. DE TURRUBARES",
    "codPres": "4164",
    "codSaber": "104206-00"
  },
  {
    "centro": "C.T.P. LA GLORIA",
    "codPres": "4165",
    "codSaber": "104207-00"
  },
  {
    "centro": "C.T.P. SAN ISIDRO",
    "codPres": "4166",
    "codSaber": "104208-00"
  },
  {
    "centro": "C.T.P. DE PLATANARES",
    "codPres": "4167",
    "codSaber": "104209-00"
  },
  {
    "centro": "C.T.P. DE PEJIBAYE",
    "codPres": "4168",
    "codSaber": "104210-00"
  },
  {
    "centro": "C.T.P. GENERAL VIEJO",
    "codPres": "4169",
    "codSaber": "104211-00"
  },
  {
    "centro": "C.T.P. DE BUENOS AIRES",
    "codPres": "4170",
    "codSaber": "104212-00"
  },
  {
    "centro": "C.T.P. JESÚS OCAÑA ROJAS",
    "codPres": "4171",
    "codSaber": "104213-00"
  },
  {
    "centro": "C.T.P. RICARDO CASTRO BEER",
    "codPres": "4172",
    "codSaber": "104214-00"
  },
  {
    "centro": "C.T.P. SAN MATEO",
    "codPres": "4173",
    "codSaber": "104215-00"
  },
  {
    "centro": "C.T.P. DE PIEDADES SUR",
    "codPres": "4174",
    "codSaber": "104216-00"
  },
  {
    "centro": "C.T.P. FRANCISCO JOSÉ ORLICH BOLMARCICH",
    "codPres": "4175",
    "codSaber": "104217-00"
  },
  {
    "centro": "C.T.P. NATANIEL ARIAS MURILLO",
    "codPres": "4176",
    "codSaber": "104218-00"
  },
  {
    "centro": "C.T.P. LOS CHILES",
    "codPres": "4177",
    "codSaber": "104219-00"
  },
  {
    "centro": "C.T.P. DE VENECIA",
    "codPres": "4178",
    "codSaber": "104220-00"
  },
  {
    "centro": "C.T.P. LA FORTUNA",
    "codPres": "4179",
    "codSaber": "104221-00"
  },
  {
    "centro": "C.T.P. DE PITAL",
    "codPres": "4180",
    "codSaber": "104222-00"
  },
  {
    "centro": "C.T.P. DE GUATUSO",
    "codPres": "4181",
    "codSaber": "104223-00"
  },
  {
    "centro": "C.T.P. SANTA ROSA",
    "codPres": "4182",
    "codSaber": "104224-00"
  },
  {
    "centro": "C.T.P. SAN CARLOS",
    "codPres": "4183",
    "codSaber": "104225-00"
  },
  {
    "centro": "C.T.P. DE PACAYAS",
    "codPres": "4185",
    "codSaber": "104226-00"
  },
  {
    "centro": "C.T.P. JOSÉ DANIEL FLORES ZAVALETA",
    "codPres": "4186",
    "codSaber": "104227-00"
  },
  {
    "centro": "C.T.P. SAN PABLO",
    "codPres": "4188",
    "codSaber": "104228-00"
  },
  {
    "centro": "C.T.P. LA SUIZA",
    "codPres": "4189",
    "codSaber": "104229-00"
  },
  {
    "centro": "C.T.P. DE FLORES",
    "codPres": "4190",
    "codSaber": "104230-00"
  },
  {
    "centro": "C.T.P. DE HEREDIA",
    "codPres": "4191",
    "codSaber": "104231-00"
  },
  {
    "centro": "C.T.P. DE ULLOA",
    "codPres": "4192",
    "codSaber": "104232-00"
  },
  {
    "centro": "C.T.P. PUERTO VIEJO",
    "codPres": "4193",
    "codSaber": "104233-00"
  },
  {
    "centro": "C.T.P. DE LIBERIA",
    "codPres": "4194",
    "codSaber": "104234-00"
  },
  {
    "centro": "C.T.P. FORTUNA DE BAGACES",
    "codPres": "4195",
    "codSaber": "104235-00"
  },
  {
    "centro": "C.T.P. DE NANDAYURE",
    "codPres": "4196",
    "codSaber": "104236-00"
  },
  {
    "centro": "C.T.P. DE HOJANCHA",
    "codPres": "4197",
    "codSaber": "104237-00"
  },
  {
    "centro": "C.T.P. DE NICOYA",
    "codPres": "4198",
    "codSaber": "104238-00"
  },
  {
    "centro": "C.T.P. LA MANSIÓN",
    "codPres": "4199",
    "codSaber": "104239-00"
  },
  {
    "centro": "C.T.P. DE CORRALILLO",
    "codPres": "4200",
    "codSaber": "104240-00"
  },
  {
    "centro": "C.T.P. CARRILLO",
    "codPres": "4201",
    "codSaber": "104241-00"
  },
  {
    "centro": "C.T.P. 27 DE ABRIL",
    "codPres": "4202",
    "codSaber": "104242-00"
  },
  {
    "centro": "C.T.P. DE SANTA CRUZ",
    "codPres": "4203",
    "codSaber": "104243-00"
  },
  {
    "centro": "C.T.P. DE SANTA BARBARA",
    "codPres": "4204",
    "codSaber": "104244-00"
  },
  {
    "centro": "C.T.P. DE CARTAGENA",
    "codPres": "4205",
    "codSaber": "104245-00"
  },
  {
    "centro": "C.T.P. SARDINAL",
    "codPres": "4206",
    "codSaber": "104246-00"
  },
  {
    "centro": "C.T.P. DE ABANGARES",
    "codPres": "4207",
    "codSaber": "104247-00"
  },
  {
    "centro": "C.T.P. DE JICARAL",
    "codPres": "4208",
    "codSaber": "104248-00"
  },
  {
    "centro": "C.T.P. DE PUNTARENAS",
    "codPres": "4209",
    "codSaber": "104249-00"
  },
  {
    "centro": "C.T.P. DE PAQUERA",
    "codPres": "4210",
    "codSaber": "104250-00"
  },
  {
    "centro": "C.T.P. DE CÓBANO",
    "codPres": "4211",
    "codSaber": "104251-00"
  },
  {
    "centro": "C.T.P. DE SANTA ELENA",
    "codPres": "4212",
    "codSaber": "104252-00"
  },
  {
    "centro": "C.T.P. DE OSA",
    "codPres": "4213",
    "codSaber": "104253-00"
  },
  {
    "centro": "C.T.P. CARLOS MANUEL VICENTE CASTRO",
    "codPres": "4214",
    "codSaber": "104254-00"
  },
  {
    "centro": "C.T.P. UMBERTO MELLONI CAMPANINI",
    "codPres": "4215",
    "codSaber": "104255-00"
  },
  {
    "centro": "C.T.P. DE SABALITO",
    "codPres": "4216",
    "codSaber": "104256-00"
  },
  {
    "centro": "C.T.P. GUAYCARA",
    "codPres": "4217",
    "codSaber": "104257-00"
  },
  {
    "centro": "C.T.P. DE CORREDORES",
    "codPres": "4218",
    "codSaber": "104258-00"
  },
  {
    "centro": "C.T.P. DE PUERTO JIMÉNEZ",
    "codPres": "4220",
    "codSaber": "104259-00"
  },
  {
    "centro": "C.T.P. DE LIMÓN",
    "codPres": "4221",
    "codSaber": "104260-00"
  },
  {
    "centro": "C.T.P. DE BATAÁN",
    "codPres": "4222",
    "codSaber": "104261-00"
  },
  {
    "centro": "C.T.P. DE TALAMANCA",
    "codPres": "4223",
    "codSaber": "104262-00"
  },
  {
    "centro": "C.T.P. VALLE LA ESTRELLA",
    "codPres": "4224",
    "codSaber": "104263-00"
  },
  {
    "centro": "COLEGIO DEPORTIVO DE LIMÓN",
    "codPres": "4225",
    "codSaber": "104264-00"
  },
  {
    "centro": "C.T.P. PADRE ROBERTO EVANS",
    "codPres": "4226",
    "codSaber": "104265-00"
  },
  {
    "centro": "C.T.P. DE POCOCÍ",
    "codPres": "4227",
    "codSaber": "104266-00"
  },
  {
    "centro": "C.T.P. GUÁCIMO",
    "codPres": "4228",
    "codSaber": "104267-00"
  },
  {
    "centro": "C.T.P. DE JACÓ",
    "codPres": "4229",
    "codSaber": "104268-00"
  },
  {
    "centro": "C.T.P. DE PARRITA",
    "codPres": "4230",
    "codSaber": "104269-00"
  },
  {
    "centro": "C.T.P. DE MATAPALO",
    "codPres": "4231",
    "codSaber": "104270-00"
  },
  {
    "centro": "C.T.P. DE UPALA",
    "codPres": "4232",
    "codSaber": "104271-00"
  },
  {
    "centro": "FERNANDO CENTENO GÜELL-RETARDO MENTAL",
    "codPres": "4234",
    "codSaber": "104272-00"
  },
  {
    "centro": "FERNANDO CENTENO GÜELL-CIEGOS Y DEFIC. VISUALES",
    "codPres": "4235",
    "codSaber": "104273-00"
  },
  {
    "centro": "FERNANDO CENTENO GÜELL-AUDICION Y LENGUAJE",
    "codPres": "4236",
    "codSaber": "104274-00"
  },
  {
    "centro": "CENTRO EDUCACIÓN ESPECIAL SANTA ANA",
    "codPres": "4237",
    "codSaber": "104275-00"
  },
  {
    "centro": "CENTRO DE APOYO DE PEDAGOGÍA HOSPITALARÍA DEL HOSPITAL NACIONAL DE NIÑOS",
    "codPres": "4238",
    "codSaber": "104276-00"
  },
  {
    "centro": "NEURO PSIQUIATRICO INFANTIL",
    "codPres": "4239",
    "codSaber": "104277-00"
  },
  {
    "centro": "CENTRO EDUCACION ESPECIAL LA PITAHAYA",
    "codPres": "4240",
    "codSaber": "104278-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL ANDREA JIMÉNEZ",
    "codPres": "4241",
    "codSaber": "104279-00"
  },
  {
    "centro": "CENTRO NACIONAL DE EDUCACIÓN HELEN KELLER - CNEHK",
    "codPres": "4242",
    "codSaber": "104280-00"
  },
  {
    "centro": "CENTRO APOYOS INFANTO JUVENIL HOSPITAL DR. RAFAEL ÁNGEL CALDERÓN GUARDIA",
    "codPres": "4273",
    "codSaber": "104281-00"
  },
  {
    "centro": "C.A.I. GUADALUPE",
    "codPres": "4298",
    "codSaber": "104282-00"
  },
  {
    "centro": "CENTRO INTEGRAL SAN FELIPE NERI",
    "codPres": "4352",
    "codSaber": "104283-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL SAN ISIDRO DEL GENERAL",
    "codPres": "4402",
    "codSaber": "104284-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL Y REHABILITACIÓN ALAJUELA",
    "codPres": "4439",
    "codSaber": "104285-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL DE GRECIA",
    "codPres": "4440",
    "codSaber": "104286-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL Y REHABILITACIÓN DE SAN RAMÓN",
    "codPres": "4495",
    "codSaber": "104287-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL AMANDA ÁLVAREZ DE UGALDE",
    "codPres": "4514",
    "codSaber": "104288-00"
  },
  {
    "centro": "DR. CARLOS SÁENZ HERRERA",
    "codPres": "4535",
    "codSaber": "104289-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL CARLOS LUIS VALLE MASÍS",
    "codPres": "4536",
    "codSaber": "104290-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL DE TURRIALBA",
    "codPres": "4586",
    "codSaber": "104291-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL DE HEREDIA",
    "codPres": "4615",
    "codSaber": "104292-00"
  },
  {
    "centro": "ENSEÑANZA ESPECIAL DE LIBERIA",
    "codPres": "4673",
    "codSaber": "104293-00"
  },
  {
    "centro": "CENTRO ENSEÑANZA ESPECIAL IVONNE PÉREZ GUEVARA",
    "codPres": "4729",
    "codSaber": "104294-00"
  },
  {
    "centro": "NOCTURNO JOSÉ JOAQUÍN JIMÉNEZ NÚÑEZ",
    "codPres": "4822",
    "codSaber": "104295-00"
  },
  {
    "centro": "NOCTURNO DE HATILLO",
    "codPres": "4824",
    "codSaber": "104296-00"
  },
  {
    "centro": "NOCTURNO BRAULIO CARRILLO COLINA",
    "codPres": "4825",
    "codSaber": "104297-00"
  },
  {
    "centro": "IPEC SAN JOSÉ",
    "codPres": "4826",
    "codSaber": "105092-00"
  },
  {
    "centro": "CINDEA MARÍA MAZZARELLO",
    "codPres": "4827",
    "codSaber": "105093-00"
  },
  {
    "centro": "CINDEA SANTA ANA",
    "codPres": "4828",
    "codSaber": "105094-00"
  },
  {
    "centro": "IPEC 15 DE SETIEMBRE",
    "codPres": "4830",
    "codSaber": "105095-00"
  },
  {
    "centro": "IPEC 15 SETIEMBRE- BARRIO CÓRDOBA",
    "codPres": "4830",
    "codSaber": "105095-01"
  },
  {
    "centro": "IPEC 15 SETIEMBRE-CIUDADELA 15 SETIEMBRE",
    "codPres": "4830",
    "codSaber": "105095-02"
  },
  {
    "centro": "IPEC 15 SETIEMBRE-CONCEPCIÓN DE ALAJUELITA",
    "codPres": "4830",
    "codSaber": "105095-03"
  },
  {
    "centro": "ALBERTO MANUEL BRENES MORA",
    "codPres": "4834",
    "codSaber": "104298-00"
  },
  {
    "centro": "CINDEA ALBERTO BRENES MORA",
    "codPres": "4834",
    "codSaber": "105096-00"
  },
  {
    "centro": "NOCTURNO DESAMPARADOS",
    "codPres": "4837",
    "codSaber": "104299-00"
  },
  {
    "centro": "NOCTURNO DE PURISCAL",
    "codPres": "4838",
    "codSaber": "104300-00"
  },
  {
    "centro": "NOCTURNO DE CIUDAD COLÓN",
    "codPres": "4839",
    "codSaber": "104301-00"
  },
  {
    "centro": "NOCTURNO DE PÉREZ ZELEDÓN",
    "codPres": "4840",
    "codSaber": "104302-00"
  },
  {
    "centro": "NOCTURNO DE BUENOS AIRES",
    "codPres": "4841",
    "codSaber": "104303-00"
  },
  {
    "centro": "NOCTURNO MIGUEL OBREGÓN LIZANO",
    "codPres": "4842",
    "codSaber": "104304-00"
  },
  {
    "centro": "NOCTURNO DE GRECIA",
    "codPres": "4843",
    "codSaber": "104305-00"
  },
  {
    "centro": "C.T.P. NOCTURNO CARLOS FALLAS SIBAJA",
    "codPres": "4844",
    "codSaber": "104306-00"
  },
  {
    "centro": "IPEC POÁS",
    "codPres": "4845",
    "codSaber": "105097-00"
  },
  {
    "centro": "IPEC MARÍA PACHECO",
    "codPres": "4847",
    "codSaber": "105098-00"
  },
  {
    "centro": "IPEC MARÍA PACHECO-CENTRO DIURNO III EDAD",
    "codPres": "4847",
    "codSaber": "105098-01"
  },
  {
    "centro": "NOCTURNO DE PALMARES",
    "codPres": "4848",
    "codSaber": "104307-00"
  },
  {
    "centro": "NOCTURNO JULIÁN VOLIO LLORENTE",
    "codPres": "4849",
    "codSaber": "104308-00"
  },
  {
    "centro": "NOCTURNO DE NARANJO",
    "codPres": "4850",
    "codSaber": "104309-00"
  },
  {
    "centro": "CINDEA SAN CARLOS",
    "codPres": "4852",
    "codSaber": "105099-00"
  },
  {
    "centro": "CINDEA SAN CARLOS-C.A.I. NELSON MANDELA",
    "codPres": "4852",
    "codSaber": "105099-01"
  },
  {
    "centro": "NOCTURNO DE CARTAGO",
    "codPres": "4853",
    "codSaber": "104310-00"
  },
  {
    "centro": "SECCIÓN NOCTURNA ACADÉMICA DE PARAÍSO",
    "codPres": "4854",
    "codSaber": "104311-00"
  },
  {
    "centro": "NOCTURNO LA UNIÓN",
    "codPres": "4855",
    "codSaber": "104312-00"
  },
  {
    "centro": "IPEC ARABELLA JIMÉNEZ DE VOLIO",
    "codPres": "4856",
    "codSaber": "105100-00"
  },
  {
    "centro": "IPEC ARABELLA JIMÉNEZ DE VOLIO-C.A.I. JORGE DEBRAVO",
    "codPres": "4856",
    "codSaber": "105100-02"
  },
  {
    "centro": "IPEC ARABELLA JIMÉNEZ DE VOLIO-SAN FRANCISCO",
    "codPres": "4856",
    "codSaber": "105100-05"
  },
  {
    "centro": "JESÚS ROBLES MORALES",
    "codPres": "4858",
    "codSaber": "104313-00"
  },
  {
    "centro": "NOCTURNO PBRO. ENRIQUE MENZEL",
    "codPres": "4859",
    "codSaber": "104314-00"
  },
  {
    "centro": "NOCTURNO ALFREDO GONZÁLEZ FLORES",
    "codPres": "4860",
    "codSaber": "104315-00"
  },
  {
    "centro": "NOCTURNO HERMÁN LÓPEZ HERNÁNDEZ",
    "codPres": "4861",
    "codSaber": "104316-00"
  },
  {
    "centro": "NOCTURNO DE RÍO FRÍO",
    "codPres": "4862",
    "codSaber": "104317-00"
  },
  {
    "centro": "IPEC SANTA BÁRBARA",
    "codPres": "4863",
    "codSaber": "105101-00"
  },
  {
    "centro": "IPEC SANTA BÁRBARA-BELÉN",
    "codPres": "4863",
    "codSaber": "105101-01"
  },
  {
    "centro": "IPEC SANTA BÁRBARA-SAN JOAQUÍN DE FLORES",
    "codPres": "4863",
    "codSaber": "105101-02"
  },
  {
    "centro": "IPEC SANTA BÁRBARA-SANTA BÁRBARA",
    "codPres": "4863",
    "codSaber": "105101-03"
  },
  {
    "centro": "IPEC SANTO DOMINGO",
    "codPres": "4864",
    "codSaber": "105102-00"
  },
  {
    "centro": "IPEC SANTO DOMINGO-JUVENIL ZURQUÍ",
    "codPres": "4864",
    "codSaber": "105102-01"
  },
  {
    "centro": "CAPACITACIÓN OBRERA",
    "codPres": "4865",
    "codSaber": "104318-00"
  },
  {
    "centro": "IPEC BARVA",
    "codPres": "4866",
    "codSaber": "105103-00"
  },
  {
    "centro": "IPEC BARVA-CORAZÓN DE JESÚS",
    "codPres": "4866",
    "codSaber": "105103-01"
  },
  {
    "centro": "IPEC BARVA-CUBUJUQUÍ",
    "codPres": "4866",
    "codSaber": "105103-02"
  },
  {
    "centro": "IPEC BARVA-FÁTIMA",
    "codPres": "4866",
    "codSaber": "105103-03"
  },
  {
    "centro": "IPEC BARVA-GETSEMANÍ",
    "codPres": "4866",
    "codSaber": "105103-04"
  },
  {
    "centro": "IPEC BARVA-SAN RAFAEL",
    "codPres": "4866",
    "codSaber": "105103-06"
  },
  {
    "centro": "NOCTURNO LA CRUZ",
    "codPres": "4867",
    "codSaber": "104319-00"
  },
  {
    "centro": "NOCTURNO DE LIBERIA",
    "codPres": "4869",
    "codSaber": "104320-00"
  },
  {
    "centro": "IPEC LIBERIA",
    "codPres": "4870",
    "codSaber": "105104-00"
  },
  {
    "centro": "IPEC LIBERIA-C.A.I. CALLE REAL",
    "codPres": "4870",
    "codSaber": "105104-01"
  },
  {
    "centro": "IPEC LIBERIA-GUAYABO",
    "codPres": "4870",
    "codSaber": "105104-02"
  },
  {
    "centro": "IPEC LIBERIA-SANTA CECILIA",
    "codPres": "4870",
    "codSaber": "105104-03"
  },
  {
    "centro": "NOCTURNO DE NICOYA",
    "codPres": "4871",
    "codSaber": "104321-00"
  },
  {
    "centro": "NOCTURNO DE SANTA CRUZ",
    "codPres": "4872",
    "codSaber": "104322-00"
  },
  {
    "centro": "CINDEA SANTA CRUZ",
    "codPres": "4873",
    "codSaber": "105105-00"
  },
  {
    "centro": "NOCTURNO MAURILIO ALVARADO VARGAS",
    "codPres": "4874",
    "codSaber": "104323-00"
  },
  {
    "centro": "NOCTURNO JUAN SANTAMARÍA",
    "codPres": "4875",
    "codSaber": "104324-00"
  },
  {
    "centro": "IPEC CAÑAS",
    "codPres": "4876",
    "codSaber": "105106-00"
  },
  {
    "centro": "IPEC CAÑAS-LAJAS",
    "codPres": "4876",
    "codSaber": "105106-01"
  },
  {
    "centro": "IPEC CAÑAS-SAN MIGUEL",
    "codPres": "4876",
    "codSaber": "105106-02"
  },
  {
    "centro": "NOCTURNO JOSÉ MARTÍ",
    "codPres": "4877",
    "codSaber": "104325-00"
  },
  {
    "centro": "NOCTURNO DE ESPARZA",
    "codPres": "4878",
    "codSaber": "104326-00"
  },
  {
    "centro": "IPEC PUNTARENAS",
    "codPres": "4879",
    "codSaber": "105107-00"
  },
  {
    "centro": "IPEC PUNTARENAS-EL PROGRESO",
    "codPres": "4879",
    "codSaber": "105107-03"
  },
  {
    "centro": "IPEC PUNTARENAS-JIRETH",
    "codPres": "4879",
    "codSaber": "105107-01"
  },
  {
    "centro": "IPEC PUNTARENAS-KENNEDY",
    "codPres": "4879",
    "codSaber": "105107-02"
  },
  {
    "centro": "NOCTURNO DE CIUDAD NEILY",
    "codPres": "4881",
    "codSaber": "104327-00"
  },
  {
    "centro": "NOCTURNO DE GOLFITO",
    "codPres": "4882",
    "codSaber": "104328-00"
  },
  {
    "centro": "NOCTURNO DE SAN VITO",
    "codPres": "4883",
    "codSaber": "104329-00"
  },
  {
    "centro": "NOCTURNO DE OSA",
    "codPres": "4884",
    "codSaber": "104330-00"
  },
  {
    "centro": "CINDEA CIUDAD NEILY",
    "codPres": "4885",
    "codSaber": "105108-00"
  },
  {
    "centro": "IPEC AGUA BUENA",
    "codPres": "4887",
    "codSaber": "105109-00"
  },
  {
    "centro": "IPEC AGUA BUENA-LA LUCHA",
    "codPres": "4887",
    "codSaber": "105109-01"
  },
  {
    "centro": "NOCTURNO LA CUESTA",
    "codPres": "4888",
    "codSaber": "104331-00"
  },
  {
    "centro": "NOCTURNO DE LIMÓN",
    "codPres": "4889",
    "codSaber": "104332-00"
  },
  {
    "centro": "NOCTURNO DE BATAÁN",
    "codPres": "4890",
    "codSaber": "104333-00"
  },
  {
    "centro": "NOCTURNO DE POCOCÍ",
    "codPres": "4893",
    "codSaber": "104334-00"
  },
  {
    "centro": "NOCTURNO DE GUÁCIMO",
    "codPres": "4894",
    "codSaber": "104335-00"
  },
  {
    "centro": "CINDEA CARIARI",
    "codPres": "4895",
    "codSaber": "105110-00"
  },
  {
    "centro": "CINDEA CARIARI-CAMPO DOS",
    "codPres": "4895",
    "codSaber": "105110-01"
  },
  {
    "centro": "CINDEA CARIARI-LAS PALMITAS",
    "codPres": "4895",
    "codSaber": "105110-02"
  },
  {
    "centro": "CINDEA CARIARI-LOS ÁNGELES",
    "codPres": "4895",
    "codSaber": "105110-03"
  },
  {
    "centro": "CINDEA CARIARI-TORTUGUERO",
    "codPres": "4895",
    "codSaber": "105110-04"
  },
  {
    "centro": "NOCTURNO DE QUEPOS",
    "codPres": "4896",
    "codSaber": "104336-00"
  },
  {
    "centro": "CINDEA UPALA",
    "codPres": "4897",
    "codSaber": "105111-00"
  },
  {
    "centro": "CINDEA UPALA-MÉXICO",
    "codPres": "4897",
    "codSaber": "105111-01"
  },
  {
    "centro": "CINDEA UPALA-SAN ISIDRO",
    "codPres": "4897",
    "codSaber": "105111-02"
  },
  {
    "centro": "JAMAICA",
    "codPres": "4899",
    "codSaber": "104337-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "4901",
    "codSaber": "104338-00"
  },
  {
    "centro": "CINDEA RICARDO JIMÉNEZ O.",
    "codPres": "4911",
    "codSaber": "105112-00"
  },
  {
    "centro": "CINDEA RICARDO JIMÉNEZ O.-C.A.I. SAN SEBASTIAN",
    "codPres": "4911",
    "codSaber": "105112-01"
  },
  {
    "centro": "CINDEA RICARDO JIMÉNEZ-JUAN SANTAMARÍA",
    "codPres": "4911",
    "codSaber": "105112-02"
  },
  {
    "centro": "LICEO DOS RÍOS",
    "codPres": "4913",
    "codSaber": "104339-00"
  },
  {
    "centro": "LICEO RURAL CABECERAS",
    "codPres": "4915",
    "codSaber": "104340-00"
  },
  {
    "centro": "NOCTURNO CARLOS MELÉNDEZ CHAVERRI",
    "codPres": "4916",
    "codSaber": "104341-00"
  },
  {
    "centro": "RAFAEL VARGAS QUIRÓS",
    "codPres": "4917",
    "codSaber": "104342-00"
  },
  {
    "centro": "J.N. MANUEL BELGRANO",
    "codPres": "4918",
    "codSaber": "104343-00"
  },
  {
    "centro": "JUAN ENRIQUE PESTALOZZI",
    "codPres": "4919",
    "codSaber": "104344-00"
  },
  {
    "centro": "ARUBA",
    "codPres": "4929",
    "codSaber": "104345-00"
  },
  {
    "centro": "DOMINGO FAUSTINO SARMIENTO",
    "codPres": "4930",
    "codSaber": "104346-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "4933",
    "codSaber": "104347-00"
  },
  {
    "centro": "EL PITAL",
    "codPres": "4934",
    "codSaber": "104348-00"
  },
  {
    "centro": "NAVAJUELAR",
    "codPres": "4939",
    "codSaber": "104349-00"
  },
  {
    "centro": "SAN VICENTE Y LAS GRANADINAS",
    "codPres": "4940",
    "codSaber": "104350-00"
  },
  {
    "centro": "ANTILLAS NEERLANDESAS",
    "codPres": "4941",
    "codSaber": "104351-00"
  },
  {
    "centro": "CRISTO REY",
    "codPres": "4942",
    "codSaber": "104352-00"
  },
  {
    "centro": "GUADALUPE",
    "codPres": "4943",
    "codSaber": "104353-00"
  },
  {
    "centro": "LEÓN CORTÉS CASTRO",
    "codPres": "4947",
    "codSaber": "104354-00"
  },
  {
    "centro": "EL SITIO",
    "codPres": "4948",
    "codSaber": "104355-00"
  },
  {
    "centro": "SAN LUIS",
    "codPres": "4955",
    "codSaber": "104356-00"
  },
  {
    "centro": "BAHAMAS",
    "codPres": "4956",
    "codSaber": "104357-00"
  },
  {
    "centro": "DOMINICA",
    "codPres": "4957",
    "codSaber": "104358-00"
  },
  {
    "centro": "GRANADA",
    "codPres": "4958",
    "codSaber": "104359-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "4964",
    "codSaber": "104361-00"
  },
  {
    "centro": "J.N. JUAN VÁZQUEZ DE CORONADO",
    "codPres": "4965",
    "codSaber": "104362-00"
  },
  {
    "centro": "DR. FERNANDO GUZMÁN MATA",
    "codPres": "4967",
    "codSaber": "104363-00"
  },
  {
    "centro": "TULËSI",
    "codPres": "4971",
    "codSaber": "104364-00"
  },
  {
    "centro": "JAREY",
    "codPres": "4972",
    "codSaber": "104365-00"
  },
  {
    "centro": "SHINABLA",
    "codPres": "4973",
    "codSaber": "104366-00"
  },
  {
    "centro": "TSIMARI",
    "codPres": "4974",
    "codSaber": "104367-00"
  },
  {
    "centro": "REPÚBLICA TRINIDAD Y TOBAGO",
    "codPres": "4978",
    "codSaber": "104368-00"
  },
  {
    "centro": "ROJOMACA",
    "codPres": "4979",
    "codSaber": "104369-00"
  },
  {
    "centro": "RÍO MAGDALENA",
    "codPres": "4980",
    "codSaber": "104370-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "4981",
    "codSaber": "104371-00"
  },
  {
    "centro": "BERMÚDAS",
    "codPres": "4986",
    "codSaber": "104372-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "4987",
    "codSaber": "104373-00"
  },
  {
    "centro": "JULIA ACUÑA DE SOMARRIBAS",
    "codPres": "4989",
    "codSaber": "104374-00"
  },
  {
    "centro": "SAN ISIDRO",
    "codPres": "4993",
    "codSaber": "104375-00"
  },
  {
    "centro": "JOSÉ MARTÍN CARRILLO CASTRILLO",
    "codPres": "4995",
    "codSaber": "104376-00"
  },
  {
    "centro": "MONTE ROMO",
    "codPres": "4996",
    "codSaber": "104377-00"
  },
  {
    "centro": "PUERTO CARRILLO",
    "codPres": "4997",
    "codSaber": "104378-00"
  },
  {
    "centro": "LAJAS",
    "codPres": "5004",
    "codSaber": "104379-00"
  },
  {
    "centro": "J.N. MONSEÑOR LUIS LEIPOLD",
    "codPres": "5005",
    "codSaber": "104380-00"
  },
  {
    "centro": "LA PLAZA",
    "codPres": "5006",
    "codSaber": "104381-00"
  },
  {
    "centro": "ARANCIBIA",
    "codPres": "5009",
    "codSaber": "104382-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "5010",
    "codSaber": "104383-00"
  },
  {
    "centro": "MANUEL MORA VALVERDE",
    "codPres": "5011",
    "codSaber": "104384-00"
  },
  {
    "centro": "SAN RAMÓN DE ARÍO",
    "codPres": "5012",
    "codSaber": "104385-00"
  },
  {
    "centro": "SAN PEDRO",
    "codPres": "5013",
    "codSaber": "104386-00"
  },
  {
    "centro": "BALLENA",
    "codPres": "5016",
    "codSaber": "104387-00"
  },
  {
    "centro": "LA ESMERALDA",
    "codPres": "5017",
    "codSaber": "104388-00"
  },
  {
    "centro": "CAÑA BLANCA",
    "codPres": "5018",
    "codSaber": "104389-00"
  },
  {
    "centro": "SAND BOX",
    "codPres": "5021",
    "codSaber": "104390-00"
  },
  {
    "centro": "ALTO URÉN",
    "codPres": "5022",
    "codSaber": "104391-00"
  },
  {
    "centro": "OROCHICO",
    "codPres": "5023",
    "codSaber": "104392-00"
  },
  {
    "centro": "SAN CRISTÓBAL Y NEVIS",
    "codPres": "5025",
    "codSaber": "104393-00"
  },
  {
    "centro": "ALTOS DE GERMANIA",
    "codPres": "5026",
    "codSaber": "104394-00"
  },
  {
    "centro": "BAJO BLEY",
    "codPres": "5027",
    "codSaber": "104395-00"
  },
  {
    "centro": "GRANO DE ORO",
    "codPres": "5028",
    "codSaber": "104396-00"
  },
  {
    "centro": "PALMERA",
    "codPres": "5029",
    "codSaber": "104397-00"
  },
  {
    "centro": "POZO AZUL",
    "codPres": "5030",
    "codSaber": "104398-00"
  },
  {
    "centro": "SERINACH",
    "codPres": "5031",
    "codSaber": "104399-00"
  },
  {
    "centro": "PROYECTO PACUARE",
    "codPres": "5032",
    "codSaber": "104400-00"
  },
  {
    "centro": "NUEVO SANTO DOMINGO",
    "codPres": "5033",
    "codSaber": "104401-00"
  },
  {
    "centro": "LA ESPERANZA",
    "codPres": "5036",
    "codSaber": "104402-00"
  },
  {
    "centro": "BARBADOS",
    "codPres": "5037",
    "codSaber": "104403-00"
  },
  {
    "centro": "SARDINA",
    "codPres": "5038",
    "codSaber": "104404-00"
  },
  {
    "centro": "ESCOCIA",
    "codPres": "5039",
    "codSaber": "104405-00"
  },
  {
    "centro": "J.N. GUÁPILES",
    "codPres": "5040",
    "codSaber": "104406-00"
  },
  {
    "centro": "MACADAMIA",
    "codPres": "5041",
    "codSaber": "104407-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "5044",
    "codSaber": "104408-00"
  },
  {
    "centro": "REPÚBLICA DE GUYANA",
    "codPres": "5045",
    "codSaber": "104409-00"
  },
  {
    "centro": "EL PILÓN",
    "codPres": "5047",
    "codSaber": "104410-00"
  },
  {
    "centro": "RÍO NARANJO",
    "codPres": "5048",
    "codSaber": "104411-00"
  },
  {
    "centro": "LABORATORIO TURRIALBA",
    "codPres": "5053",
    "codSaber": "104412-00"
  },
  {
    "centro": "UNIDAD PEDAGÓGICA CASA HOGAR TÍA TERE",
    "codPres": "5065",
    "codSaber": "104460-00"
  },
  {
    "centro": "COLEGIO DE GRAVILIAS",
    "codPres": "5072",
    "codSaber": "104415-00"
  },
  {
    "centro": "LICEO LA UVITA",
    "codPres": "5073",
    "codSaber": "104416-00"
  },
  {
    "centro": "LICEO FRANCISCO AMIGUETTE HERRERA",
    "codPres": "5075",
    "codSaber": "104417-00"
  },
  {
    "centro": "LICEO GASTÓN PERALTA CARRANZA",
    "codPres": "5076",
    "codSaber": "104418-00"
  },
  {
    "centro": "COLEGIO RODRIGO HERNÁNDEZ VARGAS",
    "codPres": "5077",
    "codSaber": "104419-00"
  },
  {
    "centro": "LICEO VILLARREAL",
    "codPres": "5079",
    "codSaber": "104420-00"
  },
  {
    "centro": "COLEGIO JORGE VOLIO JIMÉNEZ",
    "codPres": "5080",
    "codSaber": "104421-00"
  },
  {
    "centro": "C.T.P. MARIO QUIROS SASSO",
    "codPres": "5082",
    "codSaber": "104422-00"
  },
  {
    "centro": "CINDEA TURRIALBA",
    "codPres": "5101",
    "codSaber": "105113-00"
  },
  {
    "centro": "LICEO RURAL LAS CEIBAS",
    "codPres": "5121",
    "codSaber": "104423-00"
  },
  {
    "centro": "LICEO RURAL CHÁNGUENA",
    "codPres": "5125",
    "codSaber": "104424-00"
  },
  {
    "centro": "LICEO RURAL RÍO NUEVO",
    "codPres": "5128",
    "codSaber": "104425-00"
  },
  {
    "centro": "LICEO RURAL EL JARDÍN",
    "codPres": "5129",
    "codSaber": "104426-00"
  },
  {
    "centro": "LICEO CONCEPCIÓN DANIEL FLORES",
    "codPres": "5131",
    "codSaber": "104427-00"
  },
  {
    "centro": "COLEGIO MAÍZ DE LOS UVA",
    "codPres": "5132",
    "codSaber": "104428-00"
  },
  {
    "centro": "LICEO RURAL LOS ÁNGELES DE PÁRAMO",
    "codPres": "5133",
    "codSaber": "104429-00"
  },
  {
    "centro": "COLEGIO SANTA EDUVIGES",
    "codPres": "5134",
    "codSaber": "104430-00"
  },
  {
    "centro": "COLEGIO DE UJARRÁS",
    "codPres": "5136",
    "codSaber": "104431-00"
  },
  {
    "centro": "LICEO LA GUÁCIMA",
    "codPres": "5137",
    "codSaber": "104432-00"
  },
  {
    "centro": "LICEO  POASITO",
    "codPres": "5139",
    "codSaber": "104433-00"
  },
  {
    "centro": "LICEO RURAL SAN JORGE",
    "codPres": "5142",
    "codSaber": "104434-00"
  },
  {
    "centro": "LICEO RURAL PONGOLA",
    "codPres": "5144",
    "codSaber": "104435-00"
  },
  {
    "centro": "LICEO RURAL SAN JOAQUÍN DE CUTRIS",
    "codPres": "5145",
    "codSaber": "104436-00"
  },
  {
    "centro": "LICEO RURAL EL CONCHO",
    "codPres": "5146",
    "codSaber": "104437-00"
  },
  {
    "centro": "LICEO RURAL SAN RAFAEL",
    "codPres": "5148",
    "codSaber": "104438-00"
  },
  {
    "centro": "LICEO RURAL MEDIO QUESO",
    "codPres": "5149",
    "codSaber": "104439-00"
  },
  {
    "centro": "LICEO SAN MARCOS",
    "codPres": "5150",
    "codSaber": "104440-00"
  },
  {
    "centro": "LICEO BUENOS AIRES DE POCOSOL",
    "codPres": "5151",
    "codSaber": "104441-00"
  },
  {
    "centro": "LICEO VERACRUZ",
    "codPres": "5152",
    "codSaber": "104442-00"
  },
  {
    "centro": "LICEO RURAL SAN JOAQUÍN",
    "codPres": "5154",
    "codSaber": "104443-00"
  },
  {
    "centro": "LICEO RURAL PACAYITAS",
    "codPres": "5155",
    "codSaber": "104444-00"
  },
  {
    "centro": "LICEO RURAL GRANO DE ORO",
    "codPres": "5156",
    "codSaber": "104445-00"
  },
  {
    "centro": "LICEO SÁMARA",
    "codPres": "5159",
    "codSaber": "104446-00"
  },
  {
    "centro": "LICEO RURAL LA ESPERANZA",
    "codPres": "5161",
    "codSaber": "104447-00"
  },
  {
    "centro": "LICEO RURAL OSTIONAL",
    "codPres": "5162",
    "codSaber": "104448-00"
  },
  {
    "centro": "LICEO RURAL JOSÉ LUIS JIMÉNEZ ALCALÁ",
    "codPres": "5163",
    "codSaber": "104449-00"
  },
  {
    "centro": "LICEO RURAL ISLA VENADO",
    "codPres": "5165",
    "codSaber": "104450-00"
  },
  {
    "centro": "LICEO FINCA ALAJUELA",
    "codPres": "5166",
    "codSaber": "104451-00"
  },
  {
    "centro": "LICEO RURAL BAHÍA DRAKE",
    "codPres": "5167",
    "codSaber": "104452-00"
  },
  {
    "centro": "LICEO RURAL BOCA DE SIERPE",
    "codPres": "5168",
    "codSaber": "104453-00"
  },
  {
    "centro": "LICEO RURAL BARRA DE PARISMINA",
    "codPres": "5170",
    "codSaber": "104454-00"
  },
  {
    "centro": "LICEO RURAL GAVILÁN",
    "codPres": "5171",
    "codSaber": "104455-00"
  },
  {
    "centro": "LICEO RURAL CAHUITA",
    "codPres": "5173",
    "codSaber": "104456-00"
  },
  {
    "centro": "LICEO RURAL BARRA DE TORTUGUERO",
    "codPres": "5176",
    "codSaber": "104457-00"
  },
  {
    "centro": "LICEO RURAL EL PORVENIR",
    "codPres": "5177",
    "codSaber": "104458-00"
  },
  {
    "centro": "LICEO LAS DELICIAS",
    "codPres": "5178",
    "codSaber": "104459-00"
  },
  {
    "centro": "CINDEA SAN JUAN DE DIOS",
    "codPres": "5280",
    "codSaber": "105114-00"
  },
  {
    "centro": "CINDEA SAN JUAN DE DIOS-C.A.I. VILMA CURLING RIVERA",
    "codPres": "5280",
    "codSaber": "105114-01"
  },
  {
    "centro": "CINDEA SAN JUAN DE DIOS-SAN MIGUEL",
    "codPres": "5280",
    "codSaber": "105114-04"
  },
  {
    "centro": "CINDEA SAN JUAN DE DIOS-SAN RAFAEL",
    "codPres": "5280",
    "codSaber": "105114-03"
  },
  {
    "centro": "CINDEA PURISCAL",
    "codPres": "5281",
    "codSaber": "105115-00"
  },
  {
    "centro": "CINDEA SAN RAFAEL-C.A.I. DR. GERARDO RODRIGUEZ",
    "codPres": "5282",
    "codSaber": "105194-03"
  },
  {
    "centro": "CINDEA SAN RAFAEL-C.A.I. JORGE ARTURO MONTERO CASTRO",
    "codPres": "5282",
    "codSaber": "105194-04"
  },
  {
    "centro": "CINDEA SAN RAFAEL-C.A.I. LUIS PAULINO MORA MORA",
    "codPres": "5282",
    "codSaber": "105194-00"
  },
  {
    "centro": "CINDEA SAN RAFAEL-C.A.I. OFELIA VINCENZI PEÑARANDA",
    "codPres": "5282",
    "codSaber": "105194-01"
  },
  {
    "centro": "CINDEA SAN RAFAEL-LA PAZ",
    "codPres": "5282",
    "codSaber": "105194-05"
  },
  {
    "centro": "CINDEA SAN RAFAEL-UAI REYNALDO VILLALOBOS ZÚÑIGA.",
    "codPres": "5282",
    "codSaber": "105194-02"
  },
  {
    "centro": "CINDEA PUERTO VIEJO",
    "codPres": "5283",
    "codSaber": "105116-00"
  },
  {
    "centro": "CINDEA PUERTO VIEJO-FINCA OCHO",
    "codPres": "5283",
    "codSaber": "105116-01"
  },
  {
    "centro": "CINDEA PUERTO VIEJO-HUETARES",
    "codPres": "5283",
    "codSaber": "105116-02"
  },
  {
    "centro": "NOCTURNO PACIFÍCO SUR",
    "codPres": "5284",
    "codSaber": "104461-00"
  },
  {
    "centro": "LICEO RURAL MANZANILLO",
    "codPres": "5288",
    "codSaber": "104462-00"
  },
  {
    "centro": "LICEO RURAL CEDRAL",
    "codPres": "5289",
    "codSaber": "104463-00"
  },
  {
    "centro": "LICEO DE CASCAJAL",
    "codPres": "5290",
    "codSaber": "104464-00"
  },
  {
    "centro": "LICEO RURAL BIJAGUAL",
    "codPres": "5291",
    "codSaber": "104465-00"
  },
  {
    "centro": "LICEO RURAL BOCA TAPADA",
    "codPres": "5293",
    "codSaber": "104466-00"
  },
  {
    "centro": "LICEO RURAL USEKLA",
    "codPres": "5294",
    "codSaber": "104467-00"
  },
  {
    "centro": "LICEO LA PERLA",
    "codPres": "5295",
    "codSaber": "104468-00"
  },
  {
    "centro": "LICEO RURAL SALVADOR DURÁN OCAMPO",
    "codPres": "5296",
    "codSaber": "104469-00"
  },
  {
    "centro": "COLEGIO LA PALMA",
    "codPres": "5297",
    "codSaber": "104470-00"
  },
  {
    "centro": "LICEO CANAÁN",
    "codPres": "5299",
    "codSaber": "104471-00"
  },
  {
    "centro": "LICEO LAS ESPERANZAS",
    "codPres": "5300",
    "codSaber": "104472-00"
  },
  {
    "centro": "LICEO PLATANILLO DE BARÚ",
    "codPres": "5301",
    "codSaber": "104473-00"
  },
  {
    "centro": "LICEO LOS ÁNGELES",
    "codPres": "5302",
    "codSaber": "104474-00"
  },
  {
    "centro": "LICEO CAPITÁN MANUEL QUIRÓS",
    "codPres": "5303",
    "codSaber": "104475-00"
  },
  {
    "centro": "LICEO NICOLAS AGUILAR MURILLO",
    "codPres": "5304",
    "codSaber": "104476-00"
  },
  {
    "centro": "TSIPIRIÑAK",
    "codPres": "5305",
    "codSaber": "104477-00"
  },
  {
    "centro": "NIMARI TÄWÄ",
    "codPres": "5306",
    "codSaber": "104478-00"
  },
  {
    "centro": "VILLA DAMARIS",
    "codPres": "5307",
    "codSaber": "104479-00"
  },
  {
    "centro": "KARKÖ",
    "codPres": "5308",
    "codSaber": "104480-00"
  },
  {
    "centro": "YÖLDI KICHA",
    "codPres": "5309",
    "codSaber": "104481-00"
  },
  {
    "centro": "MANZANILLO",
    "codPres": "5310",
    "codSaber": "104482-00"
  },
  {
    "centro": "SHUKËBACHARI",
    "codPres": "5311",
    "codSaber": "104483-00"
  },
  {
    "centro": "SHORDI",
    "codPres": "5312",
    "codSaber": "104484-00"
  },
  {
    "centro": "SHIKIARI TÄWÄ",
    "codPres": "5313",
    "codSaber": "104485-00"
  },
  {
    "centro": "EL BARRO",
    "codPres": "5314",
    "codSaber": "104486-00"
  },
  {
    "centro": "CALIENTA TIGRA",
    "codPres": "5315",
    "codSaber": "104487-00"
  },
  {
    "centro": "LICEO CAPITÁN RAMÓN RIVAS",
    "codPres": "5316",
    "codSaber": "104488-00"
  },
  {
    "centro": "LICEO CANALETE",
    "codPres": "5317",
    "codSaber": "104489-00"
  },
  {
    "centro": "LICEO CORONEL MANUEL ARGÜELLO",
    "codPres": "5318",
    "codSaber": "104490-00"
  },
  {
    "centro": "LA RIVERA",
    "codPres": "5319",
    "codSaber": "104491-00"
  },
  {
    "centro": "SANTA TERESITA",
    "codPres": "5320",
    "codSaber": "104492-00"
  },
  {
    "centro": "LA ROXANA",
    "codPres": "5321",
    "codSaber": "104493-00"
  },
  {
    "centro": "EL GUAPOTE",
    "codPres": "5322",
    "codSaber": "104494-00"
  },
  {
    "centro": "J.N. DULCE NOMBRE",
    "codPres": "5323",
    "codSaber": "104495-00"
  },
  {
    "centro": "JOSÉ JOAQUÍN MORA PORRAS",
    "codPres": "5324",
    "codSaber": "104496-00"
  },
  {
    "centro": "OROCU",
    "codPres": "5325",
    "codSaber": "104497-00"
  },
  {
    "centro": "DOS RAMAS",
    "codPres": "5326",
    "codSaber": "104498-00"
  },
  {
    "centro": "EL ENCANTO",
    "codPres": "5327",
    "codSaber": "104499-00"
  },
  {
    "centro": "LOS NARANJOS",
    "codPres": "5328",
    "codSaber": "104500-00"
  },
  {
    "centro": "LAGUNA DEL TORTUGUERO",
    "codPres": "5329",
    "codSaber": "104501-00"
  },
  {
    "centro": "LA PRADERA",
    "codPres": "5330",
    "codSaber": "104502-00"
  },
  {
    "centro": "CEBADILLA",
    "codPres": "5331",
    "codSaber": "104503-00"
  },
  {
    "centro": "SAN JUAN DE DIOS HIGUITO",
    "codPres": "5332",
    "codSaber": "104504-00"
  },
  {
    "centro": "LIMONCITO DE CUTRIS",
    "codPres": "5333",
    "codSaber": "104505-00"
  },
  {
    "centro": "LA CAJETA",
    "codPres": "5334",
    "codSaber": "104506-00"
  },
  {
    "centro": "PLAYA GRANDE",
    "codPres": "5343",
    "codSaber": "104508-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "5344",
    "codSaber": "104509-00"
  },
  {
    "centro": "J.N. SIMÓN BOLÍVAR",
    "codPres": "5345",
    "codSaber": "104510-00"
  },
  {
    "centro": "LA RIVIERA",
    "codPres": "5346",
    "codSaber": "104511-00"
  },
  {
    "centro": "LICEO RURAL BUENA VISTA",
    "codPres": "5347",
    "codSaber": "104512-00"
  },
  {
    "centro": "I.D.A. CAÑA BLANCA",
    "codPres": "5348",
    "codSaber": "104513-00"
  },
  {
    "centro": "J.N. EL ROBLE",
    "codPres": "5349",
    "codSaber": "104514-00"
  },
  {
    "centro": "LICEO SABANILLAS",
    "codPres": "5350",
    "codSaber": "104515-00"
  },
  {
    "centro": "BRIS",
    "codPres": "5354",
    "codSaber": "104516-00"
  },
  {
    "centro": "SANTA CRUZ",
    "codPres": "5355",
    "codSaber": "104517-00"
  },
  {
    "centro": "LICEO RURAL LOS ARBOLITOS",
    "codPres": "5356",
    "codSaber": "104518-00"
  },
  {
    "centro": "SANTA CRUZ-EL TABLAZO",
    "codPres": "5358",
    "codSaber": "104519-00"
  },
  {
    "centro": "CALLE LA LUCHA",
    "codPres": "5449",
    "codSaber": "104520-00"
  },
  {
    "centro": "J.N. REPÚBLICA DE COLOMBIA",
    "codPres": "5450",
    "codSaber": "104521-00"
  },
  {
    "centro": "TAMBOR",
    "codPres": "5455",
    "codSaber": "104522-00"
  },
  {
    "centro": "SAN RAFAEL",
    "codPres": "5457",
    "codSaber": "104523-00"
  },
  {
    "centro": "SAN FRANCISCO DE ASÍS",
    "codPres": "5501",
    "codSaber": "104524-00"
  },
  {
    "centro": "REPÚBLICA DEL PERÚ-VITALIA MADRIGAL ARAYA",
    "codPres": "5516",
    "codSaber": "104526-00"
  },
  {
    "centro": "SIPAR",
    "codPres": "5521",
    "codSaber": "104528-00"
  },
  {
    "centro": "CARTAGO",
    "codPres": "5522",
    "codSaber": "104529-00"
  },
  {
    "centro": "SANTA MARÍA",
    "codPres": "5523",
    "codSaber": "104530-00"
  },
  {
    "centro": "QUEBRADAS ARRIBA",
    "codPres": "5524",
    "codSaber": "104531-00"
  },
  {
    "centro": "I.D.A. JERUSALÉN",
    "codPres": "5525",
    "codSaber": "104532-00"
  },
  {
    "centro": "COOPEY",
    "codPres": "5526",
    "codSaber": "104533-00"
  },
  {
    "centro": "DURIÑAK",
    "codPres": "5527",
    "codSaber": "104534-00"
  },
  {
    "centro": "BUENAVENTURA",
    "codPres": "5528",
    "codSaber": "104535-00"
  },
  {
    "centro": "LOS PLANCITOS",
    "codPres": "5529",
    "codSaber": "104536-00"
  },
  {
    "centro": "LICEO SAN FRANCISCO",
    "codPres": "5530",
    "codSaber": "104537-00"
  },
  {
    "centro": "LICEO CONCEPCIÓN",
    "codPres": "5531",
    "codSaber": "104538-00"
  },
  {
    "centro": "LICEO BOCA DE ARENAL",
    "codPres": "5532",
    "codSaber": "104539-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE CLAUDIO BONILLA ALARCÓN",
    "codPres": "5533",
    "codSaber": "104540-00"
  },
  {
    "centro": "CEDRAL ARRIBA",
    "codPres": "5534",
    "codSaber": "104541-00"
  },
  {
    "centro": "LICEO DE GUARDIA",
    "codPres": "5535",
    "codSaber": "104542-00"
  },
  {
    "centro": "COLEGIO BARRA DE COLORADO",
    "codPres": "5536",
    "codSaber": "104543-00"
  },
  {
    "centro": "J.N. LOMAS DEL RÍO",
    "codPres": "5542",
    "codSaber": "104544-00"
  },
  {
    "centro": "J.N. JUAN ENRIQUE PESTALOZZI",
    "codPres": "5543",
    "codSaber": "104545-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "5547",
    "codSaber": "104546-00"
  },
  {
    "centro": "DULCE NOMBRE",
    "codPres": "5548",
    "codSaber": "104547-00"
  },
  {
    "centro": "LAS DELICIAS",
    "codPres": "5549",
    "codSaber": "104548-00"
  },
  {
    "centro": "UKA TIPEY",
    "codPres": "5550",
    "codSaber": "104549-00"
  },
  {
    "centro": "JAMEIKÄRI YOKSORO",
    "codPres": "5551",
    "codSaber": "104550-00"
  },
  {
    "centro": "EL BAMBÚ",
    "codPres": "5552",
    "codSaber": "104551-00"
  },
  {
    "centro": "EL CHILE",
    "codPres": "5553",
    "codSaber": "104552-00"
  },
  {
    "centro": "BAMBEL #1",
    "codPres": "5554",
    "codSaber": "104553-00"
  },
  {
    "centro": "SAVEGRE",
    "codPres": "5555",
    "codSaber": "104554-00"
  },
  {
    "centro": "CENTRO ENSEÑANZA ESPECIAL LENIN SALAZAR QUESADA",
    "codPres": "5557",
    "codSaber": "104555-00"
  },
  {
    "centro": "LINDA VISTA",
    "codPres": "5560",
    "codSaber": "104556-00"
  },
  {
    "centro": "EL PELONCITO",
    "codPres": "5561",
    "codSaber": "104557-00"
  },
  {
    "centro": "PORTICA",
    "codPres": "5562",
    "codSaber": "104558-00"
  },
  {
    "centro": "PUEBLO NUEVO",
    "codPres": "5563",
    "codSaber": "104559-00"
  },
  {
    "centro": "MRÜSARA",
    "codPres": "5564",
    "codSaber": "104560-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "5565",
    "codSaber": "104561-00"
  },
  {
    "centro": "SAN FRANCISCO",
    "codPres": "5566",
    "codSaber": "104562-00"
  },
  {
    "centro": "LICEO VENECIA",
    "codPres": "5567",
    "codSaber": "104563-00"
  },
  {
    "centro": "COLEGIO SEPECUE",
    "codPres": "5568",
    "codSaber": "104564-00"
  },
  {
    "centro": "MARÍA RAFFOLS",
    "codPres": "5569",
    "codSaber": "104565-00"
  },
  {
    "centro": "EL ROBLE",
    "codPres": "5570",
    "codSaber": "104566-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "5573",
    "codSaber": "104567-00"
  },
  {
    "centro": "BELLA VISTA",
    "codPres": "5574",
    "codSaber": "104568-00"
  },
  {
    "centro": "LICEO RURAL ABROJO MOCTEZUMA",
    "codPres": "5575",
    "codSaber": "104569-00"
  },
  {
    "centro": "LICEO RURAL SANTA ROSA",
    "codPres": "5576",
    "codSaber": "104570-00"
  },
  {
    "centro": "LICEO EL SAÍNO",
    "codPres": "5577",
    "codSaber": "104571-00"
  },
  {
    "centro": "LICEO RURAL LA GUARIA DE POCOSOL",
    "codPres": "5578",
    "codSaber": "104572-00"
  },
  {
    "centro": "LICEO ACADÉMICO SAN ANTONIO",
    "codPres": "5579",
    "codSaber": "104573-00"
  },
  {
    "centro": "LICEO RURAL SANTIAGO",
    "codPres": "5580",
    "codSaber": "104574-00"
  },
  {
    "centro": "LICEO RURAL SAN RAFAEL DE CABAGRA",
    "codPres": "5581",
    "codSaber": "104575-00"
  },
  {
    "centro": "LICEO RURAL MASTATAL",
    "codPres": "5582",
    "codSaber": "104576-00"
  },
  {
    "centro": "LICEO CUATRO BOCAS",
    "codPres": "5583",
    "codSaber": "104577-00"
  },
  {
    "centro": "LICEO RURAL LA CONQUISTA",
    "codPres": "5584",
    "codSaber": "104578-00"
  },
  {
    "centro": "LICEO RURAL LA ALDEA",
    "codPres": "5585",
    "codSaber": "104579-00"
  },
  {
    "centro": "LICEO EL PARAÍSO",
    "codPres": "5586",
    "codSaber": "104580-00"
  },
  {
    "centro": "LICEO RURAL SAN JULIÁN",
    "codPres": "5587",
    "codSaber": "104581-00"
  },
  {
    "centro": "TELESECUNDARIA LAS BRISAS",
    "codPres": "5588",
    "codSaber": "104582-00"
  },
  {
    "centro": "LICEO JUNTAS DE CAOBA",
    "codPres": "5590",
    "codSaber": "104583-00"
  },
  {
    "centro": "LICEO SAN JORGE",
    "codPres": "5591",
    "codSaber": "104584-00"
  },
  {
    "centro": "EL CARMEN",
    "codPres": "5593",
    "codSaber": "104585-00"
  },
  {
    "centro": "LICEO RURAL LOS JAZMINES",
    "codPres": "5596",
    "codSaber": "104586-00"
  },
  {
    "centro": "LICEO COQUITAL",
    "codPres": "5598",
    "codSaber": "100299-00"
  },
  {
    "centro": "J.N. LAS LETRAS",
    "codPres": "5641",
    "codSaber": "104587-00"
  },
  {
    "centro": "J.N. INGLATERRA",
    "codPres": "5642",
    "codSaber": "104588-00"
  },
  {
    "centro": "J.N. JOSÉ JOAQUÍN SALAS PÉREZ",
    "codPres": "5643",
    "codSaber": "104589-00"
  },
  {
    "centro": "COMADRE",
    "codPres": "5644",
    "codSaber": "104590-00"
  },
  {
    "centro": "LICEO BEBEDERO",
    "codPres": "5645",
    "codSaber": "104591-00"
  },
  {
    "centro": "SECTOR BARRANTES",
    "codPres": "5646",
    "codSaber": "104592-00"
  },
  {
    "centro": "MIRAVALLES",
    "codPres": "5647",
    "codSaber": "104593-00"
  },
  {
    "centro": "LA PALMERA",
    "codPres": "5648",
    "codSaber": "104594-00"
  },
  {
    "centro": "EL MANÁ",
    "codPres": "5649",
    "codSaber": "104595-00"
  },
  {
    "centro": "CHINA KICHÁ",
    "codPres": "5652",
    "codSaber": "104596-00"
  },
  {
    "centro": "TKAK-RI",
    "codPres": "5653",
    "codSaber": "104597-00"
  },
  {
    "centro": "PASO MARCOS",
    "codPres": "5654",
    "codSaber": "104598-00"
  },
  {
    "centro": "LICEO DE SAN ANDRÉS",
    "codPres": "5655",
    "codSaber": "104599-00"
  },
  {
    "centro": "LICEO RURAL SANTA CRUZ",
    "codPres": "5656",
    "codSaber": "104600-00"
  },
  {
    "centro": "LICEO RURAL SAN RAFAEL",
    "codPres": "5657",
    "codSaber": "104601-00"
  },
  {
    "centro": "LICEO RURAL YERI",
    "codPres": "5658",
    "codSaber": "104602-00"
  },
  {
    "centro": "LICEO RURAL CARTAGENA",
    "codPres": "5659",
    "codSaber": "104603-00"
  },
  {
    "centro": "LICEO RURAL LÍNEA VIEJA",
    "codPres": "5660",
    "codSaber": "104604-00"
  },
  {
    "centro": "LICEO RURAL LAS MARÍAS",
    "codPres": "5661",
    "codSaber": "104605-00"
  },
  {
    "centro": "LICEO RURAL PUERTO VIEJO",
    "codPres": "5662",
    "codSaber": "104606-00"
  },
  {
    "centro": "LICEO RURAL LA PALMA",
    "codPres": "5663",
    "codSaber": "104607-00"
  },
  {
    "centro": "LICEO RURAL SAN ANTONIO",
    "codPres": "5664",
    "codSaber": "104608-00"
  },
  {
    "centro": "LICEO RURAL BOCA RÍO SAN CARLOS",
    "codPres": "5665",
    "codSaber": "104609-00"
  },
  {
    "centro": "LICEO RURAL COOPE SAN JUAN",
    "codPres": "5666",
    "codSaber": "104610-00"
  },
  {
    "centro": "LICEO RURAL JUANILAMA",
    "codPres": "5667",
    "codSaber": "104611-00"
  },
  {
    "centro": "TELESECUNDARIA LA URRACA",
    "codPres": "5668",
    "codSaber": "104612-00"
  },
  {
    "centro": "TELESECUNDARIA MÉXICO",
    "codPres": "5669",
    "codSaber": "104613-00"
  },
  {
    "centro": "LICEO COLONIA PUNTARENAS",
    "codPres": "5670",
    "codSaber": "104614-00"
  },
  {
    "centro": "LICEO COLONIA VILLA NUEVA",
    "codPres": "5671",
    "codSaber": "104615-00"
  },
  {
    "centro": "LICEO RURAL VALLE VERDE",
    "codPres": "5672",
    "codSaber": "104616-00"
  },
  {
    "centro": "LICEO RURAL I.D.A. SAN LUIS",
    "codPres": "5673",
    "codSaber": "104617-00"
  },
  {
    "centro": "LICEO RURAL PIEDRAS AZULES",
    "codPres": "5674",
    "codSaber": "104618-00"
  },
  {
    "centro": "CINDEA ABANGARES",
    "codPres": "5676",
    "codSaber": "105117-00"
  },
  {
    "centro": "CINDEA ABANGARES-MATAPALO",
    "codPres": "5676",
    "codSaber": "105117-02"
  },
  {
    "centro": "COLEGIO SAN MARTÍN",
    "codPres": "5677",
    "codSaber": "104619-00"
  },
  {
    "centro": "COLEGIO CANDELARIA",
    "codPres": "5679",
    "codSaber": "104620-00"
  },
  {
    "centro": "C.T.P. SANTA ANA",
    "codPres": "5680",
    "codSaber": "104621-00"
  },
  {
    "centro": "NOCTURNO LA JULIETA",
    "codPres": "5682",
    "codSaber": "104622-00"
  },
  {
    "centro": "CINDEA BRIBRÍ",
    "codPres": "5686",
    "codSaber": "105118-00"
  },
  {
    "centro": "CINDEA BRIBRÍ-CAHUITA",
    "codPres": "5686",
    "codSaber": "105118-01"
  },
  {
    "centro": "CINDEA BRIBRÍ-FINCA COSTA RICA",
    "codPres": "5686",
    "codSaber": "105118-02"
  },
  {
    "centro": "CINDEA 28 MILLAS",
    "codPres": "5687",
    "codSaber": "105119-00"
  },
  {
    "centro": "CINDEA 28 MILLAS-ESTRADA",
    "codPres": "5687",
    "codSaber": "105119-01"
  },
  {
    "centro": "CINDEA 28 MILLAS-LINEA B",
    "codPres": "5687",
    "codSaber": "105119-03"
  },
  {
    "centro": "CINDEA 28 MILLAS-LUZÓN",
    "codPres": "5687",
    "codSaber": "105119-04"
  },
  {
    "centro": "CINDEA 28 MILLAS-MATINA",
    "codPres": "5687",
    "codSaber": "105119-05"
  },
  {
    "centro": "CINDEA 28 MILLAS-PALACIOS",
    "codPres": "5687",
    "codSaber": "105119-06"
  },
  {
    "centro": "CINDEA 28 MILLAS-SAHARA",
    "codPres": "5687",
    "codSaber": "105119-07"
  },
  {
    "centro": "CINDEA 28 MILLAS-SANTA MARTA",
    "codPres": "5687",
    "codSaber": "105119-08"
  },
  {
    "centro": "CINDEA LIMÓN",
    "codPres": "5688",
    "codSaber": "105120-00"
  },
  {
    "centro": "CINDEA LIMÓN-C.A.I. MARCUS GARVEY",
    "codPres": "5688",
    "codSaber": "105120-03"
  },
  {
    "centro": "CINDEA LIMÓN-LIMÓN 2000",
    "codPres": "5688",
    "codSaber": "105120-01"
  },
  {
    "centro": "CINDEA LIMÓN-RÍO BLANCO",
    "codPres": "5688",
    "codSaber": "105120-02"
  },
  {
    "centro": "CINDEA LIMÓN-TOMÁS GUARDIA",
    "codPres": "5688",
    "codSaber": "105120-04"
  },
  {
    "centro": "COLORADO",
    "codPres": "5689",
    "codSaber": "104624-00"
  },
  {
    "centro": "SANTA MARTA",
    "codPres": "5690",
    "codSaber": "104625-00"
  },
  {
    "centro": "VIENTO FRESCO",
    "codPres": "5691",
    "codSaber": "104626-00"
  },
  {
    "centro": "LOS LAGOS",
    "codPres": "5692",
    "codSaber": "104627-00"
  },
  {
    "centro": "LA BONITA",
    "codPres": "5693",
    "codSaber": "104628-00"
  },
  {
    "centro": "J.N. SARCHÍ NORTE",
    "codPres": "5694",
    "codSaber": "104629-00"
  },
  {
    "centro": "SËLIKÖ",
    "codPres": "5695",
    "codSaber": "104630-00"
  },
  {
    "centro": "TSIÖBATA",
    "codPres": "5696",
    "codSaber": "104631-00"
  },
  {
    "centro": "BUKERI",
    "codPres": "5697",
    "codSaber": "104632-00"
  },
  {
    "centro": "TSIRBÄKLÄ",
    "codPres": "5698",
    "codSaber": "104633-00"
  },
  {
    "centro": "TKANYÄKÄ",
    "codPres": "5699",
    "codSaber": "104634-00"
  },
  {
    "centro": "CARRIZAL",
    "codPres": "5700",
    "codSaber": "104635-00"
  },
  {
    "centro": "MELERUK II",
    "codPres": "5701",
    "codSaber": "104636-00"
  },
  {
    "centro": "ALTO COÉN",
    "codPres": "5702",
    "codSaber": "104637-00"
  },
  {
    "centro": "JAKJUABATA",
    "codPres": "5703",
    "codSaber": "104638-00"
  },
  {
    "centro": "GUAYABA YÄKÄ",
    "codPres": "5704",
    "codSaber": "104639-00"
  },
  {
    "centro": "JAMO",
    "codPres": "5705",
    "codSaber": "104640-00"
  },
  {
    "centro": "NOCTURNO DE SIQUIRRES",
    "codPres": "5706",
    "codSaber": "104641-00"
  },
  {
    "centro": "COLEGIO ACADÉMICO COSTA DE PÁJAROS",
    "codPres": "5707",
    "codSaber": "104642-00"
  },
  {
    "centro": "LICEO RURAL LA GARITA",
    "codPres": "5708",
    "codSaber": "104643-00"
  },
  {
    "centro": "LICEO RURAL DE TÁRCOLES",
    "codPres": "5709",
    "codSaber": "104644-00"
  },
  {
    "centro": "LAS ORQUÍDEAS",
    "codPres": "5712",
    "codSaber": "104645-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE RÍO JIMÉNEZ",
    "codPres": "5718",
    "codSaber": "104646-00"
  },
  {
    "centro": "SANTA TERESITA",
    "codPres": "5720",
    "codSaber": "104647-00"
  },
  {
    "centro": "MONTE LIRIO",
    "codPres": "5721",
    "codSaber": "104648-00"
  },
  {
    "centro": "LOS ALPES",
    "codPres": "5722",
    "codSaber": "104649-00"
  },
  {
    "centro": "EL CONGO",
    "codPres": "5723",
    "codSaber": "104650-00"
  },
  {
    "centro": "EL ESTABLO",
    "codPres": "5724",
    "codSaber": "104651-00"
  },
  {
    "centro": "MONTERREY",
    "codPres": "5726",
    "codSaber": "104652-00"
  },
  {
    "centro": "EL PARAÍSO",
    "codPres": "5727",
    "codSaber": "104653-00"
  },
  {
    "centro": "LICEO SANTA MARTA",
    "codPres": "5728",
    "codSaber": "104654-00"
  },
  {
    "centro": "COLEGIO PLAYAS DEL COCO",
    "codPres": "5729",
    "codSaber": "104655-00"
  },
  {
    "centro": "NOCTURNO GUAYCARÁ",
    "codPres": "5732",
    "codSaber": "104656-00"
  },
  {
    "centro": "LICEO RURAL LAS COLONIAS",
    "codPres": "5734",
    "codSaber": "104657-00"
  },
  {
    "centro": "EL ESTADIO",
    "codPres": "5736",
    "codSaber": "104659-00"
  },
  {
    "centro": "EL BAMBÚ",
    "codPres": "5745",
    "codSaber": "104660-00"
  },
  {
    "centro": "CINDEA VENECIA",
    "codPres": "5746",
    "codSaber": "105121-00"
  },
  {
    "centro": "CINDEA VENECIA-SANTA RITA",
    "codPres": "5746",
    "codSaber": "105121-01"
  },
  {
    "centro": "TELESECUNDARIA DULCE NOMBRE",
    "codPres": "5747",
    "codSaber": "104661-00"
  },
  {
    "centro": "C.T.P. DE QUEPOS",
    "codPres": "5748",
    "codSaber": "104662-00"
  },
  {
    "centro": "LAS ROSAS",
    "codPres": "5799",
    "codSaber": "104663-00"
  },
  {
    "centro": "DIKËKLÄRIÑAK",
    "codPres": "5800",
    "codSaber": "104664-00"
  },
  {
    "centro": "SUËBATA",
    "codPres": "5801",
    "codSaber": "104665-00"
  },
  {
    "centro": "KJALARI",
    "codPres": "5802",
    "codSaber": "104666-00"
  },
  {
    "centro": "DUSIRIÑAK",
    "codPres": "5803",
    "codSaber": "104667-00"
  },
  {
    "centro": "CHUMICO",
    "codPres": "5804",
    "codSaber": "104668-00"
  },
  {
    "centro": "MONTE DE SIÓN",
    "codPres": "5805",
    "codSaber": "104669-00"
  },
  {
    "centro": "NOCTURNO DE PALMARES",
    "codPres": "5806",
    "codSaber": "104670-00"
  },
  {
    "centro": "NOCTURNO DE CARIARI",
    "codPres": "5807",
    "codSaber": "104671-00"
  },
  {
    "centro": "J.N. FEDERICO SALAS CARVAJAL",
    "codPres": "5808",
    "codSaber": "104672-00"
  },
  {
    "centro": "LAGUNAS DE BARÚ",
    "codPres": "5810",
    "codSaber": "104673-00"
  },
  {
    "centro": "J.N. JOSEFINA LÓPEZ BONILLA",
    "codPres": "5811",
    "codSaber": "104674-00"
  },
  {
    "centro": "JAKKJUÄ",
    "codPres": "5812",
    "codSaber": "104675-00"
  },
  {
    "centro": "COPALCHÍ",
    "codPres": "5813",
    "codSaber": "104676-00"
  },
  {
    "centro": "LICEO VUELTA DE JORCO",
    "codPres": "5814",
    "codSaber": "104677-00"
  },
  {
    "centro": "NOCTURNO DE SINAÍ",
    "codPres": "5815",
    "codSaber": "104678-00"
  },
  {
    "centro": "NOCTURNO OROTINA",
    "codPres": "5816",
    "codSaber": "104679-00"
  },
  {
    "centro": "LICEO LA PALMERA",
    "codPres": "5817",
    "codSaber": "104680-00"
  },
  {
    "centro": "C.T.P. DE ESCAZÚ",
    "codPres": "5818",
    "codSaber": "104681-00"
  },
  {
    "centro": "LICEO DE TÉRRABA",
    "codPres": "5820",
    "codSaber": "104682-00"
  },
  {
    "centro": "DÖRBATA",
    "codPres": "5824",
    "codSaber": "104683-00"
  },
  {
    "centro": "MOLOTUBTA",
    "codPres": "5825",
    "codSaber": "104684-00"
  },
  {
    "centro": "COOPE ROSALES",
    "codPres": "5830",
    "codSaber": "104686-00"
  },
  {
    "centro": "JORGE ROSSI CHAVARRÍA",
    "codPres": "5831",
    "codSaber": "104687-00"
  },
  {
    "centro": "PUNTA DE LANZA",
    "codPres": "5832",
    "codSaber": "104688-00"
  },
  {
    "centro": "CINDEA JICARAL",
    "codPres": "5835",
    "codSaber": "105122-00"
  },
  {
    "centro": "CINDEA JICARAL-LEPANTO",
    "codPres": "5835",
    "codSaber": "105122-01"
  },
  {
    "centro": "LICEO RURAL SANTO DOMINGO",
    "codPres": "5836",
    "codSaber": "104690-00"
  },
  {
    "centro": "LICEO RURAL CERRITOS",
    "codPres": "5837",
    "codSaber": "104691-00"
  },
  {
    "centro": "LICEO RURAL COOPESILENCIO",
    "codPres": "5838",
    "codSaber": "104692-00"
  },
  {
    "centro": "TELESECUNDARIA LA CEIBA",
    "codPres": "5839",
    "codSaber": "104693-00"
  },
  {
    "centro": "LICEO RURAL LA LUCHITA",
    "codPres": "5840",
    "codSaber": "104694-00"
  },
  {
    "centro": "LICEO SAN CARLOS",
    "codPres": "5841",
    "codSaber": "104695-00"
  },
  {
    "centro": "LICEO RURAL ALTO GUAYMÍ",
    "codPres": "5842",
    "codSaber": "104696-00"
  },
  {
    "centro": "LICEO RURAL ALTO COMTE",
    "codPres": "5843",
    "codSaber": "104697-00"
  },
  {
    "centro": "LICEO CUAJINIQUIL",
    "codPres": "5844",
    "codSaber": "104698-00"
  },
  {
    "centro": "LICEO EL CONSUELO",
    "codPres": "5845",
    "codSaber": "104699-00"
  },
  {
    "centro": "LICEO RURAL GANDOCA",
    "codPres": "5846",
    "codSaber": "104700-00"
  },
  {
    "centro": "LICEO RURAL LA CELINA",
    "codPres": "5847",
    "codSaber": "104701-00"
  },
  {
    "centro": "LICEO INDÍGENA BOCA COHÉN",
    "codPres": "5848",
    "codSaber": "104702-00"
  },
  {
    "centro": "LICEO RURAL ROCA QUEMADA",
    "codPres": "5849",
    "codSaber": "104703-00"
  },
  {
    "centro": "LICEO BELÉN",
    "codPres": "5850",
    "codSaber": "104704-00"
  },
  {
    "centro": "LICEO SANTA TERESA",
    "codPres": "5851",
    "codSaber": "104705-00"
  },
  {
    "centro": "LICEO PICAGRES DE MORA",
    "codPres": "5852",
    "codSaber": "104706-00"
  },
  {
    "centro": "LICEO RURAL EL CASTILLO FORTUNA",
    "codPres": "5853",
    "codSaber": "104707-00"
  },
  {
    "centro": "LICEO RURAL EL VENADO",
    "codPres": "5854",
    "codSaber": "104708-00"
  },
  {
    "centro": "LICEO RURAL SAN ANTONIO DE ZAPOTAL",
    "codPres": "5855",
    "codSaber": "104709-00"
  },
  {
    "centro": "TELESECUNDARIA COLONIA ANATERI",
    "codPres": "5856",
    "codSaber": "104710-00"
  },
  {
    "centro": "LICEO RURAL LA GATA",
    "codPres": "5858",
    "codSaber": "104712-00"
  },
  {
    "centro": "LICEO RURAL LAS NUBES CRISTO REY",
    "codPres": "5860",
    "codSaber": "104713-00"
  },
  {
    "centro": "JAMARI TÄWÄ",
    "codPres": "5861",
    "codSaber": "104714-00"
  },
  {
    "centro": "SAN MARTÍN",
    "codPres": "5862",
    "codSaber": "104715-00"
  },
  {
    "centro": "TOLOK KICHÁ",
    "codPres": "5864",
    "codSaber": "104716-00"
  },
  {
    "centro": "MARIARIBUTA",
    "codPres": "5865",
    "codSaber": "104717-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "5866",
    "codSaber": "104718-00"
  },
  {
    "centro": "CAPACITACIÓN AMBIENTAL VERACRUZ",
    "codPres": "5867",
    "codSaber": "104719-00"
  },
  {
    "centro": "SOTA DOS",
    "codPres": "5868",
    "codSaber": "104720-00"
  },
  {
    "centro": "LICEO AEROPUERTO JERUSALÉN",
    "codPres": "5869",
    "codSaber": "104721-00"
  },
  {
    "centro": "LICEO SOTERO GONZÁLEZ BARQUERO",
    "codPres": "5870",
    "codSaber": "105534-00"
  },
  {
    "centro": "COLEGIO ACADÉMICO DE LONDRES",
    "codPres": "5871",
    "codSaber": "104723-00"
  },
  {
    "centro": "LICEO DE BARBACOAS",
    "codPres": "5873",
    "codSaber": "104724-00"
  },
  {
    "centro": "LICEO AMBIENTALISTA DE HORQUETAS",
    "codPres": "5874",
    "codSaber": "104725-00"
  },
  {
    "centro": "JALA KICHA",
    "codPres": "5877",
    "codSaber": "104726-00"
  },
  {
    "centro": "EL PORTAL",
    "codPres": "5878",
    "codSaber": "104727-00"
  },
  {
    "centro": "GUARIAL",
    "codPres": "5879",
    "codSaber": "104728-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE SIQUIRRES",
    "codPres": "5882",
    "codSaber": "104729-00"
  },
  {
    "centro": "BARBUDAL",
    "codPres": "5883",
    "codSaber": "104730-00"
  },
  {
    "centro": "LOURDES",
    "codPres": "5884",
    "codSaber": "104731-00"
  },
  {
    "centro": "LA COSTANERA",
    "codPres": "5885",
    "codSaber": "104732-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE SARCHÍ SUR",
    "codPres": "5886",
    "codSaber": "104733-00"
  },
  {
    "centro": "ASENTAMIENTO SALAMÁ",
    "codPres": "5887",
    "codSaber": "104734-00"
  },
  {
    "centro": "CINDEA SAN FRANCISCO",
    "codPres": "5888",
    "codSaber": "105123-00"
  },
  {
    "centro": "CINDEA SAN FRANCISCO-LOMAS DE COCORI",
    "codPres": "5888",
    "codSaber": "105123-01"
  },
  {
    "centro": "CINDEA FLORIDA",
    "codPres": "5889",
    "codSaber": "105124-00"
  },
  {
    "centro": "CINDEA FLORIDA-ALEGRÍA",
    "codPres": "5889",
    "codSaber": "105124-01"
  },
  {
    "centro": "CINDEA FLORIDA-GRANO DE ORO",
    "codPres": "5889",
    "codSaber": "105124-02"
  },
  {
    "centro": "CINDEA FLORIDA-PORTÓN IBERIA",
    "codPres": "5889",
    "codSaber": "105124-03"
  },
  {
    "centro": "LA TRANQUILIDAD",
    "codPres": "5890",
    "codSaber": "104735-00"
  },
  {
    "centro": "LICEO RURAL EL CARMEN PARRITA",
    "codPres": "5891",
    "codSaber": "104736-00"
  },
  {
    "centro": "LICEO RURAL AGUAS ZARCAS",
    "codPres": "5895",
    "codSaber": "104737-00"
  },
  {
    "centro": "LICEO RURAL BELLA VISTA",
    "codPres": "5897",
    "codSaber": "104738-00"
  },
  {
    "centro": "NOCTURNO DE PUERTO VIEJO",
    "codPres": "5929",
    "codSaber": "104739-00"
  },
  {
    "centro": "LA ISLITA",
    "codPres": "5958",
    "codSaber": "104740-00"
  },
  {
    "centro": "LICEO RURAL NUEVA GUATEMALA",
    "codPres": "5967",
    "codSaber": "104742-00"
  },
  {
    "centro": "LICEO RURAL CAÑON DE EL GUARCO",
    "codPres": "5968",
    "codSaber": "104743-00"
  },
  {
    "centro": "LICEO RURAL SANTA ROSA",
    "codPres": "5969",
    "codSaber": "104744-00"
  },
  {
    "centro": "LICEO RURAL ISLAS DEL CHIRRIPÓ",
    "codPres": "5970",
    "codSaber": "104745-00"
  },
  {
    "centro": "LICEO RURAL UNIÓN DEL TORO",
    "codPres": "5971",
    "codSaber": "104746-00"
  },
  {
    "centro": "COLEGIO SAN CARLOS DE PACUARITO",
    "codPres": "5972",
    "codSaber": "104747-00"
  },
  {
    "centro": "LICEO EL CARMEN",
    "codPres": "5973",
    "codSaber": "104748-00"
  },
  {
    "centro": "LICEO RURAL LA CUREÑA",
    "codPres": "5974",
    "codSaber": "104749-00"
  },
  {
    "centro": "LICEO RURAL BANDERAS",
    "codPres": "5975",
    "codSaber": "104750-00"
  },
  {
    "centro": "LICEO RURAL SAN JUAN",
    "codPres": "5976",
    "codSaber": "104751-00"
  },
  {
    "centro": "LICEO SAN NICOLÁS DE TOLENTINO",
    "codPres": "5979",
    "codSaber": "104752-00"
  },
  {
    "centro": "CINDEA COLONIA PUNTARENAS",
    "codPres": "5980",
    "codSaber": "105125-00"
  },
  {
    "centro": "LICEO RURAL PARAÍSO",
    "codPres": "5981",
    "codSaber": "104753-00"
  },
  {
    "centro": "BUENA VISTA",
    "codPres": "5982",
    "codSaber": "104754-00"
  },
  {
    "centro": "BAJO DE MOLLEJONES",
    "codPres": "5983",
    "codSaber": "104755-00"
  },
  {
    "centro": "LICEO LABRADOR",
    "codPres": "5984",
    "codSaber": "104756-00"
  },
  {
    "centro": "LICEO RURAL ZAPATÓN",
    "codPres": "5985",
    "codSaber": "104757-00"
  },
  {
    "centro": "LICEO RURAL KABEBATA",
    "codPres": "5986",
    "codSaber": "104758-00"
  },
  {
    "centro": "LA ANGELINA",
    "codPres": "5987",
    "codSaber": "104759-00"
  },
  {
    "centro": "LICEO QUEBRADA GANADO",
    "codPres": "5988",
    "codSaber": "104760-00"
  },
  {
    "centro": "SWAKBLI",
    "codPres": "5989",
    "codSaber": "104761-00"
  },
  {
    "centro": "LICEO LAS MERCEDES",
    "codPres": "5990",
    "codSaber": "104762-00"
  },
  {
    "centro": "LICEO LAGUNA",
    "codPres": "5992",
    "codSaber": "104763-00"
  },
  {
    "centro": "LICEO LA AMISTAD",
    "codPres": "5994",
    "codSaber": "104765-00"
  },
  {
    "centro": "LICEO DE MAGALLANES",
    "codPres": "5995",
    "codSaber": "104766-00"
  },
  {
    "centro": "EXPERIMENTAL BILINGÜE DE SAN RAMÓN",
    "codPres": "5996",
    "codSaber": "104767-00"
  },
  {
    "centro": "LICEO PACTO DEL JOCOTE",
    "codPres": "5998",
    "codSaber": "104768-00"
  },
  {
    "centro": "LICEO RURAL SAN ISIDRO",
    "codPres": "5999",
    "codSaber": "104769-00"
  },
  {
    "centro": "LICEO CUATRO ESQUINAS",
    "codPres": "6000",
    "codSaber": "104770-00"
  },
  {
    "centro": "OROCHICO 2",
    "codPres": "6001",
    "codSaber": "104771-00"
  },
  {
    "centro": "LA PALMA",
    "codPres": "6002",
    "codSaber": "104772-00"
  },
  {
    "centro": "ÑORIBATA",
    "codPres": "6010",
    "codSaber": "104773-00"
  },
  {
    "centro": "LA QUEROGA",
    "codPres": "6014",
    "codSaber": "104774-00"
  },
  {
    "centro": "CINDEA NICOYA",
    "codPres": "6015",
    "codSaber": "105126-00"
  },
  {
    "centro": "CINDEA NICOYA-SAN ANTONIO",
    "codPres": "6015",
    "codSaber": "105126-01"
  },
  {
    "centro": "C.T.P. ULADISLAO GÁMEZ SOLANO",
    "codPres": "6016",
    "codSaber": "104775-00"
  },
  {
    "centro": "LICEO LA LUCHA",
    "codPres": "6017",
    "codSaber": "104776-00"
  },
  {
    "centro": "KÖKÖTSAKUBATA",
    "codPres": "6018",
    "codSaber": "104777-00"
  },
  {
    "centro": "LICEO DEPORTIVO DE GRECIA",
    "codPres": "6020",
    "codSaber": "104778-00"
  },
  {
    "centro": "J.N. PRIMO VARGAS VALVERDE",
    "codPres": "6023",
    "codSaber": "104780-00"
  },
  {
    "centro": "WAWET",
    "codPres": "6024",
    "codSaber": "104781-00"
  },
  {
    "centro": "ALTO KATSI",
    "codPres": "6025",
    "codSaber": "104782-00"
  },
  {
    "centro": "COLINAS DEL ESTE",
    "codPres": "6026",
    "codSaber": "104783-00"
  },
  {
    "centro": "LICEO HIGUITO",
    "codPres": "6027",
    "codSaber": "104784-00"
  },
  {
    "centro": "LICEO VIRGEN MEDALLA MILAGROSA",
    "codPres": "6030",
    "codSaber": "104785-00"
  },
  {
    "centro": "C.T.P. FERNANDO VOLIO JIMÉNEZ",
    "codPres": "6032",
    "codSaber": "104786-00"
  },
  {
    "centro": "C.T.P. INVU LAS CAÑAS",
    "codPres": "6033",
    "codSaber": "104787-00"
  },
  {
    "centro": "C.T.P. TRONADORA",
    "codPres": "6034",
    "codSaber": "104788-00"
  },
  {
    "centro": "CONED SAN JOSÉ",
    "codPres": "6037",
    "codSaber": "104789-00"
  },
  {
    "centro": "LICEO RURAL LANAS",
    "codPres": "6043",
    "codSaber": "104790-00"
  },
  {
    "centro": "LICEO RURAL EL LLANO",
    "codPres": "6044",
    "codSaber": "104791-00"
  },
  {
    "centro": "LICEO RURAL YORKIN",
    "codPres": "6045",
    "codSaber": "104792-00"
  },
  {
    "centro": "COLEGIO INDÍGENA LA CASONA",
    "codPres": "6046",
    "codSaber": "104793-00"
  },
  {
    "centro": "LICEO RURAL JARIS",
    "codPres": "6050",
    "codSaber": "104794-00"
  },
  {
    "centro": "J.N. FINCA LA CAJA",
    "codPres": "6095",
    "codSaber": "104795-00"
  },
  {
    "centro": "TARISE",
    "codPres": "6098",
    "codSaber": "104797-00"
  },
  {
    "centro": "LAS ORQUÍDEAS",
    "codPres": "6099",
    "codSaber": "104798-00"
  },
  {
    "centro": "MOI",
    "codPres": "6100",
    "codSaber": "104799-00"
  },
  {
    "centro": "NOCTURNO DE POCORA",
    "codPres": "6101",
    "codSaber": "104800-00"
  },
  {
    "centro": "COLEGIO ACADÉMICO PARAÍSO",
    "codPres": "6103",
    "codSaber": "104802-00"
  },
  {
    "centro": "C.T.P. JOSÉ ALBERTAZZI",
    "codPres": "6104",
    "codSaber": "104803-00"
  },
  {
    "centro": "C.T.P. CARRIZAL",
    "codPres": "6105",
    "codSaber": "104804-00"
  },
  {
    "centro": "J.N. REPÚBLICA FRANCESA",
    "codPres": "6111",
    "codSaber": "104807-00"
  },
  {
    "centro": "COLEGIO FINCA NARANJO",
    "codPres": "6112",
    "codSaber": "104808-00"
  },
  {
    "centro": "NOCTURNO DE SAN PEDRO",
    "codPres": "6113",
    "codSaber": "104809-00"
  },
  {
    "centro": "HUACAS",
    "codPres": "6114",
    "codSaber": "104810-00"
  },
  {
    "centro": "LICEO SAN RAFAEL",
    "codPres": "6115",
    "codSaber": "104811-00"
  },
  {
    "centro": "LICEO RURAL KATSI",
    "codPres": "6129",
    "codSaber": "104814-00"
  },
  {
    "centro": "C.T.P. GRANADILLA",
    "codPres": "6130",
    "codSaber": "104815-00"
  },
  {
    "centro": "J.N. PEDRO AGUIRRE CERDA",
    "codPres": "6132",
    "codSaber": "104816-00"
  },
  {
    "centro": "LICEO PUENTE DE PIEDRA",
    "codPres": "6133",
    "codSaber": "104817-00"
  },
  {
    "centro": "LICEO OCCIDENTAL",
    "codPres": "6137",
    "codSaber": "104819-00"
  },
  {
    "centro": "CHORRERAS",
    "codPres": "6139",
    "codSaber": "104820-00"
  },
  {
    "centro": "ÑUKA KICHÁ",
    "codPres": "6140",
    "codSaber": "104821-00"
  },
  {
    "centro": "KABERI",
    "codPres": "6141",
    "codSaber": "104822-00"
  },
  {
    "centro": "DUERI",
    "codPres": "6142",
    "codSaber": "104823-00"
  },
  {
    "centro": "SULAJU",
    "codPres": "6143",
    "codSaber": "104824-00"
  },
  {
    "centro": "TAKLAK YAKÄ",
    "codPres": "6144",
    "codSaber": "104825-00"
  },
  {
    "centro": "ULUJERIÑAK",
    "codPres": "6145",
    "codSaber": "104826-00"
  },
  {
    "centro": "LICEO BUENOS AIRES",
    "codPres": "6149",
    "codSaber": "104829-00"
  },
  {
    "centro": "J.N. MANUELA SANTAMARÍA RODRÍGUEZ",
    "codPres": "6151",
    "codSaber": "104830-00"
  },
  {
    "centro": "CONVENTILLO",
    "codPres": "6152",
    "codSaber": "104831-00"
  },
  {
    "centro": "KONOBATA",
    "codPres": "6154",
    "codSaber": "104832-00"
  },
  {
    "centro": "LICEO BILINGÜE ÍTALO COSTARRICENSE",
    "codPres": "6156",
    "codSaber": "104833-00"
  },
  {
    "centro": "LICEO LLANO LOS ÁNGELES",
    "codPres": "6216",
    "codSaber": "104836-00"
  },
  {
    "centro": "LICEO RURAL GUACIMAL",
    "codPres": "6217",
    "codSaber": "104837-00"
  },
  {
    "centro": "GAMONALES",
    "codPres": "6218",
    "codSaber": "104838-00"
  },
  {
    "centro": "LICEO RURAL COLONIA DEL VALLE",
    "codPres": "6220",
    "codSaber": "104840-00"
  },
  {
    "centro": "CINDEA GUÁCIMO",
    "codPres": "6221",
    "codSaber": "105127-00"
  },
  {
    "centro": "CINDEA GUÁCIMO-EL CARMEN",
    "codPres": "6221",
    "codSaber": "105127-01"
  },
  {
    "centro": "CINDEA GUÁCIMO-LA SELVA",
    "codPres": "6221",
    "codSaber": "105127-02"
  },
  {
    "centro": "CINDEA GUÁCIMO-PARISMINA",
    "codPres": "6221",
    "codSaber": "105127-03"
  },
  {
    "centro": "COLEGIO QUEBRADA GRANDE",
    "codPres": "6222",
    "codSaber": "104841-00"
  },
  {
    "centro": "LOS ÁNGELES",
    "codPres": "6223",
    "codSaber": "104842-00"
  },
  {
    "centro": "LICEO RURAL COROMA",
    "codPres": "6224",
    "codSaber": "104843-00"
  },
  {
    "centro": "LICEO RURAL NAMALDI",
    "codPres": "6235",
    "codSaber": "104844-00"
  },
  {
    "centro": "LICEO RURAL PALMERA",
    "codPres": "6236",
    "codSaber": "104845-00"
  },
  {
    "centro": "CONED CIUDAD NEILY",
    "codPres": "6237",
    "codSaber": "104846-00"
  },
  {
    "centro": "CONED ALUNASA",
    "codPres": "6238",
    "codSaber": "104847-00"
  },
  {
    "centro": "CONED LIBERIA",
    "codPres": "6239",
    "codSaber": "104848-00"
  },
  {
    "centro": "CONED HEREDIA",
    "codPres": "6240",
    "codSaber": "104849-00"
  },
  {
    "centro": "CONED PALMARES",
    "codPres": "6241",
    "codSaber": "104850-00"
  },
  {
    "centro": "CONED TURRIALBA",
    "codPres": "6242",
    "codSaber": "104851-00"
  },
  {
    "centro": "CONED LIMÓN",
    "codPres": "6243",
    "codSaber": "104852-00"
  },
  {
    "centro": "LICEO SONAFLUCA",
    "codPres": "6244",
    "codSaber": "104853-00"
  },
  {
    "centro": "CNV. LICEO DE ASERRÍ",
    "codPres": "6246",
    "codSaber": "104861-00"
  },
  {
    "centro": "CNV. LICEO SAN GABRIEL",
    "codPres": "6246",
    "codSaber": "104864-00"
  },
  {
    "centro": "CNV. LICEO SAN MIGUEL",
    "codPres": "6246",
    "codSaber": "104865-00"
  },
  {
    "centro": "CNV. LICEO DE POÁS",
    "codPres": "6249",
    "codSaber": "104875-00"
  },
  {
    "centro": "CNV. LICEO SAN RAFAEL",
    "codPres": "6249",
    "codSaber": "104877-00"
  },
  {
    "centro": "CNV. C.T.P. LA FORTUNA",
    "codPres": "6251",
    "codSaber": "104882-00"
  },
  {
    "centro": "CNV. C.T.P. NATANIEL ARIAS MURILLO",
    "codPres": "6251",
    "codSaber": "104883-00"
  },
  {
    "centro": "CONED NICOYA",
    "codPres": "6266",
    "codSaber": "104921-00"
  },
  {
    "centro": "LICEO RURAL LOS ALMENDROS",
    "codPres": "6267",
    "codSaber": "104922-00"
  },
  {
    "centro": "CINDEA LOS CHILES",
    "codPres": "6268",
    "codSaber": "105129-00"
  },
  {
    "centro": "CINDEA LOS CHILES-EL PARQUE",
    "codPres": "6268",
    "codSaber": "105129-01"
  },
  {
    "centro": "COLEGIO MATA DE PLÁTANO",
    "codPres": "6269",
    "codSaber": "104923-00"
  },
  {
    "centro": "EL LLANITO",
    "codPres": "6272",
    "codSaber": "104924-00"
  },
  {
    "centro": "LICEO RURAL CERROS",
    "codPres": "6273",
    "codSaber": "104925-00"
  },
  {
    "centro": "CONED CARTAGO",
    "codPres": "6274",
    "codSaber": "104926-00"
  },
  {
    "centro": "LA ILUSION DE CANTA GALLO",
    "codPres": "6277",
    "codSaber": "104928-00"
  },
  {
    "centro": "CEBROR",
    "codPres": "6279",
    "codSaber": "104929-00"
  },
  {
    "centro": "CERRO AZUL",
    "codPres": "6296",
    "codSaber": "104930-00"
  },
  {
    "centro": "SAN GERARDO",
    "codPres": "6297",
    "codSaber": "104931-00"
  },
  {
    "centro": "SKA DIKOL",
    "codPres": "6298",
    "codSaber": "104932-00"
  },
  {
    "centro": "I.D.A. EL VIVERO",
    "codPres": "6331",
    "codSaber": "104933-00"
  },
  {
    "centro": "ALTO PALMERA",
    "codPres": "6356",
    "codSaber": "104935-00"
  },
  {
    "centro": "C.T.P. VÁZQUEZ DE CORONADO",
    "codPres": "6358",
    "codSaber": "104937-00"
  },
  {
    "centro": "PALENQUE EL SOL",
    "codPres": "6360",
    "codSaber": "104938-00"
  },
  {
    "centro": "JÖNKRUHORÄ",
    "codPres": "6368",
    "codSaber": "104941-00"
  },
  {
    "centro": "LICEO TIERRA BLANCA",
    "codPres": "6372",
    "codSaber": "104942-00"
  },
  {
    "centro": "LAS BRISAS",
    "codPres": "6373",
    "codSaber": "104943-00"
  },
  {
    "centro": "BAKÖM DI",
    "codPres": "6374",
    "codSaber": "104944-00"
  },
  {
    "centro": "LICEO LOS ÁNGELES",
    "codPres": "6375",
    "codSaber": "104945-00"
  },
  {
    "centro": "LICEO SAN JOSÉ DEL RÍO",
    "codPres": "6376",
    "codSaber": "104946-00"
  },
  {
    "centro": "LICEO DE TOBOSI",
    "codPres": "6384",
    "codSaber": "104947-00"
  },
  {
    "centro": "LICEO SAN ANTONIO",
    "codPres": "6385",
    "codSaber": "104948-00"
  },
  {
    "centro": "CARTAGO",
    "codPres": "6386",
    "codSaber": "104949-00"
  },
  {
    "centro": "KUNABRI",
    "codPres": "6387",
    "codSaber": "104950-00"
  },
  {
    "centro": "ARROZ ITÄRÍ",
    "codPres": "6388",
    "codSaber": "104951-00"
  },
  {
    "centro": "BAJO COHEN",
    "codPres": "6389",
    "codSaber": "104952-00"
  },
  {
    "centro": "NIMARI",
    "codPres": "6390",
    "codSaber": "104953-00"
  },
  {
    "centro": "BAJO BLEY SUR",
    "codPres": "6391",
    "codSaber": "104954-00"
  },
  {
    "centro": "KUCHEY",
    "codPres": "6392",
    "codSaber": "104955-00"
  },
  {
    "centro": "LA SIBERIA",
    "codPres": "6393",
    "codSaber": "104956-00"
  },
  {
    "centro": "BISÖLA",
    "codPres": "6394",
    "codSaber": "104957-00"
  },
  {
    "centro": "JÄBËJUKTÖ",
    "codPres": "6395",
    "codSaber": "104958-00"
  },
  {
    "centro": "DÜCHIRIBATA",
    "codPres": "6396",
    "codSaber": "104959-00"
  },
  {
    "centro": "BLEITÖ",
    "codPres": "6397",
    "codSaber": "104960-00"
  },
  {
    "centro": "JÄKTÖKÖLO",
    "codPres": "6398",
    "codSaber": "104961-00"
  },
  {
    "centro": "KOWA",
    "codPres": "6399",
    "codSaber": "104962-00"
  },
  {
    "centro": "DUCHARI",
    "codPres": "6400",
    "codSaber": "104963-00"
  },
  {
    "centro": "TAMIJU",
    "codPres": "6401",
    "codSaber": "104964-00"
  },
  {
    "centro": "JUITÖ",
    "codPres": "6402",
    "codSaber": "104965-00"
  },
  {
    "centro": "KSARABATA",
    "codPres": "6403",
    "codSaber": "104966-00"
  },
  {
    "centro": "KONYÖÚ",
    "codPres": "6404",
    "codSaber": "104967-00"
  },
  {
    "centro": "AKÖM",
    "codPres": "6405",
    "codSaber": "104968-00"
  },
  {
    "centro": "LICEO RURAL SHIKABALI",
    "codPres": "6406",
    "codSaber": "104969-00"
  },
  {
    "centro": "LICEO RURAL KJAKUO SULO",
    "codPres": "6407",
    "codSaber": "104970-00"
  },
  {
    "centro": "COLEGIO INDÍGENA SHIROLES",
    "codPres": "6408",
    "codSaber": "104971-00"
  },
  {
    "centro": "LICEO RURAL SALITRE",
    "codPres": "6409",
    "codSaber": "104972-00"
  },
  {
    "centro": "CENTRO DE EDUCACIÓN ESPECIAL DE GUÁPILES",
    "codPres": "6411",
    "codSaber": "104973-00"
  },
  {
    "centro": "CONED PUNTARENAS",
    "codPres": "6424",
    "codSaber": "104974-00"
  },
  {
    "centro": "CONED ACOSTA",
    "codPres": "6427",
    "codSaber": "104975-00"
  },
  {
    "centro": "LICEO RURAL QUIRIMÁN",
    "codPres": "6429",
    "codSaber": "104976-00"
  },
  {
    "centro": "COLEGIO OMAR SALAZAR OBANDO",
    "codPres": "6456",
    "codSaber": "104977-00"
  },
  {
    "centro": "LICEO RURAL VILLA HERMOSA",
    "codPres": "6465",
    "codSaber": "104978-00"
  },
  {
    "centro": "NOCTURNO DE BAGACES",
    "codPres": "6475",
    "codSaber": "104979-00"
  },
  {
    "centro": "COLEGIO DE GUÁCIMO",
    "codPres": "6479",
    "codSaber": "104980-00"
  },
  {
    "centro": "LICEO RURAL ALTO COHEN",
    "codPres": "6480",
    "codSaber": "104981-00"
  },
  {
    "centro": "PALMITAS II",
    "codPres": "6493",
    "codSaber": "104982-00"
  },
  {
    "centro": "COLEGIO INDÍGENA YIMBA CAJC",
    "codPres": "6498",
    "codSaber": "104983-00"
  },
  {
    "centro": "CINDEA HEREDIANA",
    "codPres": "6499",
    "codSaber": "105130-00"
  },
  {
    "centro": "CINDEA HEREDIANA-CAIRO",
    "codPres": "6499",
    "codSaber": "105130-01"
  },
  {
    "centro": "CINDEA HEREDIANA-EL MILANO",
    "codPres": "6499",
    "codSaber": "105130-02"
  },
  {
    "centro": "CINDEA HEREDIANA-EL PEJE",
    "codPres": "6499",
    "codSaber": "105130-03"
  },
  {
    "centro": "CINDEA HEREDIANA-GERMANIA",
    "codPres": "6499",
    "codSaber": "105130-04"
  },
  {
    "centro": "COLEGIO DE PACUARE",
    "codPres": "6500",
    "codSaber": "104984-00"
  },
  {
    "centro": "COLEGIO FLORIDA",
    "codPres": "6501",
    "codSaber": "104985-00"
  },
  {
    "centro": "C.T.P. SANTO CRISTO DE ESQUIPULAS",
    "codPres": "6502",
    "codSaber": "104986-00"
  },
  {
    "centro": "C.T.P. DE DULCE NOMBRE",
    "codPres": "6503",
    "codSaber": "104987-00"
  },
  {
    "centro": "C.T.P. SAN PEDRO DE BARVA",
    "codPres": "6504",
    "codSaber": "104988-00"
  },
  {
    "centro": "C.T.P. DE PALMICHAL",
    "codPres": "6505",
    "codSaber": "104989-00"
  },
  {
    "centro": "C.T.P. DE BOLÍVAR",
    "codPres": "6506",
    "codSaber": "104990-00"
  },
  {
    "centro": "C.T.P. SABANILLA",
    "codPres": "6507",
    "codSaber": "104991-00"
  },
  {
    "centro": "C.T.P. SAN RAFAEL DE POÁS",
    "codPres": "6508",
    "codSaber": "104992-00"
  },
  {
    "centro": "CINDEA LA BOMBA",
    "codPres": "6511",
    "codSaber": "105131-00"
  },
  {
    "centro": "CINDEA LA BOMBA-BANANITO SUR",
    "codPres": "6511",
    "codSaber": "105131-01"
  },
  {
    "centro": "CINDEA LA BOMBA-LA GUARIA",
    "codPres": "6511",
    "codSaber": "105131-02"
  },
  {
    "centro": "CINDEA LA BOMBA-PENSHURT",
    "codPres": "6511",
    "codSaber": "105131-03"
  },
  {
    "centro": "CINDEA LA BOMBA-SAN CLEMENTE",
    "codPres": "6511",
    "codSaber": "105131-04"
  },
  {
    "centro": "LICEO SANTÍSIMA TRINIDAD",
    "codPres": "6512",
    "codSaber": "104993-00"
  },
  {
    "centro": "CINDEA CÓBANO",
    "codPres": "6513",
    "codSaber": "105132-00"
  },
  {
    "centro": "CINDEA DE PITAL",
    "codPres": "6515",
    "codSaber": "105133-00"
  },
  {
    "centro": "CINDEA PEJIBAYE",
    "codPres": "6516",
    "codSaber": "105134-00"
  },
  {
    "centro": "CINDEA MIRAMAR",
    "codPres": "6517",
    "codSaber": "105135-00"
  },
  {
    "centro": "CINDEA MIRAMAR-PITAHAYA",
    "codPres": "6517",
    "codSaber": "105135-01"
  },
  {
    "centro": "CINDEA MIRAMAR-SARDINAL",
    "codPres": "6517",
    "codSaber": "105135-02"
  },
  {
    "centro": "CINDEA PUNTARENAS",
    "codPres": "6518",
    "codSaber": "105136-00"
  },
  {
    "centro": "CINDEA PUNTARENAS-C.A.I. 26 DE JULIO",
    "codPres": "6518",
    "codSaber": "105136-01"
  },
  {
    "centro": "CINDEA JUDAS",
    "codPres": "6519",
    "codSaber": "105137-00"
  },
  {
    "centro": "CINDEA JUDAS-COSTA PÁJAROS",
    "codPres": "6519",
    "codSaber": "105137-02"
  },
  {
    "centro": "CINDEA ESPARZA",
    "codPres": "6520",
    "codSaber": "105138-00"
  },
  {
    "centro": "CINDEA ESPARZA-VILLA NUEVA",
    "codPres": "6520",
    "codSaber": "105138-01"
  },
  {
    "centro": "CINDEA FLORENCIA",
    "codPres": "6521",
    "codSaber": "105139-00"
  },
  {
    "centro": "CINDEA FLORENCIA-PLATANAR",
    "codPres": "6521",
    "codSaber": "105139-01"
  },
  {
    "centro": "CINDEA FLORENCIA-SANTA CLARA",
    "codPres": "6521",
    "codSaber": "105139-02"
  },
  {
    "centro": "CINDEA HUACAS",
    "codPres": "6522",
    "codSaber": "105140-00"
  },
  {
    "centro": "NOCTURNO DE JACÓ",
    "codPres": "6523",
    "codSaber": "104994-00"
  },
  {
    "centro": "C.T.P. SAN ISIDRO DE HEREDIA",
    "codPres": "6524",
    "codSaber": "104995-00"
  },
  {
    "centro": "C.T.P. SANTO DOMINGO",
    "codPres": "6525",
    "codSaber": "104996-00"
  },
  {
    "centro": "C.T.P. MERCEDES NORTE",
    "codPres": "6526",
    "codSaber": "104997-00"
  },
  {
    "centro": "C.T.P. MÁXIMO QUESADA",
    "codPres": "6527",
    "codSaber": "104998-00"
  },
  {
    "centro": "C.T.P. PURRAL",
    "codPres": "6528",
    "codSaber": "104999-00"
  },
  {
    "centro": "C.T.P. ABELARDO BONILLA BALDARES",
    "codPres": "6529",
    "codSaber": "105000-00"
  },
  {
    "centro": "C.T.P. PAVAS",
    "codPres": "6530",
    "codSaber": "105001-00"
  },
  {
    "centro": "C.T.P. DE ASERRÍ",
    "codPres": "6531",
    "codSaber": "105002-00"
  },
  {
    "centro": "C.T.P. AMBIENTALISTA ISAÍAS RETANA",
    "codPres": "6532",
    "codSaber": "105003-00"
  },
  {
    "centro": "C.T.P. OREAMUNO",
    "codPres": "6533",
    "codSaber": "105004-00"
  },
  {
    "centro": "C.T.P. SANTA LUCÍA",
    "codPres": "6534",
    "codSaber": "105005-00"
  },
  {
    "centro": "C.T.P. CALLE ZAMORA",
    "codPres": "6535",
    "codSaber": "105006-00"
  },
  {
    "centro": "C.T.P. ROSARIO DE NARANJO",
    "codPres": "6536",
    "codSaber": "105007-00"
  },
  {
    "centro": "C.T.P. SANTA EULALIA",
    "codPres": "6537",
    "codSaber": "105008-00"
  },
  {
    "centro": "C.T.P. DE CAÑAS",
    "codPres": "6538",
    "codSaber": "105009-00"
  },
  {
    "centro": "CINDEA LA PERLA",
    "codPres": "6539",
    "codSaber": "105141-00"
  },
  {
    "centro": "CINDEA SANTA ROSA",
    "codPres": "6541",
    "codSaber": "105142-00"
  },
  {
    "centro": "BLÚJURIÑAK",
    "codPres": "6543",
    "codSaber": "105010-00"
  },
  {
    "centro": "C.T.P. ATENAS",
    "codPres": "6547",
    "codSaber": "105011-00"
  },
  {
    "centro": "C.T.P. DE MORA",
    "codPres": "6548",
    "codSaber": "105012-00"
  },
  {
    "centro": "C.T.P. ZARCERO",
    "codPres": "6549",
    "codSaber": "105013-00"
  },
  {
    "centro": "C.T.P. ESPARZA",
    "codPres": "6550",
    "codSaber": "105014-00"
  },
  {
    "centro": "NOCTURNO DE AMUBRI",
    "codPres": "6551",
    "codSaber": "105015-00"
  },
  {
    "centro": "CINDEA GUATUSO",
    "codPres": "6552",
    "codSaber": "105143-00"
  },
  {
    "centro": "CINDEA GUATUSO-PALENQUE TONJIBE",
    "codPres": "6552",
    "codSaber": "105143-01"
  },
  {
    "centro": "LA FLORITA",
    "codPres": "6554",
    "codSaber": "105016-00"
  },
  {
    "centro": "JAPÓN",
    "codPres": "6555",
    "codSaber": "105017-00"
  },
  {
    "centro": "SANTA FÉ",
    "codPres": "6556",
    "codSaber": "105018-00"
  },
  {
    "centro": "ARCO IRIS",
    "codPres": "6557",
    "codSaber": "105019-00"
  },
  {
    "centro": "SAN JERÓNIMO",
    "codPres": "6558",
    "codSaber": "105020-00"
  },
  {
    "centro": "MÉLIDA GARCÍA FLORES",
    "codPres": "6559",
    "codSaber": "105021-00"
  },
  {
    "centro": "PROGRESO",
    "codPres": "6560",
    "codSaber": "105022-00"
  },
  {
    "centro": "TSINI KICHA",
    "codPres": "6561",
    "codSaber": "105023-00"
  },
  {
    "centro": "TOLOKSACO",
    "codPres": "6562",
    "codSaber": "105024-00"
  },
  {
    "centro": "PLAZA VIEJA",
    "codPres": "6563",
    "codSaber": "105025-00"
  },
  {
    "centro": "LICEO COPEY",
    "codPres": "6564",
    "codSaber": "105026-00"
  },
  {
    "centro": "COLEGIO EL AMPARO",
    "codPres": "6565",
    "codSaber": "105027-00"
  },
  {
    "centro": "CERRO ALEGRE",
    "codPres": "6566",
    "codSaber": "105028-00"
  },
  {
    "centro": "LICEO RURAL LA UNIÓN",
    "codPres": "6567",
    "codSaber": "105029-00"
  },
  {
    "centro": "LICEO RURAL RÍO GRANDE DE PAQUERA",
    "codPres": "6568",
    "codSaber": "105030-00"
  },
  {
    "centro": "LICEO RURAL ARANJUEZ",
    "codPres": "6569",
    "codSaber": "105031-00"
  },
  {
    "centro": "LICEO RURAL CHINA KICHA",
    "codPres": "6570",
    "codSaber": "105032-00"
  },
  {
    "centro": "LICEO RURAL EL PROGRESO",
    "codPres": "6571",
    "codSaber": "105033-00"
  },
  {
    "centro": "CINDEA SAN ISIDRO",
    "codPres": "6572",
    "codSaber": "105144-00"
  },
  {
    "centro": "CINDEA SAN ISIDRO-VALLE AZUL",
    "codPres": "6572",
    "codSaber": "105144-01"
  },
  {
    "centro": "CINDEA LA PAZ",
    "codPres": "6573",
    "codSaber": "105145-00"
  },
  {
    "centro": "CINDEA LA PAZ-VOLIO",
    "codPres": "6573",
    "codSaber": "105145-01"
  },
  {
    "centro": "CINDEA LA PAZ-ZARCERO",
    "codPres": "6573",
    "codSaber": "105145-02"
  },
  {
    "centro": "C.T.P. JOSÉ MARÍA ZELEDÓN BRENES",
    "codPres": "6574",
    "codSaber": "105034-00"
  },
  {
    "centro": "C.T.P. HENRI FRANÇOIS PITTIER",
    "codPres": "6576",
    "codSaber": "105035-00"
  },
  {
    "centro": "C.T.P. DE PLATANAR",
    "codPres": "6577",
    "codSaber": "105036-00"
  },
  {
    "centro": "C.T.P. BARRIO IRVIN",
    "codPres": "6578",
    "codSaber": "105037-00"
  },
  {
    "centro": "C.T.P. DE LIVERPOOL",
    "codPres": "6579",
    "codSaber": "105038-00"
  },
  {
    "centro": "C.T.P. AGROPORTICA",
    "codPres": "6580",
    "codSaber": "105039-00"
  },
  {
    "centro": "C.T.P. OROSI",
    "codPres": "6581",
    "codSaber": "105040-00"
  },
  {
    "centro": "C.T.P. ROBERTO GAMBOA VALVERDE",
    "codPres": "6582",
    "codSaber": "105041-00"
  },
  {
    "centro": "C.T.P. BRAULIO ODIO HERRERA",
    "codPres": "6583",
    "codSaber": "105042-00"
  },
  {
    "centro": "C.T.P. LAS PALMITAS",
    "codPres": "6584",
    "codSaber": "105043-00"
  },
  {
    "centro": "CINDEA RÍO JIMÉNEZ",
    "codPres": "6585",
    "codSaber": "105146-00"
  },
  {
    "centro": "CINDEA RÍO JIMÉNEZ-LOS ÁNGELES",
    "codPres": "6585",
    "codSaber": "105146-01"
  },
  {
    "centro": "CINDEA RÍO JIMÉNEZ-SANTA MARÍA",
    "codPres": "6585",
    "codSaber": "105146-02"
  },
  {
    "centro": "CINDEA LA RITA",
    "codPres": "6586",
    "codSaber": "105147-00"
  },
  {
    "centro": "CINDEA LA RITA-HUETAR",
    "codPres": "6586",
    "codSaber": "105147-02"
  },
  {
    "centro": "CINDEA LA RITA-LA TERESA",
    "codPres": "6586",
    "codSaber": "105147-03"
  },
  {
    "centro": "CINDEA LA RITA-TICABÁN",
    "codPres": "6586",
    "codSaber": "105147-04"
  },
  {
    "centro": "CINDEA NANDAYURE",
    "codPres": "6587",
    "codSaber": "105148-00"
  },
  {
    "centro": "LICEO RURAL SIKRIYöK",
    "codPres": "6624",
    "codSaber": "105044-00"
  },
  {
    "centro": "LICEO RURAL JAK KSARI",
    "codPres": "6625",
    "codSaber": "105045-00"
  },
  {
    "centro": "CINDEA SAN PABLO",
    "codPres": "6626",
    "codSaber": "105149-00"
  },
  {
    "centro": "CINDEA SAN JOAQUÍN",
    "codPres": "6627",
    "codSaber": "105150-00"
  },
  {
    "centro": "CINDEA SAN JOAQUÍN-COPAL",
    "codPres": "6627",
    "codSaber": "105150-01"
  },
  {
    "centro": "CINDEA PUERTO JIMÉNEZ",
    "codPres": "6628",
    "codSaber": "105151-00"
  },
  {
    "centro": "CINDEA SAN VITO",
    "codPres": "6629",
    "codSaber": "105152-00"
  },
  {
    "centro": "CINDEA SAN VITO-EL ROBLE",
    "codPres": "6629",
    "codSaber": "105152-02"
  },
  {
    "centro": "CINDEA SAN VITO-ENCUENTRO",
    "codPres": "6629",
    "codSaber": "105152-03"
  },
  {
    "centro": "CINDEA SAN VITO-FILA MÉNDEZ",
    "codPres": "6629",
    "codSaber": "105152-04"
  },
  {
    "centro": "CINDEA SAN VITO-LA CASONA",
    "codPres": "6629",
    "codSaber": "105152-05"
  },
  {
    "centro": "C.T.P. DE BELÉN",
    "codPres": "6633",
    "codSaber": "105048-00"
  },
  {
    "centro": "C.T.P. DE ALAJUELITA",
    "codPres": "6634",
    "codSaber": "105049-00"
  },
  {
    "centro": "C.T.P. DE SAN RAFAEL DE ALAJUELA",
    "codPres": "6635",
    "codSaber": "105050-00"
  },
  {
    "centro": "LICEO RURAL TSIRURURI",
    "codPres": "6636",
    "codSaber": "105051-00"
  },
  {
    "centro": "DABABLI",
    "codPres": "6637",
    "codSaber": "105052-00"
  },
  {
    "centro": "TIQUIRUZAS",
    "codPres": "6638",
    "codSaber": "105053-00"
  },
  {
    "centro": "C.T.P. DEL ESTE",
    "codPres": "6639",
    "codSaber": "105054-00"
  },
  {
    "centro": "C.T.P. DE COPAL",
    "codPres": "6640",
    "codSaber": "105055-00"
  },
  {
    "centro": "C.T.P. LA TIGRA",
    "codPres": "6641",
    "codSaber": "105056-00"
  },
  {
    "centro": "MOLLEJONES",
    "codPres": "6648",
    "codSaber": "105057-00"
  },
  {
    "centro": "ASENTAMIENTO EL GALLO",
    "codPres": "6651",
    "codSaber": "105058-00"
  },
  {
    "centro": "SANTA LUCÍA",
    "codPres": "6664",
    "codSaber": "105059-00"
  },
  {
    "centro": "PAVONES",
    "codPres": "6665",
    "codSaber": "105060-00"
  },
  {
    "centro": "COLEGIO SAN FRANCISCO DE LA PALMERA",
    "codPres": "6666",
    "codSaber": "105061-00"
  },
  {
    "centro": "LICEO RURAL PALACIOS",
    "codPres": "6667",
    "codSaber": "105062-00"
  },
  {
    "centro": "CINDEA PAVAS",
    "codPres": "6668",
    "codSaber": "105153-00"
  },
  {
    "centro": "CINDEA PAVAS-CIUDADELA DE PAVAS",
    "codPres": "6668",
    "codSaber": "105153-01"
  },
  {
    "centro": "CINDEA PAVAS-RINCÓN GRANDE",
    "codPres": "6668",
    "codSaber": "105153-02"
  },
  {
    "centro": "CINDEA ESCAZÚ",
    "codPres": "6669",
    "codSaber": "105154-00"
  },
  {
    "centro": "CINDEA ESCAZÚ-JUAN XXIII",
    "codPres": "6669",
    "codSaber": "105154-01"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO",
    "codPres": "6670",
    "codSaber": "105155-00"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO-C.A.I. CARLOS L. FALLAS",
    "codPres": "6670",
    "codSaber": "105155-02"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO-EL LIMBO",
    "codPres": "6670",
    "codSaber": "105155-01"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO-LLANO BONITO",
    "codPres": "6670",
    "codSaber": "105155-03"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO-PUEBLO NUEVO",
    "codPres": "6670",
    "codSaber": "105155-04"
  },
  {
    "centro": "CINDEA SAN ANTONIO DEL HUMO-ROXANA",
    "codPres": "6670",
    "codSaber": "105155-05"
  },
  {
    "centro": "CINDEA SAN MARTÍN",
    "codPres": "6671",
    "codSaber": "105156-00"
  },
  {
    "centro": "CINDEA SAN MARTÍN-BELLA VISTA",
    "codPres": "6671",
    "codSaber": "105156-01"
  },
  {
    "centro": "CINDEA SAN MARTÍN-CASCADAS",
    "codPres": "6671",
    "codSaber": "105156-02"
  },
  {
    "centro": "CINDEA SAN MARTÍN-LA UNIÓN",
    "codPres": "6671",
    "codSaber": "105156-03"
  },
  {
    "centro": "CINDEA PAQUERA",
    "codPres": "6672",
    "codSaber": "105157-00"
  },
  {
    "centro": "CINDEA SAN MIGUEL",
    "codPres": "6673",
    "codSaber": "105158-00"
  },
  {
    "centro": "CINDEA SURETKA",
    "codPres": "6674",
    "codSaber": "105159-00"
  },
  {
    "centro": "CINDEA SURETKA-CHINA KICHA",
    "codPres": "6674",
    "codSaber": "105159-01"
  },
  {
    "centro": "CINDEA SURETKA-KATSI",
    "codPres": "6674",
    "codSaber": "105159-02"
  },
  {
    "centro": "CINDEA REPÚBLICA DE NICARAGUA",
    "codPres": "6675",
    "codSaber": "105160-00"
  },
  {
    "centro": "COLEGIO DE LEPANTO",
    "codPres": "6676",
    "codSaber": "105063-00"
  },
  {
    "centro": "RÍO SAN CARLOS SECTOR ESTE",
    "codPres": "6688",
    "codSaber": "105064-00"
  },
  {
    "centro": "CAÑO DE MASAYA",
    "codPres": "6703",
    "codSaber": "105065-00"
  },
  {
    "centro": "LICEO NUEVO DE PURISCAL",
    "codPres": "6714",
    "codSaber": "105066-00"
  },
  {
    "centro": "LICEO DE GUARARÍ",
    "codPres": "6716",
    "codSaber": "105067-00"
  },
  {
    "centro": "COLEGIO DE SIQUIRRES",
    "codPres": "6717",
    "codSaber": "105068-00"
  },
  {
    "centro": "C.T.P. LA CARPIO",
    "codPres": "6718",
    "codSaber": "105069-00"
  },
  {
    "centro": "C.T.P. HATILLO",
    "codPres": "6719",
    "codSaber": "105070-00"
  },
  {
    "centro": "CINDEA CIUDAD CORTÉS",
    "codPres": "6720",
    "codSaber": "105161-00"
  },
  {
    "centro": "CINDEA CIUDAD CORTÉS-FINCA ALAJUELA",
    "codPres": "6720",
    "codSaber": "105161-01"
  },
  {
    "centro": "CINDEA CIUDAD CORTÉS-FINCA SEIS-ONCE",
    "codPres": "6720",
    "codSaber": "105161-02"
  },
  {
    "centro": "CINDEA KABAKOL",
    "codPres": "6721",
    "codSaber": "105162-00"
  },
  {
    "centro": "CINDEA KABAKOL-BIJAGUAL",
    "codPres": "6721",
    "codSaber": "105162-01"
  },
  {
    "centro": "CINDEA KABAKOL-SAN ANTONIO",
    "codPres": "6721",
    "codSaber": "105162-02"
  },
  {
    "centro": "CINDEA BUENOS AIRES",
    "codPres": "6722",
    "codSaber": "105163-00"
  },
  {
    "centro": "CINDEA BUENOS AIRES-BIOLLEY",
    "codPres": "6722",
    "codSaber": "105163-01"
  },
  {
    "centro": "CINDEA BUENOS AIRES-MAÍZ DE LOS UVA",
    "codPres": "6722",
    "codSaber": "105163-04"
  },
  {
    "centro": "CINDEA BUENOS AIRES-POTRERO GRANDE",
    "codPres": "6722",
    "codSaber": "105163-05"
  },
  {
    "centro": "CINDEA BUENOS AIRES-VOLCÁN",
    "codPres": "6722",
    "codSaber": "105163-03"
  },
  {
    "centro": "CINDEA MONTERREY",
    "codPres": "6723",
    "codSaber": "105164-00"
  },
  {
    "centro": "CINDEA PAVÓN",
    "codPres": "6724",
    "codSaber": "105165-00"
  },
  {
    "centro": "CINDEA SARDINAL",
    "codPres": "6725",
    "codSaber": "105166-00"
  },
  {
    "centro": "CINDEA SARDINAL-EL COCO",
    "codPres": "6725",
    "codSaber": "105166-01"
  },
  {
    "centro": "CINDEA BELÉN CARRILLO",
    "codPres": "6726",
    "codSaber": "105167-00"
  },
  {
    "centro": "CINDEA BEBEDERO",
    "codPres": "6727",
    "codSaber": "105168-00"
  },
  {
    "centro": "CINDEA TILARÁN",
    "codPres": "6728",
    "codSaber": "105169-00"
  },
  {
    "centro": "CINDEA TILARÁN-NUEVO ARENAL",
    "codPres": "6728",
    "codSaber": "105169-01"
  },
  {
    "centro": "CINDEA LA PALMA",
    "codPres": "6729",
    "codSaber": "105170-00"
  },
  {
    "centro": "CINDEA LA PALMA-COLORADO",
    "codPres": "6729",
    "codSaber": "105170-01"
  },
  {
    "centro": "CINDEA LA PALMA-SAN BUENAVENTURA",
    "codPres": "6729",
    "codSaber": "105170-02"
  },
  {
    "centro": "CINDEA DR. CLODOMIRO PICADO TWIGHT",
    "codPres": "6730",
    "codSaber": "105171-00"
  },
  {
    "centro": "CINDEA DR. CLODOMIRO PICADO TWIGHT-JABILLOS",
    "codPres": "6730",
    "codSaber": "105171-03"
  },
  {
    "centro": "CINDEA DR. CLODOMIRO PICADO TWIGHT-SAN JUAN NORTE",
    "codPres": "6730",
    "codSaber": "105171-01"
  },
  {
    "centro": "CINDEA DR. CLODOMIRO PICADO TWIGHT-SANTA CRUZ",
    "codPres": "6730",
    "codSaber": "105171-02"
  },
  {
    "centro": "CINDEA TAYUTIC",
    "codPres": "6731",
    "codSaber": "105172-00"
  },
  {
    "centro": "CINDEA TAYUTIC-CANADÁ",
    "codPres": "6731",
    "codSaber": "105172-01"
  },
  {
    "centro": "CINDEA TAYUTIC-GRANO DE ORO",
    "codPres": "6731",
    "codSaber": "105172-03"
  },
  {
    "centro": "CINDEA TAYUTIC-SAN FRANCISCO DE TUIS",
    "codPres": "6731",
    "codSaber": "105172-02"
  },
  {
    "centro": "CINDEA PEJIBAYE",
    "codPres": "6732",
    "codSaber": "105173-00"
  },
  {
    "centro": "CINDEA PEJIBAYE- TUCURRIQUE",
    "codPres": "6732",
    "codSaber": "105173-02"
  },
  {
    "centro": "CINDEA PEJIBAYE-JUAN VIÑAS",
    "codPres": "6732",
    "codSaber": "105173-01"
  },
  {
    "centro": "CINDEA SAN JOSÉ DE UPALA",
    "codPres": "6733",
    "codSaber": "105174-00"
  },
  {
    "centro": "CINDEA AGUAS CLARAS",
    "codPres": "6734",
    "codSaber": "105175-00"
  },
  {
    "centro": "CINDEA BRASILIA",
    "codPres": "6735",
    "codSaber": "105176-00"
  },
  {
    "centro": "CINDEA BIJAGUA",
    "codPres": "6736",
    "codSaber": "105177-00"
  },
  {
    "centro": "CINDEA BIJAGUA-CANALETE",
    "codPres": "6736",
    "codSaber": "105177-01"
  },
  {
    "centro": "CINDEA KATIRA",
    "codPres": "6737",
    "codSaber": "105178-00"
  },
  {
    "centro": "CINDEA KATIRA-EL CRUCE",
    "codPres": "6737",
    "codSaber": "105178-01"
  },
  {
    "centro": "CINDEA KATIRA-LA UNIÓN",
    "codPres": "6737",
    "codSaber": "105178-02"
  },
  {
    "centro": "CINDEA KATIRA-LLANO BONITO",
    "codPres": "6737",
    "codSaber": "105178-03"
  },
  {
    "centro": "CINDEA MONTES DE OCA",
    "codPres": "6741",
    "codSaber": "105179-00"
  },
  {
    "centro": "LICEO DE SANTIAGO",
    "codPres": "6742",
    "codSaber": "105071-00"
  },
  {
    "centro": "LOMA LINDA",
    "codPres": "6743",
    "codSaber": "105072-00"
  },
  {
    "centro": "LICEO RURAL VARA BLANCA",
    "codPres": "6752",
    "codSaber": "105073-00"
  },
  {
    "centro": "COLEGIO DIURNO LA CRUZ",
    "codPres": "6796",
    "codSaber": "105078-00"
  },
  {
    "centro": "CINDEA CORONADO",
    "codPres": "6797",
    "codSaber": "105180-00"
  },
  {
    "centro": "CINDEA MORAVIA",
    "codPres": "6798",
    "codSaber": "105181-00"
  },
  {
    "centro": "CINDEA HOJANCHA",
    "codPres": "6799",
    "codSaber": "105182-00"
  },
  {
    "centro": "CINDEA NOSARA",
    "codPres": "6800",
    "codSaber": "105183-00"
  },
  {
    "centro": "CINDEA SÁMARA",
    "codPres": "6801",
    "codSaber": "105184-00"
  },
  {
    "centro": "CNV. LICEO JULIO FONSECA GUTIÉRREZ",
    "codPres": "6802",
    "codSaber": "105081-00"
  },
  {
    "centro": "CINDEA NAKELKäLä",
    "codPres": "6831",
    "codSaber": "105185-00"
  },
  {
    "centro": "CINDEA ALAJUELITA",
    "codPres": "6832",
    "codSaber": "105186-00"
  },
  {
    "centro": "CINDEA EL COCAL",
    "codPres": "6833",
    "codSaber": "105187-00"
  },
  {
    "centro": "LICEO RURAL ULUK KICHA",
    "codPres": "6842",
    "codSaber": "105087-00"
  },
  {
    "centro": "CINDEA BOCA DE ARENAL",
    "codPres": "6843",
    "codSaber": "105188-00"
  },
  {
    "centro": "CINDEA KEKÖLDI",
    "codPres": "6844",
    "codSaber": "105189-00"
  },
  {
    "centro": "CINDEA SEPECUE",
    "codPres": "6845",
    "codSaber": "105190-00"
  },
  {
    "centro": "CINDEA MONTEVERDE",
    "codPres": "6846",
    "codSaber": "105191-00"
  },
  {
    "centro": "CINDEA VALVERDE VEGA",
    "codPres": "6847",
    "codSaber": "105192-00"
  },
  {
    "centro": "CHIGO",
    "codPres": "6848",
    "codSaber": "105088-00"
  },
  {
    "centro": "J.N. CENTRAL DE ALAJUELITA",
    "codPres": "6871",
    "codSaber": "105089-00"
  },
  {
    "centro": "CONED QUEPOS",
    "codPres": "6872",
    "codSaber": "105243-00"
  },
  {
    "centro": "JU KRIBÄTÄ",
    "codPres": "6877",
    "codSaber": "105090-00"
  },
  {
    "centro": "DUASKLÖ",
    "codPres": "6878",
    "codSaber": "105091-00"
  },
  {
    "centro": "CINDEA KA BATA SIWA",
    "codPres": "6946",
    "codSaber": "105193-00"
  },
  {
    "centro": "LICEO TAMBOR DE CÓBANO",
    "codPres": "6959",
    "codSaber": "105198-00"
  },
  {
    "centro": "LICEO RURAL NAIRI AWARI",
    "codPres": "6987",
    "codSaber": "105242-00"
  },
  {
    "centro": "TSIRIKBATA",
    "codPres": "6996",
    "codSaber": "105407-00"
  },
  {
    "centro": "SURUY",
    "codPres": "6997",
    "codSaber": "105406-00"
  },
  {
    "centro": "BITARKALA",
    "codPres": "6998",
    "codSaber": "105405-00"
  },
  {
    "centro": "CONED PURISCAL",
    "codPres": "7018",
    "codSaber": "105435-00"
  },
  {
    "centro": "CONED ALAJUELA",
    "codPres": "7019",
    "codSaber": "105436-00"
  },
  {
    "centro": "CONED ATENAS",
    "codPres": "7024",
    "codSaber": "105514-00"
  },
  {
    "centro": "C.T.P. ING. CARLOS PASCUA ZÚÑIGA",
    "codPres": "7025",
    "codSaber": "105517-00"
  },
  {
    "centro": "C.T.P. GUARARÍ",
    "codPres": "7026",
    "codSaber": "105518-00"
  },
  {
    "centro": "COLEGIO NOCTURNO DE TARRAZÚ",
    "codPres": "7027",
    "codSaber": "105515-00"
  },
  {
    "centro": "CINDEA ASERRÍ",
    "codPres": "7029",
    "codSaber": "105516-00"
  },
  {
    "centro": "CINDEA ASERRÍ-SAN GABRIEL",
    "codPres": "7029",
    "codSaber": "105516-01"
  },
  {
    "centro": "NIMARI",
    "codPres": "7033",
    "codSaber": "105529-00"
  },
  {
    "centro": "CONED ESCAZÚ",
    "codPres": "7040",
    "codSaber": "105542-00"
  }
]);
// PIA_INSTITUTIONAL_CENTERS_JS_END
