// PIA_CURRICULAR_PROGRESSION_DATA_START
// Catálogo relacional de solo lectura. No modifica PNFT_DATA, RDA_POR_CICLO ni indicadores oficiales.
const PIACurricularProgressionData = Object.freeze({
  "catalogVersion": "1.1.0",
  "levelOrder": [
    "0°",
    "1°",
    "2°",
    "3°",
    "4°",
    "5°",
    "6°",
    "7°",
    "8°",
    "9°"
  ],
  "states": {
    "explicit-evaluable": "Desarrollo explícito con alcance curricular e indicador correspondiente.",
    "conceptual-non-evaluable": "Presencia conceptual sin indicador directo, respaldada expresamente por una fuente curricular.",
    "reinforced-non-evaluable": "Fortalecimiento sin evaluación directa, respaldado expresamente por una fuente curricular.",
    "no-curricular-record": "La matriz no registra abordaje conceptual para el nivel; no permite inferir enseñanza, refuerzo ni dominio.",
    "not-applicable": "El saber no corresponde al nivel."
  },
  "source": {
    "file": "Saberes  por Año Escolar julio -2026(2).xlsx",
    "sha256": "8889390a01bd93b3478441da2ff7cc5a73c5ee53a67e66bc310c2229105672c8",
    "role": "Matriz validada de saberes por año escolar"
  },
  "indicatorProgressionExample": {
    "file": "Ejemplo de escalabilidad de los indicadores (1) 1(2).xlsx",
    "sha256": "ae7c3a8dbf073a571497182036759cec8b9c12644d9a43d49ddb2cf848e1bd71",
    "role": "Ejemplo asesor de lectura horizontal y vertical; no sustituye el currículo oficial.",
    "familyIds": [
      "programming.environments",
      "programming.algorithms",
      "programming.data-structures",
      "digital.productivity",
      "digital.internet",
      "data.ai"
    ],
    "dimensions": [
      "verbo o demanda cognitiva",
      "saber conceptual",
      "alcance esperado",
      "representación",
      "contexto y autonomía"
    ]
  },
  "families": [
    {
      "id": "programming.environments",
      "area": "Programación y Algoritmos",
      "label": "Entornos de programación",
      "generalKnowledge": "Entornos de programación iconográfico.\n\nEntornos de programación por bloques.\n\nEntorno de programación textual.",
      "sourceRow": 6,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Entornos de programación iconográfico:\n-Navegación en la interfaz:\n-- Desplazamiento.\n-- Orientación.\n-- Apariencia.\n-- Evento.\n-- Sonido\n-- Control."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Entornos de programación iconográfico:\n-Navegación en la interfaz:\n-- Desplazamiento.\n-- Orientación.\n-- Apariencia.\n-- Evento.\n-- Sonido\n-- Control."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Entorno de programación por bloques:\n- Exploración de la interfaz:\n-- Área de bloques."
        },
        "3°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Entorno de programación por bloques:\n- Exploración de la interfaz:\n-- Área de bloques."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Entorno de programación por bloques para computación física:\n- Exploración de la interfaz:\n-- Área de bloques."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "-Entorno de programación textual o bloques."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "- Entorno de programación textual o bloques para programar mecanismos robóticos."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "- Entorno de programación textual o bloques para programar mecanismos robóticos."
        }
      }
    },
    {
      "id": "programming.logic",
      "area": "Programación y Algoritmos",
      "label": "Introducción a la lógica",
      "generalKnowledge": "Lateralidad y orientación espacial.\n\nEstado.\n\nReconocimiento de patrones.\n\nLógica de programación (tablas de verdad).",
      "sourceRow": 8,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Lateralidad y orientación espacial.\n\nEstado:\n- Orientación.\n- Dirección.\n- Tamaño de objetos."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Reconocimiento de patrones.\n\nEstado:\n- Orientación.\n- Dirección.\n- Tamaño de objetos."
        },
        "2°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "3°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Estado."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Lógica de programación:\n-Las proposiciones (verdadero/falso)."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Lógica de programación (tablas de verdad):\n-Conjunción (Y)\n-Disyunción (O)"
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Lógica de programación:\n -Proposiciones y conectores lógicos (AND, OR, NOT).\n -Tablas de verdad y evaluación de expresiones lógicas."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "programming.algorithms",
      "area": "Programación y Algoritmos",
      "label": "Algoritmos",
      "generalKnowledge": "Algoritmo",
      "sourceRow": 9,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n-  Secuencias lógicas y ordenadas."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n-Secuencias lógicas y ordenadas."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n- Lenguaje natural."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n-Estructura\n-Caracteristicas"
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n- Pseudocódigo"
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n- Diagrama de flujo"
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n -Estructura: Entrada, proceso, salida.\n -Características: Preciso, finito, definido.\n -Representación."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Algoritmo:\n-Representación: Pseudocódigo / Diagrama de flujo."
        }
      }
    },
    {
      "id": "programming.data-structures",
      "area": "Programación y Algoritmos",
      "label": "Estructura de datos",
      "generalKnowledge": "Dato.\n\nVariable.\n\nColección de datos.\n\nGestión de datos.",
      "sourceRow": 10,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n -Contexto físico\n -Contexto digital"
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n - Contexto físico.\n - Contexto digital."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n-Datos tipo numéricos.\n-Datos tipo texto.\n\nVariable"
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Variable:\n-Gestión de variables."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Dato.\n-Datos tipo numéricos.\n-Datos tipo texto.\n\nVariable:\n-Gestión de variables."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n-Dato tipo booleano.\n\nVariable:\n-Gestión de variables.\n\n Colección de datos:\n -Gestión de colección de datos."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n -Tipos de datos\n -Almacenamiento.\n\nVariable:\n  -Tipos de variables.\n -Gestión de variables."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Colección de datos:\n -Gestión de colección de dato"
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "programming.control-structures",
      "area": "Programación y Algoritmos",
      "label": "Estructuras de control",
      "generalKnowledge": "Estructuras condicionales\n\nEstructuras repetitivas\n\nControl de flujo",
      "sourceRow": 11,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras repetitivas:\n-Ciclo finito\n-Ciclo infinito."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras repetitivas:\n-Ciclo finito\n-Ciclo infinito."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras repetitivas:\n-Estructura.\n-Diferencia ciclo finito e ciclo infinito.\n\n\nEstructuras condicionales:\n-Condicionales simples."
        },
        "3°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras repetitivas\n\n\nEstructuras  condicionales:\n-Condicionales simples\n-Condicionales compuestas"
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras  condicionales:\n-Condicionales múltiples"
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Estructuras condicionales\n\n\nEstructuras repetitivas"
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "programming.operators",
      "area": "Programación y Algoritmos",
      "label": "Operadores",
      "generalKnowledge": "Operadores aritméticos.\n\nOperadores relacionales.\n\nOperadores lógicos.\n\nOperadores en expresiones.",
      "sourceRow": 12,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Operadores aritméticos:\n- Suma.\n- Resta.\n\nOperador relacional:\n -Igual que (=)."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Operadores aritméticos:\n   - Multiplicación.\n   - División.\n\nOperadores relacionales:\n  - < Menor que.\n  - > Mayor que.\n  - = Igual que."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Operadores aritméticos:\n -Suma (+).\n -Resta (-).\n -Multiplicación (x).\n -División (/).\n\nOperadores relacionales:\n  - < Menor que.\n  - > Mayor que.\n  - = Igual que."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Operadores lógicos:\n- Conjunción (Y).\n- Disyunción (O)."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Operadores aritméticos.\n -Suma (+).\n -Resta (-).\n -Multiplicación (x).\n -División (/).\n\nOperadores relacionales:\n- Menor que (<).\n- Mayor que (>).\n- Menor o igual que (<=).\n- Mayor o igual que (>=).\n- Diferente de (!=).\n- Igual que (=).\n\nOperadores lógicos:\n- Conjunción (Y).\n- Disyunción (O).\n- Negación (NO)."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "programming.events-functions",
      "area": "Programación y Algoritmos",
      "label": "Eventos, Procedimientos y funciones.",
      "generalKnowledge": "Evento.\n\nProcedimientos.\n\nFunciones.\n\nModularidad y organización del código.\n\nEstructuración y reutilización del código.",
      "sourceRow": 13,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Evento:\n-Causa y efecto."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Evento:\n - Causa y efecto."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Evento:\n- Aplicado en un entorno de programación."
        },
        "3°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Eventos:\n- Acciones que se detonan (causa y efecto)."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Procedimientos / funciones:\n -Declaración\n -Invocación\n -Parámetros\n -Argumentos"
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Procedimientos / funciones:\n -Declaración\n -Invocación\n -Parámetros\n -Argumentos"
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Evento.\n\nProcedimientos y/o funciones:\n -Declaración\n -Invocación\n -Parámetros\n -Argumentos"
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.fundamentals",
      "area": "Apropiación tecnológica y Digital",
      "label": "Conceptos básicos de hardware y software",
      "generalKnowledge": "Computadora.\n\nHardware.\n\nSoftware.\n\nFuncionamiento de sistemas computacionales.",
      "sourceRow": 16,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Computadora:\n- ¿Qué es y qué no es?\n\nHardware:\nDispositivos de entrada de datos:\n-Mouse\n-Teclado\n-Micrófono\n-Cámara\nDispositivos de salida de datos:\n-Pantalla\n\nSoftware\n-Elementos visuales (iconos, minimizar, maximizar y Cerrar, barra de tareas y área de trabajo)."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Computadora:\n- Características.\n- Importancia.\n- Función.\n\nHardware:\n-Dispositivos de entrada de datos (ratón, teclado, micrófono y cámara).\n-Dispositivos de salida de datos ( pantalla, impresora y parlantes ).\n-Encendido y apagado.\n\nSoftware\n-Interfaz de usuario ( iconos, minimizar, maximizar y Cerrar, barra de tareas y área de trabajo)"
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n-Funcionamiento\n- Cuidados del hardware\n\nSoftware (programas):\n-Funcionamiento"
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n-Funciones básicas de dispositivos computacionales ( Entrada, procesamiento, almacenamiento y salida)."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n-Componentes internos y su función ( memoria RAM, tarjeta madre, tarjeta de red, disco duro, tarjeta de video/sonido/comunicación y microprocesador).\n\nSoftware:\n-Tipos"
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n-Dispositivos de entrada y salida mixtos ( Impresora multifuncional y pantallas interactivas).\n- Aplicaciones de computación embebida.\n\nSoftware:\n-Funcionalidad de las diferentes herramientas de ofimática."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n-Componentes internos y su función ( memoria RAM, tarjeta madre, tarjeta de red, disco duro, tarjeta de video/sonido/comunicación y microprocesador)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Computadora:\n-Reglas básicas y responsabilidades del uso de computadoras.\n\nHardware:\n-Tipos de computadoras.\n-Componentes (entrada, procesamiento, almacenamiento y salida).\n- Periféricos.\n\nSoftware:\n-Tipos de software."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Hardware:\n -Componentes internos.\n\n\nSoftware:\n-Tipos de software."
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.connections",
      "area": "Apropiación tecnológica y Digital",
      "label": "Conexión y comunicación entre dispositivos",
      "generalKnowledge": "Redes de comunicación.\n\nConexión entre dispositivos.\n\n\nTecnologías de comunicación entre dispositivos.\n\nComunicación entre dispositivos y redes.",
      "sourceRow": 17,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Conexión entre dispositivos:\n- Bluetooth\n- Wifi"
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Conexión entre dispositivos:\n- Bluetooth."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Conexión entre dispositivos:\n- Wifi."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Redes de comunicación:\n- Red local (funcionalidad, aplicación)."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Redes de comunicación:\n- Red local (funcionalidad, aplicación).\n\nConexión entre dispositivos:\n-Inalámbrica.\n-Física."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Conexión entre dispositivos\n- Proceso de comunicación entre dispositivos (tipos).\n- Transmisión de archivos entre dispositivos."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Conexión entre dispositivos\n-Direcciones IP.\n\n\nRedes de comunicación:\n-Red fija telefónica\n-Red móvil\n-Red de televisión por cable\n-Red satelital\n- Beneficios y desafíos  del uso de las redes."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Redes de comunicación:\n- Tipos de redes.\n- Dispositivos (módem, router y puntos de acceso.)\n- Funcionamiento y principios de comunicación."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Redes de comunicación:\n-Unidades de almacenamiento en red.\n\nConexión entre dispositivos:\n-Comunicación física.\n-Comunicación inalámbrica."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "-Redes de comunicación:\n -Arquitectura de red.\n -Protocolos de comunicación.\n -Las interfaces de comunicaciones."
        }
      }
    },
    {
      "id": "digital.operating-systems",
      "area": "Apropiación tecnológica y Digital",
      "label": "Sistemas Operativos",
      "generalKnowledge": "Gestión de archivos.\n\n\nSitema operativo.\n\n\nSistemas operativos y gestión de recursos.",
      "sourceRow": 18,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Gestión de archivos:\n- Carpetas, subcarpetas y su función.\n- Exploración de archivos y  organización de información."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Gestión de archivos.\n-Organización y manipulación de archivos y carpetas."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Sistema Operativo:\n-Funcionalidad del escritorio vs otras rutas de acceso.\n-Barra de tareas ( altavoces, auriculares, estado de la batería y audio)."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Gestión de archivos:\n-Propiedades (tamaño, tipo y extensión)\n-Compresión y  descompresión de archivos.\n\nSistema Operativo:\n-Optimización de rendimiento:\n-- Gestión memoria.\n-- Caché y temporales.\n-- Administrador de tareas."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Sistema operativo:\n-Categorías (escritorio y dispositivos móviles).\n-Papelera.\n\nGestión de archivos:\n-Propiedades (tamaño, tipo, extensión)."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Sistema Operativo:\n-Licenciamiento (software libre vs propietario).\n-Optimización de rendimiento.\n\nGestión de archivos:\n-Compresión y  descompresión de archivos."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Sistema Operativo:\n-Optimización de rendimiento:\n-- Gestión memoria.\n-- Desfragmentación del disco.\n-- Caché y temporales.\n-- Actualización del sistema operativo."
        }
      }
    },
    {
      "id": "digital.productivity",
      "area": "Apropiación tecnológica y Digital",
      "label": "Herramientas de productividad",
      "generalKnowledge": "Herramienta de productividad\n\n\nGestión de información y productividad digital.",
      "sourceRow": 20,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Procesador de texto (cinta de opciones, pestañas, comandos básicos y sus funciones por teclado)."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Editor de presentaciones (cinta de opciones, pestañas, comandos básicos y sus funciones por teclado)."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Procesador de texto.\n- Editor de presentaciones."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n-Hoja de cálculo."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Ofimática local o en línea."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Procesador de texto.\n- Editor de presentaciones."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n-Hoja de cálculo."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Herramienta de productividad:\n- Gestor de bases de datos (tablas, relaciones y consultas)."
        }
      }
    },
    {
      "id": "digital.multimedia",
      "area": "Apropiación tecnológica y Digital",
      "label": "Creación y edición de audio, imagen y videos",
      "generalKnowledge": "Herramientas de creación de contenido multimedia.\n\nContenido multimedia con criterios de diseño.\n\nEstrategias de comunicación mediante contenidos multimedia.",
      "sourceRow": 21,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Editor gráfico.\n- Grabadora de audio.\n- Video."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Creación de audio (inclusión en productos digitales).\n- uso de imagen (incorporación de imágenes en productos digitales)."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Grabadora de audio y editores de gráficos (funciones básicas, creación, edición, guardado)."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Videos (funciones básicas, creación, edición, guardado)."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Editor gráfico (creación, edición, guardado)."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Audio (creación, edición, guardado).\n- Video (creación, edición, guardado)."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Creación y/o edición con herramientas disponibles (imagen, audio, video)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Editor de gráficos (principios básicos de diseño formato en relación con la calidad)."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Edición de audio (formato en relación con la calidad).\n- Edición de video (principios básicos de diseño, técnicas de edición, formato en relación con la calidad)."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas de creación de contenido multimedia:\n- Modelado 3D (creación, edición, formato en relación con el uso)."
        }
      }
    },
    {
      "id": "digital.internet",
      "area": "Apropiación tecnológica y Digital",
      "label": "Internet",
      "generalKnowledge": "Internet.\n\nNavegador.\n\nBuscador.\n\nPlataformas de creación de contenido.\n\nGestión de información en Internet",
      "sourceRow": 22,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Internet:\n-Requerimientos para conexión a internet (hardware, software)."
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Internet:\n-Requerimientos para conexión a internet (hardware, software)."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Internet:\n- Exploración dirigida en sitios web educativos confiables."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Navegador:\n-Partes del navegador\n- Uso (Que se puede hacer en este)\n\nBuscador:\n- Sitios confiables y no confiables.\n- Búsquedas  dirigidas en un buscador infantil."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Navegador:\n- Diferentes navegadores Web.\n\nBuscador:\n- Diferentes buscadores.\n\nInternet:\n- Dispositivos que se conectan a internet."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Buscador:\n- Uso.\n- Búsquedas eficientes en internet ( filtros, comillas)\n- Criterios para sitios web confiables\n- Tipos de dominios (.edu, .go, .com)."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Internet:\n-Funcionamiento (Conectividad y proveedores)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Internet:\n- Funcionamiento (Conectividad y proveedores).\n\n\nNavegador.\n\nBuscador."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Buscador:\n- Fuentes confiables.\n\n\nPlataformas de creación de contenido:\n-Infografías.\n-Diagramas.\n-Presentaciones."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Plataformas de creación de contenido:\n-Encuestas\n-Formularios"
        }
      }
    },
    {
      "id": "digital.collaboration",
      "area": "Apropiación tecnológica y Digital",
      "label": "Ciudadanía digital colaborativa",
      "generalKnowledge": "Netiqueta.\n\nComunicación y colaboración sincrónica y asincrónica.\n\nAlmacenamiento en la nube.\n\nComunicación y colaboración en entornos digitales.",
      "sourceRow": 23,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Netiqueta:\n - Procesos de comunicación.\n\n\nComunicación y colaboración sincrónica y asincrónica:\n - Correo electrónico ( uso  y características)."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Netiqueta:\n- Procesos de comunicación.\n\nComunicación y colaboración sincrónica y asincrónica:\n- Chats"
        },
        "5°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Comunicación y colaboración sincrónica y asincrónica:\n- Creación de documentos\n- Creación carpetas\n-Gestión de correo electrónico (envío, recepción, adjuntos).\n\nAlmacenamiento en la nube:\n- Creación de archivos compartidos"
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Netiqueta.\n\nComunicación y colaboración sincrónica/asincrónica:\n\n-Gestión de correo electrónico (envío, recepción, adjuntos, estructura de mensaje y spam).\n-Chats,  videollamadas y reuniones.\n\nAlmacenamiento en la nube."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.intellectual-property",
      "area": "Apropiación tecnológica y Digital",
      "label": "Propiedad intelectual",
      "generalKnowledge": "Derechos de autor.\n\nReferencias bibliograficas.\n\nLicencia.\n\nLicenciamiento.\n\nPropiedad intelectual en contenidos digitales.",
      "sourceRow": 24,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Derechos de autor:\n- Aplicación en diseños propios.\n- Plagio"
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Referencias bibliográficas:\n - Formatos"
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Referencias bibliográficas:\n- Formatos"
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Licencia:\n- Tipos (Creative Commons- alcances y limitaciones)."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Derechos de autor y licenciamiento:\n- Importancia y consecuencia."
        }
      }
    },
    {
      "id": "digital.iot",
      "area": "Apropiación tecnológica y Digital",
      "label": "Internet de las cosas (IoT)",
      "generalKnowledge": "Internet de las cosas\n\nAplicaciones del Internet de las cosas.\n\nAplicaciones y seguridad del Internet de las cosas.",
      "sourceRow": 25,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Internet de las cosas:\n- IoT en la cotidianidad"
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Internet de las cosas\n- Aplicaciones en la automatización (ventajas y desventajas)."
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.crypto",
      "area": "Apropiación tecnológica y Digital",
      "label": "Criptomonedas",
      "generalKnowledge": "Moneda virtual\n\nCriptomoneda",
      "sourceRow": 26,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Moneda virtual:\n-Utilidad e implicaciones."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Criptomonedas:\n-Utilidad e implicaciones"
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.citizenship",
      "area": "Apropiación tecnológica y Digital",
      "label": "Ciudadanía digital",
      "generalKnowledge": "Huella Digital\n\nIdentidad digital\n\nGestión de la identidad digital",
      "sourceRow": 28,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Huella digital:\n- Implicaciones."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Huella digital.\n-Usos\n-Implicaciones"
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Huella digital:\n-Medidas para proteger la privacidad."
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Huella digital:\n-Utilidad e implicaciones."
        }
      }
    },
    {
      "id": "digital.authentication",
      "area": "Apropiación tecnológica y Digital",
      "label": "Contraseñas y autenticación",
      "generalKnowledge": "Contraseñas seguras.\n\nMétodos de autenticación digital",
      "sourceRow": 29,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Contraseñas seguras:\n-¿Qué es una contraseña?\n- Elementos básicos de una contraseña segura."
        },
        "5°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Contraseñas seguras:\n-Autentificador de doble factor ( ¿Qué es la autenticación? , doble factor: contraseña + código/biometría)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Contraseñas seguras:\n- Características\n- Importancia de uso\n- Generadores aleatorios de contraseñas."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.hacking",
      "area": "Apropiación tecnológica y Digital",
      "label": "Hackeo",
      "generalKnowledge": "Hackeo",
      "sourceRow": 30,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Hackeo:\n- ¿Qué es el hackeo?\n- Phishing\n- Conexiones inseguras (Wi-Fi públicas)\n- Medidas de seguridad ante el hackeo."
        },
        "5°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Hackeo:\n-Hacker ( Tipos).\n-Implicaciones legales.\n-Medidas para enfrentar el hackeo."
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.malware",
      "area": "Apropiación tecnológica y Digital",
      "label": "Software malicioso y antivirus",
      "generalKnowledge": "Antivirus.\n\nSoftware malicioso.",
      "sourceRow": 31,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Software malicioso:\n-Virus informático ( Consecuencias)"
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Software malicioso:\n-Virus informático ( Riesgos)\n\n Antivirus:\n-Función y características.\n- Protección del equipo"
        },
        "5°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Software malicioso:\nVirus informático ( Cómo se propagan y se evitan)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Software malicioso:\n- Características\n- Sitios y aplicaciones potencialmente peligrosos"
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Software malicioso:\n-Tipos.\n\n Antivirus:\n-Uso correcto y  actualización\n-Diferencias entre antivirus"
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "digital.online-risks",
      "area": "Apropiación tecnológica y Digital",
      "label": "Riesgos en línea y seguridad web",
      "generalKnowledge": "Riesgos en línea.\nMedidas de seguridad web.",
      "sourceRow": 32,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Riesgos en línea:\n- Perfiles falsos.\n- Pérdida de privacidad.\n- Adicción.\n- Contacto con extraños.\n\nMedidas de seguridad web:\n- Control parental."
        },
        "4°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "5°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Riesgos en línea:\n- Ciberacoso.\n- Contenido inapropiado.\n- Suplantación de identidad.\n- Protocolos de actuación.\n\nMedidas de seguridad web:\n-Diferencia entre http y https.\n-Términos y condiciones."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Riesgos en línea:\n- Suplantación de Identidad.\n- Grooming.\n- Phishing.\n- Noticias falsas (fake news)."
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Riesgos en línea:\n- Acceso a información inapropiada.\n- Ciberadicción.\n- Ciberacoso.\n- Sexting."
        }
      }
    },
    {
      "id": "physical.robotics",
      "area": "Computación física y Robótica",
      "label": "Robótica",
      "generalKnowledge": "Robot\n\nComputación física\n\nRobótica\n\nRobótica inteligente",
      "sourceRow": 35,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Robot:\n- ¿Qué es y  qué no es un robot?\n- Componentes de un robot (cuerpo, sistema sensorial, sistema de control).\n- Programación de robots.\n- Usos de los robots."
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Computación física:\n- Componentes básicos (microcontrolador, sensores, actuadores, entorno de programación).\n- Usos y aplicaciones"
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Computación física:\n- Aplicaciones."
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Robot:\n-¿Qué es y qué no es un robot?\n-Tipos de robot.\n-Componentes de un robot (cuerpo, sistema sensorial, sistema de control).\n\nRobótica:\n-De la computación física a la robótica."
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "physical.mechanics",
      "area": "Computación física y Robótica",
      "label": "Conceptos básicos de mecánica",
      "generalKnowledge": "Mecánica aplicada a la robótica.",
      "sourceRow": 37,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Mecánica aplicada a la robótica:\n- Principios (estructura, estabilidad).\n- Aplicación."
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "physical.mechanisms",
      "area": "Computación física y Robótica",
      "label": "Mecanismos robóticos",
      "generalKnowledge": "Mecanismos.\n\nMovimiento en mecanismos.",
      "sourceRow": 38,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Mecanismos:\n-Tipos de mecanismos."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Movimiento  en mecanismos:\n-Movimiento de entrada.\n-Movimiento de salida."
        }
      }
    },
    {
      "id": "physical.electronics",
      "area": "Computación física y Robótica",
      "label": "Principios de electrónica",
      "generalKnowledge": "Circuito eléctrico\n\nFundamentos de electrónica",
      "sourceRow": 40,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Circuito eléctrico:\n-Tipo de circuito.\n-Flujo de corriente y polaridad.\n-Interruptores.\n\n\nFundamentos de electrónica:\n- Pin de entrada o salida.\n- Señal analógica o digital."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Circuito eléctrico\n-Carga eléctrica\n-Voltaje\n-Corriente eléctrica\n -Resistencias\n -Interruptores\n\n\nFundamentos de electrónica:\n- Pin de entrada o salida.\n- Señal analógica o digital."
        },
        "9°": {
          "status": "no-curricular-record",
          "scope": ""
        }
      }
    },
    {
      "id": "physical.interfaces",
      "area": "Computación física y Robótica",
      "label": "Interfaces físicas y digitales",
      "generalKnowledge": "Microcontrolador\n\nSensor\n\nActuador\n\nInterfaces digitales para el control de prototipos físicos.\n\nInterfaces digitales para monitoreo y control de sistemas físicos.",
      "sourceRow": 42,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Microcontrolador:\n-Pines (digitales y analógicos).\n-Placa de expansión.\n-Comunicación entre el programa y tarjeta microcontroladora.\n\nSensor:\n-Integrados.\n-Externos con conexión a VCC  y GND.\n\nActuador:\n-Integrados.\n-Externos con conexión a VCC  y GND."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Microcontrolador:\n-Pines (digitales y analógicos).\n-Placa de expansión.\n-Comunicación entre el programa y tarjeta microcontroladora.\n\nSensor:\n-Integrados.\n-Externos con conexión a VCC  y GND.\n\nActuador:\n-Integrados.\n-Externos con conexión a VCC  y GND."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Microcontrolador.\n\nSensor.\n\nActuador."
        }
      }
    },
    {
      "id": "physical.domotics",
      "area": "Computación física y Robótica",
      "label": "Domótica",
      "generalKnowledge": "Domótica.\n\nPrototipos.",
      "sourceRow": 43,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Domótica:\n -Usos y aplicaciones."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Prototipos:\n-Diseño y creación de prototipos."
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Domótica:\n-Usos y aplicaciones.\n- Beneficios.\n\nPrototipos:\n-Diseño y creación de prototipos."
        }
      }
    },
    {
      "id": "data.importance",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Datos y su importancia",
      "generalKnowledge": "Dato\n\nTipología de los datos.\n\nDatos para la toma de decisiones",
      "sourceRow": 48,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n- Tipos de datos (texto, imagen, sonido y video.\n- Importancia en situaciones cotidianas."
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n- Tipos (numérico, texto).\n- Importancia en la vida cotidiana."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n -Registros ( gastos, notas, deportivos, médicos)."
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n-Tipos ( numéricos, de texto, ubicación y de imágenes).\n-Los Datos y su Importancia en el Mundo Digital (control de redes sociales, historial y navegación, registro de actividades, registro de localización)."
        },
        "8°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Dato:\n-Importancia de organizar y conservar los datos"
        }
      }
    },
    {
      "id": "data.management",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Gestión de datos",
      "generalKnowledge": "Recolección de datos.\n\nAlmacenamiento de datos.\n\nRecolección y organización de datos.\n\nEstructuración y consulta de datos.",
      "sourceRow": 50,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Recolección de datos:\nTécnicas (observación, entrevistas, formularios, cuestionarios).\n\nAlmacenamiento de datos:\n -Formas de almacenamiento (local, hojas de cálculo)."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Recolección de datos:\n-Datos para la construcción de prototipos.\n\n\nAlmacenamiento de datos:\n -Formas de almacenamiento (local o en línea, hojas de cálculo)."
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Recolección de datos:\n-Registros ( gastos, notas, deportivos, médicos)."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Almacenamiento de datos:\n-Ciclo de vida del dato"
        }
      }
    },
    {
      "id": "data.visualization-intro",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Introducción a la visualización de datos\n\n.",
      "generalKnowledge": "Visualización de datos.\n\nEstrategias para presentar datos.\n\nRepresentación y visualización de datos.",
      "sourceRow": 51,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Estrategias para presentar datos:\n- Gráficos pictóricos: ( creación y análisis de datos).\n\nVisualización de datos.\n- Interpretación de los gráficos pictóricos"
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Visualización de datos:\n -Representación de datos.\n\nEstrategias para presentar datos:\n-Tablas."
        },
        "6°": {
          "status": "explicit-evaluable",
          "scope": "Visualización de datos.\n Representación gráfica de la información.\n\nEstrategias para presentar datos:\n-Gráfico ( barras, lineales)."
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.statistics",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Introducción a estadística descriptiva",
      "generalKnowledge": "Análisis estadístico de datos",
      "sourceRow": 53,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.presentation",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Presentación de datos de manera clara y efectiva.",
      "generalKnowledge": "Visualización de datos.\n\nPanel de control (Dashboard).",
      "sourceRow": 55,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.augmented-reality",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Realidad aumentada",
      "generalKnowledge": "Realidad aumentada",
      "sourceRow": 57,
      "levels": {
        "0°": {
          "status": "explicit-evaluable",
          "scope": "Realidad aumentada:\n -Actividades prácticas y sensoriales en entornos físicos."
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.virtual-reality",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Realidad virtual",
      "generalKnowledge": "Realidad virtual.",
      "sourceRow": 58,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.metaverse",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Metaversos",
      "generalKnowledge": "Metaverso.",
      "sourceRow": 59,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.blockchain",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Tecnología Blockchain",
      "generalKnowledge": "Blockchain.",
      "sourceRow": 60,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "not-applicable",
          "scope": ""
        },
        "2°": {
          "status": "not-applicable",
          "scope": ""
        },
        "3°": {
          "status": "not-applicable",
          "scope": ""
        },
        "4°": {
          "status": "not-applicable",
          "scope": ""
        },
        "5°": {
          "status": "not-applicable",
          "scope": ""
        },
        "6°": {
          "status": "not-applicable",
          "scope": ""
        },
        "7°": {
          "status": "not-applicable",
          "scope": ""
        },
        "8°": {
          "status": "not-applicable",
          "scope": ""
        },
        "9°": {
          "status": "not-applicable",
          "scope": ""
        }
      }
    },
    {
      "id": "data.ai",
      "area": "Ciencia de datos e Inteligencia artificial",
      "label": "Inteligencia Artificial",
      "generalKnowledge": "Fundamentos de la IA.\n\nAsistentes virtuales.\n\nHerramientas generativas.\n\nDesafíos de  la IA.\n\nUso crítico y responsable de la IA.\n\nAplicación de la Inteligencia artificial para la toma de decisiones.",
      "sourceRow": 62,
      "levels": {
        "0°": {
          "status": "not-applicable",
          "scope": ""
        },
        "1°": {
          "status": "explicit-evaluable",
          "scope": "Fundamentos de la IA.\n\nAsistentes virtuales."
        },
        "2°": {
          "status": "explicit-evaluable",
          "scope": "Fundamentos de la IA.\n\nAsistentes virtuales."
        },
        "3°": {
          "status": "explicit-evaluable",
          "scope": "Desafíos de la IA:\n- Importancia de la IA en la vida cotidiana.\n- Uso seguro y responsable."
        },
        "4°": {
          "status": "explicit-evaluable",
          "scope": "Fundamentos de la IA.\n\nAsistentes virtuales."
        },
        "5°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas generativas.\n-Texto, imagen o audio.\n\nDesafíos de  la IA:\n- Protección de la información personal sensible."
        },
        "6°": {
          "status": "no-curricular-record",
          "scope": ""
        },
        "7°": {
          "status": "explicit-evaluable",
          "scope": "Fundamentos de la IA.\n\nAsistentes virtuales."
        },
        "8°": {
          "status": "explicit-evaluable",
          "scope": "Fundamentos de la IA.\n\nHerramientas generativas."
        },
        "9°": {
          "status": "explicit-evaluable",
          "scope": "Herramientas generativas.\n\nDesafíos de  la IA."
        }
      }
    }
  ]
});
// PIA_CURRICULAR_PROGRESSION_DATA_END
