// PIA_RDA_CONTRIBUTION_CATALOG_START
// Grafo estructural de solo lectura. La pertenencia a un área no constituye por sí sola
// una correspondencia pedagógica validada ni evidencia de cumplimiento del RdA.
const PIARdaContributionCatalog = (() => {
    const VERSION = '1.0.0';
    const LEVEL_ORDER = Object.freeze(['0°', '1°', '2°', '3°', '4°', '5°', '6°', '7°', '8°', '9°']);
    const CYCLE_BY_LEVEL = Object.freeze({
        '0°': 'Materno Infantil/Transición',
        '1°': 'I Ciclo', '2°': 'I Ciclo', '3°': 'I Ciclo',
        '4°': 'II Ciclo', '5°': 'II Ciclo', '6°': 'II Ciclo',
        '7°': 'III Ciclo', '8°': 'III Ciclo', '9°': 'III Ciclo'
    });

    // Este catálogo permanece vacío hasta que una fuente y una autoridad curricular
    // validen explícitamente cada correspondencia indicador–RdA.
    const VALIDATED_PEDAGOGICAL_CORRESPONDENCES = Object.freeze([]);

    const normalize = value => String(value || '')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
        .toLocaleLowerCase('es').replace(/[^a-z0-9]+/g, ' ').trim();
    const encode = value => encodeURIComponent(String(value || ''));
    const occurrenceId = (level, moduleName, area, name) => `saber::${[level, moduleName, area, name].map(encode).join('::')}`;
    const indicatorId = (knowledgeId, index) => `indicador::${knowledgeId}::${index}`;
    const rdaId = (cycle, area) => `rda::${[cycle, area].map(encode).join('::')}`;
    const projectionConceptId = (level, moduleName, area, index) => [level, moduleName, area, index].map(encode).join('|');
    const isNotApplicable = text => /^no aplica(?:\s|\.|$)/i.test(String(text || '').trim());
    const nonEmpty = value => typeof value === 'string' && value.trim().length > 0;

    function validCorrespondenceShape(item) {
        return Boolean(item && item.status === 'validated' && item.relation === 'validated-contribution'
            && nonEmpty(item.correspondenceId) && nonEmpty(item.indicatorId) && nonEmpty(item.rdaId)
            && nonEmpty(item.indicatorText) && nonEmpty(item.rdaText) && item.partialContribution === true
            && nonEmpty(item.source?.file) && nonEmpty(item.source?.locator) && nonEmpty(item.source?.version)
            && nonEmpty(item.approval?.authority) && nonEmpty(item.approval?.date) && nonEmpty(item.approval?.version));
    }

    // Puente estructural exacto para la denominación contextual de Preescolar. No es
    // una correspondencia pedagógica con el RdA y no usa coincidencia aproximada.
    const EXACT_FAMILY_BRIDGES = Object.freeze({
        [`${normalize('Programación y Algoritmos')}::${normalize('Dato (programación).')}`]: 'programming.data-structures'
    });

    function freezeGraph(graph) {
        Object.values(graph.nodes).forEach(list => list.forEach(Object.freeze));
        Object.values(graph.nodes).forEach(Object.freeze);
        graph.edges.forEach(Object.freeze);
        graph.unresolved.forEach(Object.freeze);
        Object.freeze(graph.nodes);
        Object.freeze(graph.edges);
        Object.freeze(graph.unresolved);
        return Object.freeze(graph);
    }

    function familyFor(area, name, progressionService) {
        const resolved = progressionService?.familyIdFor?.(area, name) || '';
        return resolved || EXACT_FAMILY_BRIDGES[`${normalize(area)}::${normalize(name)}`] || '';
    }

    function preschoolEntryIndex(preschoolCurriculum, route) {
        const index = new Map();
        [1, 2].forEach(moduleNumber => {
            const itinerary = preschoolCurriculum?.getItinerary?.(moduleNumber, route);
            (itinerary?.entries || []).forEach(entry => {
                const key = [moduleNumber, entry.area, normalize(entry.conceptualKnowledge)].join('::');
                index.set(key, { entryId: entry.id, itineraryId: itinerary.id, itineraryLabel: itinerary.label, sourcePages: itinerary.sourcePages });
            });
        });
        return index;
    }

    function build(options = {}) {
        const pnftData = options.pnftData || (typeof PNFT_DATA !== 'undefined' ? PNFT_DATA : {});
        const rdaByCycle = options.rdaByCycle || (typeof RDA_POR_CICLO !== 'undefined' ? RDA_POR_CICLO : {});
        const progressionData = options.progressionData || (typeof PIACurricularProgressionData !== 'undefined' ? PIACurricularProgressionData : { families: [] });
        const progressionService = options.progressionService || (typeof PIACurricularProgression !== 'undefined' ? PIACurricularProgression : null);
        const preschoolCurriculum = options.preschoolCurriculum || (typeof PIAPreschoolCurriculum !== 'undefined' ? PIAPreschoolCurriculum : null);
        const preschoolTrack = preschoolCurriculum?.normalizeRoute?.(options.preschoolTrack) || 'optimal';
        const preschoolData = preschoolCurriculum?.getLevelData?.(preschoolTrack);
        const curriculum = { ...pnftData, ...(preschoolData ? { '0°': preschoolData } : {}) };
        const preschoolSources = preschoolEntryIndex(preschoolCurriculum, preschoolTrack);

        const nodes = { families: [], rdas: [], knowledge: [], indicators: [] };
        const edges = [];
        const unresolved = [];

        (progressionData.families || []).forEach(family => nodes.families.push({
            id: family.id,
            type: 'family',
            area: family.area,
            label: family.label,
            generalKnowledge: family.generalKnowledge || '',
            sourceRow: family.sourceRow ?? null,
            levelStates: LEVEL_ORDER.map(level => ({
                level,
                status: family.levels?.[level]?.status || 'no-curricular-record',
                scope: family.levels?.[level]?.scope || ''
            }))
        }));

        Object.entries(rdaByCycle).forEach(([cycle, areas]) => Object.entries(areas || {}).forEach(([area, text]) => {
            nodes.rdas.push({ id: rdaId(cycle, area), type: 'rda', cycle, area, text, applicable: !isNotApplicable(text) });
        }));
        const knownRdaIds = new Set(nodes.rdas.map(node => node.id));

        LEVEL_ORDER.forEach(level => {
            const cycle = CYCLE_BY_LEVEL[level];
            Object.entries(curriculum[level] || {}).forEach(([moduleName, areas]) => {
                Object.entries(areas || {}).forEach(([area, payload]) => {
                    (payload?.saberes || []).forEach((saber, knowledgeIndex) => {
                        const id = occurrenceId(level, moduleName, area, saber.nombre);
                        const familyId = familyFor(area, saber.nombre, progressionService);
                        const moduleNumber = Number(String(moduleName).match(/\d+/)?.[0]);
                        const preschoolSource = level === '0°'
                            ? preschoolSources.get([moduleNumber, area, normalize(saber.nombre)].join('::'))
                            : null;
                        const knowledgeNode = {
                            id, type: 'knowledge-occurrence', level, cycle, module: moduleName, area,
                            name: saber.nombre, familyId, projectionConceptId: projectionConceptId(level, moduleName, area, knowledgeIndex),
                            preschoolTrack: level === '0°' ? preschoolTrack : '',
                            sourceRecordId: preschoolSource?.entryId || '',
                            sourceItineraryId: preschoolSource?.itineraryId || '',
                            sourceItineraryLabel: preschoolSource?.itineraryLabel || ''
                        };
                        nodes.knowledge.push(knowledgeNode);
                        if (familyId) edges.push({ from: id, to: familyId, type: 'member-of-family', semanticClaim: false });
                        else unresolved.push({ type: 'family-unresolved', occurrenceId: id, level, module: moduleName, area, name: saber.nombre });

                        const targetRdaId = rdaId(cycle, area);
                        const targetRda = nodes.rdas.find(node => node.id === targetRdaId);
                        if (knownRdaIds.has(targetRdaId) && targetRda?.applicable) {
                            edges.push({ from: id, to: targetRdaId, type: 'within-cycle-area-rda-scope', semanticClaim: false });
                        } else if (!knownRdaIds.has(targetRdaId)) {
                            unresolved.push({ type: 'rda-unresolved', occurrenceId: id, cycle, area });
                        }

                        (saber.indicadores || []).forEach((text, index) => {
                            const currentIndicatorId = indicatorId(id, index);
                            nodes.indicators.push({ id: currentIndicatorId, type: 'indicator-occurrence', knowledgeId: id, text, index });
                            edges.push({ from: currentIndicatorId, to: id, type: 'indicator-of', semanticClaim: false });
                        });
                    });
                });
            });
        });

        const validatedPedagogicalCorrespondences = Object.freeze([...(options.validatedPedagogicalCorrespondences || VALIDATED_PEDAGOGICAL_CORRESPONDENCES)]);
        return freezeGraph({
            catalogVersion: VERSION,
            preschoolTrack,
            levelOrder: LEVEL_ORDER,
            cycleByLevel: CYCLE_BY_LEVEL,
            nodes,
            edges,
            validatedPedagogicalCorrespondences,
            unresolved
        });
    }

    return Object.freeze({
        VERSION, LEVEL_ORDER, CYCLE_BY_LEVEL, VALIDATED_PEDAGOGICAL_CORRESPONDENCES,
        occurrenceId, indicatorId, rdaId, projectionConceptId, validCorrespondenceShape, build
    });
})();
// PIA_RDA_CONTRIBUTION_CATALOG_END
