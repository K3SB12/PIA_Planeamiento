        function configurarEventListeners() {
            document.getElementById('leccionesPlanificadas').addEventListener('change', actualizarSemanasPreservandoContenido);
            document.getElementById('metodologiaActiva').addEventListener('change', manejarCambioMetodologia);
        }

        function manejarCambioMetodologia() {
            const metodologia = document.getElementById('metodologiaActiva').value;
            const container = document.getElementById('metodologiaPersonalizadaContainer');
            
            if (metodologia === 'otra') {
                container.classList.add('visible');
            } else {
                container.classList.remove('visible');
            }
        }

        function actualizarNiveles() {
            const ciclo = document.getElementById('ciclo').value;
            const nivelSelect = document.getElementById('nivel');
            
            nivelSelect.innerHTML = '<option value="">Seleccione nivel</option>';
            
            if (ciclo === 'Materno Infantil/Transición') {
                nivelSelect.innerHTML += '<option value="0°">Grupo Interactivo II y Transición</option>';
            } else if (ciclo === 'I Ciclo') {
                nivelSelect.innerHTML += '<option value="1°">1°</option>';
                nivelSelect.innerHTML += '<option value="2°">2°</option>';
                nivelSelect.innerHTML += '<option value="3°">3°</option>';
            } else if (ciclo === 'II Ciclo') {
                nivelSelect.innerHTML += '<option value="4°">4°</option>';
                nivelSelect.innerHTML += '<option value="5°">5°</option>';
                nivelSelect.innerHTML += '<option value="6°">6°</option>';
            } else if (ciclo === 'III Ciclo') {
                nivelSelect.innerHTML += '<option value="7°">7°</option>';
                nivelSelect.innerHTML += '<option value="8°">8°</option>';
                nivelSelect.innerHTML += '<option value="9°">9°</option>';
            }
        }

        function inicializarSemanas() {
            const lecciones = parseInt(document.getElementById('leccionesPlanificadas').value) || 8;
            const numSemanas = Math.ceil(lecciones / 2);
            
            semanas = [];
            const container = document.getElementById('semanasContainer');
            container.innerHTML = '';
            
            for (let i = 1; i <= numSemanas; i++) {
                const leccionInicio = (i - 1) * 2 + 1;
                const leccionFin = Math.min(i * 2, lecciones);
                
                semanas.push({
                    id: i,
                    nombre: `Semana ${i}`,
                    lecciones: `Lecciones ${leccionInicio} y ${leccionFin}`,
                    fase: i === 1 ? 'diagnóstico' : 'desarrollo',
                    modulos: modulosPredeterminadosSemana(),
                    areas: [],
                    rda: '',
                    saberes: [],
                    saberRefs: [],
                    procedimentales: [],
                    actitudinales: [],
                    actividades: '',
                    recursos: '',
                    evaluacion: '',
                    indicadores: '',
                    project: PIAProjectComponentCatalog.defaultWeekProject()
                });
                
                const semanaElement = crearElementoSemana(i, leccionInicio, leccionFin);
                container.appendChild(semanaElement);
            }
            
            actualizarContadoresSemanas();
        }

        function actualizarSemanasPreservandoContenido() {
            const leccionesActual = parseInt(document.getElementById('leccionesPlanificadas').value) || 8;
            const numSemanasNecesarias = Math.ceil(leccionesActual / 2);
            
            console.log(`Actualizando semanas: ${semanas.length} → ${numSemanasNecesarias}`);
            
            // PRESERVAR datos existentes completamente
            const semanasBackup = JSON.parse(JSON.stringify(semanas));
            const saberesBackup = new Set(saberesSeleccionados);
            const procBackup = new Set(saberesProcedimentalesGlobales);
            const actBackup = new Set(saberesActitudinalesGlobales);
            
            // Solo preguntar si estamos reduciendo semanas
            if (semanas.length > numSemanasNecesarias) {
                if (!confirm(`Al reducir las lecciones se eliminarán ${semanas.length - numSemanasNecesarias} semana(s) y su contenido. ¿Desea continuar?`)) {
                    document.getElementById('leccionesPlanificadas').value = semanas.length * 2;
                    return;
                }
            }
            
            semanas = [];
            const container = document.getElementById('semanasContainer');
            container.innerHTML = '';
            
            for (let i = 1; i <= numSemanasNecesarias; i++) {
                const leccionInicio = (i - 1) * 2 + 1;
                const leccionFin = Math.min(i * 2, leccionesActual);
                
                // PRESERVAR datos de la semana si existe en el backup
                const semanaBackup = semanasBackup[i-1];
                
                semanas.push({
                    id: i,
                    nombre: `Semana ${i}`,
                    lecciones: `Lecciones ${leccionInicio} y ${leccionFin}`,
                    fase: semanaBackup ? (semanaBackup.fase || (i === 1 ? 'diagnóstico' : 'desarrollo')) : (i === 1 ? 'diagnóstico' : 'desarrollo'),
                    modulos: semanaBackup ? normalizarModulosSemana(semanaBackup) : modulosPredeterminadosSemana(),
                    areas: semanaBackup ? semanaBackup.areas : [],
                    rda: semanaBackup ? semanaBackup.rda : '',
                    saberes: semanaBackup ? semanaBackup.saberes : [],
                    saberRefs: semanaBackup ? normalizarReferenciasSaberesSemana(semanaBackup) : [],
                    procedimentales: semanaBackup ? semanaBackup.procedimentales : [],
                    actitudinales: semanaBackup ? semanaBackup.actitudinales : [],
                    actividades: semanaBackup ? semanaBackup.actividades : '',
                    recursos: semanaBackup ? semanaBackup.recursos : '',
                    evaluacion: semanaBackup ? semanaBackup.evaluacion : '',
                    indicadores: semanaBackup ? semanaBackup.indicadores : '',
                    project: PIAProjectComponentCatalog.normalizeWeekProject(semanaBackup?.project)
                });
                
                const semanaElement = crearElementoSemana(i, leccionInicio, leccionFin);
                container.appendChild(semanaElement);
            }
            
            // RESTAURAR datos globales
            saberesSeleccionados = new Set(saberesBackup);
            saberesProcedimentalesGlobales = new Set(procBackup);
            saberesActitudinalesGlobales = new Set(actBackup);
            
            // ACTUALIZAR interfaz preservando todo el contenido
            setTimeout(() => {
                reconstruirVistaSemanasPreservandoContenido();
                actualizarContadoresSemanas();
            }, 100);
        }

