        // Funciones para los botones de acción
        function nuevoPlan() {
            if (confirm('¿Está seguro de que desea crear un nuevo plan? Se perderán los cambios no guardados.')) {
                location.reload();
            }
        }

        function abrirPlan() {
            console.log("🚨 USANDO VERSIÓN DE EMERGENCIA");
            
            // Método SUPER simple - nada de overlays
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            
            // Agregar al body inmediatamente
            document.body.appendChild(input);
            
            // Función de cambio
            input.addEventListener('change', function(e) {
                const file = e.target.files[0];
                if (!file) {
                    input.remove();
                    return;
                }
                
                // Validar que sea JSON
                if (!file.name.endsWith('.json')) {
                    alert('Solo archivos .json');
                    input.remove();
                    return;
                }
                
                const reader = new FileReader();
                reader.onload = function(e) {
                    try {
                        const data = JSON.parse(e.target.result);
                        alert('Archivo válido. Cargando...');
                        cargarPlan(data);
                        input.remove();
                    } catch (err) {
                        alert('Error en el archivo JSON');
                        input.remove();
                    }
                };
                reader.readAsText(file);
            });
            
            // Disparar el selector de archivos
            setTimeout(() => {
                input.click();
                // Limpiar después de 10 segundos
                setTimeout(() => {
                    if (input.parentNode) input.remove();
                }, 10000);
            }, 50);
        }

        // FUNCIÓN guardarPlan() - VERSIÓN MEJORADA
        function guardarPlan() {
            // Llama a la función mejorada que incluye mensaje de confirmación
            ejecutarGuardarNormal();
            return false; // Previene cualquier comportamiento no deseado
        }

        // FUNCIÓN ejecutarGuardarNormal() - NUEVA FUNCIÓN COMPLETA
        function ejecutarGuardarNormal() {
            // Cerrar menú si está abierto
            const menu = document.getElementById('menuGuardar');
            if (menu) {
                menu.classList.remove('abierto');
            }
            
            // Ejecutar guardado normal (código original de guardarPlan)
            const plan = obtenerDatosPlan();
            const dataStr = JSON.stringify(plan, null, 2);
            const dataBlob = new Blob([dataStr], {type: 'application/json'});
            
            const enlace = document.createElement('a');
            enlace.download = 'planeamiento-didáctico.json';
            enlace.href = URL.createObjectURL(dataBlob);
            enlace.click();
            
            setTimeout(() => URL.revokeObjectURL(enlace.href), 100);
            
            // Mostrar retroalimentación sutil
            mostrarMensaje('✅ Archivo .json guardado exitosamente');
        }

        function obtenerDatosPlan() {
            // Obtener metodología activa
            let metodologia = document.getElementById('metodologiaActiva').value;
            if (metodologia === 'otra') {
                metodologia = document.getElementById('metodologiaPersonalizada').value || 'Otra metodología (personalizada)';
            }
            
            return {
                informacionGeneral: {
                    cursoLectivo: document.getElementById('cursoLectivo').value,
                    semestre: document.getElementById('semestre').value,
                    direccionRegional: document.getElementById('direccionRegional').value,
                    centroEducativo: document.getElementById('centroEducativo').value,
                    codigoCentro: document.getElementById('codigoCentro').value,
                    nombreDocente: document.getElementById('nombreDocente').value,
                    circuito: document.getElementById('circuito').value,
                    ciclo: document.getElementById('ciclo').value,
                    nivel: document.getElementById('nivel').value,
                    leccionesPlanificadas: document.getElementById('leccionesPlanificadas').value,
                    mesInicio: document.getElementById('mesInicio').value,
                    mesFinal: document.getElementById('mesFinal').value,
                    asignatura: document.getElementById('asignatura').value
                },
                ejesTransversales: Array.from(document.querySelectorAll('input[name="eje"]:checked')).map(cb => cb.value),
                metodologiaActiva: metodologia,
                semanas: semanas,
                reflexiones: {
                    queFunciono: document.getElementById('queFunciono').value,
                    queNoFunciono: document.getElementById('queNoFunciono').value,
                    queMejorar: document.getElementById('queMejorar').value
                },
                observaciones: document.getElementById('observaciones').value,
                saberesGlobales: Array.from(saberesSeleccionados),
                saberesProcedimentalesGlobales: Array.from(saberesProcedimentalesGlobales),
                saberesActitudinalesGlobales: Array.from(saberesActitudinalesGlobales),
                fechaGuardado: new Date().toISOString()
            };
        }

        function cargarPlan(plan) {
            if (plan.informacionGeneral) {
                document.getElementById('cursoLectivo').value = plan.informacionGeneral.cursoLectivo || '2026';
                document.getElementById('semestre').value = plan.informacionGeneral.semestre || 'I';
                document.getElementById('direccionRegional').value = plan.informacionGeneral.direccionRegional || '';
                document.getElementById('centroEducativo').value = plan.informacionGeneral.centroEducativo || '';
                document.getElementById('codigoCentro').value = plan.informacionGeneral.codigoCentro || '';
                document.getElementById('nombreDocente').value = plan.informacionGeneral.nombreDocente || '';
                document.getElementById('circuito').value = plan.informacionGeneral.circuito || '';
                document.getElementById('ciclo').value = plan.informacionGeneral.ciclo || '';
                
                actualizarNiveles();
                
                document.getElementById('nivel').value = plan.informacionGeneral.nivel || '';
                document.getElementById('leccionesPlanificadas').value = plan.informacionGeneral.leccionesPlanificadas || '8';
                document.getElementById('mesInicio').value = plan.informacionGeneral.mesInicio || '';
                document.getElementById('mesFinal').value = plan.informacionGeneral.mesFinal || '';
                document.getElementById('asignatura').value = plan.informacionGeneral.asignatura || 'Formación tecnológica/Informática Educativa';
            }
            
            if (plan.ejesTransversales) {
                document.querySelectorAll('input[name="eje"]').forEach(checkbox => {
                    checkbox.checked = plan.ejesTransversales.includes(checkbox.value);
                });
            }
            
            if (plan.metodologiaActiva) {
                // Manejar metodología personalizada
                const metodologia = plan.metodologiaActiva;
                if (metodologia.includes('ABJ') || metodologia.includes('Aprendizaje basado en juegos')) {
                    document.getElementById('metodologiaActiva').value = 'ABJ';
                } else if (metodologia.includes('ABR') || metodologia.includes('Aprendizaje basado en retos')) {
                    document.getElementById('metodologiaActiva').value = 'ABR';
                } else if (metodologia.includes('APD') || metodologia.includes('Pensamiento por Diseño')) {
                    document.getElementById('metodologiaActiva').value = 'APD';
                } else if (metodologia) {
                    document.getElementById('metodologiaActiva').value = 'otra';
                    document.getElementById('metodologiaPersonalizada').value = metodologia;
                    document.getElementById('metodologiaPersonalizadaContainer').classList.add('visible');
                }
            }
            
            if (plan.semanas && plan.semanas.length > 0) {
                semanas = plan.semanas;
                reconstruirVistaSemanasPreservandoContenido();
            }
            
            if (plan.saberesGlobales) {
                saberesSeleccionados = new Set(plan.saberesGlobales);
            }
            
            if (plan.saberesProcedimentalesGlobales) {
                saberesProcedimentalesGlobales = new Set(plan.saberesProcedimentalesGlobales);
            }
            
            if (plan.saberesActitudinalesGlobales) {
                saberesActitudinalesGlobales = new Set(plan.saberesActitudinalesGlobales);
            }
            
            if (plan.reflexiones) {
                document.getElementById('queFunciono').value = plan.reflexiones.queFunciono || '';
                document.getElementById('queNoFunciono').value = plan.reflexiones.queNoFunciono || '';
                document.getElementById('queMejorar').value = plan.reflexiones.queMejorar || '';
            }
            
            if (plan.observaciones) {
                document.getElementById('observaciones').value = plan.observaciones || '';
            }
            
            actualizarContadoresSemanas();
            
            // FORZAR ACTUALIZACIÓN DE SABERES CONCEPTUALES
            setTimeout(() => {
                semanas.forEach((semana, index) => {
                    actualizarRdASemana(index + 1);
                    actualizarOpcionesSaberesSemana(index + 1);
                    actualizarIndicadoresSemana(index + 1);
                    actualizarSaberesConceptualesContenedor(index + 1);
                });
            }, 500);
            
            alert('Plan cargado exitosamente');
        }

        // ===== FUNCIONES DE EXPORTACIÓN CORREGIDAS =====

        // Función para mostrar el modal CON INICIALIZACIÓN
