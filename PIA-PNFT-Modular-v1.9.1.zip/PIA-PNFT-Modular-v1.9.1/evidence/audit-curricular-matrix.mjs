import fs from 'node:fs';
import vm from 'node:vm';

const root = new URL('../', import.meta.url);
function loadConst(file, name) {
  const source = fs.readFileSync(new URL(file, root), 'utf8');
  const context = {};
  vm.createContext(context);
  vm.runInContext(`${source}\n;globalThis.__value=${name};`, context);
  return context.__value;
}

const data = loadConst('src/data/pnft-data.js', 'PNFT_DATA');
const rdas = loadConst('src/data/rda-por-ciclo.js', 'RDA_POR_CICLO');
const cycleFor = level => level === '0°' ? 'Materno Infantil/Transición' :
  ['1°','2°','3°'].includes(level) ? 'I Ciclo' :
  ['4°','5°','6°'].includes(level) ? 'II Ciclo' : 'III Ciclo';

const records = [];
const defects = [];
for (const [level, modules] of Object.entries(data)) {
  for (const [module, areas] of Object.entries(modules)) {
    for (const [area, payload] of Object.entries(areas)) {
      const cycle = cycleFor(level);
      const items = payload.saberes || [];
      const indicators = items.flatMap(item => item.indicadores || []);
      const blankNames = items.filter(item => !String(item.nombre || '').trim()).length;
      const withoutIndicators = items.filter(item => !(item.indicadores || []).length).length;
      const blankIndicators = indicators.filter(item => !String(item || '').trim()).length;
      const rda = rdas[cycle]?.[area];
      records.push({level,module,cycle,area,saberes:items.length,indicators:indicators.length,withoutIndicators,blankNames,blankIndicators,rdaStatus:!rda?'MISSING':/no aplica/i.test(rda)?'N/A':'PRESENT'});
      if (blankNames || withoutIndicators || blankIndicators || !rda) defects.push(records.at(-1));
    }
  }
}

const totals = Object.keys(data).map(level => {
  const rows = records.filter(row => row.level === level);
  return {
    level,
    cycle: cycleFor(level),
    modules: new Set(rows.map(row => row.module)).size,
    areas: new Set(rows.map(row => row.area)).size,
    moduleAreas: rows.length,
    saberEntries: rows.reduce((n,row)=>n+row.saberes,0),
    indicatorEntries: rows.reduce((n,row)=>n+row.indicators,0),
    areasByModule: Object.fromEntries([...new Set(rows.map(row=>row.module))].map(module=>[module,rows.filter(row=>row.module===module).map(row=>row.area)]))
  };
});

const output = {generatedAt:new Date().toISOString(), records, totals, defects};
fs.writeFileSync(new URL('audit-curricular-matrix.json', import.meta.url), JSON.stringify(output,null,2));
console.log(JSON.stringify({totals,defects},null,2));
