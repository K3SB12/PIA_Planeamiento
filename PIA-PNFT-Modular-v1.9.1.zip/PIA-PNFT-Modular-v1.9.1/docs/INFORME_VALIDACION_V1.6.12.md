# Informe de validación — PIA-PNFT Modular 1.6.12

Fecha: 11 de setiembre de 2026.

## Resultado

- Fuente y ensamblado reproducible: aprobados.
- Alcance autorizado respecto de la referencia protegida: aprobado.
- Pruebas automatizadas: **127/127 aprobadas**.
- Salidas equivalentes: `index.html`, `dist/web/index.html` y `dist/portable/index.html`.
- Currículo protegido: 38 familias, cuatro áreas, diez niveles y 235 registros relacionados sin cambios.
- Huellas de los Excel adjuntos: coinciden con las registradas en el catálogo de progresión.

## Cobertura específica

- Tarjetas ANTES–AHORA–DESPUÉS y filtros por área.
- AHORA limitado a saberes seleccionados e indicadores literales.
- Diferenciación entre fortalecimiento sin evaluación directa y ausencia en la trayectoria.
- Exclusión de la vista en JSON, PDF y Word.
- Auditoría temporal posterior sin regla de conteo aislado.
- “Etapa de desarrollo → Prototipar” en español.
- Compatibilidad JSON v6 y funcionamiento portable preservados.

## Validación humana pendiente

La revisión visual automatizada no pudo abrir el servidor local por restricción del navegador de trabajo.
Antes de despliegue institucional se mantiene la comprobación humana en Edge/Chrome de escritorio y móvil:
apertura, filtros, tarjetas, desplazamiento, cierre con `Esc`, contraste, texto largo y funcionamiento `file://`.
