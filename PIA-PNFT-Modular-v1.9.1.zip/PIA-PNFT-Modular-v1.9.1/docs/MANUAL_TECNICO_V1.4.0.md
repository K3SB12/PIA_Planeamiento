# Manual técnico — PIA-PNFT Modular 1.4.0

## Fuente y ensamblado

La fuente editable está en `src/`. `scripts/fragment-manifest.mjs` declara el orden de carga y
`node scripts/build.mjs` genera `index.html`, `dist/web/index.html` y
`dist/portable/index.html`. Las tres salidas deben ser idénticas; nunca se editan directamente.

## Dependencias principales

| Componente | Depende de | Responsabilidad |
|---|---|---|
| `preschool-curriculum.js` | Guía docente oficial | Cuatro itinerarios de Preescolar, RdA y adaptación al contrato modular |
| `institutional-centers.js` | Excel institucional depurado | Catálogo mínimo local, sin datos personales ni códigos `0000` |
| `center-lookup-service.js` | Catálogo de centros | Normalización e índices `unique`, `ambiguous`, `notFound` |
| `curriculum-operations.js` | PNFT y catálogo Preescolar | Saberes, indicadores y RdA de las semanas |
| `projection-core.js` | datos curriculares | esquema v3, migración y reglas puras |
| `semester-projection-prompt.js` | selección docente | prompt semestral y andamiaje ABJ/ABR/APD |
| `enhancements.js` | componentes anteriores | coordinación de interfaz, persistencia, Proyección y consulta de centros |
| `pdf-exporter.js` | plan oficial | PDF y Word sin Proyección/Cobertura |

## Consulta institucional

`PIACenterLookup` crea un índice en memoria al abrir PIA. `normalizeBudgetCode()` conserva cuatro
cifras y ceros iniciales. El resultado de `lookup()` tiene uno de estos contratos:

- `unique`: contiene `center` y permite autocompletar.
- `ambiguous`: contiene `matches`; la interfaz exige selección explícita.
- `notFound`: no cambia automáticamente el nombre del centro.

El valor seleccionado se persiste en `pia.institutional.codSaber`. Este campo es opcional y
aditivo, por lo que no exige cambiar `schemaVersion: 3` ni rompe planes v1/v2.

## Regenerar el catálogo

La actualización es exclusiva del equipo técnico:

```bash
node scripts/import-centers.mjs "ruta/Asesores-Centros.xlsx" src/data/institutional-centers.js
npm test
```

El importador usa Node estándar, lee XLSX sin instalar dependencias, exige `centro`, `cod_saber` y
`cod_pres`, excluye `0000`, valida cuatro cifras, comprueba `codSaber` único y ordena el resultado.
No incorpore campos de personas asesoras, correos o teléfonos.

## Preescolar

El identificador técnico sigue siendo `0°`. `PIAPreschoolCurriculum.getLevelData(route)` adapta
`basic` u `optimal` a la estructura `Módulo → área → saberes`. La interfaz activa la ruta antes de
refrescar Proyección y semanas. Las cuatro combinaciones se prueban por separado; no existe una
ruta combinada ni mezcla automática.

## Prompt metodológico

`methodologyGuidance()` añade requisitos específicos para ABJ, ABR y APD. El punto 4 exige una
progresión semestral enlazada, actuación del estudiantado, mediación y retroalimentación docente,
recursos, evidencia y preparación de la semana siguiente.

## Pruebas

```bash
npm test
```

Equivalente detallado:

```bash
node scripts/verify-source.mjs
node scripts/build.mjs
node scripts/verify-authorized-change.mjs
node --test tests/*.test.mjs
```

Las pruebas automatizadas no sustituyen la revisión humana en Edge/Chrome de ventanas emergentes,
impresión, descargas y selección visual de códigos ambiguos.
