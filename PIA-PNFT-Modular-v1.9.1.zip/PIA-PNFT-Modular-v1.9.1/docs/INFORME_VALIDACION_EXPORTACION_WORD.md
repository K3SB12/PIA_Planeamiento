# Informe de validación de exportación Word

## Identificación

- Producto: PIA-PNFT Modular 1.1.1.
- Paquete: `1.1.1-modular.1`.
- Fecha: 24 de agosto de 2026.
- Alcance: incorporación de Word sin modificar la presentación del planeamiento ni la función PDF.

## Implementación

El modal de exportación presenta PDF y Word como opciones independientes y utiliza el botón
genérico **Exportar** para ambos formatos. Word abre una vista
continua en una ventana emergente y ofrece controles para guardar un archivo `.doc` compatible,
imprimir o cerrar. Si el navegador bloquea la ventana, se ejecuta una descarga de respaldo.

El contenido editable se sanea antes de incorporarse al documento y los valores textuales se
escapan. El nombre del archivo elimina caracteres no permitidos. No se introdujeron solicitudes
de red, dependencias, API, backend ni cambios curriculares. El archivo incorpora la sección
`WordSection1`, metadatos de Microsoft Office y A4 horizontal; las tablas y encabezados permiten
saltos internos para evitar desbordamientos de títulos largos.

## Resultados automáticos

| Comprobación | Resultado |
|---|---|
| Sintaxis de fuente y pruebas | APROBADA |
| Fuente JavaScript, CSS y destinos de red | APROBADA |
| Construcción de las tres salidas | APROBADA |
| Alcance limitado a eliminación semanal y exportación Word | APROBADA |
| Salidas raíz, web y portable idénticas | APROBADA |
| Selección independiente PDF/Word | APROBADA |
| Vista Word continua sin saltos forzados | APROBADA |
| A4 horizontal reconocido en el archivo guardado | APROBADA |
| Encabezados largos contenidos en su ancho | APROBADA |
| Botón morado identificado como `Exportar` | APROBADA |
| Descarga `.doc` compatible | APROBADA |
| Respaldo cuando se bloquea la ventana | APROBADA |
| Impresión desde la vista Word | APROBADA |
| Saneamiento de contenido editable | APROBADA |
| Guardado y carga JSON sin pérdida | APROBADA |
| Eliminación consecutiva de semanas 8 y 7 | APROBADA |
| Total de pruebas | 8/8 APROBADAS |

## Validación documental

Se generó un archivo Word de muestra, se abrió mediante LibreOffice Writer en modo compatible y
se convirtió a PDF para inspección visual. Se comprobaron encabezado institucional, información
general, ejes, metodología, área y RdA, saberes globales, planificación semanal, reflexiones,
observaciones y pie institucional. El documento convertido produjo tres páginas de 841,89 ×
595,304 puntos: A4 horizontal. Los títulos permanecieron dentro del ancho disponible. El resultado
es editable, imprimible y no contiene JavaScript incrustado.

## Límite de la sesión

El entorno de validación no dispone de Chrome ni Edge instalados. La ejecución real de la ventana
emergente y del diálogo de impresión debe confirmarse una vez en una computadora docente con
Microsoft Edge o Google Chrome. Esta comprobación no requiere cambiar el código.

## Huella de la entrega

`ea772429ca9e5fe178e4695b6532da4a87c8834f66d081cdc18a90b1360536a1`
