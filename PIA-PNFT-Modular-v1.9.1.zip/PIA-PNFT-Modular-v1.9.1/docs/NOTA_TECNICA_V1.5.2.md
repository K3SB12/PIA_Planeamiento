# Nota técnica — PIA-PNFT Modular 1.5.2

## Finalidad

Cerrar la correspondencia entre el Proyecto guardado en cada semana y las salidas oficiales PDF y
Word, sin crear una sección paralela ni modificar el formato de tres columnas.

## Regla única de selección efectiva

`PIAProjectComponentCatalog.exportSelection()` recibe el registro semanal y los identificadores
globales seleccionados. Solo produce contenido cuando la semana es `mixed` o `integrated`, la fase
tiene una instantánea guardada y el indicador permanece seleccionado.

Para cada texto aplica:

1. `teacherText` no vacío.
2. `officialText` guardado como respaldo.
3. Exclusión de la salida cuando un indicador de evaluación tiene `selected: false`.

La exclusión no borra el registro. Volver a marcar el indicador recupera su texto docente u oficial.

## Integración de exportadores

- Word añade un bloque visual discreto dentro de la celda de Indicadores de logro y otro dentro de
  Indicadores de evaluación.
- PDF utiliza la misma selección y compone bloques equivalentes dentro de sus columnas existentes.
- Los textos del Proyecto se escapan antes de insertarlos en el documento.
- Proyección y Cobertura continúan fuera del documento oficial.

## Persistencia

El esquema permanece en JSON v5. No fue necesario cambiarlo porque ya conservaba modo, etapa, fase,
instantánea oficial, contextualización docente y estado seleccionado. Se amplió la prueba de ida y
vuelta para comprobar esos campos.

## Validación

`npm test`: 68 pruebas aprobadas y 0 fallidas. Se verificaron fuente, construcción, alcance,
selección efectiva, original/edición, exclusión de desmarcados, guardado/carga y composición de
Word/PDF. La revisión visual final debe realizarse en Edge o Chrome institucional.
