# Manual funcional — PIA-PNFT Modular 1.4.1

## Abrir PIA

Abra `dist/portable/index.html` en Microsoft Edge o Google Chrome. PIA funciona localmente sin
servidor, API ni backend. Para probar descargas, PDF y Word utilice una computadora y permita
ventanas emergentes.

## Código presupuestario y centro educativo

1. Escriba el código presupuestario en el encabezado oficial.
2. Si el código identifica un único registro, PIA completa automáticamente **Centro educativo**.
3. Si varias sedes comparten el código, PIA muestra una lista. Seleccione la sede correcta; el
   sistema no elige por usted.
4. Si el código no aparece, PIA lo informa y permite escribir el centro manualmente.

Los códigos `0000` no se atienden y fueron excluidos. La plantilla no ofrece botones para cargar
Excel. El identificador `codSaber` se guarda internamente en el JSON, pero no aparece en la vista,
PDF o Word.

## Recorrido docente

1. Complete el escudo y lema opcionales.
2. Complete el encabezado administrativo oficial.
3. Seleccione ejes transversales y metodología activa.
4. Registre Contextualización y DUA sin datos personales del estudiantado.
5. En Proyección, defina periodo, diagnóstico, módulo, áreas y saberes.
6. Para Preescolar seleccione **Básico requerido** u **Óptimo**. PIA aplica la ruta oficial elegida
   de forma independiente a Módulo 1 y Módulo 2.
   Este selector permanece oculto y deshabilitado en todos los demás ciclos y niveles.
7. Consulte los RdA y los indicadores oficiales visibles por área.
8. Si necesita apoyo externo, genere el prompt semestral. La metodología se solicita como una ruta
   continua: no se reinicia en cada semana.
9. Complete cada semana manualmente. Use Anterior, Siguiente, el selector o **Ver todas**.
10. Aplique formato solamente a Mediación e Indicadores de evaluación. El indicador oficial
    permanece protegido.

## Guardar, cargar y exportar

- **Guardar:** descarga JSON v3 con el plan completo y los metadatos internos compatibles.
- **Cargar:** admite JSON v1, v2 y v3; los planes antiguos siguen funcionando.
- **Recuperar autoguardado:** restaura una copia guardada en el mismo navegador.
- **PDF/Word:** incluyen únicamente el planeamiento oficial, no Proyección ni Cobertura.
- **Word:** usa A4 horizontal; el escudo conserva 90 px de ancho máximo y altura proporcional.
- **Portable:** genera un HTML autónomo con el plan vigente.

## Seguridad y criterio profesional

PIA no envía el código, centro, plan o prompt por Internet. No incluye datos de personas asesoras,
correos o teléfonos. La selección curricular, contextualización, evaluación y aprobación final
corresponden siempre a la persona docente.
