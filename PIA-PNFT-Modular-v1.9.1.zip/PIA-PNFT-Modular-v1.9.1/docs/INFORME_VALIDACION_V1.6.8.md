# Informe de validación — PIA-PNFT Modular 1.6.8

> **Estado: validación automatizada aprobada.** La revisión humana en navegadores y Word permanece
> como comprobación recomendada antes del despliegue institucional masivo.

## 1. Alcance candidato

La versión 1.6.8 integra portada, identidad alineada, diagnóstico 0–2, Contextualización/DUA
estructurada, perfiles de implementación, escenarios tecnológicos, referencias curriculares controladas,
persistencia explícita de prompts y el formato contextual validado en 1.6.7.

No se autorizan cambios al currículo del PNFT, al encabezado administrativo, a la independencia de
PIA 1.7.x, al backend inactivo ni a la exclusión de Proyección/Cobertura en PDF y Word.

## 2. Matriz de validación

| Área | Criterio | Estado |
|---|---|---|
| Construcción | Las tres salidas se generan desde `src/` | Aprobado |
| Fuente | Referencias protegidas conservan su huella | Aprobado |
| Red | No aparecen `fetch`, XHR, WebSocket ni envío automático | Aprobado |
| Portada | Iniciar, cargar, omitir y regresar funcionan sin pérdida | Pendiente |
| Identidad | Solo escudo/lema, alineación izquierda y tamaño estable | Pendiente |
| Diagnóstico | Acepta 0–2 y sincroniza sin borrar semanas | Aprobado |
| Prompt condicional | Omite opciones no elegidas y no imprime valores neutrales | Aprobado |
| Ruta curricular | Relaciona área, saber, indicador de logro del PNFT y RdA | Aprobado |
| Contexto/DUA | Guarda campos, perfil, condiciones, tecnología y punto de partida | Aprobado |
| Privacidad | No solicita datos personales del estudiantado | Aprobado |
| Referencias | Solo catálogo PNFT, literalidad y procedencia preservadas | Aprobado |
| Semanas | Selección de referencia reversible y persistente | Aprobado |
| Prompts | General/Semestral/Semanal independientes y persistentes | Aprobado |
| Sobrescritura | Actualizar/restablecer solicita confirmación | Aprobado |
| Formato | Solo Mediación/Evaluación; logro oficial protegido | Aprobado |
| JSON | Plan anterior migra y plan nuevo conserva todo al reabrir | Aprobado |
| PDF/Word | Documento oficial sin portada/proyección/cobertura | Aprobado por contrato automatizado |
| Portable | Abre y funciona mediante `file://` | Pendiente |
| Accesibilidad | Teclado, foco, ARIA, contraste, tacto y vista angosta | Pendiente |

## 3. Casos críticos

### Caso A — edición de prompt

1. Generar el prompt semestral.
2. Añadir una solicitud docente.
3. Cerrar y reabrir el diálogo.
4. Confirmar que el texto permanece.
5. Guardar el prompt y el JSON.
6. Cerrar PIA, cargar el JSON y comprobar igualdad literal.
7. Intentar actualizar desde PIA y cancelar la sustitución.

Resultado esperado: ninguna edición desaparece y copiar/abrir una IA externa no cambia su estado.

### Caso B — referencia de otro nivel

1. Mantener el nivel administrativo vigente.
2. Seleccionar una referencia desde otro nivel del catálogo PNFT.
3. Registrar motivo y contextualización.
4. Incorporarla en una semana.
5. Guardar/cargar y exportar PDF/Word.

Resultado esperado: el nivel administrativo no cambia; texto y procedencia se conservan; la referencia
no se rotula como indicador oficial del nivel vigente.

### Caso C — contexto con tecnología limitada

1. Seleccionar un perfil y condiciones pertinentes.
2. Elegir ausencia o limitación de conectividad/dispositivos.
3. Generar los tres tipos de prompt.

Resultado esperado: aparecen solo las condiciones elegidas y se solicitan alternativas equivalentes
desconectadas sin reducir el indicador ni inventar currículo.

### Caso D — compatibilidad

1. Cargar un JSON anterior a 1.6.8.
2. Verificar semanas, módulos, saberes, Proyecto, textos y formatos.
3. Guardar como plan vigente y volver a abrir.

Resultado esperado: la migración añade valores seguros y no pierde información histórica.

## 4. Resultado automatizado

- Comando: `npm test`.
- Total: **105**.
- Aprobadas: **105**.
- Fallidas: **0**.
- Huella SHA-256 común de las tres salidas: `de256cf9a92ad22a19caf5d6dc915c016aebb0f67ac1ad39b8f9464fbae1b624`.

## 5. Validación humana

- Edge: pendiente.
- Chrome: pendiente.
- Apertura local/portable: pendiente.
- Word de escritorio: pendiente.
- Guardar como PDF: pendiente.
- Navegación por teclado y pantalla angosta: pendiente.

## 6. Dictamen

La arquitectura, construcción modular y contratos automatizados quedan aprobados. La validación humana
multinavegador y en Word continúa indicada como control previo al despliegue nacional; por ello el informe
no reemplaza la prueba de aceptación de las personas asesoras y docentes.
