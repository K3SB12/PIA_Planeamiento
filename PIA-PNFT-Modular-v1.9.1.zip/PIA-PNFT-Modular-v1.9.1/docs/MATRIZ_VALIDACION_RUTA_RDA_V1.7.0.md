# Matriz de validación curricular — Ruta hacia el RdA 1.7.0

## Objetivo

Esta matriz define la información requerida para que una relación estructural indicador–RdA pueda
pasar, mediante revisión humana, al catálogo de correspondencias pedagógicas validadas. No modifica
el currículo oficial.

## Campos obligatorios

| Campo | Regla |
|---|---|
| Identidad del indicador | Nivel + módulo + área + saber + índice/texto literal. |
| Familia curricular | Identificador exacto del catálogo longitudinal. |
| Ciclo y RdA | Ciclo, área y texto literal completo. |
| Estado | `pending-review`, `validated` o `needs-resolution`. |
| Correspondencia | Explicación técnica de la relación; no puede depender solo de palabras comunes. |
| Profundidad | Demanda cognitiva, alcance, representación, contexto y autonomía. |
| Fuente | Archivo, localizador, versión y huella cuando corresponda. |
| Revisión | Rol/autoridad, fecha y versión aprobada. |
| Límite | Declaración expresa de que la relación no certifica el RdA. |

## Criterios de aprobación

1. El indicador y el RdA coinciden carácter por carácter con la fuente incorporada en PIA.
2. Ambos pertenecen al mismo ciclo y área.
3. La explicación identifica una relación curricular concreta y respeta el alcance del nivel.
4. No incorpora aprendizajes anteriores o futuros como currículo vigente.
5. No convierte vacío, `N/A`, área ausente o fortalecimiento en indicador.
6. Incluye autoridad revisora, fecha, fuente y decisión.
7. Declara que la correspondencia es parcial y no basta por sí sola para concluir el RdA.

## Gobernanza recomendada

- Primera revisión: persona especialista curricular o asesora responsable de la familia.
- Contraste: persona docente o asesora con experiencia en el ciclo.
- Cierre: autoridad curricular definida para PIA.
- Cambio de fuente: retorno automático a `pending-review`.

## Estado inicial de 1.7.0

PIA contiene el vínculo estructural verificable de los 235 registros con su nivel, módulo, área,
familia y RdA. El catálogo de correspondencias pedagógicas inicia sin relaciones aprobadas porque no
se recibió una matriz oficial de aprobación indicador–RdA. La interfaz informa el estado pendiente y
no lo completa mediante inferencia.
