# Manual técnico — PIA-PNFT Modular 1.6.11

## Arquitectura conservada

- Frontend autónomo, clásico y ejecutable mediante `file://`.
- Fuente editable en `src/`; `index.html` y `dist/` se generan con `node scripts/build.mjs`.
- Sin backend, API, autenticación, analítica activa ni transmisión de prompts.
- `schemaVersion: 6` y migración compatible con planes anteriores.
- `PNFT_DATA`, `RDA_POR_CICLO` y los textos oficiales permanecen protegidos.

## Estado añadido

`pia.diagnostic` conserva modo, propósito, fuente de antecedentes, áreas de valoración, experiencia,
resultados generales, decisiones, prompt generado/editado y fecha de guardado.

`pia.evaluation.guidance` conserva la huella del perfil/periodo y una lista de sugerencias con estado,
semana y nota. Los estados válidos son `suggested`, `confirmed` y `discarded`.

`pia.aiReview` conserva respuestas general, semestral y por semana, además de reportes separados. Este
estado no se fusiona con `semanas`, `aiProposal` ni los campos oficiales.

## Contratos de comportamiento

- El diagnóstico tiene máximo dos lecciones y no escribe automáticamente mediación o evaluación semanal.
- Las áreas diagnósticas no se modelan como secuencia obligatoria.
- Las sugerencias evaluativas se regeneran con una huella de origen; si cambian perfil, semanas,
  diagnóstico, excepciones o Proyecto, la interfaz avisa que están desactualizadas.
- Solo una sugerencia `confirmed` pasa al prompt semestral o al prompt de la semana correspondiente.
- La auditoría de IA usa coincidencias deterministas y no modifica el planeamiento.
- Los nuevos paneles están excluidos de impresión mediante las reglas existentes de `.pia-projection`
  y `.pia-modal`; no crean secciones nuevas en PDF o Word.
- `diagnosticReadiness()` habilita únicamente el acceso al apoyo diagnóstico; no participa en la
  validación ni en la generación del prompt semestral.
- `contextHelpCatalog` centraliza las explicaciones. `showContextHelp()`, `positionContextHelp()` y
  `closeContextHelp()` administran una única ayuda efímera sin escribir en `state`.
- Los botones `data-pia-help` se atienden mediante delegación de eventos para incluir también las
  semanas creadas dinámicamente. El popover está excluido de impresión.

## Validación

```powershell
node --check src/application/enhancements.js
node --check src/domain/projection/projection-core.js
npm test
```

Las pruebas específicas se encuentran en
`tests/v1.6.10-diagnostic-evaluation-ai-review.test.mjs` y
`tests/v1.6.11-sequence-context-help.test.mjs`.
