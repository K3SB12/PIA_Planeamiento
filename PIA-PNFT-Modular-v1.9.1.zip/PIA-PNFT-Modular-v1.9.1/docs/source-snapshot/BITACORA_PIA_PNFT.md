# Bitácora técnica y funcional de PIA-PNFT

## Identificación del proyecto

- **Nombre:** PIA — Plantilla de Planeamiento Didáctico del Programa Nacional de Formación Tecnológica.
- **Propietario funcional y curricular:** Kevin Sánchez, Asesor Nacional de Informática Educativa.
- **Población usuaria:** docentes de Formación Tecnológica e Informática Educativa.
- **Modalidad de uso:** en línea mediante GitHub Pages y sin conexión mediante archivo HTML portable.
- **Sitio de referencia:** `https://k3sb12.github.io/Recurso-Plantilla-Planeamiento-/`
- **Inicio de esta bitácora:** 7 de agosto de 2026.
- **Estado del aplicativo al iniciar la bitácora:** publicado, distribuido y utilizado desde marzo de 2026.

## Propósito de la bitácora

Registrar cronológicamente cada análisis, decisión, hallazgo, cambio, prueba y resultado relacionado con PIA. La bitácora busca conservar trazabilidad técnica y curricular, facilitar futuras revisiones por equipos del MEP y permitir que agentes de desarrollo trabajen con contexto verificable.

## Reglas de actualización

1. Cada jornada debe registrarse con fecha.
2. Las entradas anteriores no deben eliminarse ni reescribirse.
3. Toda modificación curricular debe identificar nivel, módulo, área y elemento modificado.
4. Debe diferenciarse entre hallazgo, hipótesis, defecto confirmado y cambio implementado.
5. Una observación estática no debe presentarse como error confirmado hasta realizar una prueba en navegador.
6. Toda modificación debe indicar los archivos afectados.
7. Toda prueba debe registrar resultado, evidencia y entorno utilizado.
8. Los textos validados de `PNFT_DATA` y `RDA_POR_CICLO` no deben modificarse sin solicitud y aprobación expresa.
9. Debe registrarse si un cambio afecta la versión web, la versión portable o ambas.
10. Cada jornada debe cerrar con pendientes y próximo paso recomendado.

## Estados utilizados

| Estado | Significado |
|---|---|
| Registrado | Información incorporada a la bitácora |
| En análisis | Requiere revisión adicional |
| Pendiente de prueba | Hallazgo estático aún no confirmado en ejecución |
| Confirmado | Comportamiento comprobado con evidencia |
| Aprobado | Decisión autorizada por el propietario funcional |
| Implementado | Cambio incorporado al código |
| Verificado | Cambio probado contra criterios de aceptación |
| Descartado | No se continuará, indicando la razón |

---

# Entrada 001 — 7 de agosto de 2026

## 1. Objetivo de la jornada

Analizar el estado actual de PIA y establecer una ruta profesional para convertir el aplicativo monolítico en un sistema mantenible, escalable, verificable y seguro, sin modificar su funcionamiento, arquitectura visual, estilos, secciones, categorías ni contenido curricular validado.

## 2. Antecedentes confirmados

- PIA fue creado para apoyar el planeamiento docente del PNFT.
- El aplicativo se encuentra en ejecución y distribución desde marzo de 2026.
- Los docentes pueden utilizarlo en línea o almacenarlo en sus computadoras.
- No existe presupuesto para consumir APIs de inteligencia artificial.
- No se utiliza servidor de aplicación ni base de datos remota.
- La información se procesa en el navegador.
- El flujo con inteligencia artificial consiste en completar la plantilla, generar y copiar un *prompt*, abrir ChatGPT o Copilot y pegarlo manualmente.
- El aplicativo debe continuar funcionando con y sin conexión.
- La versión actual se concentra en un `index.html` embebido.

## 3. Formación y conceptos aplicados

Durante la jornada se relacionó PIA con los siguientes conceptos:

- diferencia entre *vibe coding* e ingeniería agentiva;
- modelo LLM como componente de razonamiento;
- agentes que observan, deciden, actúan y verifican;
- desarrollo dirigido por especificaciones;
- contexto persistente mediante archivos Markdown;
- uso de `info.md`, `SPEC.md`, `tasks.md` y `AGENT.md`;
- pruebas automatizadas;
- seguridad y gobernanza;
- mantenimiento y escalabilidad;
- separación de responsabilidades;
- GitHub como sistema de versiones, revisión y evidencia;
- posible revisión mediante agentes con responsabilidades diferenciadas.

## 4. Archivos recibidos y revisados

| Archivo | Uso durante la jornada | Resultado |
|---|---|---|
| `PIA_pnft.docx` | Primera fuente del código completo | Permitió inspeccionar la estructura y contenido |
| `index(2).html` | Fuente original ejecutable | Confirmado como archivo íntegro de referencia |
| `AGENT.md` del ejercicio Snake | Ejemplo de reglas para agentes | Utilizado para comprender el enfoque documental |

## 5. Verificación de equivalencia de fuentes

Se comparó el código extraído de `PIA_pnft.docx` con `index(2).html`.

**Resultado:** el contenido coincide exactamente, excluyendo únicamente líneas vacías finales. El HTML se adoptó como fuente técnica de referencia por conservar directamente codificación, saltos y caracteres.

## 6. Línea base técnica establecida

| Indicador | Resultado |
|---|---:|
| Tamaño del HTML | 290.524 bytes |
| Líneas | 5.624 |
| Declaraciones de función | 58 |
| Nombres de función únicos | 57 |
| Funciones de nivel superior | 53 |
| Funciones internas de PDF | 5 |
| Estructuras globales principales | 7 |
| Manejadores HTML detectados | 42 |
| Usos de `innerHTML` | 31 |
| Usos de `textContent` | 4 |
| Uso de `fetch` | 0 |
| Base de datos remota | No |
| APIs de IA | No |

Se realizó una comprobación sintáctica del JavaScript y no se detectaron errores de sintaxis.

## 7. Huella de integridad

Se calculó la huella SHA-256 del archivo original:

```text
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

Esta huella permitirá demostrar si el archivo de referencia permanece sin modificaciones durante las fases de diagnóstico.

## 8. Base curricular identificada

Se confirmó que `PNFT_DATA` funciona como la base de datos curricular interna y columna vertebral de PIA. Su estructura relaciona:

```text
Nivel → Módulo → Área de conocimiento → Saber → Indicadores
```

También se identificó `RDA_POR_CICLO`, que relaciona:

```text
Ciclo → Área de conocimiento → Resultado de aprendizaje
```

### Decisión curricular

`PNFT_DATA` y `RDA_POR_CICLO` se consideran contenido oficial validado y protegido. No se modificarán durante la reorganización técnica. Cualquier cambio futuro deberá especificar:

- nivel;
- módulo;
- área de conocimiento;
- elemento curricular;
- texto vigente;
- texto aprobado;
- fuente oficial;
- responsable y fecha de aprobación.

## 9. Estructuras globales documentadas

| Estructura | Función |
|---|---|
| `PNFT_DATA` | Contenido curricular por nivel, módulo y área |
| `RDA_POR_CICLO` | Resultados de aprendizaje por ciclo y área |
| `semanas` | Estado completo del planeamiento semanal |
| `saberesSeleccionados` | Consolidado conceptual |
| `saberesProcedimentalesGlobales` | Consolidado procedimental |
| `saberesActitudinalesGlobales` | Consolidado actitudinal |
| `formatoExportacion` | Formato seleccionado para exportación |

`semanas` fue identificada como el principal punto de acoplamiento: 24 funciones dependen de ella.

## 10. Flujos funcionales analizados

Se reconstruyeron los siguientes procesos:

1. Inicialización del aplicativo.
2. Selección de ciclo y nivel.
3. Creación y actualización de semanas.
4. Selección de áreas de conocimiento.
5. Recuperación de resultados de aprendizaje.
6. Presentación de saberes conceptuales.
7. Selección de saberes e indicadores.
8. Selección de saberes procedimentales y actitudinales.
9. Agregar y eliminar semanas.
10. Preservación del contenido al modificar lecciones.
11. Guardado del planeamiento en JSON.
12. Apertura y reconstrucción de un planeamiento.
13. Exportación PDF.
14. Exportación Word implementada internamente.
15. Generación del *prompt* general.
16. Generación del *prompt* semanal.
17. Apertura de ChatGPT y Copilot.
18. Descarga de la versión portable.

## 11. Hallazgos registrados

Los siguientes hallazgos provienen del análisis estático. No se modificó código.

| Código | Hallazgo | Prioridad | Estado |
|---|---|---|---|
| PIA-H001 | `ejecutarGuardarNormal()` está declarada dos veces | Alta | Pendiente de prueba |
| PIA-H002 | Los saberes se identifican principalmente por nombre, sin identidad estable de módulo y área | Crítica | En análisis |
| PIA-H003 | Posible error al desmarcar áreas debido a la estructura modular de `PNFT_DATA` | Crítica | Pendiente de prueba |
| PIA-H004 | La carga JSON no utiliza esquema, versión ni validación completa de tipos | Crítica | Registrado |
| PIA-H005 | Contenido restaurado desde JSON puede insertarse mediante `innerHTML` | Crítica | Pendiente de prueba de seguridad |
| PIA-H006 | La reconstrucción depende de temporizadores de 100 y 500 ms | Alta | Registrado |
| PIA-H007 | `exportarAPDF()` concentra 1.197 líneas y varias responsabilidades | Alta | Registrado |
| PIA-H008 | `exportarAWord()` permanece implementada, pero no se detectó una ruta activa desde la interfaz | Media | Pendiente de decisión |
| PIA-H009 | El portapapeles utiliza `document.execCommand('copy')` | Media | Registrado |
| PIA-H010 | La fuente Poppins depende de Google Fonts y cambia el comportamiento visual sin conexión | Media | Registrado |
| PIA-H011 | El HTML portable no debe asumirse como respaldo completo del plan sin comprobar valores dinámicos | Alta | Pendiente de prueba |
| PIA-H012 | La función de compatibilidad con estructuras alternativas presenta rutas incompletas | Media | Pendiente de prueba |
| PIA-H013 | Al eliminar una semana podrían desalinearse identificadores internos y orden visible | Media | Pendiente de prueba |
| PIA-H014 | Algunos campos se restauran mediante selectores dependientes del texto de ayuda | Media | Registrado |

## 12. Decisiones arquitectónicas preliminares

### PIA-D001 — No reescribir desde cero

La migración será progresiva. Primero se crearán pruebas de caracterización; luego se separarán responsabilidades.

### PIA-D002 — Mantener dos salidas desde una fuente

El repositorio modular deberá generar:

- una versión web para GitHub Pages;
- un `index.html` autónomo para uso sin conexión.

### PIA-D003 — Conservar apariencia y comportamiento

Durante la reorganización no se cambiarán estilos, categorías, secciones, textos curriculares ni funciones visibles.

### PIA-D004 — Proteger compatibilidad histórica

Los JSON generados desde marzo de 2026 deberán continuar abriendo correctamente.

### PIA-D005 — Node.js solo para desarrollo

Node.js podrá utilizarse para pruebas, construcción y automatización. El aplicativo final continuará ejecutándose en el navegador sin requerir Node.js en las computadoras docentes.

### PIA-D006 — No ejecutar todavía pruebas de estrés

Antes de ejecutar carga o estrés se deberá presentar el plan, riesgos, archivos, entorno autorizado, límites y mecanismo de detención.

## 13. Estrategia de agentes considerada

Se valoró un flujo con responsabilidades diferenciadas:

| Rol | Responsabilidad |
|---|---|
| Propietario funcional y curricular | Aprueba alcance, contenido y publicación |
| Agente coordinador | Administra especificación, tareas y trazabilidad |
| Agente desarrollador | Implementa cambios delimitados |
| Agente revisor | Revisa arquitectura y mantenibilidad |
| Agente de pruebas | Verifica criterios independientemente |
| Agente de seguridad | Analiza entradas, archivos, dependencias y exposición |

No se autorizó todavía la ejecución multiagente ni la modificación simultánea del repositorio.

## 14. Entregables producidos

| Entregable | Propósito |
|---|---|
| `ANALISIS_FUNCIONAL_PIA_PNFT.md` | Informe técnico completo de funciones, dependencias, riesgos y pruebas |
| `MAPA_FUNCIONES_PIA_PNFT.json` | Inventario legible por agentes y herramientas |
| `BITACORA_PIA_PNFT.md` | Registro cronológico iniciado en esta jornada |

## 15. Acciones no realizadas

- No se modificó `index(2).html`.
- No se modificó `PNFT_DATA`.
- No se modificó `RDA_POR_CICLO`.
- No se modificaron estilos ni interfaz.
- No se publicaron cambios en GitHub.
- No se ejecutaron pruebas de estrés.
- No se confirmó dinámicamente ningún hallazgo estático.
- No se eliminó código duplicado.
- No se creó todavía la nueva arquitectura modular.

## 16. Próximo paso recomendado

Crear pruebas de caracterización sobre la versión vigente, priorizando:

1. relación ciclo–nivel;
2. relación área–RdA;
3. relación nivel–módulo–área–saber–indicador;
4. selección y desmarcado de áreas;
5. aumento, reducción y eliminación de semanas;
6. guardado y apertura de JSON históricos;
7. generación de *prompts*;
8. exportación PDF;
9. comportamiento de la versión portable;
10. seguridad de archivos JSON manipulados.

## 17. Cierre de la jornada

Se estableció una línea base verificable del aplicativo PIA-PNFT y se documentaron sus principales funciones, dependencias y riesgos sin alterar la versión utilizada por los docentes. El proyecto queda preparado para continuar posteriormente desde la fase de pruebas de caracterización y confirmación de hallazgos.

---

# Entrada 002 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Preparar la primera entrega documental completa de PIA-PNFT para abrirla como proyecto en Visual Studio Code, conservando sin modificaciones el `index.html` original.

## 2. Aclaración de alcance confirmada

Se confirmó nuevamente que la profesionalización de PIA consiste exclusivamente en reorganizar su estructura interna para facilitar mantenimiento, persistencia y escalabilidad.

No se autoriza alterar:

- plantilla;
- estilos;
- secuencia;
- datos;
- correspondencias curriculares;
- secciones;
- categorías;
- funciones;
- JSON;
- exportaciones;
- *prompts*;
- funcionamiento en línea o sin conexión.

## 3. Decisión registrada

### PIA-D007 — Preservación absoluta del producto vigente

La futura reorganización de PIA será exclusivamente interna. Si una tarea produce una diferencia visual, funcional, curricular, secuencial o de compatibilidad, la tarea se considerará fallida y deberá revertirse.

## 4. Convención para instrucciones del agente

Se adoptó `AGENTS.md`, en plural, como archivo principal de instrucciones del proyecto para su uso con Codex en Visual Studio Code.

## 5. Archivos creados

| Archivo | Propósito |
|---|---|
| `AGENTS.md` | Reglas obligatorias y límites del agente |
| `README.md` | Instrucciones para abrir y comprender el paquete |
| `docs/info.md` | Contexto y fuente de conocimiento de PIA |
| `docs/SPEC.md` | Requisitos de equivalencia y criterios de aceptación |
| `docs/tasks.md` | Plan por fases con cambios bloqueados hasta completar pruebas |
| `BASELINE.sha256` | Huellas de las dos copias originales |
| `.gitignore` | Exclusiones básicas para futuros resultados y dependencias |

## 6. Archivos integrados

- `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`.
- `docs/MAPA_FUNCIONES_PIA_PNFT.json`.
- `docs/BITACORA_PIA_PNFT.md`.
- `index.html`.
- `reference/index.original.html`.

## 7. Estado del código

- No se modificó el código del aplicativo.
- No se modificó `PNFT_DATA`.
- No se modificó `RDA_POR_CICLO`.
- No se modificó la interfaz.
- No se ejecutaron correcciones de hallazgos.
- No se incorporaron dependencias de ejecución.

## 8. Organización de la entrega

```text
PIA-PNFT/
├── index.html
├── AGENTS.md
├── README.md
├── BASELINE.sha256
├── .gitignore
├── docs/
│   ├── info.md
│   ├── SPEC.md
│   ├── tasks.md
│   ├── ANALISIS_FUNCIONAL_PIA_PNFT.md
│   ├── MAPA_FUNCIONES_PIA_PNFT.json
│   └── BITACORA_PIA_PNFT.md
└── reference/
    └── index.original.html
```

## 9. Próximo paso recomendado

Abrir la carpeta completa en VS Code y solicitar a Codex una lectura de comprensión sin cambios. Posteriormente deberá trabajarse la tarea `PIA-T100`: diseño de la infraestructura mínima de pruebas de caracterización.

## 10. Cierre

La entrega documental queda preparada como punto de partida controlado. Las tareas de reorganización permanecen bloqueadas hasta contar con pruebas, evidencia y aprobación humana.

---

# Entrada 003 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Revisar y cerrar documentalmente la propuesta de `PIA-T100 — Diseñar infraestructura mínima de pruebas`, sin crear infraestructura, instalar dependencias, modificar el aplicativo ni ejecutar pruebas.

## 2. Archivos revisados

- `AGENTS.md`.
- `docs/info.md`.
- `docs/SPEC.md`.
- `docs/tasks.md`.
- `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`.
- `docs/BITACORA_PIA_PNFT.md`.
- `docs/MAPA_FUNCIONES_PIA_PNFT.json`.
- `BASELINE.sha256` como fuente prevista para la verificación de integridad.

## 3. Acciones realizadas

- Se confirmó que `PIA-T100` continúa siendo una tarea exclusivamente documental.
- Se definió Playwright Test como herramienta propuesta para las futuras pruebas de caracterización.
- Se propuso Node.js 24 LTS únicamente como entorno de desarrollo y pruebas.
- Se definieron la estructura prevista, los comandos, la separación de evidencias y la estrategia de integridad de la línea base.
- Se mantuvo Firefox como navegador de una fase posterior, fuera de la matriz inicial aprobable.
- Se documentaron riesgos y medidas preventivas para ventanas emergentes, descargas, portapapeles, PDF y ejecución sin conexión.

## 4. Hallazgos nuevos

No se registraron hallazgos funcionales nuevos. No se ejecutó el aplicativo ni se intentó confirmar los hallazgos `PIA-H001` a `PIA-H014`.

## 5. Decisiones tomadas

### PIA-D008 — Herramienta propuesta para caracterización

Se propone Playwright Test `1.62.1`, fijado mediante `package-lock.json`, por permitir automatización multiproyecto, capturas, ventanas emergentes, descargas, permisos de portapapeles, emulación sin conexión, servidor local y generación de reportes desde una sola dependencia de desarrollo.

### PIA-D009 — Entorno Node.js propuesto

Se propone Node.js 24 LTS, con mínimo `24.18.0` y rango restringido a la línea mayor 24. Node.js se utilizará exclusivamente durante desarrollo y pruebas; no será requisito de la versión web ni del `index.html` portable.

### PIA-D010 — Separación de resultados

Las evidencias aprobadas se conservarán separadas de resultados temporales, capturas candidatas y reportes generados. Ningún resultado temporal se convertirá automáticamente en evidencia aprobada.

### PIA-D011 — Puerta de integridad previa

Todo comando futuro de prueba deberá ejecutar primero una verificación estricta de `BASELINE.sha256`. Una discrepancia impedirá iniciar navegador o servidor y se tratará como bloqueo que requiere decisión humana.

## 6. Cambios implementados

Únicamente se añadió esta entrada documental a `docs/BITACORA_PIA_PNFT.md`. No se modificó ningún archivo del aplicativo ni se creó infraestructura de pruebas.

## 7. Pruebas ejecutadas

No se ejecutaron pruebas funcionales, visuales, offline, de carga ni de estrés. Tampoco se instalaron o ejecutaron dependencias.

## 8. Riesgos o bloqueos

- La automatización de Microsoft Edge puede estar condicionada por políticas institucionales del navegador.
- `file://` y `http://127.0.0.1` pueden aplicar permisos y restricciones diferentes; sus resultados deberán mantenerse separados.
- La exportación PDF vigente depende de ventanas y del flujo de impresión del navegador; una automatización no debe sustituir la validación humana del resultado visible.
- Las descargas de binarios de navegador requerirán red y autorización durante una futura implementación.
- Git no estuvo disponible en el entorno actual para consultar el estado del repositorio; no se utilizó ningún mecanismo alternativo que pudiera modificar archivos.

## 9. Archivos producidos o actualizados

- Actualizado: `docs/BITACORA_PIA_PNFT.md`.
- No se produjo ningún otro archivo.

## 10. Pendientes

- Obtener segunda aprobación humana de la propuesta final de `PIA-T100`.
- Solo después de esa aprobación, crear la infraestructura mínima y solicitar autorización antes de instalar dependencias o navegadores.
- Mantener `PIA-T100` como `PENDIENTE`; no se actualizó `docs/tasks.md` porque la tarea no está implementada ni verificada.

## 11. Próximo paso recomendado

Revisar y aprobar o ajustar la propuesta final detallada de `PIA-T100`. No implementar hasta recibir autorización humana expresa.

## 12. Aprobación o validación humana

El propietario aprobó únicamente continuar con el diseño documental. La implementación permanece pendiente de una segunda aprobación humana.

---

# Entrada 004 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Implementar exclusivamente la infraestructura mínima autorizada de `PIA-T100`, sin ejecutar todavía el verificador, el servidor, Playwright ni la prueba de humo.

## 2. Archivos revisados

- `.gitignore`.
- `BASELINE.sha256`.
- `index.html`.
- `reference/index.original.html`.
- Los seis destinos autorizados, para confirmar que no existían antes de crearlos.

## 3. Acciones realizadas

- Se confirmó que `node_modules/` ya estaba excluido por `.gitignore`; no fue necesario modificarlo.
- Se confirmó que ninguno de los seis archivos autorizados existía antes de su creación.
- Se crearon `package.json`, `playwright.config.mjs`, `scripts/verify-baseline.mjs`, `scripts/static-server.mjs` y `tests/smoke/opening.spec.mjs`.
- npm generó `package-lock.json` durante la instalación exacta de `@playwright/test@1.62.1` con scripts de instalación deshabilitados.
- Se configuraron únicamente los canales instalados `chrome` y `msedge`.
- Se dejó el Chromium emparejado con Playwright pendiente de autorización.
- Se configuraron aperturas separadas mediante `file://` y `http://127.0.0.1:4173/index.html`.
- La prueba de humo bloquea las conexiones a destinos externos mediante interceptación local.

## 4. Hallazgos nuevos

No se registraron hallazgos funcionales nuevos porque no se ejecutó el aplicativo. El primer intento de instalación quedó bloqueado por el modo de caché restringida del entorno y no instaló paquetes; el segundo intento autorizado completó la instalación.

## 5. Decisiones tomadas

- `@playwright/test@1.62.1` quedó como única dependencia directa de desarrollo y sin prefijos `^` o `~`.
- `package-lock.json`, versión de formato 3, conserva el árbol transitivo y sus comprobaciones de integridad.
- Node.js y Playwright se mantienen exclusivamente como herramientas de desarrollo y pruebas.
- No se instalarán ni actualizarán navegadores sin autorización separada.

## 6. Cambios implementados

- Creado: `package.json`.
- Creado: `package-lock.json`.
- Creado: `playwright.config.mjs`.
- Creado: `scripts/verify-baseline.mjs`.
- Creado: `scripts/static-server.mjs`.
- Creado: `tests/smoke/opening.spec.mjs`.
- Actualizado: `docs/BITACORA_PIA_PNFT.md`.

No se modificaron `index.html`, `reference/index.original.html`, `BASELINE.sha256`, `PNFT_DATA` ni `RDA_POR_CICLO`.

## 7. Dependencias

- Directa de desarrollo: `@playwright/test@1.62.1`.
- Transitivas: `playwright@1.62.1` y `playwright-core@1.62.1`.
- Transitiva opcional registrada en el lock para macOS: `fsevents@2.3.2`; no se instaló en Windows.

npm añadió tres paquetes en el entorno Windows, auditó cuatro entradas y comunicó cero vulnerabilidades conocidas.

## 8. Pruebas ejecutadas

No se ejecutaron pruebas. Tampoco se ejecutaron el verificador de línea base, el servidor local, Playwright ni la prueba de humo.

Las huellas se obtuvieron únicamente con `Get-FileHash`:

```text
index.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

reference/index.original.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

BASELINE.sha256
aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055
```

## 9. Riesgos o bloqueos

- Los archivos creados aún no han sido revisados mediante una fase autorizada de inspección.
- El verificador y la prueba de humo aún no han sido ejecutados.
- Chrome y Edge instalados deben validarse posteriormente con la prueba de humo.
- El Chromium emparejado con Playwright no está instalado y permanece fuera del alcance autorizado.

## 10. Archivos producidos o actualizados

Se produjeron exactamente los seis archivos autorizados y se añadió esta entrada a la bitácora. No se modificó otra documentación.

## 11. Pendientes

- Obtener autorización humana para revisar los seis archivos.
- Obtener autorización humana para ejecutar la verificación de `BASELINE.sha256`.
- No ejecutar todavía servidor, Playwright ni prueba de humo sin autorización posterior.
- Mantener `PIA-T100` sin marcar como completada hasta su verificación.

## 12. Próximo paso recomendado

Realizar una revisión de solo lectura de la infraestructura y, si se autoriza expresamente, ejecutar primero `npm run baseline:verify` antes de considerar cualquier ejecución de Playwright.

## 13. Aprobación o validación humana

La implementación mínima y la instalación de la única dependencia directa fueron autorizadas. La revisión de archivos y la ejecución del verificador permanecen pendientes de autorización.

---

# Entrada 005 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Corregir los dos hallazgos de la revisión estática de la infraestructura mínima de `PIA-T100`: separar realmente la apertura `file://` del servidor local y restringir el acceso local al único `index.html` autorizado.

## 2. Archivos revisados

- `package.json`.
- `playwright.config.mjs`.
- `tests/smoke/opening.spec.mjs`.
- `playwright.server.config.mjs`, creado durante esta jornada.
- `index.html` y `reference/index.original.html`, únicamente para comprobar sus huellas.

## 3. Acciones realizadas

- Se retiró `webServer` de `playwright.config.mjs`, que quedó dedicado a los proyectos `chrome-file` y `edge-file`.
- Se creó `playwright.server.config.mjs`, que reutiliza las reglas comunes, añade el servidor en `127.0.0.1:4173` y define únicamente `chrome-server` y `edge-server`.
- Se actualizaron los comandos `test:smoke:file` y `test:smoke:server` para indicar explícitamente su archivo de configuración.
- Se restringieron las solicitudes `file://` al `index.html` exacto del repositorio mediante `fileURLToPath()`, `resolve()` y comparación compatible con rutas de Windows.

## 4. Hallazgos nuevos

No se registraron hallazgos nuevos durante las verificaciones autorizadas.

## 5. Decisiones tomadas

- Se utilizaron dos configuraciones explícitas y portables, sin inspección de `process.argv`, variables de entorno ni comandos exclusivos de PowerShell.
- La comparación de rutas en Windows se realiza sin distinguir mayúsculas y minúsculas; en otros sistemas conserva comparación exacta.
- `package-lock.json` no se modificó porque no cambió ninguna dependencia.

## 6. Cambios implementados

- Modificado: `package.json`.
- Modificado: `playwright.config.mjs`.
- Creado: `playwright.server.config.mjs`.
- Modificado: `tests/smoke/opening.spec.mjs`.
- Actualizado después de verificar: `docs/BITACORA_PIA_PNFT.md`.

## 7. Pruebas y verificaciones ejecutadas

- `node --check playwright.config.mjs`: código de salida 0.
- `node --check playwright.server.config.mjs`: código de salida 0.
- `node --check tests/smoke/opening.spec.mjs`: código de salida 0.
- `npm run baseline:verify`: código de salida 0; dos archivos protegidos verificados.

No se ejecutaron Playwright, el servidor ni la prueba de humo.

## 8. Huellas confirmadas

```text
index.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

reference/index.original.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

## 9. Riesgos o bloqueos

- La prueba de humo todavía no ha sido ejecutada.
- La operación real de los canales instalados Chrome y Edge continúa pendiente de autorización.
- El Chromium emparejado con Playwright continúa sin instalar y fuera del alcance.

## 10. Archivos producidos o actualizados

- `package.json`.
- `playwright.config.mjs`.
- `playwright.server.config.mjs`.
- `tests/smoke/opening.spec.mjs`.
- `docs/BITACORA_PIA_PNFT.md`.

## 11. Pendientes

- Obtener autorización antes de ejecutar Playwright o la prueba de humo.
- Mantener `PIA-T100` abierta hasta completar la verificación autorizada de su infraestructura.

## 12. Próximo paso recomendado

Realizar una revisión humana de las diferencias y decidir si se autoriza la ejecución controlada de la prueba de humo por configuración y navegador.

## 13. Aprobación o validación humana

Las dos correcciones y las verificaciones sintácticas y de línea base fueron autorizadas. La ejecución de Playwright permanece pendiente.

---

# Entrada 006 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Ejecutar de forma controlada las pruebas de humo de `PIA-T100`, comenzando por la apertura directa mediante `file://` y continuando con servidor local únicamente si la primera modalidad finalizaba correctamente.

## 2. Acciones realizadas

- Se ejecutó `npm run test:smoke:file`.
- El comando ejecutó previamente `baseline:verify`, que verificó correctamente los dos archivos protegidos.
- Playwright intentó iniciar la ejecución serial de dos proyectos, pero falló antes de abrir Chrome al crear el proceso trabajador.
- Se detuvo el procedimiento; no se ejecutaron Edge ni los proyectos de servidor.
- Se conservaron los resultados temporales y se comprobó que el puerto 4173 no estuviera escuchando.

## 3. Resultado

```text
Error: spawn EPERM
errno: -4048
code: EPERM
syscall: spawn
Node.js v24.18.0
```

El fallo pertenece al entorno de creación de procesos y ocurrió antes de abrir el aplicativo. No se observaron errores de consola o página porque ningún navegador llegó a iniciarse.

## 4. Estado individual

- `chrome-file`: no ejecutado; bloqueo al iniciar el trabajador previo al navegador.
- `edge-file`: no ejecutado debido a la regla de detención.
- `chrome-server`: no ejecutado.
- `edge-server`: no ejecutado.

## 5. Evidencia

- Resultado temporal conservado: `test-results/.playwright-artifacts-0`.
- No se generó `playwright-report`.
- Puerto 4173 en escucha después del intento: no.

## 6. Huellas finales

```text
index.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

reference/index.original.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

## 7. Cambios implementados

No se modificó código ni producto. Únicamente se generó el directorio temporal de Playwright y se añadió esta entrada documental.

## 8. Riesgos o bloqueos

El entorno actual impidió que Playwright creara su proceso trabajador mediante `child_process.fork()`. Debe obtenerse autorización antes de repetir la ejecución bajo permisos diferentes o investigar mediante acciones adicionales.

## 9. Próximo paso recomendado

Solicitar validación humana y, si se autoriza, repetir únicamente `npm run test:smoke:file` con los permisos necesarios para crear el proceso trabajador. No ejecutar la modalidad servidor hasta que la modalidad directa termine correctamente.

## 10. Aprobación o validación humana

Pendiente. `PIA-T100` no puede cerrarse con la evidencia actual.

---

# Entrada 007 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Completar la ejecución controlada de las pruebas de humo mínimas de `PIA-T100` en las modalidades de apertura directa mediante `file://` y apertura mediante servidor local restringido a `127.0.0.1:4173`.

## 2. Pruebas `file://`

El reintento autorizado de `npm run test:smoke:file` ejecutó primero `baseline:verify` y finalizó correctamente:

| Proyecto | Resultado | Duración |
|---|---|---:|
| `chrome-file` | Aprobado | 2,9 s |
| `edge-file` | Aprobado | 1,1 s |

Resultado global: dos pruebas aprobadas en 14,2 s. No se inició servidor durante esta modalidad.

## 3. Pruebas mediante servidor local

Antes de ejecutar se confirmó que el puerto 4173 estaba libre. `npm run test:smoke:server` ejecutó primero `baseline:verify` y después inició temporalmente el servidor:

| Proyecto | Resultado | Duración |
|---|---|---:|
| `chrome-server` | Aprobado | 1,2 s |
| `edge-server` | Aprobado | 1,3 s |

Resultado global: dos pruebas aprobadas en 9,4 s. El proceso completo terminó con código de salida 0.

## 4. Consola, página y red

- No se detectaron errores de página.
- No se detectaron mensajes de consola de tipo error.
- Las solicitudes diferentes del `index.html` autorizado o del origen local `127.0.0.1:4173` permanecieron bloqueadas por la ruta de prueba y fueron respondidas localmente con estado 204.
- No se habilitaron conexiones a ChatGPT, Copilot, Google Fonts ni otros destinos externos.

## 5. Servidor y puerto

- Dirección autorizada: `127.0.0.1:4173`.
- Estado antes de la ejecución: libre.
- Estado después de la ejecución: sin proceso en escucha.
- El servidor temporal fue cerrado por Playwright al finalizar.

## 6. Evidencia y artefactos

- `test-results/.last-run.json`.
- `playwright-report/index.html`.

Los artefactos son resultados temporales y no se promovieron a evidencia aprobada.

## 7. Huellas finales

```text
index.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

reference/index.original.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79
```

## 8. Cambios implementados

No se modificó el producto ni la infraestructura para obtener los resultados. Únicamente se actualizaron los artefactos temporales de Playwright y se añadió esta entrada documental autorizada.

## 9. Riesgos o bloqueos

No existen bloqueos técnicos en las cuatro pruebas de humo ejecutadas. El cierre formal de `PIA-T100` permanece pendiente de validación humana.

## 10. Pendientes

- Obtener validación humana final de los resultados.
- No actualizar todavía el estado de `PIA-T100` en `docs/tasks.md`.
- No iniciar pruebas de caracterización adicionales sin autorización.

## 11. Próximo paso recomendado

Revisar humanamente los resultados y decidir si `PIA-T100` cumple sus criterios de aceptación y puede cerrarse documentalmente.

## 12. Aprobación o validación humana

Pendiente. Las cuatro pruebas de humo están aprobadas técnicamente, pero `PIA-T100` no se marca como completada hasta recibir validación humana final.

---

# Entrada 008 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Registrar la validación humana final y el cierre documental de `PIA-T100 — Diseñar infraestructura mínima de pruebas` después de verificar la infraestructura, la línea base y las cuatro pruebas de humo autorizadas.

## 2. Resultados aceptados por validación humana

| Proyecto | Resultado |
|---|---|
| `chrome-file` | Aprobado |
| `edge-file` | Aprobado |
| `chrome-server` | Aprobado |
| `edge-server` | Aprobado |

También se aceptaron expresamente:

- cero errores de página;
- cero errores de consola;
- conexiones externas bloqueadas;
- servidor local cerrado correctamente;
- huellas SHA-256 protegidas sin cambios;
- código productivo y datos curriculares intactos.

## 3. Decisiones registradas

### PIA-D012 — Navegador Chromium pendiente

Chrome estable sustituyó temporalmente al Chromium emparejado con Playwright para las pruebas iniciales. La instalación del Chromium emparejado continúa pendiente de autorización y no forma parte del cierre de `PIA-T100`.

### PIA-D013 — Restricción temporal de creación del trabajador

La primera ejecución encontró `spawn EPERM` al crear el proceso trabajador de Playwright. La restricción se resolvió mediante un permiso temporal limitado a la ejecución, sin privilegios administrativos de Windows y sin establecer reglas permanentes.

## 4. Cambios implementados

- Se cambió el estado de `PIA-T100` de `PENDIENTE` a `COMPLETADA` en `docs/tasks.md`.
- Se añadió esta entrada de cierre a `docs/BITACORA_PIA_PNFT.md`.
- No se modificó ningún archivo del producto, infraestructura o pruebas.

## 5. Verificación final

Las cuatro pruebas de humo fueron aprobadas y las dos modalidades conservaron la línea base. El servidor temporal quedó cerrado y el puerto 4173 dejó de estar en escucha después de la ejecución.

## 6. Riesgos o bloqueos

- Chromium y Firefox no están instalados para Playwright y permanecen fuera del alcance completado.
- Las pruebas realizadas son únicamente pruebas de humo; no sustituyen las tareas de caracterización posteriores.

## 7. Pendientes

- No iniciar `PIA-T101` sin autorización.
- Diseñar posteriormente `PIA-T101 — Capturar referencia visual` bajo un alcance humano aprobado.
- No instalar Chromium o Firefox sin autorización independiente.

## 8. Próximo paso recomendado

Esperar autorización humana para diseñar documentalmente `PIA-T101`, sin ejecutar todavía nuevas pruebas ni modificar el producto.

## 9. Aprobación o validación humana

Validación humana final otorgada. `PIA-T100` queda `COMPLETADA` con evidencia técnica y documental aceptada.

---

# Entrada 009 — 11 de agosto de 2026

## 1. Objetivo de la jornada

Implementar exclusivamente la infraestructura visual autorizada para `PIA-T101`, sin ejecutar Playwright, iniciar el servidor ni generar capturas.

## 2. Archivos revisados

- `package.json`.
- `package-lock.json`, únicamente para confirmar que permaneciera sin cambios.
- Configuraciones y pruebas de humo de `PIA-T100`, únicamente para preservar su separación.
- Los cuatro destinos nuevos, para confirmar que no existían antes de crearlos.

## 3. Acciones realizadas

- Se creó `playwright.visual.config.mjs` para apertura directa mediante `file://`.
- Se creó `playwright.visual.server.config.mjs` para servidor local en `127.0.0.1:4173`.
- Se creó `tests/visual/fixtures.mjs` con el escenario aprobado, datos docentes ficticios y las 12 definiciones visuales.
- Se creó `tests/visual/reference.spec.mjs` para preparar estados mediante controles visibles, bloquear la red externa, registrar fuentes efectivas y generar capturas únicamente en resultados temporales.
- Se añadieron a `package.json` los comandos `visual:file` y `visual:server`, ambos precedidos por `baseline:verify`.

## 4. Decisiones y controles implementados

- Chrome se ejecutará antes de Edge dentro de cada modalidad.
- Las modalidades `file://` y servidor utilizan configuraciones distintas.
- Cada configuración genera un `run-id` compatible con Windows.
- Los resultados se separan en `test-results/PIA-T101/file/<run-id>` y `test-results/PIA-T101/server/<run-id>`.
- Los reportes se separan de igual manera bajo `playwright-report/PIA-T101/`.
- Solo se permite por `file://` el `index.html` exacto del repositorio.
- Solo se permite por HTTP el origen `127.0.0.1:4173` y las rutas `/` o `/index.html`.
- Cualquier solicitud externa se responde localmente con estado 204 y se registra como bloqueada.
- No existe escritura automática en `evidence/approved/`.
- La preparación curricular selecciona los valores aprobados mediante controles visibles y no sustituye `PNFT_DATA` ni `RDA_POR_CICLO`.
- Los modales y la vista de exportación se alcanzan mediante botones visibles; no se invocan funciones internas.
- La previsualización de exportación se captura antes del diálogo nativo y no automatiza “Guardar como PDF”.

## 5. Cambios implementados

- Modificado: `package.json`.
- Creado: `playwright.visual.config.mjs`.
- Creado: `playwright.visual.server.config.mjs`.
- Creado: `tests/visual/reference.spec.mjs`.
- Creado: `tests/visual/fixtures.mjs`.
- Actualizado después de verificar: `docs/BITACORA_PIA_PNFT.md`.

No se modificaron `package-lock.json`, las pruebas de humo, el producto ni los datos curriculares.

## 6. Verificaciones ejecutadas

- `node --check playwright.visual.config.mjs`: código 0.
- `node --check playwright.visual.server.config.mjs`: código 0.
- `node --check tests/visual/reference.spec.mjs`: código 0.
- `node --check tests/visual/fixtures.mjs`: código 0.
- `npm run baseline:verify`: código 0; dos archivos protegidos verificados.

No se ejecutaron Playwright, el servidor ni capturas.

## 7. Revisión estática

- Se confirmaron exactamente 12 identificadores, de `VIS-001` a `VIS-012`.
- Cada identificador tiene un nombre de archivo único y aparece en un único proyecto.
- Los artefactos de PIA-T101 no sobrescriben los de PIA-T100 ni los de otra modalidad o ejecución.
- No se encontraron llamadas directas a funciones internas del aplicativo.
- No se encontraron rutas de escritura a evidencia aprobada.
- Los módulos no inician navegador, servidor ni capturas durante su importación; el archivo de prueba solo registra el caso de Playwright y mantiene las acciones dentro del callback.

## 8. Huellas finales

```text
index.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

reference/index.original.html
46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79

BASELINE.sha256
aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055
```

## 9. Riesgos o bloqueos

- La infraestructura todavía no ha sido ejecutada.
- Las capturas y la interacción real con los estados visuales permanecen pendientes de autorización.
- La apariencia conectada con Poppins continúa fuera del alcance y requerirá autorización específica.

## 10. Pendientes

- Obtener revisión humana de las diferencias.
- No ejecutar `visual:file` ni `visual:server` sin autorización.
- No actualizar todavía el estado de `PIA-T101`.

## 11. Próximo paso recomendado

Revisar estáticamente la infraestructura creada y autorizar, si corresponde, la ejecución controlada de `visual:file` antes de cualquier ejecución de servidor.

## 12. Aprobación o validación humana

La implementación de infraestructura fue autorizada. Su ejecución y la aceptación de capturas permanecen pendientes.

---

# Entrada 010 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Ejecutar una única vez `npm run visual:file`, con permiso temporal limitado a la creación de trabajadores de Playwright, para generar exclusivamente `VIS-001`, `VIS-002` y `VIS-012` mediante Chrome y Edge instalados, sin servidor, conexiones externas, instalación de navegadores ni promoción de evidencia.

## 2. Archivos revisados

- `package.json`.
- `playwright.visual.config.mjs`.
- `tests/visual/reference.spec.mjs`.
- `tests/visual/fixtures.mjs`.
- Artefactos temporales producidos bajo `test-results/PIA-T101/file/`.
- Informe temporal producido bajo `playwright-report/PIA-T101/file/`.
- `index.html`, `reference/index.original.html` y `BASELINE.sha256`, únicamente mediante comprobación de huellas.

## 3. Acciones realizadas

- Se confirmó antes de la ejecución que el puerto 4173 estaba libre.
- Se confirmó estáticamente que la configuración `file://` incluía solo `VIS-001` y `VIS-002` en Chrome, y `VIS-012` en Edge.
- Se ejecutó una única invocación de `npm run visual:file` con permiso temporal, sin privilegios administrativos ni regla permanente.
- El comando ejecutó primero `baseline:verify`, que verificó los dos archivos protegidos.
- No se repitió ninguna prueba después del fallo.
- Se conservaron e inspeccionaron en modo de solo lectura los artefactos temporales.

## 4. Resultados por captura

| Captura | Resultado | Duración de captura | Dimensiones | Tamaño | SHA-256 | Navegador |
|---|---|---:|---:|---:|---|---|
| `VIS-001` | PNG generado; proyecto fallido por error de consola | 1,246 s | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Google Chrome 151.0.7922.138 |
| `VIS-002` | PNG generado; proyecto fallido por error de consola | 0,915 s | 1366 × 6933 | 1.176.380 bytes | `bbe655710c708e2ae8f0657a8e33339dbe11f312067a4096611bc4a05ddfca0c` | Google Chrome 151.0.7922.138 |
| `VIS-012` | PNG generado; proyecto fallido por error de consola | 1,172 s | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Microsoft Edge 151.0.4129.72 |

Las duraciones anteriores corresponden a cada operación `Page.screenshot()` registrada en las trazas. La prueba completa de Chrome duró 10,987 s y la de Edge 3,949 s.

## 5. Rutas de las capturas

- `test-results/PIA-T101/file/20260812T134943303Z/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-file-1366x768/PIA-T101_VIS-001_chrome-file_1366x768_inicial-offline.png`.
- `test-results/PIA-T101/file/20260812T134943303Z/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-file-1366x768/PIA-T101_VIS-002_chrome-file_1366x768_semana-poblada.png`.
- `test-results/PIA-T101/file/20260812T135008986Z/reference-captura-la-refer-86472-a-sin-modificar-el-producto-edge-file-1366x768/PIA-T101_VIS-012_edge-file_1366x768_inicial-offline.png`.

## 6. Fuentes, consola y red

- Fuente declarada en las tres capturas: `Poppins, sans-serif`.
- Fuente renderizada: Poppins instalada localmente (`isCustomFont: false`); `Poppins-Regular` en controles y `Poppins-Italic` en los contenedores editables vacíos de `VIS-001` y `VIS-012`; `Poppins-Regular` en el contenedor editable poblado de `VIS-002`.
- Errores de página: cero en las tres capturas.
- Errores de consola: uno por captura, con el mensaje de Chromium `Unsafe attempt to load URL ... 'file:' URLs are treated as unique security origins.`.
- Única solicitud externa interceptada por captura: `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`, respondida localmente con estado 204.
- No se permitieron conexiones externas.

## 7. Resultado global y regla de detención

`baseline:verify` aprobó y Playwright generó las tres capturas. Después de escribir los PNG, ambos proyectos fallaron en la aserción que exige cero errores de consola.

El proyecto Chrome generó `VIS-001` y `VIS-002` antes de declarar el fallo. La invocación existente de Playwright continuó automáticamente con Edge dentro del mismo comando y generó `VIS-012` antes de devolver el control; no se lanzó una segunda invocación ni se repitió ninguna prueba. No se modificó la infraestructura para cambiar este comportamiento.

## 8. Identificadores de ejecución

- `run-id` del informe: `20260812T134941991Z`.
- Directorio de salida de Chrome: `20260812T134943303Z`.
- Directorio de salida de Edge: `20260812T135008986Z`.

La existencia de identificadores de salida distintos dentro de una sola invocación queda registrada como observación pendiente; no se corrigió.

## 9. Puerto, integridad y archivos modificados

- El puerto 4173 estaba libre antes y después de la ejecución.
- No se inició servidor y no se ejecutó `visual:server`.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- No se modificó el producto, la infraestructura de pruebas, `PNFT_DATA`, `RDA_POR_CICLO`, `docs/tasks.md` ni las casillas de `PIA-T100`.
- Se generaron únicamente artefactos temporales y se añadió esta entrada documental.

## 10. Riesgos o bloqueos

- Las capturas no pueden aceptarse todavía como referencia aprobada porque los proyectos finalizaron con errores de consola.
- Debe decidirse humanamente si el mensaje de aislamiento de origen `file://` es esperado para esta modalidad o si requiere una futura adaptación autorizada de la infraestructura.
- El comportamiento de los `run-id` debe revisarse antes de asumir una carpeta única por ejecución.

## 11. Pendientes y próximo paso recomendado

- Mantener `PIA-T101` como `PENDIENTE`.
- No promover las capturas a `evidence/approved/`.
- No repetir `visual:file` ni ejecutar `visual:server` sin nueva autorización.
- Revisar humanamente los artefactos y decidir el tratamiento de los errores de consola y de los identificadores de salida.

## 12. Aprobación o validación humana

La ejecución única fue autorizada. Las capturas y el resultado fallido permanecen pendientes de revisión humana; `PIA-T101` no se cierra.

---

# Entrada 011 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Corregir exclusivamente tres hallazgos de infraestructura de `PIA-T101`: clasificación estricta del diagnóstico conocido de Chromium en modalidad `file://`, generación de un único `run-id` heredado por toda la ejecución y detención ordenada Chrome → Edge, incorporando además protección explícita contra sobrescritura de capturas.

## 2. Archivos revisados

- `package.json`.
- `playwright.visual.config.mjs`.
- `playwright.visual.server.config.mjs`.
- `tests/visual/reference.spec.mjs`.
- `node_modules/playwright/cli.js`, únicamente para confirmar la ruta del CLI local ya instalado.
- `docs/tasks.md`, únicamente para confirmar el estado de `PIA-T101`.

No fue necesario modificar `tests/visual/fixtures.mjs`.

## 3. Acciones realizadas

- Se creó un lanzador Node multiplataforma que acepta únicamente `file` o `server`.
- El lanzador genera una sola vez un identificador UTC con milisegundos y sufijo aleatorio hexadecimal, lo transmite mediante `PIA_VISUAL_RUN_ID` y ejecuta el CLI local de Playwright sin utilizar *shell* ni descargar navegadores.
- El lanzador rechaza una ejecución si ya existe el directorio de resultados o el directorio de reportes correspondiente.
- Las dos configuraciones visuales ahora exigen un `PIA_VISUAL_RUN_ID` con formato estricto y ya no generan fechas durante su evaluación.
- Se añadió `maxFailures: 1`, conservando `workers: 1`, `retries: 0` y `fullyParallel: false`.
- Edge quedó declarado como dependiente del proyecto Chrome correspondiente en las modalidades `file` y servidor.
- La prueba registra todos los mensajes de consola en `console-messages.json` con captura, proyecto, canal, versión, tipo, texto, ubicación y clasificación.
- El diagnóstico conocido de Chromium solo se clasifica como `knownFileOriginMessage` cuando coinciden exactamente modalidad, tipo, texto dinámico, URL, línea, columna y canal autorizados.
- La única normalización aplicada al texto es la eliminación de un salto final `LF` o `CRLF`.
- Cualquier otro mensaje de tipo `error` continúa produciendo un fallo.
- Los errores de página y los errores de consola inesperados se comprueban al finalizar cada captura, por lo que un fallo en `VIS-001` impide generar `VIS-002`.
- Cada PNG se obtiene como búfer y se escribe con `flag: 'wx'`, que impide reemplazar un archivo existente.

## 4. Decisiones tomadas

- El `run-id` se crea antes de iniciar Playwright; configuración, proyectos, resultados, reporte y metadatos leen el mismo valor heredado.
- Las rutas de resultados y reportes se mantienen separadas bajo `file/<run-id>` y `server/<run-id>`.
- En modalidad servidor no se permite ningún error de consola, incluso si su texto coincidiera con el diagnóstico observado en `file://`.
- La dependencia de Edge respecto de Chrome formaliza el orden y evita ejecutar Edge cuando Chrome falla.
- El módulo lanzador no inicia procesos al ser importado; `spawn()` solo se alcanza bajo ejecución directa y después de validar modo, colisiones y CLI local.

## 5. Cambios implementados

- Creado: `scripts/run-visual.mjs`.
- Modificado: `package.json`, únicamente los comandos `visual:file` y `visual:server`.
- Modificado: `playwright.visual.config.mjs`.
- Modificado: `playwright.visual.server.config.mjs`.
- Modificado: `tests/visual/reference.spec.mjs`.
- Actualizado después de verificar: `docs/BITACORA_PIA_PNFT.md`.

No se modificaron `tests/visual/fixtures.mjs`, `package-lock.json`, las pruebas de humo de `PIA-T100`, `index.html`, `reference/index.original.html`, `BASELINE.sha256`, `PNFT_DATA`, `RDA_POR_CICLO`, capturas existentes ni evidencia aprobada.

## 6. Verificaciones ejecutadas

| Verificación | Resultado |
|---|---|
| `node --check scripts/run-visual.mjs` | Código 0 |
| `node --check playwright.visual.config.mjs` | Código 0 |
| `node --check playwright.visual.server.config.mjs` | Código 0 |
| `node --check tests/visual/reference.spec.mjs` | Código 0 |
| `npm run baseline:verify` | Código 0; dos archivos protegidos verificados |

No se ejecutaron Playwright, `visual:file`, `visual:server`, servidor local, navegadores ni capturas.

## 7. Revisión estática

Se confirmó:

- un único `run-id` creado por el lanzador y heredado mediante el entorno;
- ausencia de `new Date()` en las configuraciones visuales;
- ausencia de creación de procesos durante la importación del lanzador;
- rutas diferenciadas para `file` y servidor;
- rechazo previo de colisiones en resultados y reportes;
- escritura exclusiva de PNG mediante `flag: 'wx'`;
- filtro conjunto y exacto del único diagnóstico conocido;
- conservación de todos los mensajes en `console-messages.json`;
- fallo por cualquier otro error de consola;
- comprobación de errores al terminar cada captura;
- dependencia formal Chrome → Edge;
- detención global con `maxFailures: 1`;
- conservación de `workers: 1`, `retries: 0` y `fullyParallel: false`;
- mantenimiento de `PIA-T101` como `PENDIENTE`.

## 8. Hallazgos nuevos

No se identificaron nuevos hallazgos durante la revisión estática. La eficacia dinámica de las correcciones permanece pendiente de una futura ejecución autorizada.

## 9. Riesgos o bloqueos

- La corrección no ha sido ejecutada con navegador; solo cuenta con verificación sintáctica, de integridad y revisión estática.
- La clasificación exacta del mensaje y la detención efectiva antes de Edge deberán confirmarse en una repetición controlada autorizada.
- Los artefactos de la ejecución fallida anterior permanecen intactos y no fueron promovidos.

## 10. Pendientes y próximo paso recomendado

- Mantener `PIA-T101` como `PENDIENTE`.
- Obtener autorización humana antes de repetir `visual:file`.
- No ejecutar `visual:server` ni promover evidencia.
- En una futura repetición autorizada, confirmar un solo `run-id`, tres capturas sin sobrescritura, diagnóstico conocido registrado y ausencia de errores inesperados.

## 11. Aprobación o validación humana

La corrección de infraestructura fue autorizada y quedó verificada de forma sintáctica y estática. La validación dinámica permanece pendiente de autorización separada.

---

# Entrada 012 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Repetir una única vez y de forma controlada `npm run visual:file` para validar dinámicamente las correcciones de infraestructura registradas en la Entrada 011, generando exclusivamente `VIS-001`, `VIS-002` y `VIS-012` mediante Chrome y Edge instalados.

## 2. Acciones realizadas

- Se confirmó antes de la ejecución que el puerto 4173 estaba libre.
- Se comprobaron las huellas de los tres PNG del primer intento antes de iniciar la repetición.
- Se ejecutó una única invocación exacta de `npm run visual:file` con permiso temporal para crear trabajadores, sin privilegios administrativos ni reglas permanentes.
- El comando ejecutó primero `baseline:verify` y después utilizó `scripts/run-visual.mjs file`.
- No se repitió ninguna prueba, no se inició servidor y no se ejecutó `visual:server`.
- Los artefactos nuevos se inspeccionaron únicamente en modo de solo lectura.

## 3. Resultado global

```text
PIA-T101 run-id (file): 20260812T141620906Z-de20e1b1ed05
2 passed (20.2s)
Código de salida: 0
```

| Proyecto | Resultado | Duración |
|---|---|---:|
| `chrome-file-1366x768` | Aprobado | 8,435 s |
| `edge-file-1366x768` | Aprobado | 4,637 s |

El informe, ambos proyectos, los resultados y los metadatos utilizaron el mismo `run-id`.

## 4. Resultados por captura

| Captura | Resultado | Dimensiones | Tamaño | SHA-256 | Navegador |
|---|---|---:|---:|---|---|
| `VIS-001` | Aprobada | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Chrome 151.0.7922.138 |
| `VIS-002` | Aprobada | 1366 × 6933 | 1.176.380 bytes | `bbe655710c708e2ae8f0657a8e33339dbe11f312067a4096611bc4a05ddfca0c` | Chrome 151.0.7922.138 |
| `VIS-012` | Aprobada | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Edge 151.0.4129.72 |

## 5. Rutas nuevas

- `test-results/PIA-T101/file/20260812T141620906Z-de20e1b1ed05/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-file-1366x768/PIA-T101_VIS-001_chrome-file_1366x768_inicial-offline.png`.
- `test-results/PIA-T101/file/20260812T141620906Z-de20e1b1ed05/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-file-1366x768/PIA-T101_VIS-002_chrome-file_1366x768_semana-poblada.png`.
- `test-results/PIA-T101/file/20260812T141620906Z-de20e1b1ed05/reference-captura-la-refer-86472-a-sin-modificar-el-producto-edge-file-1366x768/PIA-T101_VIS-012_edge-file_1366x768_inicial-offline.png`.
- `playwright-report/PIA-T101/file/20260812T141620906Z-de20e1b1ed05/index.html`.

## 6. Consola y clasificación

`console-messages.json` conservó exactamente tres mensajes:

- `VIS-001`: tipo `error`, canal `chrome`, clasificación `knownFileOriginMessage`.
- `VIS-002`: tipo `error`, canal `chrome`, clasificación `knownFileOriginMessage`.
- `VIS-012`: tipo `error`, canal `msedge`, clasificación `knownFileOriginMessage`.

Los tres mensajes contienen el diagnóstico literal conocido de Chromium sobre orígenes únicos `file://`, la URL exacta del `index.html`, línea 0 y columna 0. No se registraron otros mensajes de consola de tipo error ni errores de página.

## 7. Fuentes y red

- Fuente declarada en las tres capturas: `Poppins, sans-serif`.
- Fuente renderizada: Poppins instalada localmente (`isCustomFont: false`).
- `VIS-001` y `VIS-012`: `Poppins-Regular` en controles y `Poppins-Italic` en el contenedor editable vacío.
- `VIS-002`: `Poppins-Regular`, incluido el contenedor editable poblado.
- Única URL externa interceptada: `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`.
- Ninguna conexión externa fue permitida; la solicitud fue respondida localmente con estado 204 por la infraestructura.

## 8. Protección de resultados e integridad

- Los tres PNG anteriores permanecen en sus directorios originales y conservaron sus huellas SHA-256.
- Los nuevos PNG se almacenaron bajo el nuevo `run-id`; no hubo sobrescritura.
- Los PNG nuevos son byte por byte idénticos a sus equivalentes del primer intento.
- El puerto 4173 permaneció libre antes y después de la ejecución.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.

No se modificaron el producto, la infraestructura, `package-lock.json`, las pruebas de humo, los datos curriculares, las capturas anteriores ni la evidencia aprobada.

## 9. Riesgos o bloqueos

No se observaron bloqueos técnicos en esta repetición. La aceptación visual de las capturas continúa pendiente de revisión humana.

## 10. Pendientes y próximo paso recomendado

- Mantener `PIA-T101` como `PENDIENTE`.
- No promover todavía las capturas a `evidence/approved/`.
- Realizar revisión visual humana de `VIS-001`, `VIS-002` y `VIS-012`.
- No ejecutar nuevas capturas ni `visual:server` sin autorización.

## 11. Aprobación o validación humana

La repetición controlada fue autorizada y aprobó técnicamente. La validación visual humana y el cierre de `PIA-T101` permanecen pendientes.

---

# Entrada 013 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Registrar la revisión visual humana de las candidatas `file://` y ejecutar una única vez `npm run visual:server` para generar exclusivamente `VIS-003` a `VIS-011` mediante el servidor local restringido a `127.0.0.1:4173`, Chrome y Edge instalados.

## 2. Validación visual humana de candidatas `file://`

La persona propietaria funcional aprobó visualmente:

- `VIS-001`.
- `VIS-002`.
- `VIS-012`.

La revisión humana confirmó:

- contenido completo;
- ausencia de superposiciones y recortes;
- escenario curricular visible en `VIS-002`;
- equivalencia visual Chrome–Edge;
- tipografía Poppins local correctamente identificada.

Las imágenes no se promovieron a `evidence/approved/` y `PIA-T101` permanece `PENDIENTE`.

## 3. Acciones realizadas para la modalidad servidor

- Se confirmó antes de la ejecución que `127.0.0.1:4173` estaba libre.
- Se confirmó que no existían resultados visuales anteriores bajo `test-results/PIA-T101/server/`.
- Se ejecutó una única invocación exacta de `npm run visual:server` con permiso temporal para crear trabajadores e iniciar el servidor local, sin privilegios administrativos ni reglas permanentes.
- El comando ejecutó primero `baseline:verify` y después utilizó `scripts/run-visual.mjs server`.
- No se repitió ninguna prueba, no se instalaron navegadores y no se modificaron archivos para obtener el resultado.
- No se automatizó el diálogo nativo “Guardar como PDF”, ni se abrieron ChatGPT o Copilot.

## 4. Resultado global

```text
PIA-T101 run-id (server): 20260812T143516931Z-405676a1a29f
4 passed (50.0s)
Código de salida: 0
```

| Proyecto | Resultado | Duración |
|---|---|---:|
| `chrome-server-1366x768` | Aprobado | 20,124 s |
| `chrome-server-1920x1080` | Aprobado | 4,713 s |
| `chrome-server-390x844` | Aprobado | 4,379 s |
| `edge-server-1366x768` | Aprobado | 4,431 s |

El informe, los cuatro proyectos, los resultados y los metadatos utilizaron el mismo `run-id`. El orden fue Chrome y posteriormente Edge.

## 5. Resultados por captura

| Captura | Resultado | Dimensiones PNG | Tamaño | SHA-256 | Navegador |
|---|---|---:|---:|---|---|
| `VIS-003` | Aprobada | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Chrome 151.0.7922.138 |
| `VIS-004` | Aprobada | 1366 × 6933 | 1.176.380 bytes | `bbe655710c708e2ae8f0657a8e33339dbe11f312067a4096611bc4a05ddfca0c` | Chrome 151.0.7922.138 |
| `VIS-005` | Aprobada | 1366 × 768 | 168.434 bytes | `f196cdde197922c51d27549f6c75a319b7c03bf25a3b430ed09f2946e12591f8` | Chrome 151.0.7922.138 |
| `VIS-006` | Aprobada | 1366 × 768 | 180.832 bytes | `f29897823bd21c1422bc4d4d9b8e6637e401a0bc19ad0e170a98dda7a4fc4679` | Chrome 151.0.7922.138 |
| `VIS-007` | Aprobada | 1366 × 768 | 169.677 bytes | `6b2f32c50195ed0130603f7634911f0c65e8ba1022b0503ff059fc14d2af243f` | Chrome 151.0.7922.138 |
| `VIS-008` | Aprobada | 1366 × 2747 | 423.917 bytes | `3812cdbd018de26383ac80996557064249da1dcebf8a1a6acaacede4614fe67f` | Chrome 151.0.7922.138 |
| `VIS-009` | Aprobada | 1920 × 6499 | 1.147.888 bytes | `d34a389ad3a3ae21238648ca5b17ac242d338b39d783864a96799a01189354d9` | Chrome 151.0.7922.138 |
| `VIS-010` | Aprobada | 626 × 10270 | 975.333 bytes | `7c24409aad124fa91cd561091691518772323aa2274df73b31cd921aab4813c5` | Chrome 151.0.7922.138 |
| `VIS-011` | Aprobada | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` | Edge 151.0.4129.72 |

`VIS-010` fue ejecutada con un *viewport* de 390 × 844. La captura completa resultó de 626 píxeles de ancho debido al ancho mínimo del contenido vigente; este resultado no se interpretó como defecto y queda pendiente de revisión visual humana.

## 6. Rutas de las capturas

- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-003_chrome-server_1366x768_inicial.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-004_chrome-server_1366x768_semana-poblada.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-005_chrome-server_1366x768_modal-exportacion.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-006_chrome-server_1366x768_modal-prompt-general.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-007_chrome-server_1366x768_modal-prompt-semanal.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1366x768/PIA-T101_VIS-008_chrome-server_1366x768_vista-exportacion.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-1920x1080/PIA-T101_VIS-009_chrome-server_1920x1080_inicial.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-chrome-server-390x844/PIA-T101_VIS-010_chrome-server_390x844_inicial.png`.
- `test-results/PIA-T101/server/20260812T143516931Z-405676a1a29f/reference-captura-la-refer-86472-a-sin-modificar-el-producto-edge-server-1366x768/PIA-T101_VIS-011_edge-server_1366x768_inicial.png`.
- Informe: `playwright-report/PIA-T101/server/20260812T143516931Z-405676a1a29f/index.html`.

## 7. Fuentes

- Familia declarada: `Poppins, sans-serif` en las nueve capturas.
- Las fuentes renderizadas fueron locales (`isCustomFont: false`); Google Fonts no fue descargada.
- `VIS-003`, `VIS-009`, `VIS-010` y `VIS-011`: `Poppins-Regular` en controles y `Poppins-Italic` en contenedores editables vacíos.
- `VIS-004`: `Poppins-Regular`, incluido el contenedor editable poblado.
- `VIS-005`: Poppins Regular y Bold en el modal, con un glifo de `Segoe UI Emoji`.
- `VIS-006` y `VIS-007`: la evidencia de Poppins local se conserva en controles y contenedores; el nodo modal consultado no reportó glifos de plataforma.
- `VIS-008`: Poppins Regular, `Segoe UI Emoji` y Arial Bold en la vista generada vigente.

## 8. Consola, página y red

- Errores de página: cero.
- Errores de consola: cero.
- `console-messages.json` quedó vacío para `VIS-009`, `VIS-010` y `VIS-011` y no registró mensajes durante `VIS-003` a `VIS-007`.
- `VIS-008` registró únicamente dos mensajes informativos de tipo `log`: `Exportando en formato: pdf` e `Iniciando exportación a PDF...`; ambos se clasificaron como `consoleMessage` y proceden del flujo vigente de PIA.
- La única URL externa registrada en `blocked-external-requests.json` fue `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`.
- La solicitud de Google Fonts fue interceptada y respondida localmente con estado 204; no se permitió ninguna conexión externa.
- No se registraron solicitudes a ChatGPT o Copilot.

## 9. Servidor, integridad y archivos modificados

- Servidor autorizado: `127.0.0.1:4173`.
- Estado antes de ejecutar: libre.
- Estado después de ejecutar: sin proceso en escucha.
- Playwright cerró el servidor temporal al finalizar.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- Se generaron únicamente artefactos temporales nuevos bajo un `run-id` inexistente y se añadió esta entrada documental.
- No se modificaron producto, infraestructura, datos curriculares, capturas anteriores, tareas ni evidencia aprobada.

## 10. Riesgos o bloqueos

No se observaron bloqueos técnicos. La aceptación visual de `VIS-003` a `VIS-011`, incluida la representación móvil de `VIS-010`, permanece pendiente de revisión humana.

## 11. Pendientes y próximo paso recomendado

- Mantener `PIA-T101` como `PENDIENTE`.
- No promover todavía imágenes a `evidence/approved/`.
- Realizar revisión visual humana de `VIS-003` a `VIS-011`.
- No ejecutar nuevas capturas ni cerrar `PIA-T101` sin autorización.

## 12. Aprobación o validación humana

Las candidatas `file://` `VIS-001`, `VIS-002` y `VIS-012` cuentan con aprobación visual humana. La ejecución de servidor aprobó técnicamente; sus nueve capturas permanecen pendientes de aprobación visual humana.

---

# Entrada 014 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Registrar la aprobación visual humana de `VIS-003` a `VIS-011`, promover los doce PNG originales `VIS-001` a `VIS-012` como línea base visual aprobada y cerrar documentalmente `PIA-T101` sin modificar el producto.

## 2. Aprobación visual humana

La persona propietaria funcional aprobó visualmente `VIS-003` a `VIS-011`. Con esta decisión, `VIS-001` a `VIS-012` cuentan con aprobación visual humana.

La revisión confirmó contenido completo, ausencia de superposiciones o recortes no documentados, escenario curricular visible en `VIS-002`, equivalencia visual Chrome–Edge y correcta identificación de Poppins local.

## 3. Archivos revisados

- Tres PNG originales, `VIS-001`, `VIS-002` y `VIS-012`, bajo el run-id de modalidad file `20260812T141620906Z-de20e1b1ed05`.
- Nueve PNG originales, `VIS-003` a `VIS-011`, bajo el run-id de modalidad server `20260812T143516931Z-405676a1a29f`.
- `docs/tasks.md`.
- `docs/BITACORA_PIA_PNFT.md`.
- `index.html`.
- `reference/index.original.html`.
- `BASELINE.sha256`.

## 4. Acciones realizadas

- Se comprobó antes de la promoción que `evidence/approved/visual/PIA-T101/` no existía y no contenía archivos previos.
- Se creó `evidence/approved/visual/PIA-T101/`.
- Se copiaron sin recomprimir, renombrar ni recodificar los doce PNG originales.
- Cada copia se creó sin permitir sobrescritura y se comparó byte por byte con su original.
- Se creó `evidence/approved/visual/PIA-T101/README.md` con inventario, metadatos, diagnósticos y observaciones de línea base.
- Se creó `evidence/approved/visual/PIA-T101/manifest.sha256` con las huellas de los doce PNG y de `README.md`; el manifiesto no se incluye a sí mismo.
- Se validaron las trece entradas del manifiesto.
- No se ejecutó nuevamente Playwright, no se generaron capturas y no se habilitó Internet.
- No se modificaron el producto, la infraestructura visual, los datos curriculares ni los resultados temporales.
- Se actualizó únicamente `PIA-T101` en `docs/tasks.md`.

## 5. Evidencia promovida

| ID | Dimensiones PNG | Tamaño | SHA-256 |
|---|---:|---:|---|
| `VIS-001` | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` |
| `VIS-002` | 1366 × 6933 | 1.176.380 bytes | `bbe655710c708e2ae8f0657a8e33339dbe11f312067a4096611bc4a05ddfca0c` |
| `VIS-003` | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` |
| `VIS-004` | 1366 × 6933 | 1.176.380 bytes | `bbe655710c708e2ae8f0657a8e33339dbe11f312067a4096611bc4a05ddfca0c` |
| `VIS-005` | 1366 × 768 | 168.434 bytes | `f196cdde197922c51d27549f6c75a319b7c03bf25a3b430ed09f2946e12591f8` |
| `VIS-006` | 1366 × 768 | 180.832 bytes | `f29897823bd21c1422bc4d4d9b8e6637e401a0bc19ad0e170a98dda7a4fc4679` |
| `VIS-007` | 1366 × 768 | 169.677 bytes | `6b2f32c50195ed0130603f7634911f0c65e8ba1022b0503ff059fc14d2af243f` |
| `VIS-008` | 1366 × 2747 | 423.917 bytes | `3812cdbd018de26383ac80996557064249da1dcebf8a1a6acaacede4614fe67f` |
| `VIS-009` | 1920 × 6499 | 1.147.888 bytes | `d34a389ad3a3ae21238648ca5b17ac242d338b39d783864a96799a01189354d9` |
| `VIS-010` | 626 × 10270 | 975.333 bytes | `7c24409aad124fa91cd561091691518772323aa2274df73b31cd921aab4813c5` |
| `VIS-011` | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` |
| `VIS-012` | 1366 × 6499 | 1.119.194 bytes | `dc3552fdaecfab33ae76479e98d1f6de77cf10756b37084dc7b86e80c28b2b69` |

Los doce archivos promovidos coincidieron byte por byte con sus originales.

Huellas documentales de la evidencia:

- `README.md`: `325afab0d21dea6694cb6a8f4b860a1c63d4502e51a64ed62ff3f455f87f254d`.
- `manifest.sha256`: `34dd218402e7dff722d22454f8ebdeaa41db5081a9ffefb39d807696fbcc4c89`.

## 6. Observaciones de línea base

Las siguientes observaciones describen el producto vigente y no se corrigieron:

1. En `VIS-005`, la parte inferior del modal de exportación excede parcialmente el viewport de 1366 × 768.
2. En `VIS-010`, el viewport es 390 × 844, pero el contenido vigente mantiene un ancho aproximado de 626 px y produce desbordamiento horizontal.
3. La referencia offline utilizó Poppins instalada localmente. En equipos sin esa fuente, el navegador podría utilizar una sustitución.
4. No se requiere una ejecución conectada para cerrar `PIA-T101`; cualquier comparación futura con Google Fonts necesitará autorización independiente.

Estas observaciones se registran como características de la línea base aprobada, no como defectos corregidos ni como autorización para modificar el producto.

## 7. Consola, página y red

- Las capturas `file://` conservaron exclusivamente el diagnóstico conocido `knownFileOriginMessage`.
- En la evidencia aprobada, la ubicación se representa como `file:///<REPOSITORY>/index.html`.
- El mensaje literal original, incluida la URL local real, permanece únicamente en los artefactos temporales de Playwright.
- No hubo otros errores de consola ni errores de página.
- La modalidad servidor no presentó errores de consola.
- `VIS-008` registró únicamente dos mensajes informativos del flujo vigente de exportación.
- La única solicitud externa interceptada fue la hoja de estilos de Google Fonts.
- Ninguna conexión externa fue permitida.
- No se abrieron ChatGPT ni Copilot.
- No se realizó una ejecución conectada.

## 8. Verificación de integridad

- Entradas esperadas en `manifest.sha256`: 13.
- Entradas validadas: 13.
- Archivos no incluidos en el manifiesto: únicamente el propio `manifest.sha256`.
- PNG comparados byte por byte con sus originales: 12 de 12.
- Colisiones o sobrescrituras: ninguna.
- Referencias a usuario, unidad local, OneDrive o ubicación institucional en `README.md`: ninguna.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.

No se modificaron `index.html`, `reference/index.original.html`, `BASELINE.sha256`, `package-lock.json`, las pruebas de humo de `PIA-T100`, `PNFT_DATA`, `RDA_POR_CICLO` ni los resultados temporales.

## 9. Archivos producidos o actualizados

- Doce PNG bajo `evidence/approved/visual/PIA-T101/`.
- `evidence/approved/visual/PIA-T101/README.md`.
- `evidence/approved/visual/PIA-T101/manifest.sha256`.
- `docs/tasks.md`.
- `docs/BITACORA_PIA_PNFT.md`.

## 10. Estado de la tarea

`PIA-T101` cumple sus criterios de captura, conservación de evidencia y aprobación visual humana. Su estado se actualizó a `COMPLETADA` y sus seis casillas se marcaron como realizadas.

No se modificaron el estado ni las casillas de `PIA-T100`. No se inició `PIA-T102`.

## 11. Riesgos o bloqueos

No quedan bloqueos para `PIA-T101`. Las observaciones de `VIS-005`, `VIS-010` y la dependencia de Poppins local permanecen documentadas como características de la línea base y no fueron corregidas.

Cualquier comparación futura conectada con Google Fonts requerirá autorización humana independiente.

## 12. Pendientes y próximo paso recomendado

- Mantener intacta la evidencia aprobada.
- No reemplazar ni recodificar los PNG promovidos.
- No iniciar `PIA-T102` sin autorización.
- Solicitar autorización independiente antes de cualquier ejecución conectada o corrección de las observaciones registradas.

## 13. Aprobación o validación humana

La persona propietaria funcional aprobó visualmente `VIS-001` a `VIS-012` y autorizó su promoción y el cierre documental de `PIA-T101` con el destino definitivo `evidence/approved/visual/PIA-T101/`.

---

# Entrada 015 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Implementar y verificar exclusivamente la infraestructura autorizada de `PIA-T102 — Caracterizar ciclo y nivel`, sin ejecutar Playwright, iniciar el servidor, generar resultados de caracterización ni modificar el producto.

## 2. Archivos revisados

- `AGENTS.md` y la documentación obligatoria del repositorio.
- `docs/MAPA_FUNCIONES_PIA_PNFT.json`.
- `index.html` y `reference/index.original.html` como fuentes vigentes e inalterables.
- `PNFT_DATA` y `RDA_POR_CICLO`, sin modificarlos, normalizarlos ni ejecutarlos.
- Las funciones y los controles relacionados con ciclos, niveles, semanas, áreas, módulos, saberes, indicadores y RdA.
- La infraestructura existente de ejecución visual y servidor local, solo como referencia de aislamiento y preservación.

## 3. Acciones realizadas

- Se creó la ficha literal de relaciones ciclo–nivel, valores internos, estructuras curriculares esperadas, cobertura por proyecto y hallazgos conocidos.
- Se implementó una prueba de caracterización que separa verificaciones estáticas, observables mediante controles visibles, diferidas hasta la selección de un área y reservadas para una tarea posterior.
- Las comprobaciones estáticas analizan literales y localizan estructuras o funciones por identidad y contenido; las líneas encontradas se conservan únicamente como metadatos observados.
- Las interacciones de interfaz se limitan a controles visibles de ciclo, nivel y área. No se invocan funciones internas del producto mediante `page.evaluate()` ni mecanismos equivalentes.
- No se pulsa Guardar, no se generan descargas, no se abren ni cargan JSON, no se usan selectores de archivos y no se desmarcan áreas.
- Se configuró Chrome servidor como proyecto canónico con `T102-01` a `T102-16` y se limitaron Edge servidor, Chrome `file://` y Edge `file://` a `T102-01`, `T102-07` y `T102-11`.
- Se conservaron `workers: 1`, `retries: 0`, `fullyParallel: false` y `maxFailures: 1`; Edge depende formalmente del proyecto Chrome de su modalidad.
- El servidor quedó declarado exclusivamente para modalidad `server` en `127.0.0.1:4173`.
- El aislamiento permite en modalidad `file` solo el `index.html` exacto por `file://`, y en modalidad `server` solo `/` o `/index.html` en `127.0.0.1:4173`. Toda otra solicitud queda interceptada localmente.
- El diagnóstico conocido de Chromium se admite solamente en modalidad `file` mediante coincidencia simultánea de tipo, texto exacto construido con la URL directa, ubicación, línea, columna y canal; todos los mensajes se conservan en los metadatos. En servidor no se permite ningún error de consola.
- Se implementó un lanzador multiplataforma que acepta únicamente `file` o `server`, crea un solo run-id UTC con milisegundos y sufijo aleatorio, usa el CLI local de Playwright, separa resultados y reportes por modalidad, rechaza directorios existentes y no inicia procesos durante la importación.
- Los resultados temporales tienen nombres diferenciados por proyecto. `cycle-level-results.json` queda reservado, sin colisión, para componer el documento agregado después de las dos ejecuciones autorizadas, sin eliminar los resultados individuales.
- `cycle-level-inventory.json` conserva una sola propiedad `"plannedLessons": "8"` dentro del estado inicial.
- Las escrituras JSON temporales usan creación exclusiva con `flag: "wx"`. La infraestructura no escribe en `evidence/approved/`.
- Se añadieron únicamente los comandos `characterization:cycle-level:file` y `characterization:cycle-level:server` a `package.json`; ambos ejecutan primero `npm run baseline:verify`.

## 4. Hallazgos preservados

Los seis hallazgos aprobados se registraron con clasificación `knownBaseline` y `automaticFailure: false`:

1. Ausencia de manejador de cambio de nivel.
2. Actualización curricular diferida.
3. Diferencia entre rótulo visible y valor `0°`.
4. Capitalización diferente del área.
5. RdA no asignado a `semana.rda`.
6. Diferencia de procedencia del mapa funcional.

Las firmas de estos hallazgos deben coincidir con el comportamiento vigente; no se corrigieron ni se ocultaron. Cualquier desviación futura de esas firmas producirá un fallo.

## 5. Cambios implementados

Archivos creados:

- `tests/characterization/cycle-level.fixture.mjs`.
- `tests/characterization/cycle-level.spec.mjs`.
- `playwright.cycle-level.config.mjs`.
- `scripts/run-characterization.mjs`.

Archivo modificado:

- `package.json`.

Registro documental actualizado:

- `docs/BITACORA_PIA_PNFT.md`.

No se modificaron `docs/tasks.md`, `package-lock.json`, la infraestructura o evidencia de `PIA-T100` y `PIA-T101`, ni archivos del producto.

## 6. Verificaciones ejecutadas

| Verificación | Resultado |
|---|---|
| `node --check tests/characterization/cycle-level.fixture.mjs` | Aprobada, código 0 |
| `node --check tests/characterization/cycle-level.spec.mjs` | Aprobada, código 0 |
| `node --check playwright.cycle-level.config.mjs` | Aprobada, código 0 |
| `node --check scripts/run-characterization.mjs` | Aprobada, código 0 |
| `npm run baseline:verify` | Aprobada: 2 archivos protegidos |

No se ejecutaron Playwright, los comandos de caracterización, navegadores ni servidor local.

## 7. Revisión estática

La revisión confirmó:

- cobertura exacta por proyecto;
- ausencia de claves duplicadas en los documentos JSON construidos y una sola propiedad `plannedLessons` en el inventario;
- nombres distintos para los cuatro resultados temporales y para el agregado final;
- ausencia de procesos, escrituras o lecturas del producto durante la simple importación de los módulos;
- separación de rutas y artefactos entre `file` y `server`;
- rechazo de colisiones y escrituras exclusivas;
- bloqueo de red y restricción exacta de la entrada `file://`;
- ausencia de llamadas directas a funciones productivas;
- ausencia de acciones de guardado, carga o descarga JSON;
- separación entre verificaciones estáticas y verificaciones mediante interfaz;
- preservación de los seis hallazgos conocidos como `knownBaseline`;
- ausencia de cualquier escritura automática en evidencia aprobada.

## 8. Verificación de integridad

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- `docs/tasks.md`: `81003b59d3c89eb576b93da3fe0affe61e255af1f1453d143fabfa7addd92fa3`.

Las huellas protegidas y los archivos expresamente excluidos permanecen intactos.

## 9. Riesgos o bloqueos

La infraestructura solo cuenta con verificación sintáctica y estática. Su comportamiento efectivo en Chrome y Edge, tanto por servidor como por `file://`, permanece sin ejecutar y requiere autorización humana independiente.

La ejecución y compatibilidad completa del guardado y la carga de JSON permanece reservada para `PIA-T105`.

## 10. Estado y próximo paso

`PIA-T102` permanece `PENDIENTE`; no se modificaron su estado ni sus casillas en `docs/tasks.md`. `PIA-T103` no se inició.

El próximo paso es esperar autorización humana antes de ejecutar cualquiera de los dos comandos de caracterización.

## 11. Aprobación o validación humana

La persona propietaria funcional aprobó el diseño final y autorizó exclusivamente la implementación y las cinco verificaciones registradas. No existe todavía autorización para ejecutar la caracterización.

---

# Entrada 016 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Ejecutar una sola vez, de forma controlada y exclusivamente en modalidad servidor, `npm run characterization:cycle-level:server`, conservar los artefactos ante cualquier fallo y mantener `PIA-T102` pendiente.

## 2. Comprobaciones previas

- El puerto `4173` se encontraba sin escucha.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- No existían `test-results/PIA-T102/server/` ni `playwright-report/PIA-T102/server/`; el lanzador comprobó además que las rutas del nuevo run-id no existían antes de crear el proceso hijo.

## 3. Ejecución autorizada

- Comando único: `npm run characterization:cycle-level:server`.
- Verificación inicial: `npm run baseline:verify`, aprobada para los dos archivos protegidos.
- Run-id único: `20260812T164050277Z-ea683c9588bc`.
- Proyectos planificados: Chrome servidor con `T102-01` a `T102-16`; Edge servidor con `T102-01`, `T102-07` y `T102-11`.
- Trabajadores reales: 1.
- Duración Playwright: `14021.302 ms`.
- Duración de la prueba Chrome: `8659 ms`.
- Resultado global: fallido, código de salida `1`.

## 4. Resultados por caso

| Proyecto | Caso | Resultado | Duración registrada |
|---|---|---|---:|
| Chrome servidor | `T102-01` | Aprobado | 621 ms |
| Chrome servidor | `T102-02` | Aprobado | 491 ms |
| Chrome servidor | `T102-03` | Aprobado | 497 ms |
| Chrome servidor | `T102-04` | Aprobado | 508 ms |
| Chrome servidor | `T102-05` | Aprobado | 527 ms |
| Chrome servidor | `T102-06` | Aprobado, dos comprobaciones | 1465 ms |
| Chrome servidor | `T102-07` | Aprobado | 1502 ms |
| Chrome servidor | `T102-08` | Fallido | 1150 ms |
| Chrome servidor | `T102-09` a `T102-16` | No ejecutados | — |
| Edge servidor | `T102-01`, `T102-07`, `T102-11` | No ejecutados; proyecto omitido por dependencia | — |

`maxFailures: 1` detuvo la matriz tras el fallo de Chrome y la dependencia formal impidió iniciar Edge. No se repitió la ejecución.

## 5. Diagnóstico del fallo

`T102-08` falló en la infraestructura al leer la instantánea curricular. El selector:

```text
#semana-1 .contenedor-editable[data-placeholder*="indicadores"]
```

resolvió dos elementos visibles: el control de indicadores y el control de evaluación cuyo `data-placeholder` también contiene la palabra “indicadores”. Playwright produjo una infracción de modo estricto en `tests/characterization/cycle-level.spec.mjs:598`.

El fallo corresponde al selector de la infraestructura de caracterización, no a un error de página, consola, red, datos curriculares o producto. No se corrigió ni se repitió.

## 6. Inventario observado antes de la detención

- Estado inicial: ciclo `Seleccionar` con valor `""`; nivel `Seleccione primero el ciclo` con valor `""`; `8` lecciones planificadas y `4` semanas calculadas.
- Ciclos: `Materno Infantil/Transición`, `I Ciclo`, `II Ciclo`, `III Ciclo`; sus rótulos y valores internos coinciden.
- Niveles: rótulo `"Grupo Interactivo II y Transición"` con valor interno y clave `0°`; `1°` a `9°` con rótulo, valor interno y clave coincidentes.
- La matriz fuente nivel → módulo → área y los conteos de saberes quedaron materializados en `cycle-level-inventory.json` para los diez niveles.
- La comparación formal completa de esa matriz correspondía a `T102-15` y no se ejecutó; por tanto, no se declara aprobada por esta ejecución parcial.

## 7. Hallazgos conocidos

Los seis hallazgos se cargaron antes de las interacciones, conservaron `classification: "knownBaseline"`, `automaticFailure: false` y `matchesBaseline: true`:

1. Ausencia de manejador de cambio de nivel.
2. Actualización curricular diferida.
3. Diferencia entre rótulo visible y valor `0°`.
4. Capitalización diferente del área.
5. RdA no asignado a `semana.rda`.
6. Diferencia de procedencia del mapa funcional.

## 8. Consola, página y red

- Navegador ejecutado: Chrome `151.0.7922.138`.
- Errores de página: ninguno.
- Mensajes de consola: ninguno.
- Solicitud externa interceptada: `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`.
- Conexiones externas permitidas: ninguna.

## 9. JSON temporales conservados

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `.last-run.json` | 96 bytes | `fb879670d9a853ad2486114eb6854891fcc51803f997fa143ddd985f33c16b04` |
| `cycle-level-inventory.json` | 15.096 bytes | `d3e280ec758b2f197bd4040750afac2863d654cb88cbbd3c5e521afee1f3d171` |
| `cycle-level-results.chrome-server.json` | 27.615 bytes | `c6381140fc8aec0298b3a92df07901f6893247915abc2c99ab8cdee5df43103d` |
| `source-fingerprints.json` | 1.459 bytes | `b42971bfb2d075bad2e6de897896e3783ce58b57de77bcd8bfe41917c54446de` |

Los tres documentos de caracterización se encuentran bajo el directorio de artefactos de Chrome del run-id. `.last-run.json` se encuentra en la raíz del run-id. No se generaron JSON de planeamiento, un resultado Edge ni el agregado final `cycle-level-results.json`.

## 10. Cierre e integridad final

- El servidor local se cerró.
- El puerto `4173` quedó sin escucha.
- Las tres huellas protegidas finales coinciden con las comprobaciones previas.
- No se modificaron el producto, los datos curriculares, la infraestructura para conseguir que pasara, `docs/tasks.md` ni evidencia aprobada.
- No se ejecutó la modalidad `file://` y no se inició `PIA-T103`.

## 11. Estado y próximo paso

`PIA-T102` permanece `PENDIENTE`. Los artefactos fallidos se conservan sin sobrescritura. Se requiere una autorización humana independiente antes de corregir el selector de infraestructura o ejecutar nuevamente la caracterización.

---

# Entrada 017 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Repetir una sola vez la caracterización completa de ciclo y nivel en modalidad servidor después de la corrección autorizada del selector de `T102-08`, preservar el run fallido anterior y mantener `PIA-T102` pendiente.

## 2. Comprobaciones previas

- Puerto `4173`: sin escucha.
- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- El único run de servidor existente era el intento fallido `20260812T164050277Z-ea683c9588bc`.
- Se fijaron antes de la repetición las huellas de sus siete artefactos temporales.
- El lanzador generó un nuevo run-id y rechazaba la ejecución si sus directorios de resultados o reporte ya existían.

## 3. Ejecución

- Comando único: `npm run characterization:cycle-level:server`.
- `baseline:verify`: aprobado antes de Playwright.
- Run-id único: `20260812T170435651Z-cf80ea05344a`.
- Resultado global: aprobado, código de salida `0`.
- Duración global Playwright: `27330.054 ms`.
- Trabajadores reales: 1.
- Orden registrado: `chrome-server` → `edge-server`.
- Chrome finalizó correctamente antes del inicio de Edge.

## 4. Cobertura y resultados

### Chrome servidor `151.0.7922.138`

| Caso | Resultado | Duración |
|---|---|---:|
| `T102-01` | Aprobado | 652 ms |
| `T102-02` | Aprobado | 507 ms |
| `T102-03` | Aprobado | 604 ms |
| `T102-04` | Aprobado | 688 ms |
| `T102-05` | Aprobado | 740 ms |
| `T102-06` | Aprobado, dos comprobaciones | 1511 ms |
| `T102-07` | Aprobado | 1482 ms |
| `T102-08` | Aprobado | 1127 ms |
| `T102-09` | Aprobado | 1502 ms |
| `T102-10` | Aprobado | 572 ms |
| `T102-11` | Aprobado | 706 ms |
| `T102-12` | Aprobado | 9 ms |
| `T102-13` | Aprobado | 13 ms |
| `T102-14` | Aprobado | 823 ms |
| `T102-15` | Aprobado | 2 ms |
| `T102-16` | Aprobado | 1 ms |

Duración del proyecto Chrome: `12680 ms`.

### Edge servidor `151.0.4129.72`

| Caso | Resultado | Duración |
|---|---|---:|
| `T102-01` | Aprobado | 782 ms |
| `T102-07` | Aprobado | 1540 ms |
| `T102-11` | Aprobado | 766 ms |

Duración del proyecto Edge: `4319 ms`.

No hubo casos omitidos, inesperados ni repetidos.

## 5. Inventario y matriz curricular

- Estado inicial observado en ambos navegadores: ciclo `Seleccionar` con valor `""`, nivel `Seleccione primero el ciclo` con valor `""`, `8` lecciones planificadas y `4` semanas.
- Los cuatro ciclos y los diez niveles, incluidos el rótulo `"Grupo Interactivo II y Transición"` y el valor interno `0°`, coincidieron con el inventario aprobado.
- `T102-15` aprobó la igualdad exacta entre la matriz esperada y la observada para los diez niveles, sus dos módulos, las áreas disponibles y los conteos de saberes.
- No se normalizó ni modificó contenido de `PNFT_DATA` o `RDA_POR_CICLO`.

## 6. Hallazgos conocidos

Los seis hallazgos conservaron en ambos proyectos `classification: "knownBaseline"`, `automaticFailure: false` y `matchesBaseline: true`:

1. Ausencia de manejador de cambio de nivel.
2. Actualización curricular diferida.
3. Diferencia entre rótulo visible y valor `0°`.
4. Capitalización diferente del área.
5. RdA no asignado a `semana.rda`.
6. Diferencia de procedencia del mapa funcional.

## 7. Consola y red

- Errores de página en Chrome y Edge: ninguno.
- Mensajes o errores de consola en Chrome y Edge: ninguno.
- Solicitud externa interceptada en ambos proyectos: `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`.
- Conexiones externas permitidas: ninguna.

## 8. JSON temporales

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `.last-run.json` | 45 bytes | `91d1c43004802cd49950d78eb11c8fa7d05da8ffffe219a8b13b2f561bc00903` |
| `cycle-level-inventory.json` | 15.096 bytes | `d3e280ec758b2f197bd4040750afac2863d654cb88cbbd3c5e521afee1f3d171` |
| `cycle-level-results.chrome-server.json` | 63.525 bytes | `15818e4337981cbc30b21e2df3dd903aefdffead2498a0ba6f43f3a9d24dbb08` |
| `source-fingerprints.json` | 1.459 bytes | `35994041ba6b1a7b481cc627f979717531413b11f63dad4316684dc0176f81ad` |
| `cycle-level-results.edge-server.json` | 11.883 bytes | `03598bf58807f9678024228a70f791a373c79e24db827849d3f8b2fb79654a93` |

No se generaron JSON de planeamiento, descargas, un resultado agregado ni evidencia aprobada.

## 9. Preservación del run fallido

El run `20260812T164050277Z-ea683c9588bc` continuó existiendo junto al nuevo run. Las siete huellas de sus artefactos temporales y las cuatro huellas principales del reporte HTML coincidieron exactamente con los valores anteriores. No hubo sobrescrituras ni eliminaciones.

## 10. Cierre e integridad final

- Servidor cerrado.
- Puerto `4173`: sin escucha.
- Las huellas finales de `index.html`, `reference/index.original.html` y `BASELINE.sha256` coinciden con las huellas protegidas.
- `package-lock.json` y `docs/tasks.md` permanecen intactos.
- No se modificaron el producto, los datos curriculares ni la infraestructura durante o después de la ejecución.
- No se ejecutó la modalidad `file://`, no se generó evidencia aprobada y no se inició `PIA-T103`.

## 11. Estado y próximo paso

`PIA-T102` permanece `PENDIENTE`. La modalidad servidor está caracterizada técnicamente; se requiere autorización humana independiente antes de ejecutar la modalidad `file://`, componer el resultado agregado o promover evidencia.

---

# Entrada 018 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Ejecutar una sola vez la caracterización representativa de ciclo y nivel mediante `file://`, comparar sus resultados con la modalidad servidor aprobada y conservar intactos los dos runs anteriores.

## 2. Comprobaciones previas

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- Puerto `4173`: sin escucha.
- No existían directorios de resultados ni reporte para `PIA-T102/file`.
- La cobertura declarada para Chrome y Edge `file` contenía exactamente `T102-01`, `T102-07` y `T102-11`; Edge dependía formalmente de Chrome.
- Se fijaron las huellas individuales de los resultados anteriores y las huellas agregadas de sus árboles de reporte.

## 3. Ejecución

- Comando único: `npm run characterization:cycle-level:file`.
- `baseline:verify`: aprobado antes de Playwright.
- Run-id único: `20260812T171236394Z-f0e5b878c299`.
- Resultado global: aprobado, código de salida `0`.
- Duración global Playwright: `15844.219 ms`.
- Trabajadores reales: 1.
- Orden: `chrome-file` → `edge-file`.
- Chrome aprobó antes del inicio de Edge.
- No se inició servidor local.

## 4. Resultados por caso

### Chrome `151.0.7922.138`

| Caso | Resultado | Duración |
|---|---|---:|
| `T102-01` | Aprobado | 665 ms |
| `T102-07` | Aprobado | 1506 ms |
| `T102-11` | Aprobado | 866 ms |

Duración del proyecto: `4889 ms`.

### Edge `151.0.4129.72`

| Caso | Resultado | Duración |
|---|---|---:|
| `T102-01` | Aprobado | 610 ms |
| `T102-07` | Aprobado | 1232 ms |
| `T102-11` | Aprobado | 974 ms |

Duración del proyecto: `3844 ms`.

No se ejecutaron `T102-02` a `T102-06`, `T102-08` a `T102-10` ni `T102-12` a `T102-16` en modalidad `file`.

## 5. Observaciones y equivalencia

- `T102-01`: ciclo `Seleccionar` con valor `""`; nivel `Seleccione primero el ciclo` con valor `""`; `8` lecciones planificadas y `4` semanas.
- `T102-07`: la secuencia `III Ciclo` → `Materno Infantil/Transición` → `I Ciclo` → `II Ciclo` produjo los mismos rótulos y valores internos de nivel que la modalidad servidor.
- `T102-11`: se observaron literalmente `Computación física y Robótica:No aplica para este ciclo.` y `No hay saberes disponibles para esta área en el nivel seleccionado`.
- La comparación de `checkId`, `expected`, `observed` y `status` fue exactamente igual para los seis pares navegador/caso frente al run canónico de servidor `20260812T170435651Z-cf80ea05344a`.

## 6. Consola, página y red

- Errores de página: ninguno.
- Mensajes de consola en Chrome: ninguno.
- Mensajes de consola en Edge: ninguno.
- El diagnóstico conocido `knownFileOriginMessage` no fue emitido por ninguno de los navegadores en esta ejecución; por ello no existe una instancia por caso que conservar. El filtro exacto permaneció configurado y no ocultó mensajes distintos.
- Solicitud externa interceptada en ambos proyectos: `https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap`.
- Conexiones externas permitidas: ninguna.
- Solo se permitió el `index.html` autorizado mediante `file://`.

## 7. JSON temporales

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `.last-run.json` | 45 bytes | `91d1c43004802cd49950d78eb11c8fa7d05da8ffffe219a8b13b2f561bc00903` |
| `cycle-level-results.chrome-file.json` | 11.887 bytes | `615b30cb04ff8630661eb60b14e4ce9fa70de8a1ce0c5ff8bb596d26c32f405f` |
| `cycle-level-results.edge-file.json` | 11.873 bytes | `b2134ce83087ffc1676ecfe880987e7290b48ee72118da0508533207b199a684` |

No se generaron JSON de planeamiento, inventarios duplicados, `cycle-level-results.json` agregado ni evidencia aprobada.

## 8. Preservación de runs anteriores

- Run fallido `20260812T164050277Z-ea683c9588bc`: las siete huellas de resultados coincidieron; su reporte conservó 22 archivos, 5.433.837 bytes y huella agregada `f4f2caef88564afdc8d77df8ce42d13b2e9ba210e2092372e96d7ccdd67ac558`.
- Run aprobado `20260812T170435651Z-cf80ea05344a`: las cinco huellas de resultados coincidieron; su reporte conservó un archivo, 537.235 bytes y huella agregada `f122c9fe394772871a220a25e6416ac4287cdae86f775ee7789da3c3789fe6a5`.
- No hubo sobrescrituras, eliminaciones ni reutilización de resultados.

## 9. Cierre e integridad final

- El servidor local nunca fue iniciado por la configuración `file`.
- Puerto `4173`: sin escucha antes y después de la ejecución.
- Las huellas protegidas finales coincidieron con las iniciales.
- `package-lock.json`, `docs/tasks.md` y el producto permanecieron intactos.
- No se modificaron `PNFT_DATA`, `RDA_POR_CICLO` ni la infraestructura para conseguir un resultado aprobado.

## 10. Estado y próximo paso

`PIA-T102` permanece `PENDIENTE`. No se compuso el resultado agregado definitivo, no se promovió evidencia y no se inició `PIA-T103`. Se requiere autorización humana independiente para cualquier siguiente paso documental o de promoción.

---

# Entrada 019 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Componer, normalizar, validar y promover la evidencia aprobada de `PIA-T102`, cerrar documentalmente la tarea y conservar intactos el producto, los datos curriculares y los resultados temporales.

## 2. Archivos revisados

- Seis artefactos temporales válidos de los runs `20260812T170435651Z-cf80ea05344a` y `20260812T171236394Z-f0e5b878c299`.
- `index.html`.
- `reference/index.original.html`.
- `BASELINE.sha256`.
- `docs/tasks.md`.
- `docs/BITACORA_PIA_PNFT.md`.

El run fallido `20260812T164050277Z-ea683c9588bc` se utilizó únicamente para confirmar su preservación temporal. Sus resultados, captura, traza y diagnóstico no se promovieron.

## 3. Acciones realizadas

- Se confirmó que `evidence/approved/characterization/PIA-T102/` no existía antes de la promoción.
- Se copió byte por byte el inventario canónico.
- Se compusieron y normalizaron los resultados de los cuatro proyectos aprobados.
- Se conservaron 16 ejecuciones canónicas, 9 ejecuciones representativas, 25 ejecuciones de caso y 26 registros internos de comprobación.
- Se conservaron los seis hallazgos con clasificación `knownBaseline`.
- Se crearon el resumen técnico, el documento recompuesto de huellas, el README y el manifiesto.
- Las rutas dependientes del equipo se normalizaron como `file:///<REPOSITORY>/index.html` y `http://127.0.0.1:4173/index.html`.
- Se rechazaron claves JSON duplicadas antes de escribir y se volvieron a comprobar después de la escritura.
- No se ejecutaron Playwright, pruebas, navegadores, servidor ni conexiones externas.

## 4. Resultados promovidos

- Chrome servidor: `T102-01` a `T102-16`.
- Edge servidor: `T102-01`, `T102-07` y `T102-11`.
- Chrome `file://`: `T102-01`, `T102-07` y `T102-11`.
- Edge `file://`: `T102-01`, `T102-07` y `T102-11`.
- Proyectos reales: 4.
- Ejecuciones canónicas: 16.
- Ejecuciones representativas: 9.
- Ejecuciones de caso: 25.
- Registros internos: 26.
- Resultados con estado `passed`: 25 de 25 ejecuciones y 26 de 26 comprobaciones.
- Resultados simulados: ninguno.

## 5. Hallazgos preservados

Los seis hallazgos aprobados conservaron `classification: "knownBaseline"`, `automaticFailure: false` y `matchesBaseline: true`:

1. Ausencia de manejador de cambio de nivel.
2. Actualización curricular diferida.
3. Diferencia entre rótulo visible y valor `0°`.
4. Capitalización diferente del área.
5. RdA no asignado a `semana.rda`.
6. Diferencia de procedencia del mapa funcional.

## 6. Consola, página y red

- Errores de página: ninguno.
- Errores inesperados de consola: ninguno.
- El diagnóstico permitido `knownFileOriginMessage` no fue emitido en el run aprobado `file://`.
- Google Fonts fue interceptado en los cuatro proyectos.
- No se permitió ninguna conexión externa.

## 7. Archivos producidos

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `README.md` | 3.414 bytes | `d44ec8b5d2f1a6f53efdbdc75a903640042cc7cc33ee1071f3e1a5313c85484a` |
| `cycle-level-inventory.json` | 15.096 bytes | `d3e280ec758b2f197bd4040750afac2863d654cb88cbbd3c5e521afee1f3d171` |
| `cycle-level-results.json` | 122.636 bytes | `86f824dc5bd184eba670feb95f02d92b591aadc04b8ff281d620f22138a6ff43` |
| `test-results-summary.json` | 3.579 bytes | `8f5b38319a86720b6b528980476796518980c5311458242955fe04f8e05ca0f4` |
| `source-fingerprints.json` | 3.762 bytes | `aac1f97c966c9f2a0df203a0d3a9cfb05a6c65773a02a7459eab175d1d2af73a` |
| `manifest.sha256` | 443 bytes | `0866fece8c8fac9fb41bdbc6b9f8159cfb64c311fcd78d070207179370efb99d` |

`manifest.sha256` contiene exactamente cinco entradas, valida los otros cinco archivos y no se incluye a sí mismo. El inventario promovido coincide byte por byte con el original canónico.

## 8. Validaciones realizadas

- JSON definitivos analizados correctamente: 4 de 4.
- Claves JSON duplicadas: ninguna.
- Proyectos/casos/comprobaciones: `4/25/26`.
- Composición: 16 ejecuciones canónicas y 9 representativas.
- Entradas del manifiesto validadas: 5 de 5.
- Hallazgos `knownBaseline`: 6.
- Información local o personal detectada en la evidencia: ninguna.
- JSON de planeamiento, trazas, capturas o `.last-run.json` promovidos: ninguno.

## 9. Integridad y preservación

- Run fallido de servidor: 7 archivos de resultados y 22 de reporte, con las mismas huellas agregadas previas.
- Run aprobado de servidor: 5 archivos de resultados y 1 de reporte, con las mismas huellas agregadas previas.
- Run aprobado `file://`: 3 archivos de resultados y 1 de reporte, con las mismas huellas agregadas previas.
- No hubo sobrescrituras, eliminaciones ni modificaciones de resultados temporales.
- No se modificaron `index.html`, `reference/index.original.html`, `BASELINE.sha256`, `package-lock.json`, `PNFT_DATA` ni `RDA_POR_CICLO`.
- No se modificaron `PIA-T100` ni `PIA-T101`.

## 10. Estado de la tarea

`PIA-T102` cumplió sus cinco criterios, la caracterización canónica y las comprobaciones representativas de equivalencia. Su estado se actualizó a `COMPLETADA`, se marcaron sus cinco casillas y se registró `evidence/approved/characterization/PIA-T102/` como evidencia aprobada.

`PIA-T103` no se inició.

## 11. Riesgos y pendientes

Los seis hallazgos `knownBaseline` permanecen documentados sin corrección. La ejecución y compatibilidad histórica completa de JSON continúa reservada para `PIA-T105`.

## 12. Aprobación humana

La persona propietaria funcional aceptó los resultados técnicos, aprobó la composición normalizada, la promoción al destino definitivo y el cierre documental de `PIA-T102`.

---

# Entrada 020 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Implementar y verificar estáticamente la infraestructura de caracterización curricular de `PIA-T103`, sin ejecutar Playwright, navegador, servidor ni comandos de caracterización y sin modificar el producto o los datos curriculares.

## 2. Archivos revisados

- `AGENTS.md` y la documentación obligatoria del repositorio.
- `index.html` y `reference/index.original.html` como fuente vigente y referencia inalterable.
- `docs/MAPA_FUNCIONES_PIA_PNFT.json` y `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`.
- Evidencia aprobada de `PIA-T102`, incluido su `manifest.sha256`.
- Infraestructura vigente de caracterización de `PIA-T102` como referencia técnica inalterada.
- `package.json` y `package-lock.json`.

## 3. Decisión humana incorporada

- La base vigente contiene `235` saberes.
- Los `235` saberes tienen exactamente un indicador.
- Existen `0` saberes con múltiples indicadores y `0` saberes sin indicador.
- No se alteraron, inyectaron, simularon ni fabricaron datos curriculares para producir un caso inexistente con múltiples indicadores.
- Los inventarios y resultados separan literalmente `2 nombres de módulo` de `20 apariciones de módulo`.

## 4. Cambios implementados

- Se creó `tests/characterization/curriculum.fixture.mjs` con conteos, relaciones, identidades, cobertura, nombres temporales y hallazgos conocidos.
- Se creó `tests/characterization/curriculum.spec.mjs` con un analizador estático de literales que no utiliza `eval`, `vm` ni ejecución del código productivo; conserva el orden y la identidad mínima `nivel + módulo + área + posición + nombre literal`.
- Se creó `playwright.curriculum.config.mjs` con `workers: 1`, `retries: 0`, `fullyParallel: false`, `maxFailures: 1`, separación `file`/`server` y dependencia formal Edge → Chrome.
- Se creó `scripts/run-curriculum-characterization.mjs` con un único run-id por comando, rechazo de colisiones y ejecución diferida bajo guarda de punto de entrada.
- Se añadieron a `package.json` únicamente `characterization:curriculum:file` y `characterization:curriculum:server`; ambos anteponen `npm run baseline:verify`.
- Los JSON temporales previstos se escribirán mediante creación exclusiva `flag: "wx"`; no existe composición ni promoción automática de evidencia.

## 5. Cobertura configurada

- Chrome servidor: `T103-01` a `T103-17`.
- Edge servidor: `T103-09` y `T103-16`.
- Chrome `file://`: `T103-08` y `T103-16`.
- Edge `file://`: `T103-09`.
- Chrome debe completar antes de Edge en ambas modalidades.
- La modalidad servidor es la única que puede iniciar `node scripts/static-server.mjs` en `127.0.0.1:4173`.
- La modalidad `file://` admite únicamente el `index.html` protegido.

## 6. Conteos incorporados

- Ciclos: `4`.
- Niveles: `10`.
- Nombres de módulo: `2 nombres de módulo`.
- Apariciones de módulo: `20 apariciones de módulo`.
- Nombres de área: `4`.
- Apariciones nivel–módulo–área: `55`.
- Combinaciones nivel–módulo–área ausentes: `25`.
- RdA: `16`.
- Apariciones de saber: `235`; nombres únicos: `103`.
- Nombres repetidos: `58`, distribuidos en `190` apariciones; apariciones con nombre no repetido: `45`.
- Indicadores: `235`; textos únicos: `232`.
- Saberes con exactamente un indicador: `235`; con múltiples indicadores: `0`; sin indicador: `0`.

## 7. Hallazgos y riesgos preservados

- Se conservan como `knownBaseline` los seis hallazgos documentados por `PIA-T102`.
- Se conservan como `knownBaseline` `PIA-H002`, `PIA-H003`, `PIA-H012`, `PIA-H014` y la distribución vigente de un indicador por saber.
- La infraestructura no desmarca áreas, no selecciona saberes homónimos, no cambia ciclo o nivel después de poblar una semana y no reproduce deliberadamente esos hallazgos.
- Guardado y carga JSON, semanas, exportaciones, prompts, funcionamiento offline y selección de homónimos permanecen reservados para tareas posteriores.

## 8. Verificaciones realizadas

| Verificación | Resultado |
|---|---|
| `node --check tests/characterization/curriculum.fixture.mjs` | Aprobada |
| `node --check tests/characterization/curriculum.spec.mjs` | Aprobada |
| `node --check playwright.curriculum.config.mjs` | Aprobada |
| `node --check scripts/run-curriculum-characterization.mjs` | Aprobada |
| `npm run baseline:verify` | Aprobada; 2 archivos protegidos |
| Manifiesto aprobado de `PIA-T102` | Aprobado; 5 de 5 entradas |
| Revisión estática de cobertura, orden, run-id, colisiones, red, restricciones y escrituras | Aprobada |

No se ejecutaron Playwright, navegadores, servidor, `characterization:curriculum:file`, `characterization:curriculum:server` ni ninguna caracterización.

## 9. Integridad final

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- La infraestructura de `PIA-T102` conserva sus cuatro huellas previas.
- No existen `test-results/PIA-T103/`, `playwright-report/PIA-T103/` ni `evidence/approved/characterization/PIA-T103/`.
- No hay procesos relacionados ni escucha en el puerto `4173`.

## 10. Estado y próximo paso

`PIA-T103` permanece `PENDIENTE`; `docs/tasks.md` no fue modificado. Se requiere una nueva autorización humana antes de ejecutar cualquiera de los dos comandos de caracterización.

---

# Entrada 021 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Revisar en profundidad la infraestructura recién implementada de `PIA-T103`, abstenerse de ejecutar la versión defectuosa y corregir exclusivamente los hallazgos autorizados `B-01`, `B-02`, `B-03`, `I-01` y `M-01` antes de cualquier caracterización.

## 2. Hallazgos revisados

- `B-01`: el localizador anterior aceptaba la primera coincidencia textual y no demostraba ausencia de ambigüedad o duplicación.
- `B-02`: `normalizeVisibleText()` colapsaba espacios y saltos de contenidos curriculares observados.
- `B-03`: parte de `observed`, incluida la selección de áreas, procedía de la definición esperada y no de los controles.
- `I-01`: un caso podía insertar un resultado `passed` y después otro `failed` si aparecía un diagnóstico.
- `I-02`: la Entrada 020 registró una aprobación estática anterior a la revisión más profunda; por la inmutabilidad de la bitácora no se reescribió.
- `M-01`: el título de un saber se localizaba mediante el selector parcial de estilo `div[style*="font-weight: 500"]`.

## 3. Decisiones

- No se ejecutaron Playwright, navegadores, servidor ni comandos de caracterización mientras existían los hallazgos.
- La Entrada 020 se conservó intacta. `I-02` se resuelve documentalmente mediante esta nueva entrada, que deja constancia del alcance real de la revisión posterior.
- No se modificaron el producto, la referencia, los datos curriculares, la configuración, el lanzador, las tareas ni la infraestructura o evidencia de tareas anteriores.

## 4. Correcciones aplicadas

- Se añadió un escáner léxico local, sin dependencias, que examina bloques `<script>`, enmascara comentarios de línea, comentarios de bloque, cadenas simples, cadenas dobles y plantillas literales, reúne los símbolos reales y exige exactamente una declaración o función.
- `PNFT_DATA` y `RDA_POR_CICLO` deben existir exactamente una vez, iniciar con un objeto literal y tener un cierre inequívoco; el analizador literal vigente continúa comprobando su contenido y sus claves duplicadas.
- Las funciones consultadas por la caracterización y los controles/metadatos localizados deben aparecer exactamente una vez.
- Se eliminó `normalizeVisibleText()` de los contenidos curriculares. El resultado distingue `sourceText`, `domTextContent` y `visibleInnerText`; no usa `trim`, reemplazo general de espacios ni normalización de saltos para RdA, saberes o indicadores.
- El fixture incorporó, para cada escenario visible, rótulo y valor interno esperados de ciclo y nivel.
- La prueba observa realmente `#ciclo option:checked`, `#nivel option:checked`, los checkboxes de área marcados, sus rótulos y sus valores.
- Los resultados de interfaz separan `expected`, `observedFromControls`, `observedFromDom` y `staticIdentity`.
- `T103-16` y `T103-17` exigen una sola coincidencia seleccionable en el DOM y observan nombre, módulo `M1`/`M2`, indicador y estado marcado; la posición y demás componentes no visibles permanecen como identidad estática.
- Los errores de página y consola se comprueban antes de crear un resultado aprobado. Cada caso tiene un único punto de inserción en `results`; los diagnósticos tardíos cambian a `failed` el resultado afectado y el proyecto.
- Se comprueban orden exacto de `plannedCaseIds`, cantidad de resultados y ausencia de identificadores duplicados.
- El selector parcial de estilo se sustituyó por la relación estructural `.saber-conceptual-item` → contenedor directo → `.indicador-logro`, su elemento hermano de título y el distintivo directo `M1`/`M2`, exigiendo una coincidencia en cada nivel.

## 5. Preservación curricular y cobertura

- Cobertura conservada: Chrome servidor `T103-01` a `T103-17`; Edge servidor `T103-09` y `T103-16`; Chrome `file://` `T103-08` y `T103-16`; Edge `file://` `T103-09`.
- Conteos conservados: 4 ciclos, 10 niveles, 2 nombres de módulo, 20 apariciones de módulo, 4 nombres de área, 55 apariciones nivel–módulo–área, 25 combinaciones ausentes, 16 RdA, 235 saberes, 103 nombres únicos, 58 nombres repetidos, 190 apariciones de nombres repetidos, 235 indicadores y 232 textos de indicador únicos.
- Los 235 saberes mantienen exactamente un indicador; existen cero con múltiples indicadores y cero sin indicador.
- No se añadieron dependencias ni se fabricaron, transformaron o ejecutaron datos curriculares.

## 6. Verificaciones realizadas

| Verificación | Resultado |
|---|---|
| `node --check tests/characterization/curriculum.fixture.mjs` | Aprobada |
| `node --check tests/characterization/curriculum.spec.mjs` | Aprobada |
| `npm run baseline:verify` | Aprobada; 2 archivos protegidos |
| Ausencia de `normalizeVisibleText()` en contenido curricular | Confirmada |
| Ausencia de copia de `definition.areas` hacia `observed` | Confirmada |
| Único punto `results.push()` posterior a diagnósticos | Confirmado |
| Ausencia del selector parcial de estilo y de selectores posicionales | Confirmada |
| Rechazo explícito de ausencia y multiplicidad de símbolos | Confirmado |
| Cobertura y conteos curriculares | Conservados |
| Dependencias | Sin cambios |

No se ejecutaron Playwright, `characterization:curriculum:server`, `characterization:curriculum:file`, navegador, servidor ni ninguna caracterización.

## 7. Integridad y estado

- Las huellas protegidas de `index.html`, `reference/index.original.html`, `BASELINE.sha256` y `package-lock.json` coinciden con la línea base.
- `package.json`, `playwright.curriculum.config.mjs` y `scripts/run-curriculum-characterization.mjs` permanecen intactos.
- No existen `test-results/PIA-T103/`, `playwright-report/PIA-T103/` ni `evidence/approved/characterization/PIA-T103/`.
- No hay procesos relacionados ni escucha en el puerto `4173`.
- `PIA-T103` permanece `PENDIENTE`; se requiere autorización humana independiente antes de ejecutar la infraestructura corregida.

---

# Plantilla para próximas entradas

## Entrada NNN — Fecha

### Objetivo

### Archivos revisados

### Acciones realizadas

### Funciones o módulos analizados

### Hallazgos nuevos

| Código | Hallazgo | Prioridad | Estado |
|---|---|---|---|

### Decisiones tomadas

### Cambios implementados

### Pruebas ejecutadas

| Prueba | Entorno | Resultado | Evidencia |
|---|---|---|---|

### Riesgos o bloqueos

### Archivos producidos o actualizados

### Pendientes

### Próximo paso recomendado

### Aprobación o validación humana

---

# Entrada 022 — 12 de agosto de 2026

## 1. Objetivo de la jornada

Corregir exclusivamente los defectos pendientes `B-01`, `B-03` e `I-01`, incluida la preservación diagnóstica ante un fallo inicial de `readSourceModel()`, verificar las diez condiciones de salida autorizadas y ejecutar una sola vez la caracterización de currículo mediante servidor únicamente si todas ellas se cumplían.

## 2. Archivos revisados

- `tests/characterization/curriculum.spec.mjs`.
- `tests/characterization/curriculum.fixture.mjs`, solo para contraste; permaneció intacto.
- `playwright.curriculum.config.mjs`, solo para confirmar orden, dependencia y detención.
- `scripts/run-curriculum-characterization.mjs`, solo para confirmar el lanzador autorizado.
- `package.json`, solo para confirmar el comando autorizado.
- `index.html`, `reference/index.original.html`, `BASELINE.sha256` y `package-lock.json`, únicamente para comprobar huellas.

## 3. Defectos pendientes y corrección aplicada

- `B-01`: se sustituyó el enmascarado lineal de plantillas por una pila de contextos de código, plantilla e interpolación; se añadieron retorno temporal a código dentro de `${...}`, plantillas e interpolaciones anidadas y rechazo de llaves sobrantes o sin cierre. No se añadieron dependencias ni se usaron `eval`, `vm`, `Function` o ejecución de código productivo.
- `B-03`: `observedFromDom.selection` quedó limitado a valores leídos del DOM; `sameNameOccurrencesInLevel` pasó a `staticAnalysis` y la presentación construida esperada pasó a `expectedPresentation`. La identidad curricular continúa separada en `staticIdentity`.
- `I-01`: cada caso prepara sus metadatos antes de comenzar; el `catch` usa solo datos ya disponibles, conserva la excepción original mediante serialización defensiva, define siempre `finalResult` y mantiene un único `results.push(finalResult)`.
- Fallo previo a casos: `readSourceModel()` y la preparación susceptible de excepción se movieron al ámbito protegido. El documento de resultado distingue `preparation`, no fabrica resultados de casos no iniciados e intenta conservar diagnósticos sin sustituir el fallo primario si una escritura secundaria también falla.

`B-02`, `M-01` e `I-02` no se modificaron nuevamente.

## 4. Verificaciones previas

| Verificación | Resultado |
|---|---|
| `node --check tests/characterization/curriculum.spec.mjs` | Aprobada |
| `node --check tests/characterization/curriculum.fixture.mjs` | Aprobada |
| 14 muestras en memoria del localizador | 14/14 aprobadas |
| Segunda declaración dentro de interpolación anidada | Rechazada por multiplicidad |
| Llave de cierre sobrante | Rechazada |
| Conservación byte por byte del literal extraído | Confirmada |
| `npm run baseline:verify` | Aprobada; 2 archivos protegidos |
| Separación `expected`/`observed` | Confirmada estáticamente |
| `catch` sin `getSourceEntries()` ni `readSourceModel()` | Confirmado |
| `readSourceModel()` dentro del ámbito protegido | Confirmado |
| Puntos `results.push()` | Uno |
| Puerto `4173` antes de ejecutar | Libre |
| Artefactos previos de `PIA-T103` | Inexistentes |
| Huellas protegidas | Coincidentes |

Al cumplirse las diez condiciones, se ejecutó una sola vez `npm run characterization:curriculum:server`.

## 5. Ejecución de servidor

- Run-id único: `20260812T205414114Z-1ca18f7ee107`.
- `baseline:verify` se ejecutó primero y aprobó.
- Chrome inició el único proyecto canónico, pero falló durante la preparación, antes de comenzar `T103-01`.
- Error literal: `JavaScript truncado: estado final template.`
- Ubicación: `maskNonCodeJavaScript()`, al analizar estáticamente `index.html` desde `readSourceModel()`.
- El diagnóstico posterior identificó que la estructura vigente contiene una expresión regular dentro de una interpolación de plantilla (`fecha.replace(/\//g, '-')`); el escáner no distingue literales de expresión regular y puede interpretar parte de esa secuencia como comentario de línea, perdiendo el cierre de la interpolación y de la plantilla.
- Resultado global: fallido, código de salida `1`.
- `maxFailures: 1` detuvo la matriz.
- Edge no se ejecutó.
- No se ejecutó ningún caso `T103-01` a `T103-17` y no se fabricaron resultados de casos.
- No se corrigió ni se repitió después del fallo.

## 6. Artefactos y estado final

- Se conservaron los artefactos disponibles bajo `test-results/PIA-T103/server/20260812T205414114Z-1ca18f7ee107/` y `playwright-report/PIA-T103/server/20260812T205414114Z-1ca18f7ee107/`.
- El resultado temporal accesible en `test-results` es `.last-run.json`, con estado `failed`; el reporte HTML conserva el contexto, la captura y la traza del fallo.
- No se generó evidencia aprobada ni resultado agregado.
- El servidor terminó; el puerto `4173` quedó sin escucha y no permanecen procesos relacionados.
- Las huellas protegidas permanecen intactas.
- `PIA-T103` continúa `PENDIENTE`.
- No se ejecutó la modalidad `file://` y no se inició `PIA-T104`.

## 7. Próximo paso

Esperar una autorización humana independiente para revisar y, si se aprueba, corregir el tratamiento de literales de expresión regular del localizador. No ejecutar ni repetir la caracterización actual.

---

# Entrada 023 — 17 de agosto de 2026

## 1. Objetivo de la jornada

Reanudar `PIA-T103` desde el fallo documentado en la Entrada 022, sustituir el analizador general de JavaScript por un extractor curricular mínimo condicionado por la línea base protegida, aprobar siete comprobaciones previas y ejecutar una sola vez la caracterización mediante servidor. La modalidad `file://`, la composición de evidencia y `PIA-T104` quedaban condicionadas a la aprobación completa del servidor.

## 2. Archivos revisados

- `AGENTS.md` y toda la documentación obligatoria, en el orden establecido.
- `index.html`, `reference/index.original.html`, `BASELINE.sha256` y `package-lock.json`.
- `tests/characterization/curriculum.fixture.mjs`.
- `tests/characterization/curriculum.spec.mjs`.
- `playwright.curriculum.config.mjs`.
- `scripts/run-curriculum-characterization.mjs`.
- `package.json`.
- Los resultados y el reporte del run fallido `20260812T205414114Z-1ca18f7ee107`.
- Los resultados y el reporte del nuevo run `20260817T150325868Z-1d2f1077bc4d`.

## 3. Confirmaciones iniciales de solo lectura

- `index.html` y `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Procesos Node relacionados: ninguno.
- Puerto `4173`: sin escucha.
- Evidencia aprobada previa de `PIA-T103`: inexistente.
- Run fallido de la Entrada 022: presente bajo su run-id original, con 5 archivos de resultados y 22 archivos de reporte; `.last-run.json` conservó la huella `d0e3f3d2f0c4ce21eae2d9cc16f9f76dc028be2cad72f2f3e7cbf7204ca13ae6`.

Git continuó sin estar disponible en el entorno. La inspección de línea de comandos de procesos mediante CIM fue denegada por el sistema; se utilizaron la ausencia de procesos Node, el estado del puerto y la enumeración de procesos instalados como controles no invasivos.

## 4. Sustitución del analizador

- Se eliminó de `curriculum.spec.mjs` el escáner general `maskNonCodeJavaScript()` y sus localizadores generales de bloques, símbolos y funciones.
- Se creó `tests/characterization/curriculum-source-extractor.mjs`.
- El extractor nuevo admite exclusivamente `PNFT_DATA` y `RDA_POR_CICLO`.
- Antes de localizar o analizar un literal, exige la huella exacta del HTML protegido.
- Cada literal se delimita mediante declaración, cierre y límite posterior literales propios de la línea base aprobada.
- Cada literal debe coincidir además con su huella curricular protegida.
- El análisis posterior admite únicamente valores literales y conserva la detección de claves duplicadas; no utiliza `eval`, `vm`, `Function` ni ejecución del código productivo.
- Las secciones funcionales requeridas para metadatos y firmas se leen por los intervalos documentados en el mapa funcional, después de aprobar la huella completa del HTML; ya no se analiza la gramática general de JavaScript.
- Se creó `scripts/verify-curriculum-extractor.mjs` para ejecutar siete comprobaciones reproducibles.

Durante la primera invocación del verificador, antes de cualquier navegador, se detectó que un ancla nueva usaba `de formatoExportacion` en lugar del texto literal `DE formatoExportacion`. Se corrigió exclusivamente esa ancla y se repitió el verificador previo. No se inició Playwright, navegador o servidor durante ese intento.

## 5. Siete comprobaciones previas

El verificador finalizó con `7/7` y estado `passed`:

1. huella literal de `PNFT_DATA` vigente;
2. huella literal de `RDA_POR_CICLO` vigente;
3. ausencia de claves duplicadas en `PNFT_DATA`;
4. ausencia de claves duplicadas en `RDA_POR_CICLO`;
5. igualdad literal de `PNFT_DATA` entre producto y referencia;
6. igualdad literal de `RDA_POR_CICLO` entre producto y referencia;
7. rechazo de una fuente alterada antes de extraer datos.

También aprobaron las comprobaciones sintácticas de los dos archivos nuevos, `curriculum.spec.mjs`, el fixture, la configuración y el lanzador. `npm run baseline:verify` aprobó los dos archivos protegidos.

## 6. Ejecución única de servidor

- Comando único: `npm run characterization:curriculum:server`.
- Run-id: `20260817T150325868Z-1d2f1077bc4d`.
- `baseline:verify`: aprobado antes de Playwright.
- Trabajadores: 1.
- Chrome: `151.0.7922.138`.
- Preparación del modelo curricular: aprobada.
- `T103-01` a `T103-15`: aprobados.
- `T103-16`: fallido.
- `T103-17`: no ejecutado.
- Edge: no ejecutado por `maxFailures: 1` y dependencia formal.
- Resultado global: fallido, código de salida `1`.
- La ejecución no se repitió.

## 7. Diagnóstico del fallo

`T103-16` falló al intentar localizar para selección el saber `Mecánica aplicada a la robótica` mediante su indicador exacto. La instantánea accesible conservada en `error-context.md` demuestra que el DOM sí contenía tanto el saber como el indicador esperado:

```text
Mecánica aplicada a la robótica M1
Emplear principios de la mecánica aplicados a la robótica, como la estructura y la estabilidad, en el diseño de mecanismos robóticos.
```

El defecto está en el localizador de la infraestructura: el `locator` usado como opción `has` ya estaba anclado en `#saberes-conceptuales-1`, por lo que Playwright intentó resolver nuevamente ese contenedor desde cada `.saber-conceptual-item` y obtuvo cero coincidencias en los 23 elementos visibles.

### PIA-T103-B04 — Localizador `has` con raíz duplicada

- **Clasificación:** defecto confirmado de infraestructura de prueba.
- **Producto:** no se confirmó una diferencia funcional o curricular del aplicativo.
- **Evidencia:** `error-context.md`, captura, traza y resultado JSON del run `20260817T150325868Z-1d2f1077bc4d`.
- **Acción aplicada:** ninguna; el localizador no se corrigió y la ejecución no se repitió.

## 8. Resultados y diagnósticos conservados

El nuevo run conserva 7 archivos de resultados, 15.189.260 bytes en total, incluida la traza de 14.492.366 bytes. El reporte conserva 22 archivos y 16.679.692 bytes. Las huellas principales son:

| Archivo | SHA-256 |
|---|---|
| `curriculum-inventory.json` | `b8ad2a09120260756b7e88a2bfc5df99b81bbd7a1c8c709a8d33f12e20bf77f9` |
| `curriculum-results.chrome-server.json` | `dab92261be7ddf449d958099361ad82708cb52a0408a57a2e07fe4c5cc48868a` |
| `source-fingerprints.json` | `e336a9a0989cfe74bdfc522c40c1e86469c0f304a25d0a6312eb1ae38127fb66` |
| `error-context.md` | `ff5529ded4825e8148eb094f3572a147bceafab5c3d653f4bc55fcd2884bf586` |
| `test-failed-1.png` | `ef335fca0b1036b24f0a87b337b2dd706178c7166b1e325de52ad0d7ef133fc5` |
| `trace.zip` | `8e9bc7d397f76596e249e548cd7f56be4794aa54e3ece4263f9170209a194b31` |

La preparación no registró errores de página, consola o escritura. Google Fonts fue la única solicitud externa interceptada y ninguna conexión externa fue permitida.

## 9. Integridad y preservación final

- Los dos HTML, `BASELINE.sha256` y `package-lock.json` conservaron sus huellas iniciales.
- `PNFT_DATA` y `RDA_POR_CICLO` no fueron modificados.
- El run fallido `20260812T205414114Z-1ca18f7ee107` permanece separado y sin sobrescritura: 5 archivos de resultados, 22 archivos de reporte, 1.912.630 bytes de reporte y huella agregada de reporte `1600adbd0ac446377ba789f793ca6494597e62b228f366543f60f2c08716ee2d` según el mismo cálculo inicial.
- El servidor terminó, no quedaron procesos Node y el puerto `4173` quedó sin escucha.
- No existe ejecución `file://` de `PIA-T103`.
- No existe `evidence/approved/characterization/PIA-T103/`.
- `docs/tasks.md` permaneció intacto y `PIA-T103` continúa `PENDIENTE`.

## 10. Archivos producidos o actualizados

- Creado: `tests/characterization/curriculum-source-extractor.mjs`.
- Creado: `scripts/verify-curriculum-extractor.mjs`.
- Modificado: `tests/characterization/curriculum.spec.mjs`.
- Actualizado: `docs/BITACORA_PIA_PNFT.md`.
- Generados y preservados: resultados y reporte temporales del run `20260817T150325868Z-1d2f1077bc4d`.

No se modificaron `index.html`, `reference/index.original.html`, `BASELINE.sha256`, `package-lock.json`, `package.json`, el fixture, la configuración, el lanzador, `docs/tasks.md` ni evidencia aprobada previa.

## 11. Estado, bloqueo y próximo paso

`PIA-T103` no se cierra. La modalidad `file://`, la composición y promoción de evidencia, el cambio de estado en `docs/tasks.md` y `PIA-T104` no se iniciaron.

El próximo paso requiere una autorización humana independiente para corregir únicamente `PIA-T103-B04`, revisar la corrección y decidir si se permite una nueva ejecución de servidor. No se inició `PIA-T105`.

---

# Entrada 024 — 17 de agosto de 2026

## 1. Objetivo de la jornada

Corregir exclusivamente `PIA-T103-B04` en la infraestructura de pruebas, ejecutar las tres comprobaciones previas autorizadas y, si aprobaban, realizar una sola caracterización efectiva mediante servidor y una sola cobertura mínima mediante `file://`. Al aprobar ambas modalidades, componer evidencia técnica pendiente de aprobación humana sin cerrar aún `PIA-T103`, modificar `docs/tasks.md` ni iniciar `PIA-T104`.

## 2. Autorización y alcance

La persona propietaria funcional autorizó únicamente:

- corregir el localizador responsable del fallo de `T103-16` en `tests/characterization/curriculum.spec.mjs`;
- utilizar como diagnóstico el run fallido `20260817T150325868Z-1d2f1077bc4d`;
- exigir una coincidencia exacta sin `first()`, `last()`, `nth()` ni selectores posicionales;
- ejecutar `node --check`, `baseline:verify` y una comprobación estática del cambio;
- ejecutar una sola vez cada modalidad efectiva, primero servidor y después la cobertura mínima `file://`;
- componer la evidencia si las dos modalidades aprobaban;
- añadir una sola entrada de bitácora.

No se autorizó modificar el producto, la referencia, datos curriculares, fixture, configuración, lanzador, dependencias, tareas ni casos distintos. `PIA-T100`, `PIA-T101` y `PIA-T102` permanecieron cerradas e intactas.

## 3. Corrección de PIA-T103-B04

El localizador anterior construía el indicador exacto desde `#saberes-conceptuales-1` y lo reutilizaba como opción `has` de cada `.saber-conceptual-item`. Playwright intentaba resolver nuevamente el contenedor raíz desde cada elemento y obtenía cero coincidencias aunque el indicador estuviera visible.

La corrección mínima:

- obtiene el texto exacto mediante `page.getByText(..., { exact: true })`;
- lo combina semánticamente con `.indicador-logro` mediante `and()`;
- evalúa ese localizador relativamente dentro de cada `.saber-conceptual-item` mediante `filter({ has: exactIndicator })`;
- conserva `toHaveCount(1)` como exigencia de unicidad;
- no introduce selectores posicionales ni modifica otro caso.

Archivo modificado: `tests/characterization/curriculum.spec.mjs`.

## 4. Comprobaciones previas

| Comprobación | Resultado |
|---|---|
| `node --check tests/characterization/curriculum.spec.mjs` | Aprobada, código 0 |
| `npm run baseline:verify` | Aprobada; 2 archivos protegidos |
| Selector anterior | 0 apariciones |
| Texto exacto nuevo | 1 aparición |
| Restricción semántica `.indicador-logro` | 1 aparición |
| `filter({ has: exactIndicator })` | 1 aparición |
| `first()`, `last()` o `nth()` en el bloque | 0 apariciones |
| `toHaveCount(1)` en el bloque | 1 aparición |

Las tres comprobaciones autorizadas aprobaron antes de iniciar Playwright.

## 5. Lanzamiento efectivo de servidor

El primer intento de lanzar el proceso hijo desde el sandbox fue bloqueado por el entorno con `spawn EPERM` después de imprimir el identificador tentativo `20260817T155625640Z-64b49c0c0d16`. Playwright no inició, no se ejecutaron proyectos y no se crearon directorios de resultados o reporte para ese identificador. Por tanto, no constituyó un run de prueba.

La ejecución efectiva autorizada se realizó fuera del sandbox:

- comando: `npm run characterization:curriculum:server`;
- run-id: `20260817T155658596Z-ba1b6bcfcf73`;
- `baseline:verify`: aprobado antes de Playwright;
- trabajadores: 1;
- orden: Chrome antes de Edge;
- resultado global: aprobado, código 0;
- duración global de Playwright: 38,0 s.

### Chrome servidor `151.0.7922.138`

`T103-01` a `T103-17` aprobaron. Se registraron 17 resultados únicos, en el orden planificado, sin omisiones ni duplicados. La suma de duraciones de caso registradas fue 23.783 ms.

### Edge servidor `151.0.4129.78`

`T103-09` y `T103-16` aprobaron después de Chrome. Se registraron 2 resultados únicos, sin omisiones ni duplicados. La suma de duraciones de caso fue 4.945 ms.

## 6. Cobertura mínima file://

Con el servidor cerrado y el puerto `4173` libre, se ejecutó una sola vez:

- comando: `npm run characterization:curriculum:file`;
- run-id: `20260817T161142251Z-f3c7330dafc7`;
- `baseline:verify`: aprobado antes de Playwright;
- trabajadores: 1;
- no se inició servidor local;
- resultado global: aprobado, código 0;
- duración global de Playwright: 20,9 s.

Resultados:

- Chrome `151.0.7922.138`: `T103-08` y `T103-16`, 2 de 2 aprobados; 9.185 ms acumulados por caso.
- Edge `151.0.4129.78`: `T103-09`, 1 de 1 aprobado; 1.596 ms.

Las comparaciones de campos funcionales fueron exactamente iguales entre servidor y `file://` para `T103-08` y `T103-16` en Chrome y para `T103-09` en Edge. No se simularon resultados.

## 7. Conteos y relaciones curriculares

La ejecución canónica confirmó:

- 4 ciclos y 10 niveles;
- 2 nombres de módulo y 20 apariciones de módulo;
- 4 nombres de área, 55 apariciones nivel–módulo–área y 25 combinaciones ausentes;
- 16 RdA;
- 235 apariciones de saber y 103 nombres únicos;
- 58 nombres de saber repetidos distribuidos en 190 apariciones y 45 apariciones con nombre no repetido;
- 235 indicadores y 232 textos únicos;
- 235 saberes con exactamente un indicador, 0 con múltiples indicadores y 0 sin indicador.

Los once hallazgos conocidos conservaron `classification: "knownBaseline"`, `automaticFailure: false` y `matchesBaseline: true`. No se modificó, normalizó ni fabricó contenido curricular.

## 8. Consola, página, red y cierre

- Errores de página: 0 en los cuatro proyectos.
- Mensajes de consola: 0 en los cuatro proyectos.
- Errores de escritura de artefactos: 0.
- Google Fonts fue la única solicitud externa interceptada en los cuatro proyectos.
- Conexiones externas permitidas: 0.
- El servidor terminó correctamente.
- Procesos Node relacionados al cierre: ninguno.
- Puerto `4173` al cierre: sin escucha.

## 9. Huellas e insumos aprobados

| Artefacto | SHA-256 |
|---|---|
| Inventario canónico | `b8ad2a09120260756b7e88a2bfc5df99b81bbd7a1c8c709a8d33f12e20bf77f9` |
| Huellas de fuente canónicas | `a450e742a69d070ee97e9f270f1e6282a86523f0d8f559fc9627aa150a7b8efc` |
| Resultado Chrome servidor | `c2279ab8e2c22f93aa9b010be64b2baaae632e41daa39f7097b0abb6fd3b1392` |
| Resultado Edge servidor | `b4a73f75f0c207f8784dd89e86970f5168c8e0b1246dda2e47cd71ec917b2a8e` |
| Resultado Chrome `file://` | `2231d95a06b7fd0a36fedb05241cc8bf8bac08fa903fa22d07fabe06a6d4c405` |
| Resultado Edge `file://` | `1968974ed85005773b440d0e6cb606fb791418f9c2fadf8065d699beaf40823c` |

Huellas protegidas finales:

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.

## 10. Preservación de runs fallidos

- `20260812T205414114Z-1ca18f7ee107`: 5 archivos de resultados, 40.066 bytes; 22 archivos de reporte, 1.912.630 bytes.
- `20260817T150325868Z-1d2f1077bc4d`: 7 archivos de resultados, 15.189.260 bytes; 22 archivos de reporte, 16.679.692 bytes.

Ambos permanecen separados y no fueron sobrescritos, eliminados, promovidos ni incorporados a los resultados válidos.

## 11. Evidencia compuesta

Se creó `evidence/pending/characterization/PIA-T103/` como evidencia técnica pendiente de cierre humano, sin promoverla todavía a `evidence/approved/`.

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `README.md` | 2.859 bytes | `ecba66e8ee7c05a636580af48deae85363120c56121095e17068432098a3b9b6` |
| `curriculum-inventory.json` | 308.210 bytes | `b8ad2a09120260756b7e88a2bfc5df99b81bbd7a1c8c709a8d33f12e20bf77f9` |
| `curriculum-results.json` | 787.676 bytes | `621d3ef3aa3ed1e74e5979c8caf4c3d8d279a647cfcd3cd07007ba8fb461a3db` |
| `test-results-summary.json` | 12.447 bytes | `3e3dfc72e93cc38404b9c4fae4f96e77435c71e2722011a2bf3f4d05bf506cd8` |
| `source-fingerprints.json` | 6.813 bytes | `f4062c598d03a0278f8be5995df67cdbc58226f4d3b379c96bd8b0b08b4e5620` |
| `manifest.sha256` | 441 bytes | `3d2a737354d9f23485b733f212aac44b0074df7ede0305f73d9a3bfb991ce22f` |

Los cuatro JSON se analizaron correctamente. `manifest.sha256` contiene exactamente cinco entradas, valida los otros cinco archivos y no se incluye a sí mismo. El inventario promovible coincide byte por byte con el inventario canónico. No se detectaron rutas locales ni identificadores personales.

## 12. Archivos producidos o actualizados

- Modificado: `tests/characterization/curriculum.spec.mjs`.
- Creada: evidencia pendiente bajo `evidence/pending/characterization/PIA-T103/`.
- Generados y conservados: resultados y reportes de los runs aprobados de servidor y `file://`.
- Actualizado: `docs/BITACORA_PIA_PNFT.md` mediante esta única entrada.

No se modificaron `index.html`, `reference/index.original.html`, `PNFT_DATA`, `RDA_POR_CICLO`, `BASELINE.sha256`, `package-lock.json`, `package.json`, el fixture, la configuración, el lanzador, `docs/tasks.md` ni evidencia aprobada previa.

## 13. Estado y próximo paso

La cobertura técnica de `PIA-T103` cumple las cinco casillas descritas en `docs/tasks.md`, pero la tarea permanece formalmente `PENDIENTE` y sus casillas no se modificaron porque falta la aprobación humana del cierre y la promoción de `evidence/pending/characterization/PIA-T103/` a `evidence/approved/characterization/PIA-T103/`.

El próximo paso es presentar esta evidencia a la persona propietaria funcional para aprobación de cierre. `PIA-T104` y `PIA-T105` no se iniciaron.

---

# Entrada 025 — 17 de agosto de 2026

## 1. Objetivo de la jornada

Aplicar la aprobación humana final de `PIA-T103`, promover exactamente su evidencia validada, cerrar documentalmente la tarea, incorporar en `AGENTS.md` el protocolo de ejecución ágil autorizado y, después del cierre, iniciar `PIA-T104` con una caracterización limitada a sus siete criterios literales. `PIA-T105` quedó expresamente fuera del alcance.

## 2. Cierre y promoción de PIA-T103

Antes de copiar se confirmó que `evidence/approved/characterization/PIA-T103/` no existía. El origen `evidence/pending/characterization/PIA-T103/` contenía exactamente seis archivos y ningún subdirectorio.

Acciones realizadas:

- se validaron las cinco entradas del manifiesto de origen;
- se creó el destino aprobado;
- se copiaron los seis archivos mediante creación sin sobrescritura;
- se compararon byte por byte los seis pares origen–destino;
- se confirmaron tamaños y huellas idénticos en los seis pares;
- se validaron nuevamente las cinco entradas del manifiesto en el destino;
- no se regeneró, transformó ni editó ningún archivo de evidencia;
- el origen pendiente se conservó como copia exacta y no se eliminó.

| Archivo aprobado | Tamaño | SHA-256 |
|---|---:|---|
| `README.md` | 2.859 bytes | `ecba66e8ee7c05a636580af48deae85363120c56121095e17068432098a3b9b6` |
| `curriculum-inventory.json` | 308.210 bytes | `b8ad2a09120260756b7e88a2bfc5df99b81bbd7a1c8c709a8d33f12e20bf77f9` |
| `curriculum-results.json` | 787.676 bytes | `621d3ef3aa3ed1e74e5979c8caf4c3d8d279a647cfcd3cd07007ba8fb461a3db` |
| `test-results-summary.json` | 12.447 bytes | `3e3dfc72e93cc38404b9c4fae4f96e77435c71e2722011a2bf3f4d05bf506cd8` |
| `source-fingerprints.json` | 6.813 bytes | `f4062c598d03a0278f8be5995df67cdbc58226f4d3b379c96bd8b0b08b4e5620` |
| `manifest.sha256` | 441 bytes | `3d2a737354d9f23485b733f212aac44b0074df7ede0305f73d9a3bfb991ce22f` |

El bloque de `PIA-T103` en `docs/tasks.md` se actualizó exclusivamente a `COMPLETADA`, se marcaron sus cinco criterios y se añadió `evidence/approved/characterization/PIA-T103/` como evidencia aprobada. No se modificaron los bloques de otras tareas.

## 3. Protocolo ágil incorporado en AGENTS.md

Se añadió la sección 17, `Protocolo de ejecución ágil para tareas autorizadas`, sin eliminar ni reescribir reglas anteriores. La sección establece:

1. documentación y especificaciones como autoridad ordenada;
2. huellas SHA-256 y `BASELINE.sha256` como frontera de integridad;
3. pruebas limitadas al criterio literal de la tarea activa;
4. una implementación mínima, una revisión focalizada y una ejecución canónica para alcances expresamente autorizados;
5. modalidad `file://` únicamente cuando sea pertinente;
6. prohibición de repetir revisiones o ejecuciones aprobadas;
7. continuidad entre tareas consecutivas solo con autorización expresa y después de cerrar la anterior;
8. detención ante fallo real, diferencia de integridad, ambigüedad material o riesgo de sobrescritura, en armonía con la sección 13;
9. conservación sin sobrescritura de artefactos ante fallos;
10. revisión de resultados, diagnósticos, huellas y procesos antes del cierre.

La nueva sección declara explícitamente que complementa y no elimina, sustituye ni debilita ninguna protección, aprobación o regla de detención existente. `docs/SPEC.md` permaneció intacto.

Huella final de `AGENTS.md`: `d1485b2884286861458a2d5707ffb578bdb88d0e69e3cb0dcfeb299a4a766d06`.

## 4. Alcance literal de PIA-T104

`docs/tasks.md` define exactamente siete criterios:

1. Inicialización.
2. Aumento de lecciones.
3. Reducción cancelada.
4. Reducción aceptada.
5. Agregar semana manual.
6. Eliminar semana intermedia.
7. Tres reconstrucciones consecutivas.

`docs/SPEC.md` limita la caracterización a cálculo de semanas, conservación al aumentar, confirmación y eliminación de excedentes al reducir, conservación de semanas restantes al eliminar y restauración de áreas, saberes, indicadores, saberes procedimentales, actitudinales y campos editables al reconstruir.

No se incluyeron guardado o apertura JSON, exportaciones, prompts, publicación, carga, estrés ni tareas posteriores.

## 5. Implementación mínima de PIA-T104

Archivos creados:

- `tests/characterization/weeks.spec.mjs`;
- `playwright.weeks.config.mjs`;
- `scripts/run-weeks-characterization.mjs`.

Archivo modificado:

- `package.json`, únicamente para añadir `characterization:weeks:server` y `characterization:weeks:file`.

La prueba interactúa solo con controles visibles. No utiliza `page.evaluate()`, `evaluateHandle` ni llamadas directas a `inicializarSemanas()`, `actualizarSemanasPreservandoContenido()`, `agregarSemanaManual()`, `eliminarSemana()` o `reconstruirVistaSemanasPreservandoContenido()`.

La infraestructura usa un run-id único, rechaza colisiones, escribe JSON con `flag: "wx"`, mantiene `workers: 1`, `retries: 0`, `maxFailures: 1`, ejecuta Edge después de Chrome y no instala dependencias o navegadores.

Cobertura definida:

- Chrome servidor: `T104-01` a `T104-07`.
- Edge servidor: `T104-07`.
- Chrome `file://`: `T104-07`.
- Edge `file://`: `T104-07`.

## 6. Revisión focalizada previa

| Comprobación | Resultado |
|---|---|
| `node --check tests/characterization/weeks.spec.mjs` | Aprobada |
| `node --check playwright.weeks.config.mjs` | Aprobada |
| `node --check scripts/run-weeks-characterization.mjs` | Aprobada |
| `npm run baseline:verify` | Aprobada; 2 archivos protegidos |
| Contrato de cobertura y dependencia Edge → Chrome | Aprobado |
| Llamadas directas a funciones productivas | 0 |
| Escritura exclusiva `flag: "wx"` | Confirmada |
| Guarda de punto de entrada del lanzador | Confirmada |
| Dependencias directas | Únicamente `@playwright/test` 1.62.1 |
| Artefactos previos de PIA-T104 | Inexistentes |
| Puerto `4173` | Libre |
| Procesos Node relacionados | Ninguno |

## 7. Ejecución canónica de servidor

- Comando: `npm run characterization:weeks:server`.
- Run-id: `20260817T163917217Z-5420f05b55b5`.
- Resultado global: aprobado, código 0.
- Duración Playwright: 24,1 s.
- Trabajadores: 1.
- Orden: Chrome antes de Edge.

### Chrome servidor `151.0.7922.138`

| Caso | Criterio | Resultado | Duración |
|---|---|---|---:|
| `T104-01` | Inicialización | Aprobado | 896 ms |
| `T104-02` | Aumento de lecciones | Aprobado | 1.317 ms |
| `T104-03` | Reducción cancelada | Aprobado | 1.123 ms |
| `T104-04` | Reducción aceptada | Aprobado | 1.309 ms |
| `T104-05` | Agregar semana manual | Aprobado | 980 ms |
| `T104-06` | Eliminar semana intermedia | Aprobado | 1.174 ms |
| `T104-07` | Tres reconstrucciones consecutivas | Aprobado | 3.111 ms |

### Edge servidor `151.0.4129.78`

`T104-07` aprobó en 4.380 ms. Los ocho resultados de servidor fueron únicos, completos y respetaron el orden planificado.

## 8. Cobertura file:// pertinente

La modalidad portable era pertinente porque PIA debe conservar un `index.html` autónomo y el criterio de reconstrucción opera completamente en el navegador.

- Comando: `npm run characterization:weeks:file`.
- Run-id: `20260817T164228308Z-dfb6ec307fad`.
- Resultado global: aprobado, código 0.
- Duración Playwright: 21,2 s.
- Chrome `151.0.7922.138`: `T104-07` aprobado en 3.523 ms.
- Edge `151.0.4129.78`: `T104-07` aprobado en 3.548 ms.
- No se inició servidor local.

Los campos funcionales de `T104-07` fueron exactamente iguales entre servidor y `file://` para Chrome y Edge.

## 9. Diagnósticos e integridad de PIA-T104

- Ejecuciones de caso aprobadas: 10 de 10.
- Errores de página: 0.
- Errores inesperados de consola: 0.
- Mensajes informativos vigentes: 13 en Chrome servidor y 6 en cada proyecto representativo; corresponden a actualización o eliminación de semanas y se conservaron en los resultados.
- Solicitud externa interceptada: Google Fonts en los cuatro proyectos.
- Conexiones externas permitidas: 0.
- Servidor al cierre: terminado.
- Procesos Node relacionados al cierre: ninguno.
- Puerto `4173` al cierre: sin escucha.

Huellas de resultados:

- Chrome servidor: `b1b8508ac417a7111e28f8635d5e03762b66303648d0b8a16bcf4fadcb13f786`.
- Edge servidor: `30c2dda3d91cee1082d2b9eb16ad0aabe07ffbbe7fe28627c1174f1b7125a03d`.
- Chrome `file://`: `929ff96c60cfe9091e7606dd03dddd934134e7e7d04431ace37839f264992c85`.
- Edge `file://`: `d4573ec39f18a39233a453822bd14a0efcf8807cea78da83db13eff588e3be62`.

## 10. Evidencia pendiente de PIA-T104

Se compuso `evidence/pending/characterization/PIA-T104/` sin promoverla ni modificar `docs/tasks.md` para PIA-T104.

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `README.md` | 1.779 bytes | `7140c4a0fefbd3ff07f605b8368977acd8fca509cd57468db83c7ebffb0c1068` |
| `weeks-results.json` | 101.484 bytes | `4de56e974bf2d975f3e6edbaa6f370c74978256f709faeb79049af8ce458dd80` |
| `test-results-summary.json` | 5.399 bytes | `6c5663a7ec56e3ebef90632226181f0925083855850585800b8d63b67598fabb` |
| `source-fingerprints.json` | 6.512 bytes | `2bc9f0c765b07de44aa0e1695bfafde659c0d9661ee79a51159b1b5cab510709` |
| `manifest.sha256` | 344 bytes | `bca2ed5993d7d6884a5e1d3b8ef2299fb53ebb2849d2e7f60acb4b3365367ae6` |

Los tres JSON se analizaron correctamente. El manifiesto contiene cuatro entradas y validó 4/4. No se detectaron rutas locales ni identificadores personales.

## 11. Integridad protegida y preservación

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.

Todos los runs aprobados y fallidos de `PIA-T102`, `PIA-T103` y los nuevos runs aprobados de `PIA-T104` permanecen en sus rutas originales. No se sobrescribieron, eliminaron ni reutilizaron artefactos.

## 12. Estado final y próximo paso

- `PIA-T103`: `COMPLETADA`, cinco criterios marcados y evidencia aprobada registrada.
- `PIA-T104`: `PENDIENTE`, siete criterios sin marcar; infraestructura, ejecución canónica, equivalencia `file://` y evidencia pendiente completadas técnicamente.
- `PIA-T105`: `PENDIENTE`, no iniciada y sin cambios.

El siguiente paso requiere aprobación humana de los resultados de `PIA-T104` antes de promover `evidence/pending/characterization/PIA-T104/`, actualizar su bloque en `docs/tasks.md` o declarar su cierre.

---

# Entrada 026 — 17 de agosto de 2026

## 1. Objetivo

Añadir una aclaración documental aditiva sobre el intento sandbox de PIA-T103 y ejecutar la aprobación humana final de PIA-T104 mediante la promoción exacta de su evidencia, el cierre exclusivo de su bloque en `docs/tasks.md` y la conservación integral de los runs.

## 2. Autoridad y archivos revisados

- `AGENTS.md`, incluido el protocolo de ejecución ágil.
- `docs/SPEC.md` y `docs/tasks.md`.
- `docs/BITACORA_PIA_PNFT.md`, en particular las Entradas 024 y 025.
- `evidence/pending/characterization/PIA-T104/` y su manifiesto.
- Los artefactos conservados del intento sandbox `20260817T155625640Z-64b49c0c0d16`.

## 3. Aclaración aditiva sobre el intento sandbox de PIA-T103

- El intento sandbox `20260817T155625640Z-64b49c0c0d16` no inició una ejecución funcional de Playwright.
- No abrió navegador ni servidor.
- Sí creó `.last-run.json` fallido y un reporte vacío.
- Esos artefactos permanecen conservados.
- No forman parte de los resultados aprobados ni de la evidencia promovida.
- La afirmación de la Entrada 024 sobre la inexistencia de directorios queda aclarada por esta nueva entrada.
- No se reescribe documentación histórica.

Los artefactos aclarados son:

- `test-results/PIA-T103/server/20260817T155625640Z-64b49c0c0d16/.last-run.json`: 45 bytes, estado `failed`, lista `failedTests` vacía y SHA-256 `e22df5d0991eb28c09093b1e678b3fa8cd1fab48185d38e67cf79fb6e63ad5ea`.
- `playwright-report/PIA-T103/server/20260817T155625640Z-64b49c0c0d16/index.html`: reporte vacío de resultados, 515.467 bytes y SHA-256 `17cba73cc4d99231d4977217169ab2a31620b4e229a0cef5c8504fba8b149a63`.

La Entrada 024 permanece intacta; esta Entrada 026 añade la precisión sin reemplazar ni reescribir el registro anterior.

## 4. Aprobación humana y promoción de PIA-T104

La aprobación humana final fue concedida expresamente el 17 de agosto de 2026. Antes de promover se comprobó que `evidence/approved/characterization/PIA-T104/` no existía. Los cinco archivos de `evidence/pending/characterization/PIA-T104/` se copiaron exactamente al destino aprobado, sin sobrescribir, regenerar, transformar ni editar la evidencia. El origen pendiente quedó conservado.

El manifiesto validó 4/4 en el origen y 4/4 en el destino. La comparación directa de bytes entre origen y destino aprobó 5/5; tamaños y huellas SHA-256 también fueron idénticos:

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `README.md` | 1.779 bytes | `7140c4a0fefbd3ff07f605b8368977acd8fca509cd57468db83c7ebffb0c1068` |
| `weeks-results.json` | 101.484 bytes | `4de56e974bf2d975f3e6edbaa6f370c74978256f709faeb79049af8ce458dd80` |
| `test-results-summary.json` | 5.399 bytes | `6c5663a7ec56e3ebef90632226181f0925083855850585800b8d63b67598fabb` |
| `source-fingerprints.json` | 6.512 bytes | `2bc9f0c765b07de44aa0e1695bfafde659c0d9661ee79a51159b1b5cab510709` |
| `manifest.sha256` | 344 bytes | `bca2ed5993d7d6884a5e1d3b8ef2299fb53ebb2849d2e7f60acb4b3365367ae6` |

La evidencia aprobada quedó en `evidence/approved/characterization/PIA-T104/`.

## 5. Cambio documental de PIA-T104

Se actualizó únicamente el bloque PIA-T104 de `docs/tasks.md`:

- estado `COMPLETADA`;
- siete criterios marcados;
- ruta `evidence/approved/characterization/PIA-T104/` añadida.

Los bloques PIA-T100, PIA-T101, PIA-T102 y PIA-T103 no se modificaron. PIA-T103 permanece `COMPLETADA`. PIA-T105 no se inició.

## 6. Pruebas, integridad y estado operativo

No se volvió a ejecutar Playwright, servidor ni cobertura `file://`. El cierre se basó exclusivamente en la evidencia ya validada y aprobada.

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Procesos Node: ninguno.
- Puerto `4173`: sin escucha.

Todos los runs aprobados y fallidos, incluido el intento sandbox aclarado, permanecen conservados. No se detectaron diferencias de integridad, bloqueos ni riesgos de sobrescritura.

## 7. Archivos producidos o actualizados

- `evidence/approved/characterization/PIA-T104/`: copia binariamente idéntica de los cinco archivos aprobados.
- `docs/tasks.md`: únicamente el bloque PIA-T104.
- `docs/BITACORA_PIA_PNFT.md`: únicamente esta nueva Entrada 026, añadida al final.

## 8. Estado final y próximo paso

- `PIA-T103`: `COMPLETADA`.
- `PIA-T104`: `COMPLETADA`.
- `PIA-T105`: `PENDIENTE`, no iniciada.

No quedan pendientes dentro del cierre autorizado de PIA-T104. Cualquier inicio de PIA-T105 requiere una autorización posterior.

---

# Entrada 027 — 17 de agosto de 2026

## 1. Objetivo

Iniciar `PIA-T105 — Caracterizar JSON` con dos partes separadas: inventariar en solo lectura posibles JSON históricos y, al no existir un corpus histórico aprobado y anonimizado, implementar y ejecutar una sola vez únicamente el round-trip actual mediante los flujos visibles. La tarea debía permanecer pendiente y `PIA-T106` no debía iniciarse.

## 2. Autoridad y archivos revisados

- `AGENTS.md` y su protocolo de ejecución ágil.
- `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, el análisis funcional, la bitácora y el mapa de funciones.
- `index.html` y `reference/index.original.html`, solo en lectura.
- Las funciones vigentes `abrirPlan()`, `ejecutarGuardarNormal()`, `obtenerDatosPlan()` y `cargarPlan()`.
- Infraestructura aprobada de tareas anteriores, únicamente como referencia técnica.

## 3. Inventario de posibles JSON históricos

El inventario se realizó antes de implementar o ejecutar la parte A. Se excluyeron `node_modules`, resultados de pruebas, reportes, manifiestos, el mapa funcional, `package-lock.json` y toda evidencia de otras tareas. Los archivos se analizaron estructuralmente sin mostrar ni copiar valores de contenido.

Resultado: un único JSON no excluido y cero candidatos que parecieran planeamientos PIA.

| Ubicación | Fecha UTC | Tamaño | SHA-256 | Parece planeamiento PIA |
|---|---|---:|---|---|
| `package.json` | `2026-08-17T16:30:42.240Z` | 1.622 bytes | `9df06e750bde93ecc2d8e46fbea4fda54a19a8ed2d487a13f078c2e4eb1a9b2e` | No |

No se encontró un corpus histórico aprobado y anonimizado. No se consideró histórico ningún JSON creado durante esta caracterización y no se fabricaron archivos históricos.

## 4. Decisión de alcance

Conforme a la autorización humana, se continuó únicamente con la parte A. La compatibilidad histórica no se ejecutó, no se anonimizaron archivos, no se creó evidencia aprobada y no se modificó `docs/tasks.md`.

## 5. Implementación mínima del round-trip actual

Archivos creados:

- `tests/characterization/json-roundtrip.spec.mjs`;
- `playwright.json.config.mjs`;
- `scripts/run-json-characterization.mjs`.

Archivo modificado:

- `package.json`, únicamente para añadir `characterization:json:server`.

La prueba define un solo caso, `T105-A01`, para Chrome mediante servidor. Crea un plan completamente ficticio usando controles visibles, utiliza los botones visibles Guardar y Abrir, acepta descargas reales, conserva los archivos mediante creación exclusiva y no invoca directamente funciones productivas. La configuración no incluye Edge ni modalidad `file://`. El lanzador crea un único run-id, rechaza colisiones y usa el Playwright local sin instalar navegadores o dependencias.

## 6. Revisión focalizada previa

| Comprobación | Resultado |
|---|---|
| Sintaxis del spec | Aprobada |
| Sintaxis de la configuración | Aprobada |
| Sintaxis del lanzador | Aprobada |
| Contrato de `package.json` y dependencia directa única | Aprobado |
| `npm run baseline:verify` | Aprobado; 2 archivos protegidos |
| Proyecto y caso únicos | Chrome servidor y `T105-A01` |
| `page.evaluate()` o `evaluateHandle` | 0 |
| Escritura en evidencia aprobada o pendiente | 0 |
| Creación exclusiva `flag: "wx"` | Confirmada |
| Directorios previos de PIA-T105 | Inexistentes |
| Procesos Node y puerto `4173` | Ninguno; sin escucha |

## 7. Ejecución única y fallo

- Comando único: `npm run characterization:json:server`.
- Run-id: `20260817T172147861Z-7de565db1c41`.
- `baseline:verify`: aprobado antes de Playwright.
- Proyecto iniciado: Chrome servidor.
- Trabajadores: 1.
- Resultado global: fallido, código 1.
- Repeticiones: 0.

El plan completamente ficticio se creó mediante controles visibles y el primer guardado real finalizó. La descarga `planeamiento-didactico.original.json` se conservó, se analizó como JSON y presentó 10 campos superiores, 13 campos de información general, 4 semanas con 12 campos cada una, 3 campos de reflexión y `fechaGuardado` de tipo cadena.

El flujo visible Abrir se inició y registró el mensaje informativo vigente `USANDO VERSIÓN DE EMERGENCIA`. El selector de archivo recibió el archivo conservado, pero durante los 10 segundos de espera no se emitieron los dos diálogos esperados de validación y carga. `T105-A01` falló en la comprobación de apertura con cero diálogos observados frente a dos esperados.

No se demostró la reconstrucción, no se generó la segunda descarga y no se ejecutaron las comparaciones finales de estructura, campos, tipos, orden y valores. El fallo queda localizado en la interacción de apertura de esta caracterización; con la evidencia actual no se clasifica como defecto confirmado del producto ni se corrige automáticamente.

## 8. Artefactos conservados

El run conserva siete archivos de resultados:

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `.last-run.json` | 96 bytes | `551ddabb4a1457b6e63734a0c7a36bcdc80e6a74a108cd977c2208f39a8d91bc` |
| `error-context.md` | 47.918 bytes | `1f734b9a9e164e14963b6a760bdaa49b925af110e8d95555ac842cb4e64c28b5` |
| `json-roundtrip-results.chrome-server.json` | 2.374 bytes | `5ff3130ef5113b7da1af253410f18f35497b349864f96b98ee5fa068d8f33847` |
| `planeamiento-didactico.original.json` | 5.866 bytes | `bd4d147829ffc10f8402c22d9facff871c9c72c04443ba31a8f813f4f5e3c49f` |
| `source-fingerprints.json` | 1.993 bytes | `324165d929ad8d92b00c543992ae985e7875fb1ded5e0d16dd785414bd2798c2` |
| `test-failed-1.png` | 160.489 bytes | `030b86b9d8ebaa9601dedd8f43abf43d60c01d8bf4989494c781d78d43f94035` |
| `trace.zip` | 11.623.126 bytes | `320f98ad1ab3819e29dbdbbacab558f5e718a51fedbaf081002a970dcb3db904` |

El reporte conserva 22 archivos y 13.716.105 bytes. La huella agregada del árbol de reporte es `01c1b64760f12ac148378923f690affa6ad5919b83a41f872849d26d26e8a92f`. No hubo sobrescrituras ni eliminación de artefactos.

## 9. Diagnósticos, red y cierre

- Errores de página: 0.
- Errores de consola: 0.
- Mensajes informativos de consola: 1, correspondiente al flujo vigente de apertura.
- Solicitud externa interceptada: Google Fonts.
- Conexiones externas permitidas: 0.
- Servidor al cierre: terminado.
- Procesos Node al cierre: 0.
- Puerto `4173` al cierre: sin escucha.

## 10. Integridad

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.

No se modificaron `index.html`, `reference/index.original.html`, `PNFT_DATA`, `RDA_POR_CICLO`, el formato JSON vigente, `package-lock.json` ni tareas anteriores.

## 11. Corpus histórico requerido

Para continuar la parte B se requieren copias ya anonimizadas y aprobadas de archivos `.json` descargados mediante el guardado real de PIA y creados antes de esta prueba, desde marzo de 2026. Debe aportarse al menos un archivo representativo completo por cada variante histórica conocida del formato. Las copias deben conservar estructura, nombres y orden de campos, tipos, arreglos y contenido funcional, pero sustituir cualquier nombre de persona, centro educativo, código, circuito, dirección regional y texto libre identificable. Cada archivo debe incluir confirmación humana de procedencia temporal, anonimización y autorización de uso en pruebas.

## 12. Estado y próximo paso

- `PIA-T105`: `PENDIENTE`, seis criterios sin marcar.
- Parte A: ejecución fallida durante la apertura; artefactos conservados.
- Parte B: no ejecutada por ausencia de corpus aprobado y anonimizado.
- `PIA-T106`: `PENDIENTE`, no iniciada.

El próximo paso requiere autorización humana independiente antes de diagnosticar o corregir la interacción de apertura y antes de repetir el run. No se debe usar ningún JSON histórico sin aprobación previa.

---

# Entrada 028 — 17 de agosto de 2026

## 1. Objetivo y autorización

Continuar `PIA-T105 — Caracterizar JSON` mediante un diagnóstico focalizado, sin ejecutar Playwright durante dicho diagnóstico, del fallo de apertura conservado en el run `20260817T172147861Z-7de565db1c41`. La autorización permitía corregir únicamente `tests/characterization/json-roundtrip.spec.mjs` si se demostraba inequívocamente un defecto de infraestructura, ejecutar `node --check` y `baseline:verify` y, si ambos aprobaban, realizar una sola repetición canónica de `characterization:json:server`.

La autorización exigía conservar todos los artefactos, no modificar el producto, no fabricar corpus histórico, mantener `PIA-T105` pendiente y no iniciar `PIA-T106`.

## 2. Archivos y evidencia revisados

- `AGENTS.md` y el protocolo de ejecución ágil.
- `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, el análisis funcional, la bitácora y el mapa de funciones.
- `index.html` y `reference/index.original.html`, únicamente en lectura.
- `tests/characterization/json-roundtrip.spec.mjs`.
- La traza, captura, contexto de error, resultado y JSON original del run fallido `20260817T172147861Z-7de565db1c41`.
- La implementación local instalada de `FileChooser.setFiles()` de Playwright, únicamente en lectura.

## 3. Diagnóstico focalizado de la apertura

No se ejecutó Playwright durante el diagnóstico. La traza confirmó que el botón visible Abrir creó el selector correcto, que `setFiles()` terminó sin error y que el `input[type="file"]` mostró `C:\fakepath\planeamiento-didactico.original.json`. Sin embargo, el archivo conservado se presentó desde una ruta absoluta de 306 caracteres y no apareció ningún diálogo antes del timeout. La API ordinaria de PowerShell tampoco pudo resolver esa ruta sin el prefijo de ruta extendida, mientras que el archivo permanecía accesible y válido mediante mecanismos compatibles con rutas largas.

Las diez determinaciones fueron:

1. Un JSON válido produce realmente dos diálogos en el flujo vigente.
2. Ambos son de tipo `alert`; no intervienen `confirm` ni `prompt`.
3. El orden y texto literal son: `Archivo válido. Cargando...` y luego `Plan cargado exitosamente`.
4. `page.on('dialog')` debe registrarse antes de pulsar el botón visible Abrir y antes de asignar el archivo. La prueba ya lo registraba al inicio del caso, incluso antes de navegar y de iniciar el flujo.
5. El segundo diálogo solo puede aparecer después de cerrar el primero porque `alert` bloquea la ejecución. No existe una elección aceptar/rechazar propia de `alert`; aceptar o descartar solo lo cierra y permite continuar.
6. No debe dispararse un evento `change` adicional. La implementación instalada de `setFiles()` asigna `input.files` y emite `input` y `change`.
7. No se requiere otra acción visible después de pulsar Abrir, seleccionar el archivo y cerrar los diálogos.
8. En el primer run el JSON no fue leído satisfactoriamente por `FileReader` antes del timeout: no se alcanzó ni el `alert` de JSON válido ni el `alert` del bloque de error.
9. La prueba no esperaba incorrectamente dos diálogos; la expectativa coincidía con el producto para un JSON válido.
10. El primer run no contiene evidencia de que PIA rechazara el JSON: no emitió `Solo archivos .json` ni `Error en el archivo JSON`. La evidencia indica que el contenido no llegó a procesarse, no que fuera rechazado.

La causa quedó clasificada inequívocamente como defecto de transporte de la infraestructura: la prueba copiaba el JSON descargado al directorio profundo de resultados y volvía a presentarlo mediante esa ruta de 306 caracteres.

## 4. Corrección mínima de infraestructura

Se modificó exclusivamente `tests/characterization/json-roundtrip.spec.mjs`:

- `openThroughVisibleFlow()` recibe ahora el objeto de la descarga original;
- el selector visible recibe un archivo con nombre `planeamiento-didactico.original.json`, MIME `application/json` y los mismos bytes exactos leídos de la descarga real;
- se eliminó del flujo de apertura el uso de la ruta profunda de evidencia;
- no se añadió ningún evento `change`, no se eliminaron ni simularon diálogos y se conservaron las dos alertas literales exigidas;
- se conservó la comparación posterior de todo el DOM visible para demostrar la reconstrucción.

No se modificaron `index.html`, la referencia, `PNFT_DATA`, `RDA_POR_CICLO`, configuraciones, lanzador, dependencias, formato JSON, tareas ni casos ajenos.

## 5. Comprobaciones previas

| Comprobación | Resultado |
|---|---|
| `node --check tests/characterization/json-roundtrip.spec.mjs` | Aprobada, código 0 |
| `npm run baseline:verify` | Aprobada, 2 archivos protegidos |

## 6. Única repetición canónica

- Comando: `npm run characterization:json:server`.
- Run-id: `20260817T173914214Z-b79a9c2a7569`.
- Proyecto/caso: `chrome-server` / `T105-A01`.
- Navegador: Chrome `151.0.7922.138`.
- Trabajadores: 1.
- Repeticiones adicionales: 0.
- Resultado: fallido, código 1.

La corrección de infraestructura quedó validada por el propio producto: la apertura produjo exactamente los dos `alert` esperados, en el orden literal aprobado, y `cargarPlan()` reconstruyó el DOM. El JSON original se leyó y procesó; no hubo rechazo.

La comprobación visible posterior detectó una diferencia funcional reproducida en los cuatro campos `semana-nombre`:

| Semana | Valor guardado y esperado | Valor visible reconstruido |
|---:|---|---|
| 1 | `Lecciones ficticias de la semana 1` | `Lecciones 1 y 2` |
| 2 | `Lecciones ficticias de la semana 2` | `Lecciones 2 y 4` |
| 3 | `Lecciones ficticias de la semana 3` | `Lecciones 3 y 6` |
| 4 | `Lecciones ficticias de la semana 4` | `Lecciones 4 y 8` |

El JSON original conserva los cuatro valores completos. En el producto protegido, `reconstruirVistaSemanasPreservandoContenido()` extrae los números de `semana.lecciones` y llama a `crearElementoSemana()`, que vuelve a componer el texto como `Lecciones {inicio} y {fin}`; no restaura literalmente el valor guardado. Esta es una diferencia productiva confirmada frente al criterio de equivalencia de valores de PIA-T105. No se modificó el producto ni se intentó corregirla.

No se generó la segunda descarga y, por ello, no se ejecutaron las comparaciones finales entre ambos documentos JSON. La ausencia de corpus histórico aprobado y anonimizado continúa sin cambios.

## 7. Diagnósticos y artefactos conservados

- Diálogos: 2/2, ambos `alert` y con texto literal correcto.
- Errores de página: 0.
- Errores de consola: 0.
- Mensajes informativos de consola: 1, correspondiente a `USANDO VERSIÓN DE EMERGENCIA`.
- Solicitud externa interceptada: Google Fonts.
- Conexiones externas permitidas: 0.

El nuevo run conserva siete archivos:

| Archivo | Tamaño | SHA-256 |
|---|---:|---|
| `.last-run.json` | 96 bytes | `551ddabb4a1457b6e63734a0c7a36bcdc80e6a74a108cd977c2208f39a8d91bc` |
| `error-context.md` | 47.950 bytes | `8272213bdf96d38c57d0dbc000cc85b9d1780463accce6f1ec854c4eb395bc0d` |
| `json-roundtrip-results.chrome-server.json` | 6.059 bytes | `9d0ce76ab8399961cd6ff635e407d9aee06b4dd55716f38613eb42c332da58a7` |
| `planeamiento-didactico.original.json` | 5.866 bytes | `9820b16fd4293ef1872c87b179ed27559674dac4329d0b404b21e77bce3b802f` |
| `source-fingerprints.json` | 1.993 bytes | `c1189aca6fd0b475ccb5029fcb39b306a01afa92bfcc7ec900e89364db95d0fe` |
| `test-failed-1.png` | 160.489 bytes | `030b86b9d8ebaa9601dedd8f43abf43d60c01d8bf4989494c781d78d43f94035` |
| `trace.zip` | 16.240.813 bytes | `2024c07c75d511a72f833eff762b779cb494438ca2d9d4d83c6809b4af3aab3e` |

El reporte del nuevo run conserva 22 archivos y 18.335.636 bytes. El run anterior `20260817T172147861Z-7de565db1c41`, incluidos su JSON original, traza, captura y demás artefactos, permanece intacto. No hubo sobrescrituras ni eliminaciones.

## 8. Integridad y cierre operativo

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Procesos Node al cierre: 0.
- Puerto `4173` al cierre: sin escucha.

## 9. Archivos modificados y estado

- `tests/characterization/json-roundtrip.spec.mjs`: corrección mínima del transporte del archivo descargado.
- `docs/BITACORA_PIA_PNFT.md`: esta única Entrada 028, añadida al final sin reescribir entradas anteriores.

`docs/tasks.md` no se modificó. `PIA-T105` permanece `PENDIENTE` con sus seis criterios sin marcar; la diferencia productiva bloquea el round-trip actual y sigue faltando un corpus histórico aprobado y anonimizado. `PIA-T106` permanece `PENDIENTE` y no fue iniciado.

El próximo paso requiere decisión y autorización humana sobre la diferencia productiva de `semana.lecciones`; no se autoriza otra repetición ni una corrección de `index.html` por esta entrada.

---

# Entrada 029 — 17 de agosto de 2026

## 1. Objetivo y autorización

Continuar PIA-T105 sin modificar el producto: clasificar la diferencia de `semana.lecciones` como hallazgo productivo de línea base, registrar el resultado alcanzado por la parte A y realizar una búsqueda de solo lectura y únicamente de metadatos de posibles JSON históricos en Descargas, Documentos y las carpetas accesibles de OneDrive.

La autorización prohibió abrir o analizar el contenido de los candidatos, copiarlos, modificarlos, mostrar datos personales, fabricar corpus histórico, corregir `index.html` o iniciar PIA-T106.

## 2. Autoridad y archivos revisados

- AGENTS.md y su protocolo de ejecución ágil.
- docs/info.md, docs/SPEC.md, docs/tasks.md, docs/ANALISIS_FUNCIONAL_PIA_PNFT.md, esta bitácora y docs/MAPA_FUNCIONES_PIA_PNFT.json.
- La evidencia ya conservada de los runs de PIA-T105, sin ejecutar nuevamente Playwright.
- index.html y reference/index.original.html, únicamente para confirmar integridad; no fueron modificados.

## 3. Clasificación del resultado de la parte A

La diferencia de `semana.lecciones` queda clasificada como hallazgo productivo de línea base de PIA-T105. La parte A demostró:

- creación aprobada;
- guardado aprobado;
- apertura aprobada;
- comparación completada;
- cuatro diferencias literales en `semana.lecciones`;
- causa localizada en `reconstruirVistaSemanasPreservandoContenido()`.

El resultado no constituye una aprobación de igualdad. El producto protegido recompone los cuatro valores y no los restaura literalmente; no se modificó `index.html` ni se intentó corregir el comportamiento.

En docs/tasks.md se marcaron únicamente los cuatro criterios ejecutados de la parte A. PIA-T105 conserva el estado PENDIENTE y siguen sin marcarse la reunión de JSON históricos anonimizados y la prueba de compatibilidad histórica.

## 4. Método y límites de la búsqueda

- Corte temporal: anterior a 2026-08-17T17:21:47.861Z, inicio del run `20260817T172147861Z-7de565db1c41`.
- Raíces revisadas: `%USERPROFILE%\Downloads`, `%USERPROFILE%\Documents`, `%USERPROFILE%\OneDrive` y `%USERPROFILE%\OneDrive - Ministerio de Educación`, limitadas a carpetas accesibles.
- Exclusiones: `node_modules`, repositorios del proyecto PIA-PNFT, resultados de pruebas, reportes, manifiestos, mapas funcionales, `package-lock.json`, evidencia de otras tareas y archivos generados por las pruebas actuales.
- La identificación se hizo solo por extensión, nombre, ubicación y fecha. El SHA-256 se calculó sobre los bytes sin interpretar ni analizar el JSON.
- No se abrió, analizó, copió, transformó ni modificó ningún candidato.
- Descargas y Documentos no aportaron candidatos dentro del alcance temporal obligatorio de compatibilidad de PIA, que comienza en marzo de 2026.
- El primer barrido amplio de normalización agotó su límite operativo sin modificar archivos; el inventario se confirmó sobre las dos ramas de OneDrive donde aparecieron candidatos.

## 5. Inventario anonimizado de candidatos

Para evitar exponer datos personales se usan estos alias de carpeta:

- R = `%USERPROFILE%\OneDrive - Ministerio de Educación\DOCUMENTOSASESORESDRTE\INFORMES\<REDACTED_PERSONAL>\`
- E = `%USERPROFILE%\OneDrive - Ministerio de Educación\MEP-ASESORÍA N\DIDI-2026\EVIDENCIAS-MES\`

Las fechas están expresadas en UTC. Cada fila reúne las ubicaciones que comparten nombre, fecha, tamaño y SHA-256; no se deduplicó ni alteró ningún archivo físico.

### 5.1 Probables planeamientos históricos por nombre y fecha

| Nombre | Carpetas | Fecha UTC | Bytes | SHA-256 |
|---|---|---:|---:|---|
| planeamiento-didáctico.json | R\03-Marzo\Evidencias2026\I quincena\9 MARZO; E\MARZO\9 MARZO | 2026-03-09T13:25:01.846Z | 10049 | ea4ad26c85309d8056e4d1b87164dad045f3ad4901c196f7823e03504e9f0e77 |
| planeamiento.json | R\03-Marzo\Evidencias2026\I quincena\10 MARZO; E\MARZO\10 MARZO | 2026-03-10T17:33:55.399Z | 1752 | b0712a4a27b71b8b2dd7dd6167db0c252a02c94c2b2ae95b433d00d323a9222a |
| planeamiento-didáctico.primero.json | R\03-Marzo\Evidencias2026\I quincena\10 MARZO; E\MARZO\10 MARZO | 2026-03-10T21:10:54.262Z | 5205 | f9fdb235834b875e05edc3a4929a1b533ac7284a72c0e97d7af5034496ea0ff8 |
| planeamiento-didáctico-tercer grado.json | R\03-Marzo\Evidencias2026\I quincena\11 MARZO; E\MARZO\11 MARZO | 2026-03-11T14:34:48.035Z | 5701 | a93d5afed67a386222168346dcdf3e20d9ab0c666077049cceffe000af67f694 |
| planeamiento-didáctico_primero.json | R\03-Marzo\Evidencias2026\I quincena\13 MARZO; E\MARZO\13 MARZO | 2026-03-13T15:09:33.613Z | 5983 | 005c4ba1e9d4e78d881c46249b9dfbf38c3a3ad95771f6e71031a1a718489d59 |
| planeamiento-didáctico-segundo grado.json | R\03-Marzo\Evidencias2026\I quincena\13 MARZO; E\MARZO\13 MARZO | 2026-03-13T15:58:28.833Z | 8091 | 062a3088f3715a991403c92e9ef79072bb83bdc3e7e5a82cc2d54b175d990410 |
| planeamiento-didáctico-segundo gradov2.json | R\03-Marzo\Evidencias2026\I quincena\13 MARZO; E\MARZO\13 MARZO | 2026-03-13T16:11:07.514Z | 7947 | 6d79d7a35bac780aac8ecd79459527527088ed3aaada9eec1e707aa135371b41 |
| planeamiento-didáctico-segundo grado.json | R\03-Marzo\Evidencias2026\II quincena\16 MARZO; E\MARZO\16 MARZO | 2026-03-16T13:48:30.091Z | 5267 | 4a7720a1117a173fd429e28e293ab0f2cf3e7cf203b4c40e306d97fefb6815b8 |
| planeamiento_1774029743217.json | R\03-Marzo\Evidencias2026\II quincena\20 MARZO; E\MARZO\20 MARZO | 2026-03-20T18:02:29.512Z | 17204 | 8c0dc634585725cb66bca15ab629b313e49339c540f521d38e3db72a65a229bc |
| planeamiento_sexto grado.json | R\03-Marzo\Evidencias2026\II quincena\19 MARZO; E\MARZO\19 MARZO | 2026-03-20T20:32:41.997Z | 25301 | 61c99e487714dc779e3603dd20b2da783c440bf694f7a9c50d709cd93e0f1520 |
| planeamiento_prueba 2.json | R\03-Marzo\Evidencias2026\II quincena\19 MARZO; E\MARZO\19 MARZO | 2026-03-20T20:58:32.134Z | 25107 | bec623bc78f2145f7780d1656a90c2d3265eb9f8115491d5686c4a7e8b65a250 |
| planeamiento_cuarto para revisar.json | R\03-Marzo\Evidencias2026\II quincena\20 MARZO; E\MARZO\20 MARZO | 2026-03-20T21:42:30.563Z | 26664 | 242e229f22de4b34022a70adc236c35810531fe7043ec95402e3bdd7a26c4814 |
| planeamiento_TERCERO.json | R\03-Marzo\Evidencias2026\II quincena\23 MARZO; E\MARZO\23 MARZO | 2026-03-23T13:57:21.709Z | 28866 | 363369e6c4c698da3ff19d85aa434d78ae69e239c2b9c09599fcc1b57072b651 |
| planeamiento_QUINTO.json | R\03-Marzo\Evidencias2026\II quincena\27 MARZO; E\MARZO\27 MARZO | 2026-03-27T13:26:44.963Z | 24295 | c46204cc3a6054c2e7c8edf1acb5b3c29a3e7e6ea8984d6840c96e6eb80c7506 |
| planeamiento-didáctico_cuarto.json | R\04-Abril\Evidencias 2026\6 abril; E\ABRIL\6 abril | 2026-04-06T13:50:48.669Z | 4567 | 5afde083bd5065a15084120ebaaffda04b69ff49ad41cd16b43a6b1f2e31fec6 |
| planeamiento-didáctico-primer-grado.json | R\04-Abril\Evidencias 2026\6 abril; E\ABRIL\6 abril | 2026-04-06T17:20:32.954Z | 4421 | 6e447da71c0660e088acafd85eeaf2d59fe71b6e90353b7333f862c99dd3e78f |
| planeamiento-didáctico-setimo año.json | R\04-Abril\Evidencias 2026\6 abril; E\ABRIL\6 abril | 2026-04-07T17:00:08.971Z | 4561 | 5bf6f6883e4159d6afa33df64ac6d6c5bb00f12d28ba0f64616b1fe83d4de0a9 |
| planeamiento-didáctico-segundo grado.json | R\04-Abril\Evidencias 2026\21 abril; E\ABRIL\21 abril | 2026-04-21T15:52:54.146Z | 4821 | 7feb8e10abc7bb1cd5c4d4e76adfa996785cf81d86140a064e60956a99f1cc8c |
| planeamiento-didáctico-segundo prueba.json | R\04-Abril\Evidencias 2026\21 abril; E\ABRIL\21 abril | 2026-04-21T17:16:15.215Z | 3052 | 2bb406927913a82fe715af7d939c1e3978d2ad3ee6f11b8eeed367472eb1aa8c |
| planeamiento-didáctico-2 p.json | R\04-Abril\Evidencias 2026\21 abril; E\ABRIL\21 abril | 2026-04-21T17:19:48.337Z | 3830 | db8f3a6bd3221fc205acbf2c99d3a79683a6c1d4402b9b8d206059c4b518d6ee |
| planeamiento-didáctico-cuarto.json | R\04-Abril\Evidencias 2026\21 abril; E\ABRIL\21 abril | 2026-04-21T17:52:21.827Z | 3962 | 9f0c53ab619e440b5b6a3d2ae2e5d9f26c808960597502aa792c72338cb40a7e |
| planeamiento-didáctico-3°-raee.json | R\05-Mayo\Evidencias 2026\27 mayo; E\MAYO\27 mayo | 2026-05-28T19:22:35.378Z | 6695 | 43d832e919037ccd404cb871b352e136534ae838fc19a4145fba06b18a92f285 |
| planeamiento-didáctico segundo grado.json | R\06-Junio\Evidencias 2026\29 junio; E\JUNIO\29 junio | 2026-06-29T18:01:56.931Z | 4287 | 4be372354f737d4549bb766f531372f2e27f3c1b4e5c1fe638f60164aa30e7ef |

Este grupo comprende 46 archivos físicos y 23 huellas distintas. Por nombre y fecha podrían ser planeamientos históricos de PIA, pero su estructura no fue examinada.

### 5.2 JSON relacionados con PNFT, posibles pero no confirmados

| Nombre | Carpetas | Fecha UTC | Bytes | SHA-256 |
|---|---|---:|---:|---|
| datos_pnft.json | R\04-Abril\Evidencias 2026\16 abril; E\ABRIL\16 abril | 2026-04-16T13:52:44.207Z | 306 | f07ebe62437221436a989a9aa94d79ff00ceaa7677030499bac57a39db7c9e59 |
| backup_pnft_2026-04-16.json | R\04-Abril\Evidencias 2026\15 abril; E\ABRIL\15 abril | 2026-04-16T13:53:38.916Z | 1338 | b402b1ed856eafa83cb1c8490ee91d25e63229af79721ff3af91daca113ce0e4 |
| backup_pnft_2026-04-16.json | R\04-Abril\Evidencias 2026\16 abril; E\ABRIL\16 abril | 2026-04-16T13:54:48.806Z | 1338 | b402b1ed856eafa83cb1c8490ee91d25e63229af79721ff3af91daca113ce0e4 |
| backup_pnft_2026-04-16_prueba2.json | R\04-Abril\Evidencias 2026\15 abril; E\ABRIL\15 abril | 2026-04-16T15:06:37.048Z | 3442 | 7ff574a5822d23e202fb7187ad77b3310c4ab42e74c071518f6b0c0b2668afe5 |
| backup_pnft_2026-04-24-planificadorPNFT.json | R\04-Abril\Evidencias 2026\24 abril; E\ABRIL\24 abril | 2026-04-24T15:57:08.388Z | 11253 | 074bf463ec7d7136fab3cf984cc08afd7fcd517a7504ca8e75cddbfb0e8b08be |
| backup_pnft_2026-04-24_prueba.json | R\04-Abril\Evidencias 2026\24 abril; E\ABRIL\24 abril | 2026-04-24T20:42:03.081Z | 11433 | a5ce0739700c26412a85cb5c9401b3785d57834ee74c25a5db546fd35a66fb3c |
| pnft_progreso.json | R\06-Junio\Evidencias 2026\22 junio; E\JUNIO\22 junio | 2026-06-22T19:16:12.574Z | 60170 | ab5cdd95e2049f237bf2bf4712e7a353a4f7623baa436512427cd169caec82b6 |
| pnft_progreso 2.json | R\06-Junio\Evidencias 2026\22 junio; E\JUNIO\22 junio | 2026-06-22T20:23:16.196Z | 59919 | 23294f027cb1acc73c113cd0318e52eb5e087eda370b65524120dfebac83cef8 |

Este grupo comprende 16 archivos físicos y siete huellas distintas. El nombre y la fecha indican relación con PNFT, pero no permiten afirmar que sean planeamientos ni que tengan el formato vigente.

En total se localizaron 62 archivos físicos dentro del alcance obligatorio desde marzo de 2026, representados por 30 huellas distintas. Las copias con huella idéntica permanecen en sus ubicaciones originales.

## 6. Cambios, pruebas e integridad

- docs/tasks.md: se actualizaron exclusivamente los cuatro criterios ejecutados de la parte A y se añadió la clasificación parcial.
- docs/BITACORA_PIA_PNFT.md: se añadió únicamente esta Entrada 029, sin reescribir documentación histórica.
- No se ejecutaron Playwright, servidor, file:// ni pruebas funcionales.
- No se modificaron index.html, reference/index.original.html, PNFT_DATA, RDA_POR_CICLO, el formato JSON, las pruebas, configuraciones, dependencias ni artefactos.
- Todos los runs previos y sus artefactos permanecen conservados.

Huellas protegidas:

- index.html: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- reference/index.original.html: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- BASELINE.sha256: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- package-lock.json: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.

## 7. Estado, bloqueo y próximo paso

- PIA-T105: PENDIENTE. La parte A está caracterizada, pero no aprueba igualdad por las cuatro diferencias productivas. La parte B no se ha ejecutado.
- PIA-T106: PENDIENTE y no iniciada.
- Los candidatos no constituyen todavía un corpus aprobado o anonimizado.

El próximo paso exige aprobación humana explícita para seleccionar qué candidatos pueden abrirse y, posteriormente, para crear copias anonimizadas destinadas a las pruebas de compatibilidad. Hasta recibirla no se abrirá, analizará, copiará ni anonimizará ningún candidato.

---

# Entrada 030 — 17 de agosto de 2026

## 1. Objetivo y autorización

Continuar PIA-T105 mediante la creación de copias anonimizadas de los cuatro JSON históricos expresamente suministrados en la carpeta privada `Documentos/PIA-T105-JSON-HISTORICOS-PRIVADOS/`. Los originales debían permanecer intactos y las copias debían crearse en `tests/fixtures/historical/PIA-T105/` sin ejecutar todavía compatibilidad ni Playwright.

La autorización exigió preservar estructura, orden, tipos, campos presentes o ausentes, arreglos, cantidad de semanas, formato interno y `fechaGuardado`; sustituir únicamente datos personales, institucionales y textos libres identificables; no mostrar valores privados; comparar originales y copias; confirmar las variantes históricas y detenerse para aprobación humana.

## 2. Autoridad, alcance y comprobaciones previas

- Se leyó la documentación obligatoria en el orden establecido por AGENTS.md.
- La carpeta privada se resolvió mediante la ubicación de Documentos administrada por Windows.
- Se encontraron exactamente cuatro archivos `.json`, sin subdirectorios ni archivos adicionales.
- El destino `tests/fixtures/historical/PIA-T105/` no existía.
- Los archivos se identificaron internamente como `original-01` a `original-04` según el orden lexicográfico de sus nombres, sin registrar ni mostrar nombres o valores privados.
- No se modificaron `index.html`, la referencia, `PNFT_DATA`, `RDA_POR_CICLO`, pruebas, configuraciones, dependencias ni runs anteriores.

## 3. Método de anonimización

Cada JSON se leyó y analizó mediante un recorrido que conservó los intervalos exactos de sus tokens. Las copias se formaron sustituyendo únicamente el token de cadena autorizado y conservando todos los bytes exteriores a esos tokens.

- Los campos personales e institucionales no vacíos se sustituyeron por valores ficticios del mismo tipo y longitud lógica.
- En los textos libres no vacíos se sustituyeron únicamente caracteres alfanuméricos; se conservaron longitud lógica, espacios, saltos, puntuación, entidades, etiquetas HTML, nombres de etiqueta, atributos y orden.
- Los valores curriculares y controlados, incluidos áreas, RdA, saberes, indicadores, opciones procedimentales y actitudinales, no se modificaron.
- Los campos vacíos y un campo de texto libre compuesto únicamente por espacios se conservaron exactamente porque no contenían información identificable.
- `fechaGuardado` no se incluyó en ninguna sustitución y se exigió igualdad semántica y literal.
- Las cuatro copias se escribieron con creación exclusiva, sin permitir sobrescritura.

Un primer intento de preparación se detuvo antes de crear el destino porque el campo formado solo por espacios no producía una sustitución real. Se ajustó la selección para no modificar valores no sensibles. Una comprobación independiente posterior descartó una búsqueda textual de tokens porque un valor privado original usaba una representación escapada distinta; se sustituyó esa comprobación por una comparación léxica de todos los tokens JSON. Ninguno de estos diagnósticos creó copias parciales ni alteró originales.

## 4. Comparación original–copia

No se muestran valores privados. Los identificadores permiten verificar cada pareja mediante sus huellas.

| Original | Copia | Semanas | Sustituciones autorizadas | Bytes original/copia | SHA-256 original | SHA-256 copia |
|---|---|---:|---:|---:|---|---|
| original-01 | `PIA-T105-historical-01.json` | 4 | 0 | 2.837 / 2.837 | `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12` | `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12` |
| original-02 | `PIA-T105-historical-02.json` | 4 | 0 | 6.344 / 6.344 | `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289` | `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289` |
| original-03 | `PIA-T105-historical-03.json` | 2 | 2 textos libres | 4.850 / 4.834 | `29630ea2e1b597d04efee50969dd265efae8ad632a8fd250aa34daefaa30184d` | `0b072ddc7016a0d381c31bd80da7fbd412634ec79946a1395edc25353003c8a4` |
| original-04 | `PIA-T105-historical-04.json` | 7 | 5 personales/institucionales | 5.701 / 5.699 | `a93d5afed67a386222168346dcdf3e20d9ab0c666077049cceffe000af67f694` | `88510d4fc7771a2d86e896c07425a61d7063e51763923b1d8927583c7980ac09` |

Las huellas de los cuatro originales antes y después de escribir las copias coincidieron exactamente. `original-01` y `original-02` no contenían valores sensibles o textos libres alfanuméricos no vacíos en los campos autorizados; por ello sus copias son byte por byte idénticas.

Para las cuatro parejas aprobaron:

- estructura recursiva;
- orden de campos;
- nombres y presencia o ausencia de campos;
- tipos;
- orden y longitud de todos los arreglos;
- cantidad de semanas;
- igualdad de `fechaGuardado`;
- codificación, BOM, saltos de línea y ausencia o presencia de salto final;
- igualdad de todos los bytes exteriores a las cadenas sustituidas;
- formato de textos libres, incluidas etiquetas HTML, espacios y puntuación;
- diferencias limitadas exactamente a los siete valores autorizados;
- ausencia en las copias de los valores sensibles originales.

## 5. Tres variantes históricas confirmadas

La agrupación ignora únicamente la cantidad de elementos y los valores, pero conserva orden de campos, tipos y forma de los objetos y arreglos:

1. `Variante 1` — `original-01` / `PIA-T105-historical-01.json`: incluye `proyeccionGeneral` en el nivel superior y conserva el modelo semanal completo; 4 semanas.
2. `Variante 2` — `original-02`, `original-03` / copias `02` y `03`: no incluye `proyeccionGeneral` y conserva el modelo semanal completo, incluidos `rda` y `recursos`; 4 y 2 semanas.
3. `Variante 3` — `original-04` / `PIA-T105-historical-04.json`: no incluye `proyeccionGeneral` y sus objetos de semana no presentan `rda` ni `recursos`; 7 semanas.

Las tres variantes estructurales se conservaron exactamente en las copias.

## 6. Archivos producidos y documentación

- `tests/fixtures/historical/PIA-T105/PIA-T105-historical-01.json`.
- `tests/fixtures/historical/PIA-T105/PIA-T105-historical-02.json`.
- `tests/fixtures/historical/PIA-T105/PIA-T105-historical-03.json`.
- `tests/fixtures/historical/PIA-T105/PIA-T105-historical-04.json`.
- `docs/tasks.md`: se actualizó únicamente la nota parcial de la parte B; los criterios históricos permanecen sin marcar.
- `docs/BITACORA_PIA_PNFT.md`: se añadió esta Entrada 030 sin reescribir entradas anteriores.

No se creó manifiesto adicional, no se copiaron los originales privados al repositorio y no se registraron valores privados en documentación o salida.

## 7. Integridad y cierre operativo

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Playwright, servidor, navegador, `file://` y compatibilidad histórica: no ejecutados.
- Puerto `4173`: sin escucha.
- Los procesos Node de las utilidades de análisis finalizaron; no quedó un proceso atribuible a esta tarea.

## 8. Estado y próximo paso

PIA-T105 permanece PENDIENTE. El criterio `Reunir JSON históricos anonimizados` no se marca hasta recibir aprobación humana de esta comparación, y `Probar compatibilidad histórica` sigue sin ejecutarse. PIA-T106 permanece PENDIENTE y no fue iniciado.

El próximo paso requiere aprobación humana explícita del corpus y de la comparación original–copia antes de incorporar estos cuatro archivos a la ejecución mínima de compatibilidad.

---

# Entrada 031 — 17 de agosto de 2026

## 1. Objetivo, autoridad y alcance

Continuar exclusivamente PIA-T105 con la aprobación humana del corpus histórico formado por cuatro JSON seleccionados de `Documentos/PIA-T105-JSON-HISTORICOS-PRIVADOS/`, verificar sus originales sin exponer valores privados, utilizar únicamente sus copias anonimizadas y ejecutar una sola caracterización de compatibilidad histórica mediante Chrome y servidor local.

Se aplicaron `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`, `docs/BITACORA_PIA_PNFT.md` y `docs/MAPA_FUNCIONES_PIA_PNFT.json` en el orden obligatorio. No se abrió ni procesó ningún otro candidato de OneDrive institucional. PIA-T106 no se inició.

## 2. Verificación exclusiva de los originales seleccionados

Los cuatro archivos autorizados se abrieron únicamente para su verificación. Todos aprobaron JSON válido, correspondencia con el formato PIA, presencia de `fechaGuardado` como cadena ISO válida, tipos esperados, orden de campos, estructura de semanas y huella SHA-256. No se mostraron ni registraron valores personales, institucionales o de texto libre.

| Archivo autorizado | Semanas | Variante | SHA-256 verificado |
|---|---:|---|---|
| `planeamiento-didáctico_febrero_segundo.json` | 4 | Con `proyeccionGeneral` y semana completa | `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12` |
| `planeamiento-didáctico_materno-transición II.json` | 4 | Regular con `rda` y `recursos` | `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289` |
| `planeamiento-didáctico-primer grado.json` | 2 | Regular con `rda` y `recursos` | `29630ea2e1b597d04efee50969dd265efae8ad632a8fd250aa34daefaa30184d` |
| `planeamiento-didáctico-tercer grado.json` | 7 | Semanas sin `rda` ni `recursos` | `a93d5afed67a386222168346dcdf3e20d9ab0c666077049cceffe000af67f694` |

Los campos superiores fueron los once campos históricos ya documentados en la variante con `proyeccionGeneral` y los diez campos vigentes en las otras tres copias. Los trece campos de `informacionGeneral` y los tres campos de `reflexiones` estuvieron presentes en las cuatro. Las semanas conservaron doce campos en las variantes 1 y 2, y diez campos en la variante 3. Los originales permanecieron fuera del repositorio e intactos.

## 3. Revalidación del corpus anonimizado

Las cuatro copias de `tests/fixtures/historical/PIA-T105/` volvieron a aprobar JSON válido, huella autorizada, estructura, tipos, orden, cantidad de semanas, campos presentes o ausentes y la política de privacidad aprobada:

- `PIA-T105-historical-01.json`: `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12`.
- `PIA-T105-historical-02.json`: `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289`.
- `PIA-T105-historical-03.json`: `0b072ddc7016a0d381c31bd80da7fbd412634ec79946a1395edc25353003c8a4`.
- `PIA-T105-historical-04.json`: `88510d4fc7771a2d86e896c07425a61d7063e51763923b1d8927583c7980ac09`.

Se confirmaron las tres variantes: formato regular con `rda` y `recursos`, formato con `proyeccionGeneral` y formato de semanas sin `rda` ni `recursos`. La comprobación no encontró valores sensibles originales en las copias. La aprobación humana vigente permite marcar `Reunir JSON históricos anonimizados`; el criterio `Probar compatibilidad histórica` permanece pendiente.

## 4. Implementación mínima y comprobaciones previas

Se creó infraestructura separada para no repetir ni alterar la parte A:

- `tests/characterization/json-historical-compatibility.spec.mjs`.
- `playwright.json.historical.config.mjs`.
- `scripts/run-json-historical-characterization.mjs`.
- `package.json`: comando `characterization:json:historical:server`.

La cobertura usa solo las cuatro copias anonimizadas, Chrome y servidor local; abre por el control visible, exige los dos `alert` literales del producto, comprueba la reconstrucción visible, vuelve a guardar mediante el control visible y clasifica preservación, campos ignorados y diferencias productivas. No invoca funciones del producto directamente y no modifica `index.html`.

Aprobaron antes de Playwright:

- `node --check tests/characterization/json-historical-compatibility.spec.mjs`.
- `node --check playwright.json.historical.config.mjs`.
- `node --check scripts/run-json-historical-characterization.mjs`.
- revisión estática de archivos y comando canónico.
- `npm run baseline:verify`: dos archivos protegidos verificados.
- puerto `4173`: cero escuchas; procesos atribuibles a la tarea: cero.

## 5. Única ejecución canónica y fallo real

Se ejecutó una sola vez `npm run characterization:json:historical:server`. El run asignado fue `20260817T190347409Z-ba2d902b817e`.

Las cuatro validaciones previas de fixtures aprobaron. `T105-B01` abrió el archivo mediante el flujo visible y aceptó exactamente los dos `alert` reales. Al capturar el DOM reconstruido, el localizador `.contenedor-editable[data-placeholder*="indicadores"]` resolvió dos elementos: el campo de indicadores de logro y el campo de indicadores de evaluación. Playwright detuvo la ejecución por violación de modo estricto.

Clasificación: fallo de infraestructura de prueba. No existe evidencia de rechazo del JSON ni de un defecto productivo nuevo. El caso no alcanzó la comparación ni el guardado posterior; `T105-B02`, `T105-B03` y `T105-B04` no se ejecutaron. El resultado registró cero casos completados, cuatro fixtures validados, `productModified: false` y `nextTaskStarted: false`.

Conforme a la autorización, el run no se repitió y el localizador no se corrigió automáticamente.

## 6. Artefactos conservados

Se conservan sin sobrescritura:

- `test-results/PIA-T105/historical-server/20260817T190347409Z-ba2d902b817e/.last-run.json`, con estado fallido.
- `json-historical-results.chrome-server.json`.
- `fixture-fingerprints.json`.
- `source-fingerprints.json`.
- `test-failed-1.png`.
- `error-context.md`.
- `trace.zip`.
- `playwright-report/PIA-T105/historical-server/20260817T190347409Z-ba2d902b817e/`.

No se compuso evidencia pendiente porque los cuatro archivos no alcanzaron la apertura y caracterización completas. Los runs anteriores, incluidos los fallidos, permanecen conservados.

## 7. Cambios documentales, integridad y estado operativo

`docs/tasks.md` se actualizó únicamente en PIA-T105: se marcó `Reunir JSON históricos anonimizados` y se mantuvo sin marcar `Probar compatibilidad histórica`, con referencia al run fallido. Esta Entrada 031 es la única entrada nueva; la Entrada 029 y el resto de la documentación histórica no se reescribieron.

Huellas finales:

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Puerto `4173`: cero escuchas después del run.
- Procesos Node, Chrome o servidor atribuibles a la tarea: cero.

No se modificaron `index.html`, `reference/index.original.html`, `PNFT_DATA`, `RDA_POR_CICLO`, los originales privados, las copias anonimizadas, dependencias ni `package-lock.json`.

## 8. Riesgo, bloqueo y próximo paso

PIA-T105 permanece PENDIENTE por un fallo focalizado de infraestructura en el localizador de indicadores de la nueva prueba histórica. PIA-T106 permanece PENDIENTE y no iniciada.

El próximo paso requiere autorización humana explícita para corregir exclusivamente ese localizador, exigir una sola coincidencia semántica y ejecutar, después de las comprobaciones estáticas, una única repetición canónica. No corresponde modificar el producto ni reabrir tareas anteriores.

---

# Entrada 032 — 17 de agosto de 2026

## 1. Objetivo y autorización

Corregir exclusivamente el localizador ambiguo de PIA-T105 en `tests/characterization/json-historical-compatibility.spec.mjs`, sustituir el selector parcial de indicadores por el `data-placeholder` literal del campo Indicadores de logro, exigir una sola coincidencia dentro de cada semana y, si aprobaban las comprobaciones previas, realizar una única repetición de `npm run characterization:json:historical:server`.

La autorización prohibió modificar `index.html`, los cuatro fixtures anonimizados, configuración, lanzador u otros casos; también exigió conservar el run fallido `20260817T190347409Z-ba2d902b817e`, no abrir originales privados, no usar selectores posicionales y no repetir ni corregir automáticamente ante un nuevo fallo.

## 2. Autoridad y archivos revisados

Se leyó completamente la documentación obligatoria en el orden de `AGENTS.md`: `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`, `docs/BITACORA_PIA_PNFT.md` y `docs/MAPA_FUNCIONES_PIA_PNFT.json`.

Se revisaron únicamente la especificación autorizada, las huellas de los archivos protegidos y fixtures, y los metadatos y artefactos de los dos runs fallidos. No se abrieron ni procesaron los originales privados.

## 3. Corrección mínima aplicada

En el helper `editableField(weekRoot, type)`, ya limitado al contenedor `weekRoot`, se sustituyó exactamente:

```text
[data-placeholder*="indicadores"]
```

por:

```text
[data-placeholder="Los indicadores aparecerán automáticamente según los saberes conceptuales seleccionados..."]
```

Se añadió `expect(indicadores).toHaveCount(1)` antes de leer el contenido del campo. No se usaron `first()`, `last()`, `nth()` ni selectores posicionales.

No se modificaron otros archivos de infraestructura, casos, producto o fixtures.

## 4. Comprobaciones previas

Las tres comprobaciones autorizadas aprobaron:

1. `node --check tests/characterization/json-historical-compatibility.spec.mjs`: aprobado.
2. `npm run baseline:verify`: dos archivos protegidos verificados.
3. Verificación estática:
   - selector anterior: 0 apariciones;
   - selector exacto nuevo: 1 aparición;
   - selectores posicionales: 0;
   - `toHaveCount(1)`: 3 apariciones totales;
   - aserción específica `expect(indicadores).toHaveCount(1)`: 1 aparición.

## 5. Única repetición y nuevo fallo

Se ejecutó una sola vez `npm run characterization:json:historical:server`. El nuevo run fue `20260817T191329156Z-b585dca72516`.

Las cuatro validaciones de fixtures aprobaron. La apertura visible de `T105-B01`, sus dos `alert` literales y la unicidad del campo Indicadores de logro aprobaron. Después, al terminar `snapshotVisiblePlan()`, la infraestructura produjo:

```text
ReferenceError: metodologiaSelect is not defined
```

La función declara `methodologySelect`, pero el objeto de retorno usa el identificador inexistente `metodologiaSelect`. Se clasifica como un segundo fallo real de infraestructura, distinto del localizador autorizado. El resultado registró cero casos completados, cuatro fixtures validados, `productModified: false` y `nextTaskStarted: false`.

No existe evidencia de rechazo del JSON ni de un defecto productivo nuevo. `T105-B02`, `T105-B03` y `T105-B04` no se ejecutaron. El run no se repitió y el defecto no se corrigió automáticamente.

## 6. Conservación de runs y artefactos

El run anterior permanece intacto:

- `test-results/PIA-T105/historical-server/20260817T190347409Z-ba2d902b817e/`: 7 archivos; huella agregada `d1cb7c132b46308a63260cea2935f040b16aa10e68c0569ff7c6f4569173f8e8`.
- `playwright-report/PIA-T105/historical-server/20260817T190347409Z-ba2d902b817e/`: 22 archivos; huella agregada `db17f355406575ead7a5e442f2491a41382eb46ec634ff6dce8fa5f1bcf5476c`.

El nuevo run queda conservado:

- `test-results/PIA-T105/historical-server/20260817T191329156Z-b585dca72516/`: 7 archivos; huella agregada `b77cbfb0d7eb9aef25471c6ce99337b440cb2a08ef108c9cc8b83bd0504de6e7`.
- `playwright-report/PIA-T105/historical-server/20260817T191329156Z-b585dca72516/`: 22 archivos; huella agregada `44031f9999b35025213748b2002c5f8e033fb34e393b7f8afd42311ccb8b31df`.

El nuevo run conserva `.last-run.json` fallido, resultado JSON, huellas de fuentes y fixtures, captura, contexto de error, traza y reporte HTML. No se compuso evidencia pendiente porque B01–B04 no completaron la caracterización.

## 7. Integridad y cierre operativo

Huellas protegidas finales:

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.

Huellas de fixtures sin cambios:

- `PIA-T105-historical-01.json`: `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12`.
- `PIA-T105-historical-02.json`: `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289`.
- `PIA-T105-historical-03.json`: `0b072ddc7016a0d381c31bd80da7fbd412634ec79946a1395edc25353003c8a4`.
- `PIA-T105-historical-04.json`: `88510d4fc7771a2d86e896c07425a61d7063e51763923b1d8927583c7980ac09`.

Después del run, el puerto `4173` tiene cero escuchas y no queda ningún proceso Node, Chrome, Playwright o servidor atribuible a la tarea.

## 8. Estado y próximo paso

PIA-T105 permanece PENDIENTE; el criterio de compatibilidad histórica continúa sin marcar. `docs/tasks.md` no se modificó en esta acción. PIA-T106 permanece PENDIENTE y no iniciada.

El próximo paso requiere autorización humana explícita para corregir exclusivamente la inconsistencia `methodologySelect`/`metodologiaSelect`, ejecutar las comprobaciones focalizadas que se indiquen y, solo entonces, realizar como máximo una nueva ejecución canónica.

---

# Entrada 033 — 17 de agosto de 2026

## 1. Objetivo y autorización

Corregir exclusivamente el `ReferenceError` de PIA-T105 en `tests/characterization/json-historical-compatibility.spec.mjs` mediante el cambio único `metodologiaSelect` → `methodologySelect`; comprobar el ámbito del objeto retornado por `snapshotVisiblePlan()`; ejecutar sintaxis y línea base; y, si todo aprobaba, realizar una sola ejecución canónica de compatibilidad histórica.

La autorización exigió conservar íntegros los runs fallidos `20260817T190347409Z-ba2d902b817e` y `20260817T191329156Z-b585dca72516`, no modificar producto, fixtures, configuración, lanzador u otros comportamientos de prueba, no reabrir originales privados, componer evidencia pendiente si B01–B04 aprobaban y no iniciar PIA-T106.

## 2. Autoridad, archivos revisados y cambio mínimo

Se leyó completamente la documentación obligatoria en el orden de `AGENTS.md`: `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`, `docs/BITACORA_PIA_PNFT.md` y `docs/MAPA_FUNCIONES_PIA_PNFT.json`.

El único cambio de código fue:

```text
- metodologiaSelect
+ methodologySelect
```

en el objeto retornado por `snapshotVisiblePlan()`. No se modificó ninguna otra conducta de la prueba.

## 3. Comprobaciones previas

Todas aprobaron:

1. `methodologySelect` está declarado exactamente una vez dentro de `snapshotVisiblePlan()`.
2. `metodologiaSelect` tiene cero apariciones en la especificación.
3. El único identificador abreviado del objeto `return` es `methodologySelect` y está declarado en el ámbito; no existen identificadores abreviados sin declarar.
4. `node --check tests/characterization/json-historical-compatibility.spec.mjs`: aprobado.
5. `npm run baseline:verify`: dos archivos protegidos verificados.

## 4. Ejecución canónica aprobada

Se ejecutó una sola vez `npm run characterization:json:historical:server`. El run fue `20260817T192020156Z-d89faadb5d5d` y aprobó una prueba en 40,6 segundos con Chrome `151.0.7922.138` y servidor local.

| Caso | Variante | Semanas esperadas/observadas | Alertas | Rechazo | Resultado |
|---|---|---:|---:|---|---|
| T105-B01 | Con `proyeccionGeneral` | 4/4 | 2 | No | Abierto y caracterizado |
| T105-B02 | Regular con `rda` y `recursos` | 4/4 | 2 | No | Abierto y caracterizado |
| T105-B03 | Regular con `rda` y `recursos` | 2/2 | 2 | No | Abierto y caracterizado |
| T105-B04 | Semanas sin `rda` ni `recursos` | 7/7 | 2 | No | Abierto y caracterizado |

Los cuatro casos utilizaron exclusivamente los controles visibles y las copias anonimizadas. Todos reconstruyeron los controles generales, la cantidad exacta de semanas, los campos base y las selecciones conceptuales esperadas. Se produjeron ocho `alert` en total, dos por archivo, con los textos literales vigentes. No hubo errores de página, consola o respuestas locales; la solicitud externa de Google Fonts quedó bloqueada por el aislamiento de red.

## 5. Comportamientos productivos de línea base

Se registraron sin corregir:

- `fechaGuardado` se regenera en cada guardado real: cuatro diferencias volátiles.
- `semana.indicadores` se recalcula al abrir: tres diferencias en B01, tres en B02, una en B03 y siete en B04; catorce en total.
- `proyeccionGeneral` se acepta al abrir B01, pero el cargador vigente lo ignora y el guardado posterior lo omite.
- B02 muestra los arreglos procedimentales y actitudinales de la primera semana en el orden de los controles del DOM; el JSON re-guardado conserva los arreglos y su orden histórico.
- B04 conserva la ausencia histórica de los campos semanales `rda` y `recursos`.
- No hubo diferencias de tipos, longitudes de arreglos ni orden de campos comunes.
- No se reprodujeron diferencias históricas en `semana.lecciones`. El hallazgo de la parte A permanece limitado a los cuatro valores libres creados en esa prueba y a `reconstruirVistaSemanasPreservandoContenido()`.

Estos resultados caracterizan el comportamiento del producto protegido y no constituyen autorización para modificarlo.

## 6. Privacidad, estructura y huellas del corpus

Las cuatro copias aprobaron JSON válido, formato PIA, `fechaGuardado` ISO, estructura, orden, tipos, cantidad de semanas, campos presentes o ausentes y la huella anonimizada aprobada. Playwright no abrió los originales privados.

- `PIA-T105-historical-01.json`: `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12`.
- `PIA-T105-historical-02.json`: `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289`.
- `PIA-T105-historical-03.json`: `0b072ddc7016a0d381c31bd80da7fbd412634ec79946a1395edc25353003c8a4`.
- `PIA-T105-historical-04.json`: `88510d4fc7771a2d86e896c07425a61d7063e51763923b1d8927583c7980ac09`.

## 7. Evidencia pendiente

Se creó `evidence/pending/characterization/PIA-T105/` sin sobrescribir destino previo. Contiene:

- `README.md`.
- `roundtrip-current-results.json` y `roundtrip-current-input.json` de la parte A.
- `json-historical-results.chrome-server.json`.
- `fixture-fingerprints.json` y `source-fingerprints.json`.
- `T105-B01.resaved.json` a `T105-B04.resaved.json`.
- `test-results-summary.json`.
- `manifest.sha256`.

Los nueve artefactos copiados son binariamente iguales a sus fuentes. El manifiesto validó 11/11 archivos, sin faltantes ni extras. Su huella es `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`. La comprobación de privacidad no encontró rutas del perfil, nombres de los originales privados ni la carpeta privada en la evidencia.

## 8. Conservación de runs, integridad y cierre operativo

Los dos runs fallidos permanecen intactos:

- `20260817T190347409Z-ba2d902b817e`: resultados 7 archivos, huella agregada `d1cb7c132b46308a63260cea2935f040b16aa10e68c0569ff7c6f4569173f8e8`; reporte 22 archivos, `db17f355406575ead7a5e442f2491a41382eb46ec634ff6dce8fa5f1bcf5476c`.
- `20260817T191329156Z-b585dca72516`: resultados 7 archivos, huella agregada `b77cbfb0d7eb9aef25471c6ce99337b440cb2a08ef108c9cc8b83bd0504de6e7`; reporte 22 archivos, `44031f9999b35025213748b2002c5f8e033fb34e393b7f8afd42311ccb8b31df`.

El run aprobado también permanece conservado:

- `20260817T192020156Z-d89faadb5d5d`: resultados 8 archivos, huella agregada `4fdbae53b6580bd86215b5eb136f0c2cd0fa056119ba74416a2da02a169b895a`; reporte 1 archivo, `91e9e4e8b8a9da105b2708c5c4321f8f215f7c24d3fa5ca47131c3bc2308da20`.

Huellas protegidas finales:

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Manifiesto aprobado de PIA-T104: `bca2ed5993d7d6884a5e1d3b8ef2299fb53ebb2849d2e7f60acb4b3365367ae6`, 4/4.

Después del run, el puerto `4173` tiene cero escuchas y no queda ningún proceso Node, Chrome, Playwright o servidor atribuible a la tarea. No se modificaron producto, referencia, datos curriculares, fixtures, configuración, lanzador, dependencias ni `package-lock.json`.

## 9. Estado, bloqueo y próximo paso

`docs/tasks.md` se actualizó únicamente en el bloque PIA-T105: se marcó `Probar compatibilidad histórica`, se registró el run aprobado y se añadió la ruta de evidencia pendiente. Todos los criterios están marcados, pero PIA-T105 permanece PENDIENTE hasta aprobación humana final. Esta Entrada 033 es la única entrada nueva; las Entradas 031 y 032 no se reescribieron.

PIA-T106 permanece PENDIENTE y no iniciada. El próximo paso es la revisión humana de `evidence/pending/characterization/PIA-T105/`; no corresponde promover ni cerrar PIA-T105 sin esa aprobación.

---

# Entrada 034 — 17 de agosto de 2026

## 1. Objetivo y aprobación humana

Cerrar documentalmente PIA-T105 después de recibir aprobación humana final, promoviendo exactamente `evidence/pending/characterization/PIA-T105/` hacia `evidence/approved/characterization/PIA-T105/`, conservando el origen pendiente y sin ejecutar nuevamente Playwright, navegador o servidor.

La aprobación autorizó actualizar únicamente el bloque PIA-T105 de `docs/tasks.md`, registrar esta única entrada final y prohibió modificar tareas anteriores o iniciar PIA-T106.

## 2. Autoridad y comprobaciones previas

Se leyó completamente la documentación obligatoria en el orden de `AGENTS.md`: `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`, `docs/BITACORA_PIA_PNFT.md` y `docs/MAPA_FUNCIONES_PIA_PNFT.json`.

Antes de la promoción se confirmó:

- origen pendiente existente, plano y compuesto por 12 archivos;
- destino aprobado inexistente;
- manifiesto del origen: 11/11 archivos válidos, sin faltantes ni extras;
- huella del manifiesto: `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`;
- cuatro estados `approved-copy-fingerprint-matched` en la validación de fixtures;
- `originalPrivateFilesUsedByPlaywright: false`;
- cero rutas del perfil, nombres de originales privados o referencias a la carpeta privada en la evidencia;
- fixtures, runs y huellas protegidas intactos;
- puerto `4173` sin escucha y cero procesos atribuibles a la tarea.

## 3. Promoción y validación binaria

Se creó el destino sin sobrescritura y se copiaron exactamente los 12 archivos. El origen `evidence/pending/characterization/PIA-T105/` permanece conservado.

La comparación posterior confirmó:

- inventarios origen–destino idénticos: 12/12;
- igualdad binaria: 12/12;
- manifiesto aprobado: 11/11;
- cero faltantes y cero archivos extra;
- huella del manifiesto aprobado: `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`;
- huella agregada del árbol aprobado: `b080a85fb7f4c3260ca473a783af94b610d77a678429d086b9323c8c186b4d9e`.

Huellas de los 12 archivos promovidos:

- `README.md`: `452e11ae21e840fa951b08d7c7b9bb200abb2961d5b5d09d364930ca9d1c4082`.
- `T105-B01.resaved.json`: `a47ae5bb3044d7b24fa8dbdb0a56268cb11d4a870ef96ac39994a37abd52184b`.
- `T105-B02.resaved.json`: `fe51a037e7b36a0724a9bc9b4259a22f13563a62249ad4cc2ef73f31c00d7101`.
- `T105-B03.resaved.json`: `80e7422a13fcedf4a5e938d2a7a8b0fad2af8bd92227f85026e779b21e513f7a`.
- `T105-B04.resaved.json`: `0c812ad1d1fe10ea89b8093df4b3ca18b0ae81c94a2cabe2767c58af9b36f528`.
- `fixture-fingerprints.json`: `2ce7d7d429b93fb4a0faf2def6f77df8581be113515c39bc2062b6472ef34fae`.
- `json-historical-results.chrome-server.json`: `814ea38019bc9849b8b948ffdef0cdee40dd737e60c59aa647d8aa2519c65f66`.
- `manifest.sha256`: `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`.
- `roundtrip-current-input.json`: `9820b16fd4293ef1872c87b179ed27559674dac4329d0b404b21e77bce3b802f`.
- `roundtrip-current-results.json`: `9d0ce76ab8399961cd6ff635e407d9aee06b4dd55716f38613eb42c332da58a7`.
- `source-fingerprints.json`: `eabe930d5708168c3ae196e4487ce2b1a7902aa0d9aaeaa90aa8664a54994af8`.
- `test-results-summary.json`: `48fd5806c187fbe714f86a9f7c8ec8c3f7cf730c62f88febab3a53cc17eb3330`.

## 4. Privacidad y corpus histórico

La ausencia de valores privados se confirma por transitividad de las cuatro copias anonimizadas ya aprobadas y sus huellas exactas, por la igualdad binaria de la evidencia pendiente validada y la evidencia aprobada, y por la validación de que los artefactos históricos fueron generados exclusivamente desde esas copias. La comprobación adicional encontró cero rutas, nombres de archivos originales o referencias a la carpeta privada.

Los cuatro originales privados permanecen intactos y fuera del repositorio; no se abrieron ni procesaron durante esta acción. Los cuatro fixtures anonimizados permanecen intactos:

- `PIA-T105-historical-01.json`: `45e921f411c2b153b95146bd134001cdc6aec9d60ac8e5ea28b7feb8ea268f12`.
- `PIA-T105-historical-02.json`: `75e649515d1866c69e918dac41a7bbca8bdef365727a480b29517f50e70a6289`.
- `PIA-T105-historical-03.json`: `0b072ddc7016a0d381c31bd80da7fbd412634ec79946a1395edc25353003c8a4`.
- `PIA-T105-historical-04.json`: `88510d4fc7771a2d86e896c07425a61d7063e51763923b1d8927583c7980ac09`.

## 5. Comportamientos productivos caracterizados

La aprobación y el cierre conservan la clasificación ya validada:

- cuatro diferencias literales de `semana.lecciones` en el round-trip actual, causadas por `reconstruirVistaSemanasPreservandoContenido()`;
- regeneración de `fechaGuardado` al guardar;
- recálculo de `semana.indicadores` al abrir;
- omisión de `proyeccionGeneral` al re-guardar B01;
- normalización visual del orden de selecciones procedimentales y actitudinales en B02;
- conservación de la ausencia histórica de `rda` y `recursos` en B04.

Estos comportamientos productivos no fueron corregidos. No se modificaron `index.html`, la referencia, `PNFT_DATA`, `RDA_POR_CICLO` ni el formato JSON.

## 6. Conservación de runs

Los dos runs fallidos y el run aprobado permanecen intactos:

- `20260817T190347409Z-ba2d902b817e`: resultados `d1cb7c132b46308a63260cea2935f040b16aa10e68c0569ff7c6f4569173f8e8`; reporte `db17f355406575ead7a5e442f2491a41382eb46ec634ff6dce8fa5f1bcf5476c`.
- `20260817T191329156Z-b585dca72516`: resultados `b77cbfb0d7eb9aef25471c6ce99337b440cb2a08ef108c9cc8b83bd0504de6e7`; reporte `44031f9999b35025213748b2002c5f8e033fb34e393b7f8afd42311ccb8b31df`.
- `20260817T192020156Z-d89faadb5d5d`: resultados `4fdbae53b6580bd86215b5eb136f0c2cd0fa056119ba74416a2da02a169b895a`; reporte `91e9e4e8b8a9da105b2708c5c4321f8f215f7c24d3fa5ca47131c3bc2308da20`.

## 7. Huellas protegidas y estado operativo

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Manifiesto aprobado de PIA-T104: `bca2ed5993d7d6884a5e1d3b8ef2299fb53ebb2849d2e7f60acb4b3365367ae6`, 4/4.

No se ejecutaron Playwright, navegador, servidor o `file://`. Al cierre, el puerto `4173` tiene cero escuchas y no queda ningún proceso Node, Chrome, Playwright o servidor atribuible a la tarea.

## 8. Cierre documental

`docs/tasks.md` se actualizó únicamente en el bloque PIA-T105:

- Estado: COMPLETADA.
- Seis criterios marcados.
- Evidencia aprobada: `evidence/approved/characterization/PIA-T105/`.

No se modificaron tareas anteriores ni PIA-T106. Esta Entrada 034 es la única entrada nueva y no reescribe las Entradas 031, 032 o 033.

PIA-T105 queda COMPLETADA con aprobación humana final. PIA-T106 permanece PENDIENTE y no iniciada.

---

# Entrada 035 — 17 de agosto de 2026

## 1. Objetivo y autorización humana

Implementar y ejecutar el alcance mínimo aprobado de PIA-T106 para caracterizar la exportación vigente: PDF completo, selección parcial, textos extensos, caracteres especiales, saltos y tablas, y el estado no visible de Word. La autorización exigió una sola revisión estática focalizada y una única ejecución canónica con Chrome y servidor local, sin `file://` y sin iniciar PIA-T107.

## 2. Autoridad, archivos revisados y alcance

Se leyó completamente la documentación obligatoria en el orden de `AGENTS.md`: `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md`, `docs/BITACORA_PIA_PNFT.md` y `docs/MAPA_FUNCIONES_PIA_PNFT.json`.

La revisión funcional se limitó al flujo visible de exportación de `index.html`, al modal `#exportarModal`, a los controles de selección, a la creación de la ventana imprimible y a la presencia sin llamadores de `exportarAWord()`. También se revisaron `BASELINE.sha256`, `package.json`, `package-lock.json` y la evidencia aprobada de PIA-T105. No se realizó una revisión general de la aplicación.

Archivos de infraestructura creados o modificados:

- `tests/characterization/export.spec.mjs`.
- `playwright.export.config.mjs`.
- `scripts/run-export-characterization.mjs`.
- `package.json`, únicamente para añadir `characterization:export:server`.

No se modificaron `index.html`, `reference/index.original.html`, `PNFT_DATA`, `RDA_POR_CICLO`, el formato JSON, fixtures, dependencias, funciones productivas ni `package-lock.json`.

## 3. Implementación mínima y revisión focalizada

La prueba utiliza datos exclusivamente ficticios y recorre los controles visibles: completa el plan, abre el modal mediante el botón productivo y activa `Exportar PDF`. Captura la ventana emergente creada realmente por PIA y toma su DOM exacto como referencia principal. Solo después genera mediante `page.pdf()` un artefacto identificado como representación reproducible de esa vista.

La revisión estática focalizada aprobó:

- sintaxis de lanzador, configuración y especificación;
- seis identificadores exactos T106-01–T106-06;
- Chrome y modo servidor como única combinación;
- una sola llamada `popup.pdf()` en la infraestructura;
- controles de exportación visibles localizados de forma única;
- cero cobertura `file://`;
- cero automatizaciones de Ctrl+P, teclado o clic del botón `Imprimir Ahora`;
- cero llamadas directas a `exportarAPDF()`, `confirmarExportacion()` o `exportarAWord()`;
- línea base verificada y puerto `4173` libre antes del run.

## 4. Única ejecución canónica

Se ejecutó exactamente una vez:

```text
npm run characterization:export:server
```

Run: `20260817T203021229Z-c4fe02bb3466`.

Resultado Playwright: 1 prueba agregada aprobada, seis casos, un worker, cero reintentos, Chrome `151.0.7922.138`, servidor local, 57.5 segundos de prueba y 1.1 minutos totales.

Resultados por caso:

- **T106-01 — PDF completo:** aprobó ocho secciones en orden exacto, cuatro semanas, encabezado, pie, tabla general, contenido seleccionado y PDF de 261896 bytes.
- **T106-02 — selección parcial:** aprobó la inclusión exacta de información general, ejes, metodología, reflexiones y observaciones; excluyó áreas/RdA, saberes globales y semanas; no incluyó encabezado ni pie. PDF de 83956 bytes.
- **T106-03 — textos extensos:** aprobó la conservación completa del texto en el DOM imprimible. PDF de 217983 bytes.
- **T106-04 — caracteres especiales:** aprobó Unicode, tildes, símbolos y caracteres especiales completos. PDF de 265226 bytes.
- **T106-05 — saltos, HTML y tablas:** caracterizó que el producto elimina las etiquetas y marcadores de salto aportados en los campos editables, conserva su texto visible normalizado y genera/conserva la tabla general de dos filas y ocho celdas. PDF de 206712 bytes.
- **T106-06 — Word:** aprobó cero controles Word visibles, una declaración de `exportarAWord()`, cero llamadores, cero `onclick`, cero descargas y confirmación de que la función no fue invocada. PDF de 78900 bytes.

Los seis PDF tienen firma `%PDF-`, tamaño no vacío y SHA-256 coincidente. En conjunto suman 1114673 bytes. Las seis instantáneas HTML coinciden en tamaño y huella con el DOM registrado.

## 5. Página, consola, ventanas y red

- Ventanas imprimibles creadas por el flujo visible: 6/6.
- Errores de página: 0.
- Errores de consola: 0. Se conservaron únicamente los dos mensajes informativos esperados por caso.
- Errores de respuesta local: 0.
- Solicitudes externas bloqueadas: 6, una solicitud de Google Fonts por caso.
- Descargas: 0.
- Diálogo nativo de Windows automatizado: no.
- Ctrl+P utilizado: no.
- Botón productivo `Imprimir Ahora` pulsado: no.
- `file://` ejecutado: no.

## 6. Evidencia pendiente y conservación

Se compuso `evidence/pending/characterization/PIA-T106/` con 17 archivos: README, resultado completo, huellas de fuente, resumen, seis instantáneas HTML, seis PDF y manifiesto. Los 14 artefactos copiados son binariamente iguales a sus fuentes.

El manifiesto validó 16/16 archivos, sin faltantes ni extras:

- huella de `manifest.sha256`: `7c48d4a2f79a0c3aebb59ee29d40d198fa4aa51acb1ded1c678939282352b00a`;
- huella agregada del árbol de evidencia: `f87e28f24cb877bdf2041065a8a6edee5611e473496757a679b9236204730668`;
- referencias a rutas del perfil o nombres privados: 0.

El run permanece íntegro:

- resultados: 15 archivos, huella agregada `dd7bd7d8eefb5fcf97dba32d6a84bd26edb6deb65eafef904e0ae4bf62c58841`;
- reporte: 1 archivo, huella `024e561e745ce9441d208fa6a3e02717e37bca69aeb53c9cea41a7c38267e90b`.

La primera operación estándar de copia de evidencia se detuvo antes de copiar archivos debido al límite de ruta de Windows y dejó únicamente el destino vacío. La composición continuó con copia binaria de rutas largas, exclusión de sobrescritura y validación posterior 14/14; no afectó el run ni requirió repetir la prueba.

## 7. Integridad y cierre operativo

Huellas finales:

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Manifiesto aprobado de PIA-T105: `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`, 11/11.

Al cierre, el puerto `4173` tiene cero escuchas y hay cero procesos Node y Chrome. Edge mantiene 12 procesos preexistentes ajenos a la tarea; no fue invocado, instalado ni actualizado.

## 8. Estado, riesgos y próximo paso

`docs/tasks.md` se actualizó únicamente en PIA-T106: los seis criterios quedaron marcados, se registró el run y se añadió la ruta de evidencia pendiente. El estado permanece **PENDIENTE** hasta aprobación humana.

No se identificó un fallo real, diferencia de integridad ni bloqueo. El tratamiento de saltos y etiquetas HTML quedó registrado como comportamiento productivo de línea base y no fue corregido. Esta Entrada 035 es la única entrada nueva; no se reescribieron entradas anteriores.

Próximo paso: revisión humana de `evidence/pending/characterization/PIA-T106/`. PIA-T107 no fue iniciada.

---

# Entrada 036 — 17 de agosto de 2026

## 1. Objetivo y aprobación humana

Cerrar documentalmente PIA-T106 después de recibir aprobación humana final, promoviendo exactamente `evidence/pending/characterization/PIA-T106/` hacia `evidence/approved/characterization/PIA-T106/`, conservando el origen pendiente y sin volver a ejecutar Playwright, Chrome o servidor.

La aprobación autorizó actualizar únicamente el bloque PIA-T106 de `docs/tasks.md`, registrar esta única entrada final y prohibió modificar tareas anteriores o iniciar PIA-T107.

## 2. Autoridad, alcance y comprobaciones previas

Se leyó la documentación obligatoria en el orden de `AGENTS.md`: `AGENTS.md`, `docs/info.md`, `docs/SPEC.md`, `docs/tasks.md`, `docs/ANALISIS_FUNCIONAL_PIA_PNFT.md` y `docs/BITACORA_PIA_PNFT.md`. La acción no requirió analizar funciones o dependencias, por lo que no correspondió ampliar el alcance al mapa funcional.

Antes de copiar se confirmó:

- origen pendiente existente y compuesto por 17 archivos;
- destino aprobado inexistente;
- manifiesto pendiente válido 16/16, sin faltantes ni extras;
- seis PDF y seis instantáneas DOM presentes;
- huella del manifiesto pendiente `7c48d4a2f79a0c3aebb59ee29d40d198fa4aa51acb1ded1c678939282352b00a`;
- documentación explícita de que los PDF son representaciones reproducibles de las ventanas imprimibles generadas por PIA;
- normalización de etiquetas de T106-05 conservada como comportamiento productivo de línea base;
- `exportarAWord()` documentada como no visible ni invocada;
- run canónico, huellas protegidas, procesos y puerto intactos.

## 3. Promoción y validación binaria

Se creó el destino sin sobrescritura y se copiaron exactamente los 17 archivos. No se regeneró, editó ni transformó ningún archivo de evidencia. El origen `evidence/pending/characterization/PIA-T106/` permanece conservado.

La validación posterior confirmó:

- inventarios origen–destino idénticos: 17/17;
- igualdad binaria: 17/17;
- manifiesto aprobado: 16/16;
- cero faltantes y cero archivos extra;
- huella del manifiesto aprobado: `7c48d4a2f79a0c3aebb59ee29d40d198fa4aa51acb1ded1c678939282352b00a`;
- huella agregada idéntica de los árboles pendiente y aprobado: `f87e28f24cb877bdf2041065a8a6edee5611e473496757a679b9236204730668`.

## 4. Resultados aprobados T106-01–T106-06

- **T106-01 — exportación PDF completa:** ocho secciones, cuatro semanas, encabezado, pie, tabla general y contenido seleccionado aprobados.
- **T106-02 — selección parcial:** inclusión y exclusión exactas de secciones, encabezado y pie aprobadas.
- **T106-03 — textos extensos:** conservación completa en el DOM imprimible aprobada.
- **T106-04 — caracteres especiales:** Unicode, tildes, símbolos y caracteres especiales aprobados.
- **T106-05 — saltos, HTML y tablas:** se conserva como comportamiento de línea base que PIA elimina las etiquetas y marcadores de salto aportados en campos editables, preserva su texto visible normalizado y genera/conserva la tabla general. No se corrigió el producto.
- **T106-06 — Word:** cero controles Word visibles, cero llamadores, cero `onclick`, cero descargas y confirmación de que `exportarAWord()` no fue invocada.

Los seis PDF aprobados permanecen identificados como representaciones reproducibles generadas mediante `page.pdf()` solamente después de que el flujo visible de PIA creó cada ventana imprimible. No representan automatización del diálogo nativo de Windows. Los seis PDF y las seis instantáneas DOM permanecen tanto en el run canónico como en la evidencia pendiente y aprobada.

## 5. Conservación del run y ausencia de nuevas ejecuciones

El run canónico `20260817T203021229Z-c4fe02bb3466` permanece intacto:

- resultados: 15 archivos, huella agregada `dd7bd7d8eefb5fcf97dba32d6a84bd26edb6deb65eafef904e0ae4bf62c58841`;
- reporte: 1 archivo, huella `024e561e745ce9441d208fa6a3e02717e37bca69aeb53c9cea41a7c38267e90b`.

Durante este cierre no se ejecutaron Playwright, Chrome, servidor, `file://`, Ctrl+P ni diálogo nativo de impresión.

## 6. Huellas protegidas y estado operativo

- `index.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `reference/index.original.html`: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- `BASELINE.sha256`: `aab35a3fd1e39e481bb4dcb08bd1e352082f7f38e08aba28eda407fb8da00055`.
- `package-lock.json`: `6ed1a4a1d7ab22993d424458cbec0948b8042e5851055d23011483fad6cb2069`.
- Manifiesto aprobado de PIA-T105: `740e8168012932c2ef04ae46d8aa601a5efe7db67463baae2b5cbbed4894ef1d`, 11/11.
- Manifiesto aprobado de PIA-T106: `7c48d4a2f79a0c3aebb59ee29d40d198fa4aa51acb1ded1c678939282352b00a`, 16/16.

Al cierre, el puerto `4173` tiene cero escuchas y hay cero procesos Node y Chrome. Los procesos Edge preexistentes permanecen ajenos a la tarea; Edge no fue invocado, instalado ni actualizado.

## 7. Cierre documental y próximo paso

`docs/tasks.md` se actualizó exclusivamente en el bloque PIA-T106:

- Estado: COMPLETADA.
- Seis criterios marcados.
- Evidencia aprobada: `evidence/approved/characterization/PIA-T106/`.

La comparación de las regiones externas al bloque confirmó que las tareas anteriores y PIA-T107 permanecen sin modificaciones. Esta Entrada 036 es la única entrada nueva y no reescribe la Entrada 035.

PIA-T106 queda COMPLETADA con aprobación humana final. PIA-T107 permanece PENDIENTE y no fue iniciada.
