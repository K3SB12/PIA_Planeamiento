# info.md — Contexto y fuente de conocimiento de PIA-PNFT

## 1. Identificación

PIA es la Plantilla de Planeamiento Didáctico del Programa Nacional de Formación Tecnológica. Fue creada para facilitar a docentes de Formación Tecnológica e Informática Educativa la organización automatizada de información curricular y la construcción de planeamientos.

El aplicativo se encuentra publicado, distribuido y utilizado desde marzo de 2026.

## 2. Propósito

PIA permite que una persona docente:

- registre información general del planeamiento;
- seleccione ciclo y nivel;
- defina la cantidad de lecciones y semanas;
- seleccione áreas de conocimiento;
- consulte resultados de aprendizaje;
- seleccione saberes conceptuales;
- obtenga indicadores asociados;
- seleccione saberes procedimentales y actitudinales;
- incorpore estrategias de mediación e indicadores de evaluación;
- registre reflexiones y observaciones;
- guarde y abra el planeamiento mediante JSON;
- exporte el planeamiento;
- genere un *prompt* general o semanal;
- copie el *prompt* y abra ChatGPT o Copilot manualmente;
- descargue una versión portable.

## 3. Condiciones originales

- No se dispone de un servidor de aplicación.
- No existe presupuesto para APIs de inteligencia artificial.
- No se almacenan claves de ChatGPT o Copilot.
- No se utiliza autenticación.
- No se utiliza una base de datos remota.
- La información se procesa en el navegador.
- Debe funcionar con conexión y sin conexión.
- Debe poder distribuirse mediante GitHub Pages y descargarse en una computadora.
- Los docentes no deben instalar Node.js para utilizar el producto final.

## 4. Objetivo de la reorganización

La reorganización tiene como único propósito mejorar la comprensión, mantenimiento, persistencia y escalabilidad del código interno.

No corresponde a un rediseño ni a una sustitución del aplicativo. La plantilla, datos, secuencia, correspondencias, funciones y resultados deben permanecer iguales.

## 5. Áreas de conocimiento

PIA organiza información de las siguientes áreas del PNFT:

1. Apropiación Tecnológica y Digital.
2. Programación y Algoritmos.
3. Computación Física y Robótica.
4. Ciencia de Datos e Inteligencia Artificial.

Los nombres y su capitalización deben conservarse según la fuente curricular vigente utilizada por el aplicativo.

## 6. Ejes transversales

- Pensamiento computacional.
- Ciudadanía y ética digital.
- Emprendimiento e innovación.

## 7. Metodologías

El aplicativo contempla metodologías activas asociadas con los ciclos y permite una metodología personalizada cuando corresponda:

- Aprendizaje basado en juegos (ABJ).
- Aprendizaje basado en retos (ABR).
- Pensamiento por Diseño/APD, según la denominación implementada en la versión vigente.
- Otra metodología personalizada.

La reorganización no debe cambiar los valores, textos ni reglas vigentes de selección.

## 8. Base curricular interna

### 8.1 `PNFT_DATA`

`PNFT_DATA` es la base curricular interna y columna vertebral de los módulos.

Su relación conceptual es:

```text
Nivel → Módulo → Área de conocimiento → Saber conceptual → Indicadores
```

Incluye niveles desde 0° hasta 9° y los módulos/áreas implementados en la versión vigente.

### 8.2 `RDA_POR_CICLO`

Conserva los resultados de aprendizaje:

```text
Ciclo → Área de conocimiento → Resultado de aprendizaje
```

### 8.3 Protección

Ambas estructuras contienen texto validado. No pueden corregirse, resumirse, completarse o trasladarse sin solicitud curricular expresa.

## 9. Tipos de saberes

PIA articula:

- saberes conceptuales;
- saberes procedimentales;
- saberes actitudinales.

Los saberes conceptuales y sus indicadores proceden de la base curricular. Los procedimentales y actitudinales se presentan mediante opciones establecidas en el aplicativo.

## 10. Modelo actual de una semana

Cada semana puede contener:

```text
id
nombre
lecciones
areas
rda
saberes
procedimentales
actitudinales
actividades
recursos
evaluacion
indicadores
```

La representación visible y la forma en que el aplicativo conserva estos valores deben mantenerse durante la reorganización.

## 11. Flujos principales

### 11.1 Selección curricular

```text
Ciclo → nivel → semana → área → RdA → saber → indicador
```

### 11.2 Planeamiento

```text
Información general → semanas → saberes → mediación → evaluación → reflexión
```

### 11.3 Inteligencia artificial sin API

```text
Completar plantilla → generar prompt → revisar/copiar → abrir IA → pegar manualmente
```

### 11.4 Persistencia

```text
Interfaz → objeto del plan → JSON → descarga local
JSON local → lectura → reconstrucción del plan
```

## 12. Versiones que deben diferenciarse

En la futura arquitectura se distinguirán:

- versión del aplicativo;
- versión de la base curricular;
- versión del esquema JSON de planeamiento;
- versión web;
- versión portable.

La introducción de estas versiones no autoriza cambios en el contenido vigente.

## 13. Fuentes de verdad del proyecto

| Fuente | Función |
|---|---|
| `reference/index.original.html` | Comportamiento y apariencia de referencia |
| `PNFT_DATA` | Datos de módulos, áreas, saberes e indicadores |
| `RDA_POR_CICLO` | Resultados de aprendizaje |
| `docs/SPEC.md` | Requisitos obligatorios |
| `AGENTS.md` | Reglas de trabajo |
| `docs/tasks.md` | Trabajo pendiente y evidencia |
| `docs/BITACORA_PIA_PNFT.md` | Historia de acciones y decisiones |

## 14. Glosario mínimo

| Término | Significado dentro del proyecto |
|---|---|
| PIA | Plantilla de Planeamiento Didáctico PNFT |
| PNFT | Programa Nacional de Formación Tecnológica |
| RdA | Resultado de aprendizaje |
| Base curricular | `PNFT_DATA` y `RDA_POR_CICLO` |
| Plan JSON | Archivo local con información del planeamiento |
| Versión portable | HTML autónomo para uso sin conexión |
| Reorganización | Cambio interno que no altera el producto visible |
| Equivalencia | Igualdad visual, funcional, curricular y de compatibilidad |

## 15. Estado de esta documentación

La información describe la versión recibida y analizada en agosto de 2026. Cualquier actualización deberá registrarse en la bitácora y contar con evidencia y aprobación correspondientes.
