# Análisis funcional y mapa de dependencias de PIA-PNFT

**Sistema analizado:** Plantilla de Planeamiento Didáctico PNFT (PIA)  
**Archivo fuente:** `index(2).html`  
**Estado del análisis:** diagnóstico estático; sin modificaciones al aplicativo  
**Huella SHA-256 del archivo original:** `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`

## 1. Propósito

Este informe documenta la estructura funcional del aplicativo PIA-PNFT antes de cualquier reorganización. Su finalidad es permitir que una persona desarrolladora, revisora o agente de programación comprenda qué hace cada función, cómo se relacionan las funciones entre sí, cuáles datos globales comparten, qué elementos curriculares consultan, cuáles riesgos existen y qué pruebas deben establecerse antes de refactorizar.

La revisión no modifica la interfaz, los estilos, `PNFT_DATA`, `RDA_POR_CICLO`, los formatos de exportación ni los archivos JSON generados por el aplicativo.

## 2. Alcance y método

Se realizaron las siguientes acciones:

1. Verificación de integridad y codificación del archivo HTML.
2. Comprobación sintáctica del bloque JavaScript.
3. Análisis del árbol sintáctico de JavaScript.
4. Extracción de funciones, parámetros, líneas y relaciones de llamada.
5. Identificación de manejadores de eventos HTML.
6. Identificación de variables globales y estructuras curriculares.
7. Identificación de accesos al DOM y APIs del navegador.
8. Reconstrucción de los flujos funcionales principales.
9. Clasificación preliminar de criticidad y riesgo.
10. Formulación de pruebas de caracterización.

Este es un análisis estático. Los hallazgos denominados “probable defecto” deben confirmarse posteriormente mediante pruebas ejecutadas en navegador antes de modificar el código.

## 3. Resumen ejecutivo

PIA es un aplicativo web estático y autónomo, ejecutado completamente en el navegador. Integra en un solo archivo la interfaz, los estilos, los datos curriculares, el estado del planeamiento, las exportaciones y la generación de *prompts*.

### 3.1 Métricas principales

| Indicador | Resultado |
|---|---:|
| Tamaño del archivo | 290.524 bytes |
| Líneas físicas | 5.624 |
| Declaraciones de función | 58 |
| Nombres de función únicos | 57 |
| Funciones de nivel superior | 53 |
| Funciones internas de exportación PDF | 5 |
| Estructuras globales principales | 7 |
| Manejadores HTML detectados | 42 |
| Usos de `innerHTML` | 31 |
| Usos de `textContent` | 4 |
| Solicitudes de red mediante `fetch` | 0 |
| Uso de base de datos remota | 0 |
| Acceso directo a `PNFT_DATA` | 5 funciones |
| Acceso directo a `RDA_POR_CICLO` | 3 funciones |
| Funciones dependientes de `semanas` | 24 |

### 3.2 Conclusión principal

El mayor problema técnico no es la ausencia de funcionalidad, sino el acoplamiento. La variable global `semanas` conecta selección curricular, interfaz, guardado, carga, exportación y generación de *prompts*. A su vez, la identidad de los saberes se conserva principalmente mediante su nombre visible, sin registrar de forma estable el nivel, módulo y área de procedencia.

La modernización debe comenzar con pruebas de equivalencia y una capa de acceso curricular; no con una reescritura visual.

## 4. Arquitectura funcional actual

```mermaid
flowchart TD
    UI["Formulario y semanas"] --> STATE["Estado global semanas"]
    DATA["PNFT_DATA"] --> CURR["Selección curricular"]
    RDA["RDA_POR_CICLO"] --> CURR
    CURR --> STATE
    STATE --> SAVE["Guardar y cargar JSON"]
    STATE --> EXPORT["Exportar PDF y Word"]
    STATE --> PROMPT["Prompt general y semanal"]
    SAVE --> UI
```

El sistema tiene cinco capas mezcladas dentro del mismo bloque:

- **Contenido oficial:** `PNFT_DATA` y `RDA_POR_CICLO`.
- **Estado:** semanas y conjuntos globales.
- **Lógica de dominio:** selección de áreas, saberes e indicadores.
- **Interfaz:** creación de HTML, modales y mensajes.
- **Infraestructura del navegador:** archivos, impresión, ventanas y portapapeles.

## 5. Estructuras globales

| Estructura | Tipo | Propósito | Dependencia | Criticidad |
|---|---|---|---:|---|
| `PNFT_DATA` | Objeto constante | Base curricular por nivel, módulo, área, saber e indicador | 5 funciones directas | Crítica |
| `RDA_POR_CICLO` | Objeto constante | Resultados de aprendizaje por ciclo y área | 3 funciones directas | Crítica |
| `semanas` | Arreglo mutable | Estado operativo completo del planeamiento semanal | 24 funciones | Crítica |
| `saberesSeleccionados` | `Set` mutable | Consolidado global de saberes conceptuales | 8 funciones | Alta |
| `saberesProcedimentalesGlobales` | `Set` mutable | Consolidado global procedimental | 7 funciones | Alta |
| `saberesActitudinalesGlobales` | `Set` mutable | Consolidado global actitudinal | 7 funciones | Alta |
| `formatoExportacion` | Cadena mutable | Selección del formato de exportación | 3 funciones | Baja |

### 5.1 Modelo de una semana

Cada elemento de `semanas` conserva:

```text
id, nombre, lecciones, areas, rda, saberes,
procedimentales, actitudinales, actividades,
recursos, evaluacion, indicadores
```

Observaciones:

- `rda` se inicializa, pero la actualización visible de RdA no asigna claramente el texto a `semana.rda`; la interfaz lo calcula desde `RDA_POR_CICLO`.
- `recursos` forma parte del estado, aunque no aparece como una de las tres columnas editables principales generadas por `crearElementoSemana()`.
- Los saberes se guardan por `nombre`, sin identificador compuesto de nivel, módulo y área.

## 6. Mapa de acceso curricular

### 6.1 Funciones que consultan `PNFT_DATA`

| Función | Uso |
|---|---|
| `actualizarAreaSemana()` | Intenta retirar saberes asociados al desmarcar un área |
| `generarSaberesConceptuales()` | Construye las opciones de saberes por módulo y área |
| `buscarSaberesEnTodasEstructuras()` | Compatibilidad con estructuras curriculares alternativas |
| `actualizarIndicadoresSemana()` | Convierte saberes seleccionados en indicadores visibles |
| `obtenerIndicadoresLogroSemana()` | Obtiene indicadores limpios para los *prompts* |

### 6.2 Funciones que consultan `RDA_POR_CICLO`

| Función | Uso |
|---|---|
| `actualizarRdASemana()` | Presenta el RdA de cada área seleccionada |
| `exportarAWord()` | Incluye RdA en el documento Word |
| `exportarAPDF()` | Incluye RdA en el documento PDF |

### 6.3 Riesgo de identidad curricular

El estado guarda un saber de esta forma:

```text
"Software"
```

No conserva necesariamente:

```text
nivel + módulo + área + saber
```

Cuando existen nombres repetidos, las búsquedas recorren primero Módulo 1 y luego Módulo 2. Esto puede asociar el saber con el primer indicador coincidente, aunque la selección original corresponda a otro módulo. La futura arquitectura debe utilizar identificadores curriculares estables sin cambiar el texto oficial visible.

## 7. Flujos funcionales

### 7.1 Inicio

```mermaid
flowchart LR
    DOM["DOMContentLoaded"] --> INIT["inicializarSemanas"]
    DOM --> EVENTS["configurarEventListeners"]
    EVENTS --> UPDATE["Actualizar semanas"]
    EVENTS --> METHOD["Cambiar metodología"]
```

### 7.2 Selección curricular semanal

```mermaid
flowchart TD
    AREA["Marcar área"] --> AS["actualizarAreaSemana"]
    AS --> RD["actualizarRdASemana"]
    AS --> SC["actualizarOpcionesSaberesSemana"]
    SC --> GS["generarSaberesConceptuales"]
    GS --> DATA["PNFT_DATA"]
    AS --> IND["actualizarIndicadoresSemana"]
    IND --> DATA
    RD --> RDA["RDA_POR_CICLO"]
```

### 7.3 Selección de un saber

```text
Marcar saber
→ manejarSeleccionSaber()
→ actualizar semana.saberes
→ actualizar saberesSeleccionados
→ actualizar contenedor conceptual
→ buscar indicadores en PNFT_DATA
→ guardar HTML de indicadores en la semana
```

### 7.4 Cambio de cantidad de lecciones

```text
Cambio en leccionesPlanificadas
→ actualizarSemanasPreservandoContenido()
→ respaldar semanas y conjuntos globales
→ confirmar si se reducirán semanas
→ recrear arreglo y elementos visuales
→ restaurar estado mediante temporizador
→ actualizar contadores
```

### 7.5 Guardado

```text
Botón Guardar
→ ejecutarGuardarNormal()
→ obtenerDatosPlan()
→ JSON.stringify()
→ Blob
→ descarga planeamiento-didáctico.json
→ mostrarMensaje()
```

### 7.6 Apertura

```text
Botón Abrir
→ abrirPlan()
→ seleccionar archivo .json
→ FileReader
→ JSON.parse()
→ cargarPlan()
→ reconstruir semanas
→ restaurar selección curricular
→ recalcular RdA, saberes e indicadores
```

### 7.7 Prompt general

```text
generarPromptCompleto()
→ validar ciclo y nivel
→ obtener ejes y metodología
→ obtener indicadores por semana
→ consolidar saberes
→ construir texto editable
→ mostrar modal
→ copiar o abrir ChatGPT/Copilot
```

### 7.8 Prompt semanal

```text
generarPromptSemana(numero)
→ validar ciclo, nivel y áreas
→ leer semana
→ obtener indicadores
→ incorporar saberes y metodología
→ construir instrucciones pedagógicas
→ mostrar modal semanal
```

### 7.9 Exportación

La interfaz activa fuerza actualmente el formato PDF. `exportarAWord()` permanece implementada, pero no tiene un llamador activo detectado.

```text
Abrir opciones
→ seleccionar PDF
→ confirmarExportacion()
→ exportarAPDF()
→ construir documento imprimible
→ abrir ventana/descargar resultado
```

## 8. Catálogo de funciones

La columna “riesgo” se refiere al impacto potencial de modificar la función sin pruebas, no a que la función esté necesariamente defectuosa.

### 8.1 Inicialización y configuración

| N.º | Función y líneas | Propósito | Dependencias principales | Riesgo |
|---:|---|---|---|---|
| 1 | `configurarEventListeners()` 2375–2378 | Vincula cambios de lecciones y metodología con sus controladores | DOM | Medio |
| 2 | `manejarCambioMetodologia()` 2380–2389 | Muestra u oculta la metodología personalizada | DOM | Bajo |
| 3 | `actualizarNiveles()` 2391–2412 | Regenera los niveles según el ciclo | `ciclo`, `nivel`, `innerHTML` | Alto |

### 8.2 Gestión de semanas

| N.º | Función y líneas | Propósito | Relaciones | Riesgo |
|---:|---|---|---|---|
| 4 | `inicializarSemanas()` 2414–2446 | Crea el estado y la interfaz inicial de semanas | llama `crearElementoSemana`, `actualizarContadoresSemanas` | Alto |
| 5 | `actualizarSemanasPreservandoContenido()` 2448–2508 | Cambia el número de semanas procurando conservar datos | reconstrucción, conjuntos globales, temporizador | Crítico |
| 6 | `crearElementoSemana()` 2510–2618 | Genera toda la interfaz dinámica de una semana | opciones, eventos inline, `innerHTML` | Crítico |
| 20 | `actualizarLeccionesSemana()` 3106–3108 | Actualiza el rótulo de lecciones de una semana | `semanas` | Medio |
| 21 | `actualizarContenidoSemana()` 3110–3112 | Guarda contenido editable HTML por tipo | `semanas`, contenido HTML | Alto |
| 22 | `agregarSemanaManual()` 3114–3143 | Agrega una semana y aumenta lecciones | creación y contadores | Alto |
| 23 | `eliminarSemana()` 3145–3193 | Elimina una semana y depura consolidados globales | reconstrucción, conjuntos globales | Crítico |
| 24 | `reconstruirVistaSemanasPreservandoContenido()` 3195–3271 | Reconstruye la interfaz y restaura selecciones y textos | múltiples funciones, selectores, temporizadores | Crítico |
| 25 | `actualizarContadoresSemanas()` 3273–3276 | Sincroniza totales visibles | `semanas`, DOM | Bajo |

### 8.3 Saberes procedimentales y actitudinales

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 7 | `generarOpcionesProcedimentales()` 2620–2646 | Produce casillas y descripciones procedimentales | HTML dinámico | Medio |
| 8 | `generarOpcionesActitudinales()` 2648–2665 | Produce casillas y descripciones actitudinales | HTML dinámico | Medio |
| 18 | `actualizarProcedimentalSemana()` 3068–3085 | Sincroniza selección semanal y global procedimental | `semanas`, `Set` global | Alto |
| 19 | `actualizarActitudinalSemana()` 3087–3104 | Sincroniza selección semanal y global actitudinal | `semanas`, `Set` global | Alto |

### 8.4 Núcleo curricular

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 9 | `actualizarAreaSemana()` 2667–2696 | Agrega o retira áreas y actualiza RdA, saberes e indicadores | `PNFT_DATA`, `semanas` | Crítico |
| 10 | `actualizarRdASemana()` 2698–2718 | Renderiza resultados de aprendizaje de áreas seleccionadas | `RDA_POR_CICLO` | Crítico |
| 11 | `actualizarOpcionesSaberesSemana()` 2720–2726 | Coordina la lista disponible y el resumen seleccionado | generador y contenedor | Alto |
| 12 | `generarSaberesConceptuales()` 2728–2818 | Genera saberes de Módulo 1 y Módulo 2 por área | `PNFT_DATA` | Crítico |
| 13 | `buscarSaberesEnTodasEstructuras()` 2821–2894 | Compatibilidad con estructuras alternativas de datos | `PNFT_DATA` | Alto |
| 14 | `actualizarSaberesConceptualesContenedor()` 2896–2917 | Renderiza el resumen de saberes seleccionados | `semanas` | Alto |
| 15 | `manejarSeleccionSaber()` 2919–2949 | Agrega o elimina un saber y actualiza indicadores | estado semanal/global | Crítico |
| 16 | `actualizarIndicadoresSemana()` 2951–3028 | Localiza y renderiza indicadores de saberes seleccionados | `PNFT_DATA` | Crítico |
| 17 | `obtenerIndicadoresLogroSemana()` 3030–3066 | Devuelve indicadores únicos para *prompts* | `PNFT_DATA` | Crítico |

### 8.5 Metodología y acciones generales

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 26 | `mostrarDetalleMetodologia()` 3278–3282 | Delega la visibilidad del campo personalizado | `manejarCambioMetodologia` | Bajo |
| 27 | `nuevoPlan()` 3285–3289 | Confirma y recarga el aplicativo | `location.reload` | Medio |

### 8.6 Guardado y carga

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 28 | `abrirPlan()` 3291–3340 | Selecciona, lee e interpreta un JSON local | `FileReader`, `JSON.parse`, `cargarPlan` | Crítico |
| 29 | `guardarPlan()` 3343–3347 | Adaptador que delega el guardado normal | `ejecutarGuardarNormal` | Bajo |
| 30 | `ejecutarGuardarNormal()` 3350–3371 | Primera declaración del guardado JSON | datos, `Blob`, descarga | Alto |
| 31 | `obtenerDatosPlan()` 3373–3410 | Serializa formulario, semanas, reflexiones y consolidados | estado global y DOM | Crítico |
| 32 | `cargarPlan()` 3412–3494 | Restaura un objeto JSON en estado e interfaz | reconstrucción y currículo | Crítico |
| 49 | `toggleMenuGuardar()` 5326–5330 | Abre o cierra el menú de guardado | DOM | Bajo |
| 50 | `ejecutarGuardarNormal()` 5332–5350 | Segunda declaración; reemplaza efectivamente la primera | datos, `Blob`, descarga | Alto |
| 51 | `ejecutarGuardarOffline()` 5352–5358 | Delega la creación de la versión portable | descarga portable | Medio |
| 52 | `descargarVersionPortable()` 5371–5399 | Descarga el documento HTML actual completo | `outerHTML`, `Blob` | Alto |

### 8.7 Exportación

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 33 | `mostrarOpcionesExportar()` 3499–3516 | Inicializa el modal con PDF seleccionado | `formatoExportacion` | Bajo |
| 34 | `cerrarExportModal()` 3519–3521 | Cierra el modal | DOM | Bajo |
| 35 | `seleccionarFormato()` 3524–3537 | Actualiza la selección visual y lógica | `formatoExportacion` | Bajo |
| 36 | `confirmarExportacion()` 3540–3557 | Fuerza PDF y activa la exportación | `exportarAPDF` | Alto |
| 37 | `exportarAWord()` 3559–3949 | Construye y descarga una representación compatible con Word | estado, RdA, HTML, `Blob` | Crítico |
| 38 | `exportarAPDF()` 3951–5147 | Construye el documento imprimible/PDF completo | estado, RdA, ventana, helpers | Crítico |
| 39 | `limpiarContenidoParaPDF()` 3972–3995 | Limpia HTML para la salida PDF | función interna | Alto |
| 40 | `formatearContenidoComoHTML()` 3997–4025 | Transforma contenido para presentación | función interna | Alto |
| 41 | `ajustarFuenteSegunLongitud()` 4028–4040 | Calcula ajuste tipográfico según longitud | función interna | Medio |
| 42 | `ajustarAlturaMinima()` 4043–4054 | Calcula altura mínima del contenido | función interna | Medio |
| 43 | `formatearContenidoConAjuste()` 4057–4102 | Combina limpieza y ajustes de salida | función interna | Alto |

Las funciones 39–43 están declaradas dentro de `exportarAPDF()`; no son servicios reutilizables desde el resto del sistema.

### 8.8 Prompt general, enlaces y portapapeles

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 44 | `generarPromptCompleto()` 5150–5302 | Construye el contexto y las instrucciones de todas las semanas | currículo, semanas, ejes, metodología | Crítico |
| 45 | `cerrarPromptModal()` 5304–5306 | Cierra el modal general | DOM | Bajo |
| 46 | `copiarPrompt()` 5308–5313 | Copia el prompt general | `document.execCommand` | Medio |
| 47 | `abrirEnCopilot()` 5315–5318 | Abre Copilot en otra pestaña | `window.open` | Bajo |
| 48 | `abrirEnChatGPT()` 5320–5323 | Abre ChatGPT en otra pestaña | `window.open` | Bajo |

### 8.9 Utilidades pedagógicas, mensajes y prompt semanal

| N.º | Función y líneas | Propósito | Dependencias | Riesgo |
|---:|---|---|---|---|
| 53 | `obtenerEjesTransversales()` 5402–5411 | Convierte códigos de casillas en nombres pedagógicos | DOM y mapeo interno | Alto |
| 54 | `obtenerMetodologiaActiva()` 5413–5426 | Normaliza la metodología seleccionada | DOM y mapeo interno | Alto |
| 55 | `mostrarMensaje()` 5429–5472 | Presenta notificaciones temporales | DOM, `innerHTML`, temporizadores | Medio |
| 56 | `cerrarPromptSemanaModal()` 5474–5476 | Cierra el modal semanal | DOM | Bajo |
| 57 | `copiarPromptSemana()` 5478–5483 | Copia el prompt semanal | `document.execCommand` | Medio |
| 58 | `generarPromptSemana()` 5486–5608 | Construye instrucciones para una semana específica | currículo, semana, ejes y metodología | Crítico |

## 9. Dependencias centrales

### 9.1 Funciones con más relaciones entrantes

| Función | Cantidad de orígenes detectados | Papel |
|---|---:|---|
| `actualizarAreaSemana()` | 5 | Punto de entrada al flujo curricular semanal |
| `actualizarContadoresSemanas()` | 5 | Sincronización posterior a cambios de semanas |
| `limpiarContenidoParaPDF()` | 5 | Núcleo interno de limpieza para PDF |
| `crearElementoSemana()` | 4 | Fábrica principal de interfaz semanal |
| `cerrarExportModal()` | 4 | Cierre compartido de exportación |
| `manejarSeleccionSaber()` | 4 | Entrada de selección conceptual |

### 9.2 Funciones de mayor tamaño

| Función | Líneas | Observación |
|---|---:|---|
| `exportarAPDF()` | 1.197 | Concentra datos, estilos, formato, limpieza y salida |
| `exportarAWord()` | 391 | Concentra construcción completa del documento |
| `generarPromptCompleto()` | 153 | Mezcla recolección, normalización y plantilla textual |
| `generarPromptSemana()` | 123 | Mezcla validación, datos y plantilla textual |
| `crearElementoSemana()` | 109 | Mezcla estructura HTML, eventos y contenido pedagógico |

Estas funciones son candidatas a separación, pero solo después de contar con pruebas de equivalencia.

## 10. Hallazgos y riesgos

### H-01. Función duplicada de guardado — prioridad alta

`ejecutarGuardarNormal()` está declarada en las líneas 3350 y 5332. La segunda declaración prevalece. Ambas son muy similares, pero la primera comprueba si existe el menú y la segunda asume que existe.

**Riesgo:** una modificación futura puede realizarse en la versión que no se ejecuta.  
**Acción previa:** prueba de guardado y consolidación controlada en una sola implementación.

### H-02. Estado curricular identificado solo por nombre — prioridad crítica

`manejarSeleccionSaber()` recibe área e indicadores, pero conserva principalmente `nombreSaber`. Los parámetros `area` e `indicadores` no forman parte de una identidad persistente.

**Riesgo:** nombres iguales en módulos o áreas diferentes pueden recuperar indicadores incorrectos.  
**Acción futura:** identificador estable `nivel-modulo-area-saber`, manteniendo el nombre visible.

### H-03. Probable error al desmarcar un área — prioridad crítica

`actualizarAreaSemana()` usa `Object.values(PNFT_DATA[nivel])` y presupone que cada valor contiene directamente `.saberes`. En la estructura vigente, esos valores son `Módulo 1` y `Módulo 2`, que contienen áreas antes de llegar a `saberes`.

**Riesgo:** posible excepción al desmarcar un área y pérdida de sincronización.  
**Prueba requerida:** seleccionar nivel, marcar área, seleccionar saber, desmarcar área y verificar consola/estado en todos los niveles.

### H-04. Carga JSON sin esquema ni versión — prioridad crítica

`abrirPlan()` valida la extensión y que el contenido pueda interpretarse como JSON. `cargarPlan()` comprueba parcialmente la existencia de propiedades, pero no valida tipos, tamaño, versión ni campos inesperados.

**Riesgos:** datos incompatibles, estados incompletos e inserción de HTML no confiable en campos restaurados.  
**Acción futura:** esquema JSON, `schemaVersion`, límite de tamaño y migraciones explícitas.

### H-05. Contenido del JSON reinsertado mediante `innerHTML` — prioridad crítica

Los campos editables conservan HTML y se restauran mediante `innerHTML` durante la reconstrucción.

**Riesgo:** un archivo JSON manipulado podría insertar elementos HTML peligrosos. La selección manual del archivo reduce la exposición, pero no elimina el riesgo.  
**Acción futura:** sanitización permitida por lista blanca y pruebas con archivos maliciosos controlados.

### H-06. Reconstrucción dependiente de tiempos fijos — prioridad alta

La preservación y carga utilizan retrasos de 100 ms y 500 ms.

**Riesgo:** comportamiento distinto según velocidad del equipo, volumen de semanas o navegador.  
**Acción futura:** operaciones deterministas y promesas/eventos de finalización.

### H-07. `exportarAPDF()` concentra demasiadas responsabilidades — prioridad alta

La función tiene 1.197 líneas e incluye helpers internos, lectura de datos, composición de contenido, estilos, apertura de ventana y descarga.

**Riesgo:** cualquier cambio de formato puede afectar información, impresión o cierre del modal.  
**Acción futura:** separar modelo de exportación, plantilla, estilos y adaptador del navegador.

### H-08. Exportación Word implementada pero no accesible — prioridad media

`exportarAWord()` no tiene llamador activo detectado y la interfaz fuerza PDF.

**Riesgo:** código extenso sin cobertura que puede confundirse con una función vigente.  
**Decisión requerida:** documentarla como función suspendida, reactivarla formalmente o retirarla en una versión posterior.

### H-09. Copiado con API heredada — prioridad media

Los dos flujos usan `document.execCommand('copy')`.

**Riesgo:** compatibilidad futura y comportamiento dependiente del navegador.  
**Acción futura:** `navigator.clipboard.writeText` con alternativa compatible.

### H-10. Portabilidad visual parcialmente dependiente de Internet — prioridad media

El HTML incluye Poppins desde Google Fonts. La lógica y estilos principales están embebidos, pero la tipografía remota no está disponible sin conexión.

**Riesgo:** variación visual offline.  
**Acción futura:** fuente local autorizada o pila de fuentes del sistema, con comparación visual.

### H-11. La descarga portable no equivale necesariamente a un respaldo del plan — prioridad alta

`descargarVersionPortable()` serializa `document.documentElement.outerHTML`. Los valores actuales de algunos controles de formulario se conservan como propiedades del DOM y no necesariamente como atributos HTML serializados.

**Riesgo:** interpretar el HTML portable como respaldo completo de datos ingresados.  
**Acción:** mantener el JSON como respaldo oficial y probar explícitamente qué datos conserva el HTML portable.

### H-12. Compatibilidad curricular alternativa incompleta — prioridad media

`buscarSaberesEnTodasEstructuras()` construye una variable local `html`, pero retorna un booleano. Además, contiene una búsqueda que referencia `saber` sin declararlo en una rama. Con la estructura actual normalizada, varias de estas rutas pueden no ejecutarse.

**Riesgo:** falla si se utiliza una estructura de datos antigua o alternativa.  
**Acción:** pruebas con estructuras realmente admitidas y eliminación solo después de confirmar compatibilidad histórica.

### H-13. Estado de semana potencialmente desalineado después de eliminar — prioridad media

La interfaz se reconstruye usando el índice, pero los objetos conservan sus propiedades originales `id` y `nombre` salvo que otra función las normalice.

**Riesgo:** identificadores internos y rótulos persistidos diferentes al orden visible.  
**Prueba:** eliminar una semana intermedia, guardar, abrir y comparar orden e identificadores.

### H-14. Selectores dependientes de textos de ayuda — prioridad media

La restauración localiza campos con selectores como `data-placeholder*="indicadores"`, `*="estrategias"` y `*="evaluación"`.

**Riesgo:** cambiar una frase visible puede romper la restauración del contenido.  
**Acción futura:** atributos técnicos estables como `data-field="assessment-indicators"`.

## 11. Matriz inicial de pruebas de caracterización

| Código | Flujo | Prueba | Prioridad |
|---|---|---|---|
| T-CUR-01 | Ciclo–nivel | Cada ciclo muestra únicamente sus niveles | Alta |
| T-CUR-02 | Área–RdA | Cada área presenta el RdA exacto del ciclo | Crítica |
| T-CUR-03 | Área–saberes | Cada nivel/módulo/área muestra sus saberes exactos | Crítica |
| T-CUR-04 | Saber–indicador | Cada saber recupera sus indicadores correctos | Crítica |
| T-CUR-05 | Nombres repetidos | Un saber repetido conserva módulo y área correctos | Crítica |
| T-CUR-06 | Desmarcar área | Retira únicamente saberes del área y no genera errores | Crítica |
| T-SEM-01 | Inicialización | 8 lecciones generan 4 semanas | Alta |
| T-SEM-02 | Aumento | Aumentar lecciones conserva semanas existentes | Crítica |
| T-SEM-03 | Reducción cancelada | Cancelar conserva todo el contenido | Crítica |
| T-SEM-04 | Reducción aceptada | Elimina solo semanas excedentes | Crítica |
| T-SEM-05 | Eliminación intermedia | Renumera y conserva las semanas restantes | Crítica |
| T-SEM-06 | Tres reconstrucciones | No duplica eventos ni pierde selecciones | Alta |
| T-JSON-01 | Guardar/cargar | Un plan guardado se restaura exactamente | Crítica |
| T-JSON-02 | Compatibilidad | Abre planes generados desde marzo de 2026 | Crítica |
| T-JSON-03 | Archivo inválido | Rechaza JSON incompleto sin alterar el plan actual | Crítica |
| T-JSON-04 | HTML malicioso | No ejecuta contenido insertado desde JSON | Crítica |
| T-PDF-01 | Exportación completa | Todas las secciones seleccionadas aparecen | Crítica |
| T-PDF-02 | Contenido extenso | No recorta tablas ni textos largos | Alta |
| T-PDF-03 | Caracteres | Conserva tildes, símbolos y saltos | Alta |
| T-PROM-01 | Prompt general | Incluye semanas, saberes, indicadores, ejes y metodología | Crítica |
| T-PROM-02 | Prompt semanal | Incluye solo los datos de la semana indicada | Crítica |
| T-OFF-01 | Ejecución offline | Abre y funciona sin red | Crítica |
| T-OFF-02 | Fuente externa | Mantiene apariencia aceptada sin Google Fonts | Media |
| T-OFF-03 | Datos actuales | Define si el HTML portable conserva o no el plan ingresado | Alta |

## 12. Propuesta de módulos de destino

La separación futura debería seguir los límites funcionales ya encontrados:

```text
src/
├── data/
│   ├── pnft-data.json
│   ├── rda-por-ciclo.json
│   └── curriculum-manifest.json
├── curriculum/
│   ├── curriculum-repository.js
│   ├── curriculum-identifiers.js
│   └── curriculum-validation.js
├── planning/
│   ├── planning-state.js
│   ├── week-service.js
│   └── planning-schema.js
├── ui/
│   ├── week-view.js
│   ├── curriculum-view.js
│   ├── dialogs.js
│   └── notifications.js
├── persistence/
│   ├── plan-reader.js
│   ├── plan-writer.js
│   └── migrations.js
├── export/
│   ├── export-model.js
│   ├── pdf-exporter.js
│   └── portable-builder.js
├── prompts/
│   ├── prompt-data.js
│   ├── general-prompt.js
│   └── weekly-prompt.js
└── main.js
```

La aplicación portable se generaría automáticamente desde estos módulos. La fuente modular no sustituye la salida de un solo archivo; la produce.

## 13. Orden recomendado de intervención

1. Congelar y etiquetar la versión vigente.
2. Aprobar este catálogo funcional.
3. Crear las pruebas de caracterización sin cambiar el código.
4. Definir el esquema versionado de planes JSON.
5. Crear identificadores curriculares estables.
6. Extraer `PNFT_DATA` y `RDA_POR_CICLO` sin modificar textos.
7. Crear un repositorio curricular de solo lectura.
8. Extraer el estado y las operaciones de semanas.
9. Separar las vistas dinámicas.
10. Separar persistencia, exportación y *prompts*.
11. Generar versión web y versión portable.
12. Ejecutar comparación funcional y visual.
13. Realizar revisión independiente de programación, pruebas y seguridad.
14. Publicar primero en un entorno de validación.
15. Mantener reversión inmediata a la versión de marzo de 2026.

## 14. Criterios para considerar equivalente la versión reorganizada

La reorganización será aceptable únicamente si:

- conserva todas las secciones y controles actuales;
- no modifica textos curriculares validados;
- mantiene los estilos y la arquitectura visual;
- abre los JSON históricos;
- produce JSON compatibles;
- conserva la selección y reconstrucción de semanas;
- mantiene los *prompts* general y semanal;
- mantiene la exportación PDF aprobada;
- produce un `index.html` portable;
- funciona sin API ni servidor de aplicación;
- funciona con y sin conexión;
- no introduce errores en consola;
- supera las pruebas curriculares, funcionales, visuales y de seguridad;
- conserva una ruta documentada de reversión.

## 15. Conclusión

PIA tiene una base funcional amplia y una fuente curricular valiosa. La reorganización debe proteger primero el comportamiento existente y el contenido oficial. Las funciones más sensibles son las relacionadas con `semanas`, `PNFT_DATA`, carga de JSON, reconstrucción de interfaz, exportación PDF y generación de *prompts*.

El análisis demuestra que es viable convertir el aplicativo en un sistema modular y mantenible sin sacrificar su distribución como archivo autónomo. El siguiente paso técnico no es modificar el diseño: es crear las pruebas de caracterización y confirmar los hallazgos de mayor prioridad en la versión actual.
