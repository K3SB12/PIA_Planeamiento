# tasks.md — Plan controlado de trabajo para PIA-PNFT

## 1. Reglas

- Las tareas se ejecutan en orden.
- Solo una tarea puede estar `EN PROGRESO`.
- Una tarea no se marca `COMPLETADA` únicamente porque se escribió código.
- Debe existir evidencia verificable.
- Los hallazgos estáticos se confirman antes de corregirse.
- La fase documental no autoriza modificaciones del `index.html`.
- Toda jornada actualiza la bitácora.

## Estados

```text
PENDIENTE
EN PROGRESO
BLOQUEADA
COMPLETADA
DESCARTADA
```

---

## Fase 0. Preservación y documentación

### PIA-T000 — Conservar línea base

**Estado: COMPLETADA**

- [x] Conservar `index.html` original.
- [x] Crear `reference/index.original.html`.
- [x] Calcular SHA-256.
- [x] Confirmar equivalencia entre ambas copias.

**Evidencia esperada:** ambas huellas coinciden con la registrada en `AGENTS.md`.

### PIA-T001 — Documentar funciones y dependencias

**Estado: COMPLETADA**

- [x] Inventariar declaraciones de función.
- [x] Identificar variables globales.
- [x] Identificar acceso curricular.
- [x] Reconstruir flujos principales.
- [x] Clasificar riesgos.

**Evidencia:** `ANALISIS_FUNCIONAL_PIA_PNFT.md` y `MAPA_FUNCIONES_PIA_PNFT.json`.

### PIA-T002 — Establecer documentación de gobierno

**Estado: COMPLETADA**

- [x] Crear `AGENTS.md`.
- [x] Crear `info.md`.
- [x] Crear `SPEC.md`.
- [x] Crear `tasks.md`.
- [x] Crear `README.md`.
- [x] Iniciar bitácora.

---

## Fase 1. Pruebas de caracterización

### PIA-T100 — Diseñar infraestructura mínima de pruebas

**Estado: COMPLETADA**

**Objetivo:** proponer herramientas, estructura y comandos sin modificar todavía el código productivo.

**Criterios:**

- [ ] Presentar archivos que se crearían.
- [ ] Justificar dependencias.
- [ ] Mantener funcionamiento offline.
- [ ] No ejecutar carga ni estrés.
- [ ] Obtener aprobación humana.

### PIA-T101 — Capturar referencia visual

**Estado: COMPLETADA**

- [x] Definir resoluciones.
- [x] Capturar estado inicial.
- [x] Capturar semanas con datos ficticios.
- [x] Capturar modales.
- [x] Capturar vista de exportación.
- [x] Conservar evidencia.

**Evidencia aprobada:** `evidence/approved/visual/PIA-T101/`.

### PIA-T102 — Caracterizar ciclo y nivel

**Estado: COMPLETADA**

- [x] Materno/Transición.
- [x] I Ciclo.
- [x] II Ciclo.
- [x] III Ciclo.
- [x] Verificar niveles exactos.

**Evidencia aprobada:** `evidence/approved/characterization/PIA-T102/`.

### PIA-T103 — Caracterizar currículo

**Estado: COMPLETADA**

- [x] Área → RdA.
- [x] Nivel/módulo/área → saberes.
- [x] Saber → indicadores.
- [x] Comparar todos los textos con la base original.
- [x] Probar nombres de saber repetidos.

**Evidencia aprobada:** `evidence/approved/characterization/PIA-T103/`.

### PIA-T104 — Caracterizar semanas

**Estado: COMPLETADA**

- [x] Inicialización.
- [x] Aumento de lecciones.
- [x] Reducción cancelada.
- [x] Reducción aceptada.
- [x] Agregar semana manual.
- [x] Eliminar semana intermedia.
- [x] Tres reconstrucciones consecutivas.

**Evidencia aprobada:** `evidence/approved/characterization/PIA-T104/`.

### PIA-T105 — Caracterizar JSON

**Estado: COMPLETADA**

- [x] Crear plan ficticio completo.
- [x] Guardar.
- [x] Abrir.
- [x] Comparar contenido.
- [x] Reunir JSON históricos anonimizados.
- [x] Probar compatibilidad histórica.

**Resultado parcial de la parte A:** creación aprobada, guardado aprobado, apertura aprobada y comparación completada. La comparación no aprobó igualdad: reprodujo cuatro diferencias literales en `semana.lecciones`, cuya causa quedó localizada en `reconstruirVistaSemanasPreservandoContenido()`. El resultado se clasifica como hallazgo productivo de línea base; no se modificó el producto.

**Parte B completada y aprobada:** el run canónico `20260817T192020156Z-d89faadb5d5d` abrió y caracterizó B01–B04 mediante Chrome y servidor local, sin rechazos, errores de página, errores de consola ni errores de respuesta local. Se registraron como comportamientos productivos de línea base la regeneración de `fechaGuardado`, el recálculo de `semana.indicadores`, la omisión de `proyeccionGeneral` al re-guardar B01 y la normalización visual del orden de dos selecciones en B02. No se modificó el producto y todos los runs previos permanecen conservados.

**Evidencia aprobada:** `evidence/approved/characterization/PIA-T105/` — manifiesto 11/11 validado.

### PIA-T106 — Caracterizar exportación

**Estado: COMPLETADA**

- [x] Exportación PDF completa.
- [x] Selección parcial de secciones.
- [x] Textos extensos.
- [x] Caracteres especiales.
- [x] Saltos y tablas.
- [x] Comportamiento de la función Word no visible.

**Resultado aprobado:** el run canónico único `20260817T203021229Z-c4fe02bb3466` aprobó T106-01–T106-06 mediante Chrome y servidor local. Las comprobaciones utilizaron controles visibles y datos ficticios; verificaron el DOM exacto de seis ventanas imprimibles y generaron seis PDF identificados como representaciones reproducibles mediante `page.pdf()` después del flujo productivo. No se automatizó el diálogo nativo, no se usó Ctrl+P, no se invocó `exportarAWord()` y no se ejecutó `file://`.

**Evidencia aprobada:** `evidence/approved/characterization/PIA-T106/` — manifiesto 16/16 validado.

### PIA-T107 — Caracterizar *prompts*

**Estado: PENDIENTE**

- [ ] Prompt general vacío/parcial/completo.
- [ ] Prompt semanal.
- [ ] Indicadores correctos.
- [ ] Ejes transversales.
- [ ] Metodología.
- [ ] Comparación literal con la referencia.

### PIA-T108 — Caracterizar versión portable

**Estado: PENDIENTE**

- [ ] Descargar HTML portable.
- [ ] Abrir sin conexión.
- [ ] Probar funciones principales.
- [ ] Verificar fuente y apariencia.
- [ ] Determinar qué valores actuales se serializan.
- [ ] Diferenciar aplicación portable y respaldo JSON.

---

## Fase 2. Confirmación de hallazgos

No se corrige ningún hallazgo durante esta fase.

| Tarea | Hallazgo | Prueba principal | Estado |
|---|---|---|---|
| PIA-T201 | PIA-H001 | Determinar cuál guardado se ejecuta y comparar resultados | PENDIENTE |
| PIA-T202 | PIA-H002 | Probar saberes con nombres iguales en módulos/áreas | PENDIENTE |
| PIA-T203 | PIA-H003 | Marcar y desmarcar áreas en todos los niveles | PENDIENTE |
| PIA-T204 | PIA-H004 | Probar JSON válido, incompleto y con tipos erróneos | PENDIENTE |
| PIA-T205 | PIA-H005 | Probar JSON controlado con HTML no permitido | PENDIENTE |
| PIA-T206 | PIA-H006 | Probar reconstrucción en equipos/velocidades diferentes | PENDIENTE |
| PIA-T207 | PIA-H007 | Medir responsabilidades y cobertura de PDF | PENDIENTE |
| PIA-T208 | PIA-H008 | Confirmar si Word forma parte del producto vigente | PENDIENTE |
| PIA-T209 | PIA-H009 | Probar portapapeles en navegadores acordados | PENDIENTE |
| PIA-T210 | PIA-H010 | Probar apariencia sin conexión | PENDIENTE |
| PIA-T211 | PIA-H011 | Comparar HTML portable con estado actual | PENDIENTE |
| PIA-T212 | PIA-H012 | Determinar estructuras históricas admitidas | PENDIENTE |
| PIA-T213 | PIA-H013 | Eliminar semana, guardar y volver a abrir | PENDIENTE |
| PIA-T214 | PIA-H014 | Cambiar texto de ayuda solo en entorno de prueba | PENDIENTE |

Cada tarea deberá clasificar el hallazgo como:

```text
CONFIRMADO / DESCARTADO / NO REPRODUCIBLE / REQUIERE MÁS EVIDENCIA
```

---

## Fase 3. Diseño de arquitectura futura

### PIA-T300 — Proponer arquitectura modular

**Estado: PENDIENTE**

- [ ] Delimitar datos curriculares.
- [ ] Delimitar estado del plan.
- [ ] Delimitar vistas.
- [ ] Delimitar persistencia.
- [ ] Delimitar exportación.
- [ ] Delimitar *prompts*.
- [ ] Delimitar construcción portable.
- [ ] No modificar código.
- [ ] Obtener aprobación.

### PIA-T301 — Definir esquema JSON versionado

**Estado: PENDIENTE**

- [ ] Documentar formato actual.
- [ ] Identificar campos obligatorios y opcionales.
- [ ] Definir `schemaVersion` futura.
- [ ] Diseñar migración compatible.
- [ ] Probar con JSON históricos.

### PIA-T302 — Diseñar identificadores curriculares internos

**Estado: PENDIENTE**

- [ ] Definir identificador nivel–módulo–área–saber.
- [ ] No cambiar nombres visibles.
- [ ] No romper JSON históricos.
- [ ] Diseñar trazabilidad.

### PIA-T303 — Diseñar construcción web y portable

**Estado: PENDIENTE**

- [ ] Una fuente modular.
- [ ] Salida web.
- [ ] Salida `index.html` autónoma.
- [ ] Verificación sin conexión.
- [ ] Comparación de huellas de datos curriculares.

---

## Fase 4. Reorganización incremental

Esta fase requiere aprobación explícita después de completar las fases anteriores.

### PIA-T400 — Extraer constantes y configuración

**Estado: BLOQUEADA**

### PIA-T401 — Extraer base curricular sin modificar contenido

**Estado: BLOQUEADA**

### PIA-T402 — Separar repositorio de consulta curricular

**Estado: BLOQUEADA**

### PIA-T403 — Separar estado y operaciones de semanas

**Estado: BLOQUEADA**

### PIA-T404 — Separar construcción de la interfaz semanal

**Estado: BLOQUEADA**

### PIA-T405 — Separar guardado, carga y migraciones

**Estado: BLOQUEADA**

### PIA-T406 — Separar exportación PDF

**Estado: BLOQUEADA**

### PIA-T407 — Separar generadores de *prompts*

**Estado: BLOQUEADA**

### PIA-T408 — Generar versión web y portable

**Estado: BLOQUEADA**

Después de cada tarea:

- [ ] Ejecutar pruebas previas.
- [ ] Implementar el cambio mínimo.
- [ ] Ejecutar pruebas posteriores.
- [ ] Comparar resultados.
- [ ] Verificar currículo.
- [ ] Verificar JSON.
- [ ] Verificar apariencia.
- [ ] Actualizar bitácora.
- [ ] Obtener revisión.

---

## Fase 5. Seguridad y calidad

### PIA-T500 — Plan de validación segura de JSON

**Estado: BLOQUEADA**

### PIA-T501 — Plan de reducción controlada de `innerHTML`

**Estado: BLOQUEADA**

### PIA-T502 — Revisión de dependencias y contenido externo

**Estado: BLOQUEADA**

### PIA-T503 — Accesibilidad y navegadores

**Estado: BLOQUEADA**

---

## Fase 6. Rendimiento

### PIA-T600 — Presentar plan de carga

**Estado: BLOQUEADA**

El plan deberá incluir:

- rutas;
- 50 usuarios simultáneos;
- incremento gradual;
- tiempos;
- porcentaje de errores;
- medición de navegador;
- entorno autorizado;
- riesgos;
- archivos;
- umbrales;
- mecanismo de detención.

No ejecutar todavía.

---

## Fase 7. Entrega y publicación

### PIA-T700 — Validación integral

**Estado: BLOQUEADA**

### PIA-T701 — Revisión independiente

**Estado: BLOQUEADA**

### PIA-T702 — Aprobación funcional y curricular

**Estado: BLOQUEADA**

### PIA-T703 — Publicación controlada

**Estado: BLOQUEADA**

### PIA-T704 — Verificación y reversión

**Estado: BLOQUEADA**
