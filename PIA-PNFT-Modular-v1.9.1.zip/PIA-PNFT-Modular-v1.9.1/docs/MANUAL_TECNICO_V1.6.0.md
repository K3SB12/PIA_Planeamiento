# Manual técnico — PIA-PNFT Modular 1.6.0

## Estado y migración

`src/domain/projection/projection-core.js` define `schemaVersion: 6`. `migrate()` acepta esquemas
anteriores y completa `projectPlanning.phaseRecords`, `aiPrompts` y `ui` sin descartar datos.

## Proyecto

`src/data/project-component-catalog.js` crea registros `official-project` para Empatizar, Definir e
Idear. Para Prototipar y Probar/Evaluar crea un registro `teacher-authored`, con `officialText` vacío,
un logro y dos evaluaciones. `exportSelection()` acepta estos últimos sin depender de
`selectedIndicatorIds`, pero excluye textos vacíos.

`src/application/enhancements.js` guarda las plantillas globales en `phaseRecords`. Al seleccionar
una fase semanal, clona la plantilla solo si la semana no posee un registro; así no se borra una
contextualización semanal.

## Prompts y Word

`pia.aiPrompts.general`, `semester` y `weekly[weekNumber]` almacenan el valor completo del editor.
Los generadores restauran el texto guardado después de cargar el JSON.

Word define `.word-reflection-area` (100 pt) y `.word-observations-area` (145 pt), fondo blanco y
contenido vacío con `&nbsp;` para evitar el colapso de la celda.

## Verificación

Ejecute `npm test`. La revisión manual debe cubrir Edge/Chrome, guardar/cargar JSON, edición de los
tres tipos de prompt, fases posteriores del Proyecto y vista/guardado Word horizontal.
