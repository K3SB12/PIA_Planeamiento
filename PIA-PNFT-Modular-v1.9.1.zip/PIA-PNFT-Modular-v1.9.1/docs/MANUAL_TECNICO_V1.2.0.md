# Manual técnico — PIA-PNFT Modular 1.2.0

## Ensamblado y capas

`scripts/fragment-manifest.mjs` define el orden. `npm run build` concatena bytes y genera la misma
salida en raíz, `dist/web` y `dist/portable`. No edite esas salidas directamente.

- `src/data`: PNFT y RdA protegidos.
- `src/domain/projection/projection-core.js`: IDs compuestos, catálogo normalizado, distribución,
  cobertura, defaults y migración v1→v2. No usa DOM ni red.
- `src/application/enhancements.js`: composición con la interfaz heredada, persistencia v2,
  autoguardado, historial, proyección, prompt, formato, identidad y portable con snapshot.
- `src/adapters/backend-bridge.js`: contrato remoto inactivo y analítica noop.
- `src/templates/enhancements.html` y `src/styles/08-enhancements.css`: interfaz adaptable.
- `src/infrastructure/export/pdf-exporter.js`: identidad, formato saneado y anexo en PDF/Word.

## Contrato JSON v2

Se conservan todos los campos v1 y se añaden `schemaVersion: 2` y `pia`: identidad, contexto,
estado, calendario, proyección, asignaciones y estrategias. `PIAProjectionCore.migrate()` aporta
valores por defecto al cargar JSON anteriores. Los campos ricos se saneean con una lista permitida.

## Invariantes

- Una semana de FT = 80 minutos = dos lecciones pedagógicas.
- Los conceptos usan ID `nivel|módulo|área|índice`; el nombre no es clave única.
- El currículo no se modifica desde proyección.
- Proyectado/ejecutado no implica aprendizaje alcanzado.
- No hay solicitudes de red nuevas.
- El backend y la analítica permanecen inactivos.

## Pruebas

`npm test` cubre ensamblado, protección del núcleo, ausencia de red, JSON, eliminación, Word,
proyección, IDs, distribución flexible, cobertura y migración. La comprobación manual final en
Edge/Chrome debe revisar popups, impresión, descargas, portable `file://`, escudo y formato.
