# Manual técnico — PIA-PNFT Modular 1.3.1

## Fuente y ensamblado

La fuente autorizada está en `src/`. `scripts/fragment-manifest.mjs` define el orden de carga y
`node scripts/build.mjs` genera `index.html`, `dist/web/index.html` y
`dist/portable/index.html` byte a byte iguales. Las salidas generadas no se editan directamente.

## Dependencias funcionales

| Componente | Depende de | Responsabilidad |
|---|---|---|
| `projection-core.js` | datos PNFT | esquema v3, migración y reglas puras heredadas |
| `enhancements.js` | núcleo, perfiles, prompt, semanas | Proyección, RdA, cobertura real, navegador, formato y autoguardado |
| `week-view.js` | estado global `semanas` | interfaz semanal, momento pedagógico y barra local |
| `initialization.js` | vista semanal | creación/reconstrucción con fase y contenido preservado |
| `pdf-exporter.js` | estado oficial del plan | PDF y Word sin Proyección/Cobertura |
| `backend-bridge.js` | ninguno | contrato futuro inactivo y sin red |

## Flujo de estado

- `obtenerDatosPlan()` añade `schemaVersion: 3`, `pia` y semanas saneadas.
- `cargarPlan()` migra planes anteriores, reconstruye la interfaz y reinicia el navegador en semana 1.
- `state.projection` conserva la selección de referencia; no modifica `semanas`.
- `weeklyCoverage()` compara nombres curriculares seleccionados con `semanas[].saberes`.
- `fase` y `diagnosisLessons` son campos aditivos en cada semana y sobreviven al JSON.

## Formato seguro

Solo elementos con `data-field-kind="mediation"` o `data-field-kind="evaluation"` reciben formato.
Cada campo mantiene pilas `undo`/`redo` independientes en un `WeakMap`. Antes de escribir o aplicar
un comando se conserva una instantánea HTML. `sanitizeRichText()` limita etiquetas y estilos y
elimina atributos no autorizados. `official-indicator` permanece sin `contenteditable`.

## Navegación

El navegador no mueve ni duplica datos: solo alterna la clase visual `pia-week-hidden`. Un
`MutationObserver` actualiza selector, botones y estados después de reconstruir, agregar o eliminar
semanas. En impresión se muestran todas las semanas y se ocultan controles de interfaz.

## Exportaciones

La identidad opcional puede incorporarse mediante `institutionalExportHtml()`. No existe
`projectionExportHtml()` ni llamadas equivalentes desde PDF/Word. La salida oficial se construye
desde el encabezado y `semanas`.

## Pruebas y mantenimiento

Ejecute `npm test`. Si `npm` está restringido, ejecute sus equivalentes locales:

```bash
node scripts/verify-source.mjs
node scripts/build.mjs
node scripts/verify-authorized-change.mjs
node --test tests/*.test.mjs
```

No active React, PHP, API, autenticación o analítica dentro de esta versión. Esa evolución requiere
un contrato de API, seguridad, migración y pruebas independientes.
