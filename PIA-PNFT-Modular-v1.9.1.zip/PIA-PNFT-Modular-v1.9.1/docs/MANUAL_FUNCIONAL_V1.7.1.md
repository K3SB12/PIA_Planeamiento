# Manual funcional breve PIA 1.7.1

## Abrir el ejemplo de planeamiento

Desde la portada, presione **Explorar un ejemplo de planeamiento**. El recorrido se abre sobre PIA y
permite navegar sus siete momentos, consultar ayudas y volver al planeamiento. Esta experiencia es
formativa, no modifica el plan y no certifica conocimientos. Al cerrarla, PIA recupera el foco y la
interactividad que tenía antes de abrirla.

## Registrar Contextualización y DUA

1. Abra **DUA: Contextualización — Opcional**.
2. Active **Incorporar esta contextualización y sus apoyos DUA en los prompts** únicamente cuando
   desee que la información registrada oriente las propuestas de IA.
3. Seleccione el contexto o modalidad, el acceso tecnológico y el punto de partida general del grupo.
4. Registre características generales, recursos y apoyos DUA sin nombres ni datos sensibles.
5. En **Acceso, DUA y apoyos autorizados**, identifique el marco que ya orienta el planeamiento:
   DUA, acceso, apoyo no significativo o adecuación significativa/PEI previamente aprobada.
6. Marque únicamente los apoyos previstos y consigne acuerdos institucionales generales ya definidos.

Seleccionar una opción no aprueba una adecuación y no cambia saberes, indicadores o componentes de
evaluación. PIA tampoco interpreta ni redacta una PEI.

## Plan Nacional y Diversificado Vocacional

Al seleccionar **III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional**, PIA muestra una guía
específica para:

- registrar si se efectuó la coordinación pedagógica necesaria;
- describir el criterio acordado para seleccionar y dosificar saberes;
- considerar el diagnóstico inicial y las necesidades generales del grupo;
- priorizar herramientas de productividad cuando respondan al contexto;
- ajustar la mediación a las dos lecciones semanales disponibles.

PIA contiene currículo oficial hasta 9.º. Para 10.º, 11.º o 12.º no crea saberes ni indicadores. La
persona docente debe utilizar la fuente oficial vigente y las decisiones autorizadas por las instancias
correspondientes.

## Uso de indicadores de referencia

Los indicadores de otros niveles pueden conservarse como referencias con procedencia y justificación.
No se transforman automáticamente en currículo vigente, indicador evaluable o contenido de una PEI.
La persona docente determina su uso conforme al diagnóstico y a los procedimientos institucionales.

## Fuentes consideradas

- Orientaciones generales para docentes de Formación Tecnológica 2026.
- Evaluación diagnóstica conocer para mejorar.
- Adecuaciones curriculares, boletín informativo MEP.
- Video aportado sobre adecuaciones curriculares y PEI, utilizado como antecedente explicativo.
