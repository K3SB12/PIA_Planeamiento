# Guía breve de actualización — PIA 1.7.3

## Secundaria: una sola ruta articulada

La opción base es **Ruta integrada: APD articula currículo y Proyecto**. En ella, los saberes y sus indicadores se desarrollan dentro de las fases de Pensamiento de Diseño y alimentan el Proyecto. Las semanas de énfasis del Proyecto no constituyen un segundo planeamiento ni se suman automáticamente a las semanas curriculares.

Una actividad breve de reto o juego puede utilizarse como recurso puntual dentro de APD. Solo se declara una segunda metodología completa cuando se conservarán sus fases, función, tiempo y evidencias. En ese caso, PIA muestra los campos adicionales y realiza la advertencia temporal; la persona docente o asesora toma la decisión final.

## Diagnóstico: aprendizajes previos por explorar

La opción **Condiciones de entrada para los saberes actuales** permite explorar conocimientos, procedimientos y formas de actuar necesarios para iniciar los nuevos aprendizajes. No convierte los indicadores del nivel actual en requisitos ya dominados ni presume resultados antes de aplicar el diagnóstico.

## Ventanas de prompt

Los cuadros de prompt general y semanal se adaptan a la altura disponible. Cuando el contenido supera el tamaño del monitor, desplácese dentro del cuadro para acceder a **Copiar Prompt**, **Abrir en Copilot**, **Abrir en ChatGPT** y **Cerrar**.

## Terminología temporal

PIA utiliza **lecciones pedagógicas** para referirse a la carga disponible. El cálculo sigue descontando únicamente las reservas declaradas: diagnóstico, lecciones sin desarrollo curricular y aplicación o realimentación.
