# Manual funcional — PIA-PNFT Modular 1.3.1

## Abrir PIA

Abra `dist/portable/index.html` en Microsoft Edge o Google Chrome. PIA funciona localmente sin
Node, servidor, API ni backend. Para probar descargas, PDF y Word use una computadora y permita
ventanas emergentes.

## Recorrido docente

1. Complete el escudo y lema opcionales.
2. Complete íntegramente el encabezado administrativo oficial.
3. Seleccione ejes transversales y metodología activa.
4. Registre Contextualización y DUA sin datos personales del estudiantado.
5. En Proyección, defina periodo, diagnóstico, módulo, áreas y saberes. Los RdA oficiales aparecen
   debajo de las áreas para orientar la ruta curricular.
6. Si necesita apoyo externo, genere el prompt semestral y úselo en la herramienta autorizada. PIA
   no envía datos, no recibe la respuesta y no distribuye automáticamente el resultado.
7. Complete cada semana manualmente. El navegador muestra una semana por defecto; use Anterior,
   Siguiente, el selector o los círculos numerados. **Ver todas** despliega el plan completo.
8. En la semana 1 se identifica **Diagnóstico** cuando se reservan dos lecciones, o **Diagnóstico e
   inicio del módulo** cuando se reserva una. El momento pedagógico puede ajustarse por semana.
9. Seleccione áreas, saberes e indicadores oficiales. Complete Mediación e Indicadores de evaluación.
10. Presione **Formato** dentro de la semana para negrita, cursiva, subrayado, listas, alineación,
    color, resaltado, tamaño, limpiar formato, deshacer o rehacer. El indicador oficial no se edita.

## Estados y cobertura

Los círculos semanales distinguen diagnóstico, vacía, parcial y completa. Ocultar o mostrar semanas
no elimina información. **Ver cobertura de las semanas** compara los saberes seleccionados en
Proyección con los incorporados realmente en el planeamiento y muestra incorporado/pendiente.
La cobertura no equivale al aprendizaje alcanzado.

## Guardar, cargar y exportar

- **Guardar:** descarga JSON v3 con el plan completo.
- **Cargar:** admite JSON v1, v2 y v3; reconstruye las semanas y conserva contenido compatible.
- **Recuperar autoguardado:** restaura una copia local previa después de confirmarla.
- **Exportar PDF/Word:** contiene el planeamiento didáctico oficial, no Proyección ni Cobertura.
- **Word:** abre vista continua y guarda en A4 horizontal.
- **Portable:** descarga un HTML autónomo con el plan actual.

## Regla de seguridad

No incluya datos sensibles o personales del estudiantado. El backend y la analítica permanecen
inactivos; todo el trabajo se conserva en el dispositivo o en los archivos que descargue la persona docente.
