# Informe de validación — PIA-PNFT Modular 1.6.6

Fecha: 2026-09-04

## Alcance

Validar que la trayectoria curricular continúe activa internamente, que el prompt muestre solo una
orientación breve y que el tratamiento especializado de Preescolar permanezca íntegro.

## Resultado funcional

- Las 38 familias, cuatro áreas, diez niveles y 235 correspondencias continúan disponibles al servicio interno.
- `promptContext()` conserva la trayectoria detallada para validación técnica.
- `promptSummary()` produce una sola línea sin AHORA, ANTES, DESPUÉS, `N/A` ni listados por nivel.
- La línea identifica las familias relacionadas con los saberes seleccionados.
- La IA recibe reglas de integración horizontal, progresión vertical, alcance exclusivo del nivel
  actual, diagnóstico de antecedentes y prohibición de adelantar otros niveles.
- El prompt de Preescolar conserva competencias, perfil de salida, organización lúdica del bloque,
  integración auténtica y evaluación únicamente diagnóstica/formativa.

## Regresión protegida

No se modificaron `PNFT_DATA`, `RDA_POR_CICLO`, el catálogo oficial de Preescolar, centros,
Proyecto, persistencia JSON v6, semanas, PDF, Word, portable, backend inactivo ni analítica.

## Evidencia

- Verificación sintáctica de los tres archivos modificados: aprobada.
- Pruebas focalizadas de progresión y prompt: 14/14 aprobadas.
- Suite completa: 93/93 aprobadas.
- Construcción reproducible: `index.html`, `dist/web/index.html` y `dist/portable/index.html` idénticos.

## Conclusión

PIA utiliza la trayectoria al 100% como conocimiento interno sin confundir a la persona docente. La
salida visible conserva únicamente la orientación necesaria para que la IA proponga una secuencia
coherente, siempre sujeta al nivel seleccionado y al criterio profesional docente.
