# Bitácora PIA — 9 de setiembre de 2026

## Propósito de la jornada

Convertir la enseñanza de las metodologías activas en una experiencia interactiva y, paralelamente,
cerrar ajustes operativos pendientes del planeamiento sin afectar el currículo, la persistencia, las
semanas ni las exportaciones ya validadas en PIA 1.6.8.

## Acciones realizadas y justificación

1. **Juego formativo incorporado en la portada.** Se añadió el acceso “Aprender metodologías del PNFT”.
   El recorrido contiene siete misiones con decisiones y realimentación inmediata. Se diseñó como una
   capa independiente para que una persona nueva pueda aprender antes de abrir el planeamiento, sin
   arriesgar datos ni confundir práctica formativa con edición real.

2. **Ruta propia de Preescolar.** Se incorporaron decisiones sobre itinerario Básico/Óptimo,
   experiencias que pueden iniciar y cerrar en una semana, juego y exploración, observación formativa,
   criterios de desempeño y contribución a RdA y perfil. Esto evita trasladar a Preescolar la lógica
   sumativa o la organización longitudinal rígida de otros ciclos.

3. **ABJ, ABR y Pensamiento de Diseño explicados como andamiaje.** Las misiones obligan a relacionar
   metodología, saberes, indicadores, evidencias y protagonismo estudiantil. La mejora se necesitó porque
   escribir el nombre de una metodología no garantiza que las acciones realmente respondan a ella.

4. **Dos escenarios de secundaria.** El juego y el prompt diferencian una ruta única con Pensamiento de
   Diseño para currículo y Proyecto, y dos rutas coordinadas cuando el currículo utiliza ABJ, ABR u otra
   metodología mientras Proyecto conserva Pensamiento de Diseño. Esto reduce el riesgo de producir dos
   planeamientos paralelos o reiniciar fases cada semana.

5. **Contextualización y DUA con activación explícita.** Se agregó un check. Cuando está desmarcado, el
   bloque no aparece en el prompt; cuando está marcado, se incorporan incluso las opciones iniciales
   seleccionadas. Los datos se conservan al desactivar. La finalidad es evitar ruido en proyecciones de
   asesoría y, al mismo tiempo, no perder contexto docente.

6. **Apoyo para evaluación diagnóstica.** Se añadió “Preparar evaluación diagnóstica con IA”. El prompt
   sigue el proceso de precisar, diseñar, aplicar, sistematizar, analizar, decidir y comunicar. Incluye las
   dimensiones cognitiva, socioemocional y psicomotriz cuando sean pertinentes, instrumentos posibles y
   una matriz grupal sin datos personales. Mantiene el límite de cero a dos lecciones y diferencia
   diagnóstico pedagógico de diagnóstico clínico.

7. **Fundamentación para Otra metodología.** Solo al elegir esa opción aparecen campos sobre propósito
   curricular, etapas y continuidad, rol del estudiantado, evidencia, realimentación y viabilidad. La
   información se guarda en JSON y acompaña los prompts; no se presenta como metodología oficial.

8. **Afinar semana con IA.** El prompt semanal dejó de pedir una planificación genérica. Ahora recibe el
   texto ya escrito, el filtro curricular, indicadores completos, saberes, metodología, Proyecto y
   diagnóstico cuando aplica. Solicita mejorar sin reconstruir el semestre. Si sugiere cambiar la
   metodología, debe mantener también una versión coherente con la original y justificar la alternativa.

9. **Proyecto en Prototipar y Probar/Evaluar.** Para planes nuevos, estas fases ya no generan un indicador
   de logro docente como sustituto. La persona selecciona indicadores oficiales del módulo vinculados con
   los saberes de la proyección y conserva dos espacios editables de evaluación por indicador. Los textos
   docentes creados en versiones anteriores se mantienen como históricos para impedir pérdida de trabajo.

10. **Persistencia y compatibilidad.** Se mantuvo `schemaVersion: 6`. Los campos nuevos tienen valores
    predeterminados y migración segura. El juego no forma parte del plan ni activa el autoguardado. La
    Contextualización, la fundamentación metodológica, los prompts y registros de Proyecto continúan en
    las rutas de guardado y carga vigentes.

11. **Accesibilidad y experiencia.** El juego admite teclado, foco visible, tecla Escape, controles
    táctiles amplios, diseño adaptable a celular y preferencia de movimiento reducido. La síntesis usa
    indicadores formativos y aclara que no califica ni certifica.

12. **Documentación técnica.** Se actualizaron `AGENTS.md`, `SPEC.md`, `info.md`, `README.md`,
    `CHANGELOG.md` y las pruebas de contrato para que el comportamiento esperado sea trazable.

## Controles de cierre

- Verificación sintáctica de los archivos JavaScript modificados.
- Construcción de `index.html`, `dist/web/index.html` y `dist/portable/index.html` desde `src/`.
- Verificación de cambios autorizados fuera del núcleo protegido.
- Pruebas automatizadas de juego, DUA, diagnóstico, Otra metodología, Afinar semana, Proyecto,
  persistencia, currículo, Preescolar, Word, PDF y versión portable.
- Revisión humana recomendada en Chrome/Edge, apertura local, guardado/carga JSON y Microsoft Word.
