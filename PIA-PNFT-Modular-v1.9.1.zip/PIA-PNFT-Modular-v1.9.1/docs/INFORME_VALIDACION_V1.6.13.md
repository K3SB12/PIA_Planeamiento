# Informe de validación — PIA-PNFT Modular 1.6.13

Fecha: 11 de setiembre de 2026.

## Resultado automatizado

- Fuente y ensamblado reproducible: aprobados.
- Alcance autorizado respecto de la referencia protegida: aprobado.
- Pruebas automatizadas: **132/132 aprobadas**.
- Salidas equivalentes: `index.html`, `dist/web/index.html` y `dist/portable/index.html`.
- Currículo operativo protegido: 235 registros relacionados, 38 familias, cuatro áreas y diez niveles.
- Huellas de los Excel: coinciden con las fuentes trazadas.

## Contratos verificados

- Vacío curricular distinto de fortalecimiento y de `N/A`.
- Tarjetas y tabla comparativa con filtros por módulo, área y alcance.
- RdA, procedencia curricular e iconografía PNFT local.
- Trayectoria excluida del prompt, JSON, PDF y Word.
- Diagnóstico inicialmente desactivado, incorporación expresa y reinicio aislado.
- “Observación o decisión docente” distinta de calificación y frecuencia evaluativa bajo criterio docente.
- Auditoría temporal posterior sin regla de conteo aislado.
- “Etapa de desarrollo → Prototipar” localizada.
- Compatibilidad JSON v6 y funcionamiento portable.

## Control visual pendiente en navegador de escritorio

El entorno de entrega bloqueó la apertura de archivos locales mediante el navegador automatizado. Por
ello, no se declara realizada una inspección visual en Chrome o Edge. La revisión manual debe comprobar:
apertura de la trayectoria, cambio de vista, filtros, textos extensos, desplazamiento de tabla, iconos,
cierre por botón/clic exterior/`Esc`, diagnóstico y funcionamiento directo mediante `file://`. Las pruebas
automatizadas verifican la estructura, los eventos y la inclusión exacta del recurso gráfico; PDF y Word
conservan sus verificaciones históricas y no incluyen la trayectoria.
