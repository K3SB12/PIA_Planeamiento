# Manual técnico — Ruta hacia el RdA 1.7.0

## Componentes

| Archivo | Responsabilidad |
|---|---|
| `src/data/rda-contribution-catalog.js` | Contrato y relaciones pedagógicas únicamente aprobadas. |
| `src/domain/curriculum/rda-route-service.js` | Construcción determinista de la ruta estructural por familia, nivel, ciclo y RdA. |
| `src/ui/rda-route-view.js` | Consulta accesible, filtros y representación de estados; sin escritura del plan. |
| `src/styles/09-rda-route.css` | Presentación adaptable y exclusión de impresión. |

## Dependencias permitidas

La ruta lee `PNFT_DATA`, `RDA_POR_CICLO`, `PIACurricularProgressionData`,
`PIACurricularProgression` y, en 0°, `PIAPreschoolCurriculum`. No depende de semanas, prompts,
exportadores, persistencia, evaluación ni Proyecto.

## Contratos de seguridad

- Identidad compuesta: nivel + módulo + área + saber literal.
- Correspondencia exacta saber–familia; no se admite coincidencia aproximada.
- Vínculo estructural distinto de correspondencia pedagógica aprobada.
- Catálogo validado falla si una relación carece de fuente o aprobación.
- La vista no llama `markDirty`, `obtenerDatosPlan`, `cargarPlan` ni exportadores.
- `schemaVersion: 6` permanece sin cambios.
- Los fragmentos nuevos usan marcadores `PIA_RDA_*` y se aíslan en la verificación autorizada.

## Validación

Ejecute `npm test`. Además, realice prueba humana en Chrome y Edge, escritorio y móvil, con especial
atención al desplazamiento de textos extensos, filtros, foco, `Esc`, Preescolar Básico/Óptimo y cierre
sin modificación del plan.
