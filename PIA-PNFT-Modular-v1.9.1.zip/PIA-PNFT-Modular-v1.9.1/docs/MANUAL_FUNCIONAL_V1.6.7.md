# Manual funcional — formato contextual PIA 1.6.7

## Alcance

El formato contextual funciona exclusivamente en **Estrategias de mediación** e **Indicadores de
evaluación**. Los **Indicadores de logro del currículo de FT** permanecen protegidos.

## Uso básico

1. Ingrese a la semana correspondiente.
2. Sombree el texto que desea modificar. La barra se abrirá sin necesidad de regresar al encabezado.
3. Compruebe la indicación “Aplicando formato a…”.
4. Use negrita, subrayado, lista u otra acción. La selección permanece disponible para aplicar más
   de un cambio.
5. Presione `×`, haga clic fuera del campo o use `Esc` para ocultar la barra.

El botón **Formato** del encabezado sigue disponible cuando se desea abrir la barra antes de escribir.

## Más opciones

- Cursiva, lista numerada, sangría y alineación.
- Color institucional, resaltado y tamaño.
- Inserción de Inicio, Desarrollo y Cierre, únicamente en Mediación.
- Pegado limpio opcional para retirar estilos procedentes de otras aplicaciones.
- Vínculo HTTPS revisado por la persona docente.
- Limpieza del formato de todo el campo.

**Tx** quita el formato únicamente del fragmento seleccionado. **Limpiar campo** conserva el texto,
pero retira el formato de todo el campo después de solicitar confirmación.

## Conservación

El contenido enriquecido se sincroniza con la semana y se conserva mediante el JSON, el autoguardado
y las exportaciones existentes. La apertura o cierre de la barra es una preferencia visual y no cambia
el planeamiento.
