# Bitácora PIA — 10 de setiembre de 2026

## Objetivo de la jornada

Profundizar el acompañamiento que PIA ofrece desde el diagnóstico hasta la evaluación del semestre,
sin romper el planeamiento validado, sin introducir una API y sin trasladar decisiones profesionales
a una automatización. La actualización se construyó como PIA 1.6.10 y mantuvo separada la línea 1.7.x.

## Acciones realizadas y por qué fueron necesarias

1. **Se transformó el diagnóstico en un proceso completo y persistente.** El apoyo anterior generaba
   orientación, pero no permitía distinguir claramente entre una proyección elaborada por asesoría y
   una aplicación con un grupo real. Se añadieron los modos Modelo para asesoría y Aplicación docente.
   Esto evita inventar resultados cuando los asesores elaboran planes nacionales y permite al docente
   registrar decisiones generales después de observar a su grupo.

2. **Se aclaró qué se valora en el diagnóstico.** Se incorporaron las áreas cognoscitiva, socioafectiva
   y psicomotora como dimensiones que pueden observarse dentro de una experiencia integrada. Se declaró
   expresamente que no son tres etapas ni tres pruebas, porque esa interpretación produciría una secuencia
   artificial contraria a la intención diagnóstica.

3. **Se protegió la relación entre diagnóstico y currículo.** Los indicadores del nivel seleccionado
   se presentan como referentes del aprendizaje nuevo y no como contenidos que el grupo ya debería
   dominar. Los antecedentes de la misma familia curricular pueden orientar qué explorar, pero continúan
   siendo hipótesis por verificar. Los alcances posteriores permanecen únicamente como salvaguarda interna.

4. **Se añadió un ciclo completo de diseño y uso de la información.** El prompt diagnóstico exige
   precisar aprendizajes previos, diseñar una experiencia, aplicar, registrar, sistematizar, analizar,
   decidir, realimentar y comunicar. También solicita instrumentos congruentes y una matriz grupal sin
   nombres. Esto permite que el diagnóstico produzca decisiones de mediación y no se reduzca a una actividad aislada.

5. **Se mantuvo el límite de dos lecciones.** La interfaz, el estado y la migración continúan limitando
   el diagnóstico a un máximo de 80 minutos. Cambiar ese valor sincroniza el momento inicial, pero no
   borra el contenido existente de las semanas.

6. **Se crearon momentos evaluativos orientadores.** PIA ahora puede proponer ventanas de referencia
   para trabajo cotidiano, tareas, prueba de ejecución y Proyecto según el perfil aplicable. Se necesitaba
   ayudar a ubicar la evaluación después de la mediación y la evidencia, sin convertir la sugerencia en
   una fecha, actividad o calificación automática.

7. **Se dio control explícito a la persona docente.** Cada sugerencia puede conservarse como sugerida,
   confirmarse, modificarse o descartarse. La semana y una nota contextual son editables. Solo las
   decisiones confirmadas pasan a los prompts; ninguna escribe las semanas del planeamiento.

8. **Se incorporaron reglas técnicas de 2026 con prudencia.** Las tareas se vinculan con necesidades
   observadas de repaso o reforzamiento, mínimo de dos días naturales, restricciones del calendario y
   devolución máxima de ocho días hábiles. Se recuerda el mínimo de tres por periodo, excepto CONED,
   sujeto a la modalidad aplicable. La prueba de ejecución se ubica después de mediación y realimentación.
   Proyecto se mantiene progresivo y su porcentaje no se divide automáticamente por etapas.

9. **Se conectaron las decisiones confirmadas con la IA.** El prompt semestral recibe el conjunto
   confirmado y Afinar semana recibe únicamente lo aplicable a esa semana o al seguimiento continuo.
   De esta manera la IA conoce la decisión docente, pero sigue obligada a no inventar fechas, porcentajes
   ni resultados.

10. **Se añadió revisión local de respuestas de IA.** La persona puede pegar la respuesta obtenida y
    PIA comprueba presencia literal de indicadores seleccionados, estructura A–F, saberes, numeración,
    currículo ajeno y afirmaciones automáticas de logro. La función responde a la necesidad de revisar
    contratos verificables antes de trasladar contenido a las semanas.

11. **Se separó la auditoría del planeamiento.** Guardar una respuesta no la incorpora ni la aprueba.
    El texto y su reporte se conservan en `aiReview`, mientras el contenido oficial permanece en las
    columnas existentes. Esto evita que una respuesta externa sobrescriba trabajo docente validado.

12. **Se fortaleció la persistencia.** Diagnóstico, prompts, sugerencias, decisiones, respuestas y
    reportes atraviesan JSON v6, autoguardado y portable. La migración incorpora valores seguros para
    planes anteriores y conserva todas sus semanas, ediciones, Proyecto y referencias.

13. **Se preservaron los contratos validados.** No se modificaron `PNFT_DATA`, `RDA_POR_CICLO`, los
    itinerarios de Preescolar, los indicadores oficiales, las columnas de la plantilla, la lógica de
    Proyecto, las exportaciones ni el juego metodológico. Tampoco se incorporó el Mapa de Trayectoria 1.7.x.

14. **Se actualizó la documentación relacionada.** Se modificaron `AGENTS.md`, `SPEC.md`, `info.md`,
    `README.md`, `CHANGELOG.md` y se crearon manuales funcional/técnico, informe de validación y pruebas
    específicas de 1.6.10. La finalidad es que el comportamiento implementado pueda mantenerse sin
    interpretaciones distintas en futuras mejoras.

## Verificación ejecutada

- `node --check` sobre los módulos JavaScript modificados.
- Pruebas específicas de diagnóstico, sugerencias, revisión de IA, prompt semanal y migración.
- Construcción desde `src/` y comparación de las tres salidas HTML.
- Verificación del alcance autorizado.
- Regresión completa de las funciones heredadas.
- Resultado final: 117 pruebas aprobadas de 117, sin fallos.
- Se documentó como pendiente de entorno una prueba humana en Chrome/Edge y Microsoft Word; no se
  instalaron navegadores ni dependencias externas dentro del proyecto.
