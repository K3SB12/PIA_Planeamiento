# Guía funcional breve — Organizar la ruta curricular de III Ciclo

## Propósito

El organizador ayuda a visualizar cómo se desarrollarán los saberes del módulo dentro de una sola proyección semestral. No sustituye el criterio docente, no modifica el currículo oficial y no demuestra que un aprendizaje o RdA fue alcanzado.

## Cuándo aparece

La sección **Organice la ruta curricular del semestre** aparece en III Ciclo después de la configuración del componente Proyecto. Para abrir el mapa se debe seleccionar al menos un saber conceptual.

## Cuatro puntos de partida

1. **Desarrollar la mayoría de los aprendizajes mediante el Proyecto:** el Proyecto funciona como hilo predominante cuando sus fases permiten movilizar los indicadores sin forzarlos.
2. **Iniciar el Proyecto y alternarlo con otros aprendizajes:** el Proyecto comienza temprano y se coordina con laboratorios, práctica, realimentación u otras lecciones pedagógicas.
3. **Preparar algunos aprendizajes antes de iniciar el Proyecto:** una fundamentación inicial atiende condiciones de entrada, seguridad, complejidad o recursos antes de articularse con el Proyecto.
4. **Necesito que PIA me ayude a decidir:** conserva las decisiones pendientes para que la IA compare alternativas justificadas. La persona docente elige.

## Cómo clasificar los saberes

- **Se desarrollará y evaluará directamente en el Proyecto:** el indicador y la evidencia tienen relación auténtica con las fases y el componente Proyecto.
- **Preparará el Proyecto:** aporta conocimientos, procedimientos o condiciones necesarias antes de una fase.
- **Apoyará o documentará el Proyecto:** permite investigar, comunicar, registrar o sostener el proceso sin convertirse necesariamente en evidencia directa del componente.
- **Se desarrollará en otras lecciones pedagógicas:** requiere mediación propia por profundidad, práctica, seguridad o relación limitada con el problema.
- **Requerirá continuidad o realimentación:** necesita retomarse después de una evidencia o fase.
- **Pendiente de decisión:** PIA conserva el saber y prohíbe omitirlo o asignarle una función sin justificación.

## Modo guiado y modo directo

Ambos modos usan y guardan la misma información. El modo guiado mantiene explicaciones visibles; el modo directo reduce esas ayudas para docentes o personas asesoras que prefieren mayor densidad de trabajo.

## Lectura de la auditoría

PIA comprueba si existen saberes pendientes, si se declaró evidencia directa con el Proyecto desactivado y si la ventana temporal supera los bloques disponibles declarados. Estas son comprobaciones estructurales. La pertinencia de las relaciones, la profundidad, las evidencias y la viabilidad requieren revisión profesional.

## Segunda metodología

Un reto o juego puntual puede ser un recurso de mediación sin constituir ABR o ABJ completos. Si se declara una segunda metodología completa, deben conservarse sus fases, explicar su función y puente curricular, declarar semanas o minutos y evitar repetir problema, investigación, prototipado, evaluación o evidencia.

## Paso hacia la IA

Al generar el prompt semestral, PIA incorpora la organización y la función asignada a cada saber. Los pendientes permanecen explícitos. La IA debe construir una propuesta, auditar el tiempo después de distribuirla y no duplicar una evidencia entre Proyecto y otro componente. La persona docente revisa y decide antes de completar las semanas oficiales.

