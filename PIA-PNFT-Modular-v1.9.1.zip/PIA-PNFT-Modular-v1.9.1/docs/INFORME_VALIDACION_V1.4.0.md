# Informe de validación — PIA-PNFT Modular 1.4.0

Fecha: 2026-08-27

## Alcance

- Catálogo interno de centros por código presupuestario, sin carga Excel docente.
- Exclusión de todos los registros `0000` y de datos personales del catálogo compilado.
- Resolución segura de coincidencias únicas, ambiguas e inexistentes.
- Persistencia interna opcional de `codSaber` en JSON v3.
- Cuatro itinerarios oficiales de Preescolar: M1/M2 Básico requerido y M1/M2 Óptimo.
- Saberes, indicadores y RdA de Preescolar trazables a la Guía docente.
- Metodología del prompt semestral como andamiaje continuo para ABJ, ABR y APD.
- Dimensiones estables del escudo en Word.

## Resultados

| Comprobación | Resultado |
|---|---|
| Sintaxis de fragmentos | Aprobada |
| Ausencia de APIs de red nuevas | Aprobada |
| Ensamblado reproducible | Aprobada |
| Alcance autorizado frente a referencia | Aprobada |
| Pruebas Node | **44 aprobadas, 0 fallidas** |
| Salidas HTML idénticas | Aprobada |
| Regeneración desde Excel depurado | Idéntica byte a byte |
| Códigos `0000` compilados | 0 |
| Datos personales compilados | 0 |

## Catálogo de centros

- Registros: 4.651.
- Códigos distintos: 4.511.
- Códigos con coincidencia única: 4.448.
- Códigos ambiguos: 63, correspondientes a 203 registros.
- `codSaber` únicos: 4.651.
- Código con cero inicial `0904`: preservado y verificado.

## Preescolar

- Módulo 1 Básico requerido: 6 saberes.
- Módulo 2 Básico requerido: 8 saberes.
- Módulo 1 Óptimo: 8 saberes.
- Módulo 2 Óptimo: 10 saberes.
- Otros niveles: sin sustitución de sus catálogos.

## Huellas

- Referencia protegida: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- Salidas 1.4.0: `7ef35a74307c460ce943ce80a244c5a131d07a484f5ffe1a50dd67a790caf280`.

## Límite de esta ejecución

El entorno contiene Playwright pero no un binario Chrome/Chromium instalado. Por ello no se
declaró una prueba visual de navegador en esta sesión. La revisión final en el equipo usuario debe
comprobar autocompletado, selección de un código ambiguo, cambio Básico/Óptimo, guardar/cargar,
PDF, Word y portable. Las funciones históricas ya están cubiertas por la regresión automatizada.
