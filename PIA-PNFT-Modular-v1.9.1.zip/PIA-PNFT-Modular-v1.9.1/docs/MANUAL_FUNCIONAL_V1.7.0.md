# Manual funcional breve — PIA 1.7.0

## Explorar la Ruta hacia el RdA

1. Seleccione ciclo, nivel, módulo y áreas en **Proyección semestral**.
2. Revise los saberes conceptuales disponibles y marque los que correspondan a la proyección.
3. Presione **Explorar ruta hacia el RdA**, debajo de la cobertura y de la trayectoria curricular.
4. Use los filtros para consultar todas las áreas o una en particular, y todos los saberes disponibles
   o únicamente los seleccionados.
5. Abra una familia curricular para observar los ciclos, el RdA oficial y los hitos documentados por
   nivel desde Preescolar hasta 9.º.
6. Identifique el nivel actual. Es el único que corresponde incorporar al planeamiento.
7. Revise el estado de correspondencia. **Pendiente de validación curricular** significa que PIA
   confirma la pertenencia estructural, pero no presenta una relación pedagógica como aprobada.
8. Cierre la ventana con **Volver al planeamiento**, clic fuera de la ventana o `Esc`.

## Cómo interpretar la información

- Un saber repetido puede cambiar de profundidad según su indicador.
- **Sin abordaje conceptual registrado** no significa refuerzo ni rezago.
- **No aplica** y **Área ausente** no generan contenido pendiente.
- El RdA es el horizonte del ciclo; no se obtiene al marcar una casilla o completar una barra.
- La cobertura indica incorporación al planeamiento, no aprendizaje alcanzado.
- Las evidencias acumuladas y el criterio docente permiten valorar el proceso real.

## Qué no cambia al abrir la Ruta

La consulta no modifica módulos, áreas, saberes, semanas, diagnóstico, evaluación, Proyecto, prompts,
autoguardado ni exportaciones. Los planes de PIA 1.6.15 continúan siendo compatibles.
