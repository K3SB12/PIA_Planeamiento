# Informe de validación — PIA 1.7.5

## Ajustes verificados

- La selección manual de técnica, instrumento y criterio docente está desactivada y oculta por defecto.
- El panel manual solo aparece al marcar “Técnica, evidencia e instrumento diagnóstico — definir manualmente”.
- Una selección manual incompleta no permite generar un prompt ambiguo.
- Sin selección manual, la IA recibe la instrucción de recomendar una sola técnica y un solo instrumento congruentes con actividad, evidencia, nivel, tiempo, recursos y DUA.
- El prompt utiliza como marco las Orientaciones Docentes PNFT 2026, el recurso “Evaluación de los aprendizajes en la Malla Curricular de Formación Tecnológica”, las disposiciones del Departamento de Evaluación de los Aprendizajes y el REA vigente.
- El alcance diagnóstico se relaciona con saberes conceptuales, procedimentales y actitudinales del módulo mediante experiencias integradas en un máximo de dos lecciones.
- Se elimina del prompt efectivo la regla propia “un conjunto acotado… no evalúe todo el semestre”.
- Los indicadores actuales no se convierten en requisitos de dominio previo y no se fragmenta una prueba por cada saber.
- Los planes históricos con selección expresa activan automáticamente el panel manual.

## Resultado automatizado

- Pruebas: **179/179 aprobadas**.
- Salidas verificadas: `index.html`, `dist/web/index.html` y `dist/portable/index.html` son idénticas.
- SHA-256 común: `ca9bc7fb87f90085741654ab73d9b21122dce10a0f9709a76c33a3b0cbbadcc9`.
- `schemaVersion: 6` y currículo protegido se conservan.

La comprobación automatizada no sustituye la prueba humana final de presentación e interacción en los navegadores y dispositivos de publicación.
