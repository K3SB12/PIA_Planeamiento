# Manual técnico — formato contextual PIA 1.6.7

## Responsabilidades

| Archivo | Responsabilidad |
|---|---|
| `src/ui/week-view.js` | Estructura de la barra local, acciones principales y panel “Más opciones”. |
| `src/application/enhancements.js` | Campo activo, rango seleccionado, comandos, historial, saneamiento y sincronización. |
| `src/styles/08-enhancements.css` | Posición adhesiva, diseño compacto, estados activos y adaptación táctil. |
| `tests/contextual-formatting.test.mjs` | Contratos de alcance, accesibilidad, seguridad y protección curricular. |

## Contratos

- Solo los campos `data-field-kind="mediation"` y `data-field-kind="evaluation"` son destinatarios.
- El campo `official-indicator` nunca es `contenteditable`.
- `activeSelectionRange` conserva una copia del rango antes de usar controles de la barra.
- La apertura contextual ocurre en `pointerup` o `keyup`, no durante el arrastre de selección.
- El HTML se procesa con `sanitizeRichText()` antes de guardarse en la semana.
- Los elementos `A` conservan únicamente un `href` con protocolo HTTPS.
- La preferencia de pegado limpio es temporal y no modifica `schemaVersion: 6`.

## Verificación

```bash
node --check src/application/enhancements.js
node --check src/ui/week-view.js
npm test
```

La prueba automatizada no sustituye la revisión manual del comportamiento adhesivo, selección real,
teclado, vista móvil, JSON, Word y PDF en Edge o Chrome.
