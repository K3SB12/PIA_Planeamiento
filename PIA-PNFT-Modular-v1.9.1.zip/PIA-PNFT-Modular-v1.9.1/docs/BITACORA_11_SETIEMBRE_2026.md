# Bitácora de desarrollo — 11 de setiembre de 2026

## Actualización correctiva 1.6.13 — conclusiones consolidadas

La revisión del documento **acuerdos con chat** identificó que la primera entrega 1.6.12 no había
incorporado todos los acuerdos y que la semántica aplicada a las celdas vacías era incorrecta.

- Se sustituyó “vacío = fortalecimiento” por `no-curricular-record`: ausencia de abordaje conceptual
  documentado, sin inferir enseñanza, refuerzo, dominio, indicador ni evaluación.
- Se conservaron estados separados para presencia conceptual y fortalecimiento no evaluable, utilizables
  únicamente cuando una fuente curricular los respalde expresamente.
- La trayectoria ahora ofrece tarjetas y tabla comparativa, filtros por módulo, área y alcance, encabezado
  contextual, RdA, procedencia visible e iconografía PNFT suministrada.
- Los antecedentes, continuidades y nombres de familias quedaron fuera del prompt semestral.
- El diagnóstico inicia en cero y desactivado; solo se incorpora al prompt mediante selección expresa.
  Se añadieron una guía de opciones y la acción **Reiniciar diagnóstico**.
- “Nota” cambió a **Observación o decisión docente** y se aclaró que “Durante todo el periodo” no impone
  una frecuencia semanal de evaluación.
- Se preservaron la auditoría temporal posterior, la localización de la etapa de desarrollo, JSON v6,
  currículo, semanas, Proyecto, PDF, Word y el HTML portable autónomo.
- Resultado automatizado: 132/132 pruebas aprobadas antes de la validación visual final.

## Actualización 1.6.12 — Trayectoria curricular y tiempo pedagógico

- Los dos Excel de progresión y escalabilidad coincidieron con las fuentes ya trazadas en PIA.
- Se habilitó una ventana informativa de familias curriculares con ANTES, AHORA y DESPUÉS.
- Se mantuvo AHORA restringido a los saberes seleccionados y se preservaron indicadores literales.
- Se diferenciaron fortalecimiento sin evaluación directa y ausencia del saber o área en un nivel.
- Se añadieron filtros e iconos SVG locales con los colores de las cuatro áreas del PNFT.
- Se incorporó la auditoría temporal posterior a la propuesta de IA, sin alertas por conteo aislado.
- Se corrigió la salida visible a “Etapa de desarrollo → Prototipar”.
- Resultado automatizado: 127/127 pruebas aprobadas. Revisión humana visual pendiente.

## Propósito de la jornada

Se revisó la experiencia de uso del apoyo diagnóstico considerando dos perfiles reales: la persona
docente que dispone de un grupo y la persona asesora que construye una proyección de referencia. Se
confirmó que el diagnóstico debe aportar contexto sin convertirse en un requisito para proyectar el
semestre. También se identificó la necesidad de explicar términos especializados sin llenar la pantalla
con párrafos permanentes.

## Decisiones aprobadas

1. Mantener el selector de cero a dos lecciones diagnósticas en el Marco temporal, porque afecta la
   reserva inicial del periodo.
2. Trasladar únicamente la acción **Preparar evaluación diagnóstica** al final de Saberes para la
   proyección, donde PIA ya conoce qué currículo se desea explorar.
3. Habilitar esa acción con ciclo, nivel, módulo, área, saber conceptual y una o dos lecciones.
4. Conservar el diagnóstico como recurso opcional. Un asesor puede proyectar sin aplicarlo y un docente
   puede preparar una proyección inicial y ajustarla posteriormente con hallazgos reales.
5. Incorporar ayudas contextuales accesibles y breves, procedentes de un glosario centralizado.

## Implementación y justificación

### Secuencia del diagnóstico

El botón se retiró del campo de lecciones y se colocó después del panel de saberes. El cambio evita
presentar una acción pedagógica antes de que exista información curricular suficiente. El estado del
diagnóstico se mantiene junto al nuevo acceso y comunica qué selección falta, sin bloquear la proyección.

La función `diagnosticReadiness()` comprueba exclusivamente las condiciones de apertura. No interviene
en `semesterPrompt()`, por lo que el diagnóstico sigue siendo opcional. Los datos guardados se conservan
incluso si posteriormente cambia una selección; PIA solicita completar el nuevo contexto para revisarlos,
pero no los elimina.

### Ayudas contextuales

Se creó `contextHelpCatalog` como fuente única de explicaciones. El catálogo distingue entre currículo
del PNFT, orientación pedagógica, normativa aplicable y funciones propias de PIA. Se incorporaron ayudas
para Contextualización y DUA, indicadores de referencia, proyección semestral, diagnóstico, RdA, saberes,
Proyecto, componentes de evaluación, momentos evaluativos y modalidad semanal del Proyecto.

La ayuda aparece con puntero o foco y puede fijarse mediante clic o toque. Solo una permanece abierta;
se cierra al seleccionar otra, pulsar fuera o utilizar `Esc`. El posicionamiento se ajusta al espacio de
la pantalla y no utiliza fondo modal, por lo que no interrumpe la escritura. En dispositivos pequeños
los controles aumentan su área táctil.

Las ayudas son efímeras: no se incorporan a `state`, JSON, autoguardado, prompts, PDF ni Word. También
se excluyen expresamente de impresión.

## Protección de lo validado

- Se conservó `schemaVersion: 6` y la migración de planes anteriores.
- No se modificaron `PNFT_DATA`, `RDA_POR_CICLO`, el catálogo de Preescolar ni los indicadores oficiales.
- No se alteraron Proyecto, prompts, semanas, formato, exportadores, backend inactivo ni versión portable.
- PIA 1.7.x y el Mapa de Trayectoria permanecen como proyecto independiente.

## Validación ejecutada

- Comprobación sintáctica de `src/application/enhancements.js`.
- Construcción de `index.html`, `dist/web/index.html` y `dist/portable/index.html` desde la fuente.
- Verificación del alcance autorizado y equivalencia de las tres salidas generadas.
- Tres pruebas nuevas para orden visual, requisitos diagnósticos, opcionalidad y accesibilidad de ayudas.
- Regresión completa de currículo, progresión, Preescolar, Proyecto, evaluación, prompts, semanas,
  persistencia, PDF, Word y funcionamiento portable.

Resultado: **120 pruebas aprobadas de 120; 0 fallos**.

## Resultado funcional

PIA 1.6.11 presenta el diagnóstico cuando resulta pedagógicamente comprensible, pero no obliga a
utilizarlo. La persona usuaria recibe explicaciones bajo demanda y conserva una pantalla limpia. Con
ello mejora la incorporación de docentes y asesores nuevos sin reducir autonomía ni alterar el
planeamiento oficial.
