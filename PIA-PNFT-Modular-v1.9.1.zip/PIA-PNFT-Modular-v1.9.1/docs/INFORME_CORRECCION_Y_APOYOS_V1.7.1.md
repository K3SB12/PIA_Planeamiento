# Informe de corrección y apoyos inclusivos PIA 1.7.1

## Incidencia confirmada

La experiencia **Explorar un ejemplo de planeamiento** se encuentra dentro del contenedor principal
`.container`. La versión 1.6.15 aplicaba `inert` y `aria-hidden` directamente a ese contenedor al abrir
la experiencia. Como resultado, la propia experiencia quedaba inerte y parecía congelada. La causa no
dependía de GitHub Pages y se reproducía en el HTML local.

## Corrección aplicada

PIA 1.7.1 identifica si la experiencia está dentro del plan. En ese caso aísla únicamente los elementos
hermanos; nunca el ancestro que contiene la experiencia. Al cerrar, restaura exactamente los atributos
previos y devuelve el foco al control desde el que se abrió.

## Criterio aplicado a DUA adecuaciones y PEI

La interfaz diferencia apoyos universales de mediación, acceso, apoyos no significativos y decisiones
curriculares significativas ya aprobadas. Ninguna selección de PIA constituye aprobación. Los prompts
prohíben inventar adecuaciones, interpretar una PEI o convertir referencias de otro nivel en currículo
vigente.

## Criterio aplicado a Plan Nacional

La orientación PNFT 2026 establece coordinación con la persona docente guía, diagnóstico, selección de
saberes pertinente a las necesidades y dos lecciones semanales. PIA recoge esas decisiones generales y
las comunica al prompt cuando la contextualización fue activada. El catálogo integrado llega hasta 9.º;
por responsabilidad curricular, no se generaron saberes o indicadores para 10.º–12.º.

## Alcance de las fuentes

Las Orientaciones generales para docentes 2026 se utilizaron como referente funcional principal. El
video de 2021 y el documento de ejemplo aportado ayudan a identificar necesidades docentes, pero no se
utilizaron para autorizar cambios automáticos ni para sustituir normativa u orientaciones vigentes.
