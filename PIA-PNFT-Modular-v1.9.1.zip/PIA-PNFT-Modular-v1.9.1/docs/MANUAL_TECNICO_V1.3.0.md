# Manual técnico — PIA-PNFT Modular 1.3.0

## Ensamblado

`scripts/fragment-manifest.mjs` declara el orden de fragmentos. `npm run build` concatena sin
framework ni transpilar y genera tres HTML idénticos. No edite esas salidas directamente.

## Capas

| Capa | Responsabilidad |
|---|---|
| `src/data` | Currículo protegido y perfiles de evaluación versionados |
| `src/domain` | Estado, migración, currículo, semanas, distribución y cobertura |
| `src/application` | Coordinación del núcleo, mejoras, autosave y revisión |
| `src/infrastructure` | JSON, PDF, Word y portable |
| `src/prompts` | Prompt general, semanal y semestral |
| `src/ui` | Render de semanas y notificaciones |
| `src/templates`, `src/styles` | Estructura y presentación |
| `src/adapters` | Puertos futuros; backend inactivo |

## Dependencias principales

`enhancements.js` consume `PIAProjectionCore`, `PIAEvaluationProfiles`, `PIASemesterPrompt`,
`PNFT_DATA` y `RDA_POR_CICLO`. El manifiesto debe cargarlos antes. El sistema mantiene ámbito global
por compatibilidad con eventos inline heredados.

## Contrato JSON v3

El objeto base conserva los campos históricos y añade `pia`: identidad, contexto, estado, calendario,
evaluación, propuesta IA, proyección, asignaciones y estrategias. `migrate()` fusiona v1/v2 con valores
seguros, convierte `diagnosisWeeks` a `diagnosisLessons` y elimina el nombre institucional duplicado.

## Seguridad local

No hay `fetch`, XHR, WebSocket, EventSource ni beacon. El HTML enriquecido se limita a etiquetas y
estilos permitidos; se eliminan scripts, eventos y atributos no autorizados. Los datos permanecen en
JSON/localStorage. Activar el puente requiere autenticación, autorización, cifrado, retención, auditoría,
consentimiento, minimización y aprobación institucional.

## Pruebas

Ejecute `npm test`. Las pruebas verifican currículo intacto, ensamblado, orden, migración, eliminación,
guardado/carga, Word, perfiles, distribución, prompt, ausencia de red y protección de indicadores.
