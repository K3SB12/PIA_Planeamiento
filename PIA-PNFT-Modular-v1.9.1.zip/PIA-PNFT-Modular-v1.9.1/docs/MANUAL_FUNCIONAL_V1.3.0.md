# Manual funcional — PIA-PNFT Modular 1.3.0

## Inicio

Abra `dist/portable/index.html` en Microsoft Edge o Google Chrome. No requiere instalar servidor.
Use computadora para comprobar todas las descargas y ventanas de vista previa.

## Recorrido

1. **Identidad opcional:** cargue escudo PNG/JPEG (máximo 1 MB) y lema. El nombre se completa en
   **Centro educativo** dentro del encabezado oficial.
2. **Encabezado oficial:** complete los datos administrativos sin alterar su formato.
3. **Ejes y metodología:** seleccione los correspondientes. La metodología puede cambiarse sin alerta.
4. **Contextualización y DUA:** describa grupo, recursos/conectividad y apoyos sin datos personales.
5. **Proyección:** indique semanas, máximo dos lecciones diagnósticas, fechas editables, módulo(s),
   áreas y perfil de evaluación. En preescolar aparece el itinerario; “Básico requerido” permanece
   bloqueado hasta contar con catálogo autorizado.
6. **Saberes:** PIA marca los conceptuales del módulo/área. Seleccione también procedimentales y
   actitudinales. Puede buscar y ajustar.
7. **Distribución:** revise fases y semanas. Se recomiendan dos saberes, pero puede integrar uno,
   tres o más con confirmación. Desmarcar un área exige confirmación.
8. **Prompt semestral:** genere y copie el texto a la herramienta de IA autorizada. Pegue la respuesta
   en “Propuesta semestral”, revise su estructura y apruébela solo si cumple su criterio. No se aplica sola.
9. **Semanas:** complete mediación e indicadores de evaluación. El indicador de logro oficial no se edita.
10. **Edición contextual:** seleccione un campo editable para aplicar formato, deshacer, rehacer,
    limpiar formato o duplicar la semana anterior.

## Guardar, cargar y exportar

- **Guardar:** descarga JSON v3 para continuar después.
- **Cargar:** recupera JSON v1, v2 o v3 y lo migra sin borrar el contenido compatible.
- **Exportar:** elija PDF o Word. Word abre una vista continua horizontal; use Guardar Word o Imprimir.
- **Portable:** descarga una copia autónoma de la plantilla.
- **Recuperar autoguardado:** muestra primero fecha y cantidad de semanas; usted confirma el reemplazo.

## Significado del seguimiento

“Proyectado”, “ejecutado” y “pendiente” describen la cobertura del plan. No prueban automáticamente
el dominio ni el aprendizaje alcanzado por el estudiantado.
