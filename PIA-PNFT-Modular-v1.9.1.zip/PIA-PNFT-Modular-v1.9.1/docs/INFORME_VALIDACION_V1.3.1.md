# Informe de validación — PIA-PNFT Modular 1.3.1

Fecha: 2026-08-26

## Alcance aprobado

- Simplificación de Proyección a tiempo, currículo y saberes.
- RdA oficiales visibles por área seleccionada.
- Eliminación de distribución automática y del espacio para pegar/aprobar respuestas de IA.
- Cobertura interna calculada desde las semanas reales.
- Navegador para planes extensos y una semana visible por defecto.
- Diagnóstico visible en semana 1.
- Formato, deshacer y rehacer independientes por campo semanal.
- Eliminación de reutilización/banco local de estrategias.
- Exclusión total de Proyección y Cobertura en PDF y Word.

## Resultado automatizado

- Verificación de fuente: aprobada.
- Ensamblado reproducible: aprobado.
- Alcance autorizado respecto de la referencia protegida: aprobado.
- Pruebas Node: **24 aprobadas, 0 fallidas**.
- Salidas `index.html`, `dist/web/index.html` y `dist/portable/index.html`: idénticas.
- APIs de red nuevas: 0.
- `PNFT_DATA` y `RDA_POR_CICLO`: sin modificaciones.

## Huellas

- Referencias protegidas: `46f994e2572f897e9ebd159afb71ab7d5dfe68c40469621b97030a12451bbe79`.
- Salidas 1.3.1: `dc642f6466e4d50de954b9c004aa1877ae0124e68c103eccd0002cf248c9f791`.

## Validación humana final

La prueba manual recomendada en Edge/Chrome debe recorrer un nivel real, comprobar los RdA,
navegar entre semanas, aplicar/deshacer/rehacer formato en ambos campos editables, guardar/cargar
JSON y revisar PDF/Word. Las ventanas emergentes, impresión y ubicación de descargas dependen del
navegador y del sistema operativo.
