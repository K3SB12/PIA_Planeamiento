# Informe de validación — PIA-PNFT Modular 1.6.2

**Fecha:** 4 de setiembre de 2026  
**Base:** ZIP adjunto PIA-PNFT Modular 1.6.1  
**Resultado automatizado:** 85/85 pruebas aprobadas

Las tres salidas ejecutables son idénticas y tienen SHA-256
`35ccbcf9cbaf4a28dcf3f5b3e3cf7236719937a17930e47b7e9f7ba409be5598`.

## Mejora validada

Se incorporó una capa relacional de solo lectura que organiza los saberes conceptuales en 38
familias de progresión, distribuidas en las cuatro áreas del PNFT y diez niveles (`0°` a `9°`).
La relación se usa únicamente para enriquecer el prompt semestral.

## Cobertura comprobada

- 38 familias presentes.
- 4 áreas presentes, incluida Computación física y Robótica.
- 10 niveles presentes.
- 235 de 235 registros curriculares actuales relacionados mediante correspondencia exacta.
- Cero registros curriculares sin familia.
- Hallazgo histórico corregido en 1.6.13: el vacío no acredita refuerzo; representa ausencia de
  registro curricular. Se mantienen texto/alcance explícito y `N/A`/no aplicable diferenciados.

## Protección de la versión validada

Las huellas de los siguientes archivos son idénticas a las del ZIP 1.6.1 recibido:

| Archivo protegido | SHA-256 |
| --- | --- |
| `src/data/pnft-data.js` | `ef8bab8d6ff32798425a1a28441f7651aabe050fac8307bc92c517da88212edf` |
| `src/data/rda-por-ciclo.js` | `652f1df1de6e5686dc6b1df7b19f46c23615b21eca8da6fd3336a2fc14d40a87` |
| `src/data/preschool-curriculum.js` | `c780535a780ac4ba4b3065ece9ac08cd74e8fb4099b2bc85567194e1b965cdc5` |

También permanecen sin cambios el catálogo del componente Proyecto, el esquema JSON v6, el
servicio de planes, PDF, Word y portable. No se añadieron APIs, red, backend, autenticación,
analítica, carga de Excel ni interfaz del proyecto PIA 1.7.0.

## Hallazgo conservador

El ejemplo de escalabilidad contiene una variante en 7.º: “entorno de programación textual o
bloques”, mientras PIA conserva “entorno de programación textual o por bloques”. La versión 1.6.2
no modifica el texto de PIA porque el archivo de ejemplo no sustituye una fuente curricular oficial.

## Pruebas ejecutadas

- Verificación sintáctica de todos los fragmentos JavaScript.
- Ausencia de nuevas APIs de red.
- Ensamblado reproducible de `index.html`, web y portable.
- Alcance autorizado frente a la referencia protegida.
- Regresión completa de guardado/carga, JSON v6, semanas, Proyecto, PDF y Word.
- Cobertura exacta de los 235 registros curriculares.
- Validación específica de Algoritmos como familia con desarrollo explícito y refuerzo no evaluable.
- Inclusión de Computación física y Robótica.
- Contrato del prompt contra indicadores inventados y afirmaciones de aprendizaje alcanzado.

## Validación manual pendiente

Como no cambió la interfaz, no se requiere una nueva aceptación estética. Antes de distribución
institucional se recomienda abrir `index.html` en Edge o Chrome, generar un prompt semestral con
varias áreas y confirmar que el apartado “Trayectoria curricular de referencia” resulte claro para
la persona docente. Esta revisión complementa, pero no sustituye, las pruebas automatizadas.
