# Manual funcional — PIA-PNFT Modular 1.6.0

## Proyecto en III Ciclo y Diversificada

1. Seleccione ciclo, nivel y un perfil que contenga Proyecto.
2. Active **Planificar componente Proyecto** y complete tema, población, problema y solución.
3. La etapa inicial mantiene Empatizar, Definir e Idear con sus indicadores oficiales.
4. Active **Prototipar** o **Probar/Evaluar** y escriba un indicador de logro y hasta dos de
   evaluación. PIA los identifica como aportes editables de la persona docente, no como oficiales.
5. En cada semana elija Curricular, Mixta o Integrada, luego etapa y fase. Los campos se muestran
   dentro de las columnas oficiales del planeamiento.
6. Una modificación semanal se conserva y no vuelve a ser reemplazada por la proyección.

## Prompts

PIA conserva por separado el prompt general, el semestral y el de cada semana. Después de editar un
prompt, use **Guardar** para descargar el JSON. Al cargarlo y abrir nuevamente el mismo generador,
aparece el texto guardado. PIA no envía el contenido a servicios externos.

## Proyección y exportación

- **Ocultar proyección** reduce el desplazamiento y no elimina datos.
- PDF y Word no incluyen la proyección ni la cobertura.
- Una semana de Proyecto exporta los textos efectivos en las columnas de logro y evaluación.
- Word ofrece áreas blancas más amplias para Reflexiones Docentes y Observaciones.

Los textos docentes de Prototipar y Probar/Evaluar deben revisarse y contextualizarse. No sustituyen
indicadores oficiales futuros ni modifican los datos curriculares protegidos.
