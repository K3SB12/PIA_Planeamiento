# Manual técnico — PIA-PNFT Modular 1.6.8

## 1. Arquitectura conservada

PIA continúa siendo una aplicación frontend local ensamblada desde `src/`. El constructor genera
`index.html`, `dist/web/index.html` y `dist/portable/index.html`. No se incorporan backend, autenticación,
analítica activa ni solicitudes automáticas de red.

| Responsabilidad | Ubicación principal |
|---|---|
| Portada, identidad y secciones visibles | `src/templates/`, `src/styles/` |
| Estado, migración y valores iniciales | `src/domain/projection/projection-core.js` |
| Coordinación de contexto, referencias y prompts | `src/application/enhancements.js` |
| Semanas y formato contextual | `src/ui/week-view.js`, `src/application/enhancements.js` |
| Currículo autorizado del PNFT | `src/data/`, `src/domain/curriculum/` |
| Generadores de prompts | `src/prompts/` |
| Guardado y carga | `src/application/plan-service.js`, `src/infrastructure/persistence/` |
| PDF, Word y portable | `src/infrastructure/export/` |
| Construcción y puertas de calidad | `scripts/`, `tests/` |

La asignación exacta debe mantenerse alineada con la implementación final. Ningún documento autoriza
editar directamente los archivos generados.

## 2. Contratos de datos

### 2.1 Compatibilidad

Los campos nuevos son aditivos. La migración debe completar valores seguros cuando un JSON anterior no
contenga portada, contexto estructurado, referencias o metadatos de prompt. No se eliminan `saberes`,
`saberRefs`, Proyecto, identidad, proyección ni contenidos semanales.

### 2.2 Contexto

El estado contextual separa:

- texto abierto del grupo, recursos y DUA;
- perfil de implementación;
- condiciones complementarias;
- escenario tecnológico y descripción;
- punto de partida grupal.

No deben almacenarse atributos personales del estudiantado. Los valores son locales y se incluyen en el
prompt solo cuando la persona docente los selecciona o completa.

### 2.3 Referencias curriculares

Cada referencia controlada debe conservar un identificador estable y, como mínimo, nivel de procedencia,
módulo, área, saber, texto literal del indicador, motivo y texto docente separado. Las semanas almacenan
la selección por identificador; nunca duplican ni reescriben el catálogo oficial.

La resolución exige correspondencia exacta. Una referencia huérfana después de una actualización debe
conservarse desde la instantánea guardada y mostrarse para revisión, no descartarse silenciosamente.

### 2.4 Prompts

General, Semestral y Semanal mantienen texto independiente. La implementación debe distinguir el borrador
visible, la última propuesta generada y la confirmación docente. Regenerar requiere confirmación si puede
sustituir texto. La captura debe ocurrir durante la edición y antes de cerrar, guardar o autoguardar.

## 3. Portada

La portada es una capa de interfaz anterior al contenedor principal. Su preferencia de omisión pertenece
al dispositivo, no al documento pedagógico. Iniciar, cargar y regresar deben reutilizar las operaciones
vigentes; no se admite una segunda ruta de carga que omita migración o validación.

Los recursos visuales deben quedar incorporados en las salidas autónomas. La portada debe declararse fuera
de impresión y de las composiciones Word/PDF.

## 4. Diagnóstico 0–2

La normalización acepta enteros de cero a dos. Debe sincronizar:

- `calendar.diagnosisLessons`;
- texto del marco temporal y prompt;
- momento inicial de las semanas afectadas.

La sincronización actualiza metadatos, no elimina el contenido de una semana ni redistribuye saberes.
Planes anteriores mantienen el valor guardado o reciben el valor inicial compatible.

## 5. Prompt contextual

La capa de composición debe:

1. omitir condiciones no seleccionadas;
2. omitir valores neutrales y campos opcionales vacíos;
3. exigir metodología activa antes de generar el prompt semestral;
4. conservar indicadores oficiales literalmente;
5. relacionar área, saber, indicador de logro del PNFT y RdA;
6. rotular las referencias con su nivel de procedencia;
7. mantener separado el texto elaborado por la persona docente;
8. solicitar alternativas tecnológicas equivalentes;
9. indicar “requiere validación institucional” cuando corresponda;
10. impedir que una sugerencia externa se presente como currículo oficial del PNFT;
11. numerar consecutivamente únicamente las reglas aplicables.

El prompt continúa siendo texto local. Abrir un servicio externo no transmite el contenido.

## 6. Formato contextual conservado

La versión 1.6.8 hereda los contratos de 1.6.7:

- destinatarios `mediation` y `evaluation` exclusivamente;
- logro oficial no editable;
- rango activo preservado;
- saneamiento previo a persistencia;
- vínculos solo HTTPS;
- opciones secundarias plegadas;
- controles táctiles y cierre accesible.

## 7. Exportaciones

PDF y Word deben incluir únicamente el planeamiento oficial. La referencia seleccionada puede integrarse
en la columna de logro con rotulación de procedencia, pero portada, panel contextual, proyección y cobertura
no forman parte del documento. La exportación no consulta red ni reconstruye el currículo desde texto libre.

## 8. Verificación obligatoria

```bash
node --check src/application/enhancements.js
npm test
```

Además, en Edge o Chrome:

1. abrir la versión portable desde `file://`;
2. probar iniciar/cargar/regresar en portada;
3. comprobar diagnóstico 0–2 sin pérdida;
4. guardar/cargar cada perfil, escenario y condición;
5. incorporar una referencia, guardar JSON y exportar;
6. editar, cerrar, reabrir, actualizar y restablecer cada tipo de prompt;
7. verificar barra de formato con ratón, teclado y pantalla angosta;
8. revisar PDF y Word, incluida la dimensión del escudo;
9. confirmar ausencia de solicitudes de red.

Hasta completar estas comprobaciones, la versión debe considerarse candidata y no validada.
