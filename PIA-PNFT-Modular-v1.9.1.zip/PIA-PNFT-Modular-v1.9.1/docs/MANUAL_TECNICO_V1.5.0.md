# Manual técnico — PIA-PNFT Modular 1.5.0

## Módulos nuevos

| Archivo | Responsabilidad |
| --- | --- |
| `src/data/evaluation-instruments.js` | Catálogo versionado de instrumentos, requisitos, fuentes y salvaguardas. |
| `src/data/project-component-catalog.js` | Etapas, fases e indicadores oficiales independientes del currículo PNFT. |
| `src/application/enhancements.js` | Puerta por perfil, UI, persistencia y composición de entradas para prompts. |
| `src/prompts/*.js` | Contratos de literalidad, integración, evaluación y detalle pedagógico. |

El manifiesto carga ambos catálogos después de perfiles y antes de los consumidores. No existen
importaciones de red ni dependencias nuevas.

## Persistencia

`schemaVersion: 4` añade `pia.evaluation.guidance` y `pia.evaluation.projectPlanning`. Este último
conserva activación, contexto del Proyecto, etapa, fases, hitos e `indicatorSnapshots` con `id`,
texto literal y versión. `PIAProjectionCore.migrate()` fusiona valores v1/v2/v3 con defaults v4.

Ocultar el panel por incompatibilidad no muta sus datos. Solo la acción confirmada de eliminación
restablece `projectPlanning`. El autoguardado usa `pia.plan.autosave.v4` y mantiene lectura v3/v2.

## Separación normativa

Los indicadores del Proyecto no se insertan en `PNFT_DATA` ni `RDA_POR_CICLO`. Desarrollo y etapa
final tienen estado `pending-official-source`; nunca se completan con inferencias. Los exportadores
oficiales no consumen el panel de Proyecto.

## Validación

Ejecute:

```powershell
node --check src/application/enhancements.js
npm test
```

Resultado de esta entrega: 61/61 pruebas y tres HTML idénticos con SHA-256
`df112c585f91861a26d790aaca9656cd8053921dca157cd420dd5e64dce976e2`.
