# Manual funcional — PIA-PNFT Modular 1.5.0

## Orientación de instrumentos

En **Selección curricular**, confirme el perfil de evaluación y elija qué necesita observar. PIA
muestra un instrumento pertinente, su uso y requisitos. Es una recomendación: la persona docente
decide y contextualiza; PIA no guarda nombres, resultados ni calificaciones.

## Componente Proyecto

La opción solo aparece si el perfil confirmado contiene Proyecto. Active **Planificar componente
Proyecto**, complete tema, población, problema y solución, y seleccione etapa y fase. En la etapa
inicial PIA muestra literalmente el indicador oficial disponible. Las fases sin indicador oficial
incorporado muestran una advertencia y PIA no inventa contenido.

Los hitos permiten estimar avance operativo; no son nota ni evidencia automática de aprendizaje.
Cambiar temporalmente de ciclo o perfil oculta el panel sin borrar sus datos. El botón de eliminación
solicita confirmación explícita.

## Prompts

Los prompts general, semanal y semestral exigen a la IA:

- copiar completos y literalmente los indicadores oficiales;
- mostrar saberes procedimentales y actitudinales en cada semana;
- integrar saberes por afinidad o justificar pedagógicamente su tratamiento individual;
- desarrollar inicio, desarrollo y cierre con acciones, recursos, tiempos, evidencia, DUA,
  realimentación y continuidad;
- distinguir normativa oficial de sugerencias editables.

Revise siempre la respuesta externa antes de trasladar contenido a las semanas.

## Guardar, cargar y exportar

Guardar produce JSON v4 y cargar acepta planes v1, v2, v3 y v4. PDF y Word conservan el formato
oficial y no añaden una sección de proyección, cobertura o administración del Proyecto.
