# Informe de validación — PIA 1.9.0

## Alcance validado

- Mapa integral de III Ciclo construido con HTML, CSS y JavaScript local, sin React, API o red.
- Una sola ruta para mediación curricular y Proyecto.
- Fases de Pensamiento de Diseño y protección de indicadores oficiales.
- Función, fase, semanas, grupo, evidencia, nota, relaciones y color visual por saber.
- Capas procedimentales, actitudinales, ejes, evaluación y horizonte curricular.
- Tabla equivalente, modos guiado/directo, adaptación móvil y controles por teclado/toque.
- Auditoría determinista y prompt comparativo de dos o tres enfoques.
- Persistencia compatible con planes anteriores mediante `schemaVersion: 6`.
- Exportación PNG e impresión/PDF del mapa separadas de las salidas oficiales.

## Salvaguardas curriculares

El mapa conserva textos oficiales como solo lectura. PIA no inventa indicadores para Prototipar o Probar/Evaluar, no convierte una relación en logro, no certifica RdA, competencia o perfil, no obliga un producto y no decide por la persona docente.

## Pruebas

La regresión recorre las pruebas históricas y las nuevas pruebas 1.9.0 sobre interfaz, migración, saneamiento, fases, prompt, accesibilidad y equivalencia mapa–tabla. Resultado: **192/192 pruebas aprobadas** y tres salidas HTML idénticas.

## Revisión manual recomendada

Antes de publicación institucional, verificar en Chrome y Edge: archivo local `file://`, GitHub Pages, guardado/carga JSON, mapa en 390×844, 768×1024 y 1366×768, teclado, lector de pantalla, PNG, imprimir/Guardar como PDF y retorno de foco. Esta revisión complementa las pruebas automatizadas y no se declara ejecutada sin evidencia humana.

## Huella de la entrega

`3f2ef5d2712fc7bfb2429168c1931909a50153190ed5f64adc4cb6092ef28bf2`
