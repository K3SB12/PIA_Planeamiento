# Informe de validación — PIA-PNFT Modular 1.6.0

Fecha: 2026-09-01

## Alcance verificado

- Esquema JSON v6 y migración desde planes anteriores.
- Persistencia de prompts general, semestral y semanales.
- Selección semestral de Prototipar y Probar/Evaluar.
- Un logro y dos evaluaciones docentes por fase posterior, sin atribución oficial.
- Inicialización semanal sin sobrescritura de registros existentes.
- Exportación compartida a PDF y Word y exclusión de campos vacíos.
- Proyección plegable sin eliminación de estado.
- Áreas blancas ampliadas de Reflexiones y Observaciones en Word.
- Ausencia de APIs de red y conservación de datos curriculares protegidos.

## Resultado automatizado

`npm test`: **75 aprobadas, 0 fallidas**.

Las pruebas Node verifican contratos, serialización, ensamblado y contenido exportable. La apertura
real de ventanas, impresión y comportamiento final de Microsoft Word deben confirmarse en la prueba
manual de aceptación en la computadora de la persona usuaria.
