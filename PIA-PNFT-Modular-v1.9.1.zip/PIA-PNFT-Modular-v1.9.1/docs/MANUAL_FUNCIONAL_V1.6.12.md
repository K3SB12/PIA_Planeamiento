# Guía funcional — PIA-PNFT Modular 1.6.12

## Explorar la trayectoria curricular

1. Seleccione ciclo, nivel, módulo, áreas y saberes conceptuales en Proyección semestral.
2. Presione **Explorar trayectoria curricular**, debajo de **Ver cobertura de las semanas**.
3. Use los filtros de color para mostrar todas las áreas o concentrarse en una.
4. Abra una familia curricular y lea sus tres tarjetas:
   - **ANTES:** referente explícito anterior para orientar el diagnóstico, sin suponer aprendizaje.
   - **AHORA:** saberes seleccionados del nivel actual e indicadores oficiales literales.
   - **DESPUÉS:** continuidad explícita posterior, sin adelantarla en el semestre vigente.
5. Interprete las etiquetas intermedias: amarillo indica fortalecimiento sin evaluación directa; gris
   indica que el saber o área no aparece en ese punto de la trayectoria.

La ventana no modifica el planeamiento y no forma parte del PDF o Word. Su utilidad es ofrecer al docente
o a la asesoría una referencia visual de integración, progresión y escalabilidad basada en el currículo ya
establecido, sin sugerir actividades ni afirmar que un aprendizaje previo fue alcanzado.

## Auditoría temporal del prompt

Después de generar la proyección con IA, la respuesta debe incluir **F) Auditoría temporal** y una sola
conclusión: Viabilidad temporal confirmada, Revisión temporal sugerida o Requiere ajuste temporal. La
conclusión debe considerar la distribución propuesta, la profundidad y continuidad, no solo contar bloques.

## Proyecto

En las fases posteriores, PIA presenta **Etapa de desarrollo → Prototipar**. `development` continúa siendo
un identificador técnico interno y no debe aparecer en el texto dirigido a la persona usuaria.
