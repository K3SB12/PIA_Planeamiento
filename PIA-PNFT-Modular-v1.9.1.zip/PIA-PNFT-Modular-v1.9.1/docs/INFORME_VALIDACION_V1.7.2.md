# Informe de validación — PIA 1.7.2

## Cambios verificados

- Diagnóstico con técnica e instrumento diferenciados, respuesta de IA revisable, anexo Word y bloqueo de resultados en modo asesor.
- Vinculación orientadora con semana 1 sin sobrescritura automática.
- Coordinación metodológica de secundaria con ruta común, apoyo puntual, secuencia o coordinación completa.
- Ventana de Proyecto declarada como parámetro docente, no como regla oficial.
- Balance oficial de 80 minutos y escenario preventivo no oficial separado.
- Corrección curricular de Operadores relacionales en 3.º, Módulo 1.

## Límites

- PIA no certifica viabilidad, logro, RdA alcanzado, promoción ni aprobación institucional.
- La respuesta de IA solo se incorpora al Word cuando la persona docente marca que fue revisada.
- La vinculación con semana 1 orienta los prompts; no modifica automáticamente el texto oficial del planeamiento.
- La posible separación de Software malicioso y Antivirus en 8.º requiere confirmación curricular adicional y no fue modificada en esta versión.

## Pruebas

- Fuente modular y ensamblado reproducible.
- Alcance autorizado.
- 20 combinaciones nivel–módulo y 236 saberes–indicadores.
- Diagnóstico, metodología, tiempo preventivo y migración de estado.
- Resultado automatizado previo al empaquetado: 165/165 pruebas aprobadas.

