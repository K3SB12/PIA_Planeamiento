# Informe de validación — PIA-PNFT Modular 1.2.1

Fecha: 25 de agosto de 2026.

## Alcance

Se promovió Proyección semestral desde un desplegable de herramientas avanzadas hasta una etapa
principal, visible inmediatamente después de Metodología activa. Se incorporaron orientación en
cuatro pasos, métricas en vivo, filtro de saberes, selección masiva visible y estilos adaptables.

## Resultado automático

- Verificación de fragmentos, sintaxis CSS y URLs: aprobada.
- Construcción reproducible de `index.html`, `dist/web/index.html` y
  `dist/portable/index.html`: aprobada y byte a byte idéntica.
- Alcance autorizado frente a `reference/index.original.html`: aprobado.
- Pruebas Node: 17 aprobadas, 0 fallidas.
- Puente backend y analítica: inactivos; no se incorporaron APIs de red.
- Guardado/carga JSON, eliminación de semanas, PDF, Word y portable: contratos aprobados.

## Integridad curricular

Las huellas de `src/data/pnft-data.js` y `src/data/rda-por-ciclo.js` coinciden con PIA 1.2.0.
No se modificaron saberes, indicadores ni resultados de aprendizaje.

## Revisión humana recomendada

Abrir `index.html` en Microsoft Edge y recorrer nivel → módulo → áreas → saberes → distribución.
Confirmar la comodidad visual con datos reales en la computadora institucional antes de declarar
la apariencia aprobada. Esta revisión no sustituye las puertas automáticas ya superadas.
