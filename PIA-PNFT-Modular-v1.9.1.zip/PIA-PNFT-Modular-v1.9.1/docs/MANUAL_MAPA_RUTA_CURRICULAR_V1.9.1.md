# Manual breve del mapa conceptual — PIA 1.9.1

1. Seleccione III Ciclo, nivel, módulo, áreas y saberes.
2. Confirme el perfil de evaluación y active Proyecto únicamente cuando corresponda.
3. Complete, si dispone de ellos, diagnóstico, contexto, recursos, apoyos DUA y calendario. Los campos opcionales no aportados no se inventan.
4. Elija una organización orientadora y abra **Construir o revisar mapa**.
5. Revise primero **Entrada que utilizarán el mapa y la IA**. Atienda los elementos marcados como pendientes; los opcionales pueden mantenerse sin activar.
6. Seleccione cada nodo de saber y defina su función, posible fase APD, semanas, grupo, evidencia y nota. La función organiza la ruta; no certifica aprendizaje.
7. Use **Relacionar** para declarar dependencias o aportes entre saberes. Las líneas rosadas punteadas representan relaciones creadas por la persona docente.
8. Verifique las cinco fases de Pensamiento de Diseño. Empatizar, Definir e Idear muestran sus indicadores oficiales; Prototipar y Probar/Evaluar requieren indicadores oficiales del módulo vinculados.
9. Revise calendario, evaluación y auditoría. Una advertencia solicita revisión; no toma la decisión por usted.
10. Use **Analizar mapa y comparar rutas con IA** para solicitar dos o tres enfoques. PIA no envía el prompt automáticamente ni aplica la respuesta.
11. Guarde la ruta. Después genere el prompt semestral, revise la respuesta y complete las semanas únicamente con las decisiones que haya validado.

**Ver ejemplo sin modificar mi ruta** abre una demostración de solo lectura. Para docentes con lector de pantalla o que prefieren edición lineal, la vista **Tabla accesible** contiene los mismos datos semánticos.

