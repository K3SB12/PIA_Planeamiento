import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,styles,dialogs,readme]=await Promise.all([
  read('src/templates/enhancements.html'),
  read('src/application/enhancements.js'),
  read('src/styles/08-enhancements.css'),
  read('src/templates/dialogs.html'),
  read('README.md')
]);

test('secundaria presenta currículo y Proyecto como una sola ruta integrada',()=>{
  assert.match(template,/Articular currículo y Proyecto como un solo proceso/);
  assert.match(template,/No son dos planeamientos ni dos procesos separados/);
  assert.match(template,/Ruta integrada: APD articula currículo y Proyecto \(base\)/);
  assert.match(template,/En la ruta integrada, estas semanas también desarrollan currículo/);
  assert.match(runtime,/Las semanas de Proyecto también desarrollan currículo/);
  assert.match(runtime,/no se suman como un segundo proceso/i);
});

test('la segunda metodología completa se muestra solo para las modalidades excepcionales',()=>{
  assert.match(template,/id="piaSecondMethodWrap"/);
  assert.match(template,/Excepción: metodología curricular completa antes del Proyecto/);
  assert.match(template,/Excepción: dos metodologías completas coordinadas/);
  assert.match(runtime,/completeMode=\['sequential-complete','coordinated-complete'\]\.includes\(mode\)/);
  assert.match(runtime,/secondMethodWrap\.hidden=!completeMode/);
});

test('diagnóstico conserva y explica las condiciones de entrada',()=>{
  assert.match(template,/value="current-entry">Condiciones de entrada para los saberes actuales/);
  assert.match(template,/id="piaDiagnosticPriorSourceHelp"/);
  assert.match(runtime,/necesarios para iniciar los saberes actuales/);
  assert.match(runtime,/sin exigir como dominio previo sus indicadores finales/);
});

test('los diálogos de prompt se adaptan a monitores de menor altura',()=>{
  assert.match(styles,/\.modal\s*\{[^}]*overflow-y:auto/s);
  assert.match(styles,/\.modal>\.modal-content\s*\{[^}]*max-height:calc\(100dvh/s);
  assert.match(styles,/\.modal>\.modal-content\s*\{[^}]*overflow-y:auto/s);
  for(const label of ['Copiar Prompt','Abrir en Copilot','Abrir en ChatGPT','Cerrar'])assert.match(dialogs,new RegExp(label));
});

test('la terminología visible usa lecciones pedagógicas',()=>{
  assert.doesNotMatch(template,/lecciones administrativas|lecciones curriculares/i);
  assert.doesNotMatch(runtime,/lecciones administrativas|lecciones curriculares|\badministrativas\b/i);
  assert.match(runtime,/lecciones pedagógicas/);
  assert.match(readme,/dos lecciones pedagógicas/);
});
