import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';

const root=resolve(import.meta.dirname,'..');
const read=file=>readFile(resolve(root,file),'utf8');
const [template,runtime,coreSource,dataSource,profileSource,promptSource]=await Promise.all([
  read('src/templates/enhancements.html'),read('src/application/enhancements.js'),read('src/domain/projection/projection-core.js'),read('src/data/pnft-data.js'),read('src/data/evaluation-profiles.js'),read('src/prompts/semester-projection-prompt.js')
]);

test('diagnóstico separa técnica, instrumento y función y solicita un instrumento imprimible',()=>{
  for(const id of ['piaDiagnosticTechnique','piaDiagnosticInstrument','piaDiagnosticInstrumentNotes'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(template,/La técnica define cómo se obtiene la evidencia/i);
  assert.match(template,/value="descriptive-rating">Escala de calificación descriptiva/);
  assert.doesNotMatch(template,/value="practical-playful"/);
  assert.match(runtime,/Entregue el instrumento completo, imprimible y editable/i);
  assert.match(runtime,/diagnóstica, formativa y sumativa son funciones o propósitos/i);
  assert.match(runtime,/no invente nombres ni resultados/i);
});

test('el escenario de 60 minutos se conserva como preventivo y no oficial',()=>{
  assert.match(template,/id="piaEffectiveBlockMinutes"/);
  assert.match(template,/no oficial/i);
  const context=vm.createContext({result:null});
  vm.runInContext(`${profileSource}\n${promptSource}\nresult={profiles:PIAEvaluationProfiles,prompt:PIASemesterPrompt};`,context);
  const profile=context.result.profiles.profiles.secondary;
  const text=context.result.prompt.build({level:'8°',cycle:'III Ciclo',weeks:17,lessons:34,netLessons:32,netMinutes:1280,effectiveBlockMinutes:60,effectiveNetMinutes:960,blockMinutes:80,diagnosisLessons:2,nonTeachingLessons:0,evaluationReserveLessons:0,modules:['Módulo 1'],areas:['Programación'],methodology:'ABR',methodologyCoordination:{mode:'coordinated-complete',notes:'Revisar puentes',feasibilityAcknowledged:true},axes:[],rdas:['RdA'],rdaItems:[{area:'Programación',text:'RdA'}],concepts:[{name:'Dato',module:'Módulo 1',area:'Programación',indicators:['Indicador']}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador'],evaluationProfile:profile,evaluationProfileConfirmed:true,evaluationInstruments:[],projectPlanning:{enabled:false}});
  assert.match(text,/bloque semanal de 80 minutos/i);
  assert.match(text,/escenario operativo preventivo declarado — no oficial: 60 minutos/i);
  assert.match(text,/segunda comprobación preventiva/i);
  assert.match(text,/no lo presente como carga oficial/i);
});

test('secundaria explica ABR completo y audita el riesgo de coordinar dos metodologías',()=>{
  for(const id of ['piaMethodCoordinationMode','piaMethodCoordinationNotes','piaMethodFeasibilityAcknowledged','piaMethodCoordinationAlert'])assert.match(template,new RegExp(`id="${id}"`));
  assert.match(template,/value="nested-complementary"/);
  assert.match(template,/id="piaProjectEstimatedWeeks"/);
  assert.match(template,/id="piaCurricularMethodWeeks"/);
  assert.match(template,/Diagnóstico 1 \+ ABR 4 \+ Proyecto 12/);
  for(const expected of ['Comprender','Investigar','Actuar','riesgo de duplicación','decisión docente pendiente'])assert.match(promptSource,new RegExp(expected,'i'));
  assert.match(runtime,/Junto con APD puede duplicar la definición del problema, la investigación, la solución y la evaluación/i);
  assert.match(runtime,/PIA informa riesgos, pero no decide por ella/i);
});

test('tercer grado módulo 1 conserva Operadores relacionales como saber independiente',()=>{
  const context=vm.createContext({result:null});
  vm.runInContext(`${dataSource}\nresult=PNFT_DATA;`,context);
  const knowledges=context.result['3°']['Módulo 1']['Programación y Algoritmos'].saberes;
  const arithmetic=knowledges.find(item=>item.nombre==='Operadores aritméticos');
  const relational=knowledges.find(item=>item.nombre==='Operadores relacionales');
  assert.ok(arithmetic);
  assert.ok(relational);
  assert.deepEqual([...relational.indicadores],[...arithmetic.indicadores]);
  assert.match(relational.indicadores[0],/"menor que".*"mayor que".*"igual que"/i);
});

test('la migración conserva los nuevos campos sin superar el referente oficial',()=>{
  const context=vm.createContext({result:null,encodeURIComponent});
  vm.runInContext(`${coreSource}\nresult=PIAProjectionCore;`,context);
  const migrated=context.result.migrate({pia:{calendar:{effectiveBlockMinutes:90},diagnostic:{technique:'debate',instrument:'checklist'},methodology:{coordinationMode:'sequential-complete',feasibilityAcknowledged:true}}});
  assert.equal(migrated.calendar.effectiveBlockMinutes,80);
  assert.equal(migrated.diagnostic.technique,'debate');
  assert.equal(migrated.diagnostic.instrument,'checklist');
  assert.equal(migrated.methodology.coordinationMode,'sequential-complete');
  assert.equal(migrated.methodology.feasibilityAcknowledged,true);
  assert.equal(migrated.methodology.curricularMethodWeeks,0);
  assert.equal(migrated.diagnostic.linkWeekOne,true);
  assert.equal(migrated.diagnostic.aiResponseApproved,false);
  assert.equal(migrated.evaluation.projectPlanning.plannedWeeks,0);
});
