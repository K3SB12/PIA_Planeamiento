# AGENTS.md — PIA-PNFT modular

## Autoridad

La fuente de la aplicación está en `src/`. Los scripts, pruebas, configuración y documentación
se mantienen en sus carpetas respectivas. `reference/index.original.html` y
`reference/index.received.html` son inalterables y conservan la huella SHA-256 aprobada. Los
archivos de `dist/` y el `index.html` de raíz son generados.

La documentación recibida se conserva como una instantánea histórica en
`docs/source-snapshot/`; no debe usarse para sobrescribir una bitácora o `tasks.md` más reciente
del repositorio operativo de VS Code.

## Reglas

1. No modificar textos ni correspondencias de `PNFT_DATA` o `RDA_POR_CICLO` sin autorización curricular expresa.
2. No editar directamente `index.html` ni archivos de `dist/`; ejecutar `node scripts/build.mjs`.
3. Después de cualquier cambio en la fuente, ejecutar `npm test`. `verify:equivalence` se reserva para una línea base sin diferencias funcionales autorizadas.
4. Ante una diferencia, revertir solamente la extracción causante.
5. Las mejoras de PIA 1.3.x, 1.4.x, 1.5.x y 1.6.x se mantienen dentro de bloques `PIA_*` identificados; cualquier cambio posterior debe ser pequeño, trazable y reversible.
6. React, un backend real, API, autenticación, analítica activa o migración de eventos inline requieren una fase independiente aprobada. `src/adapters/backend-bridge.js` permanece inactivo y no puede contener solicitudes de red.
7. La versión portable debe continuar siendo autónoma y no requerir Node ni servidor para el docente.
8. No actualizar `BASELINE.sha256`, `CURRENT.sha256` ni una versión sin autorización expresa y pruebas aprobadas.
9. El orden de los fragmentos en `scripts/fragment-manifest.mjs` es un contrato de ejecución; modificarlo requiere una tarea arquitectónica independiente.
10. Las pruebas Node no sustituyen la validación real en Chrome o Edge de ventanas emergentes, impresión, descarga y apertura local.
11. Los planes nuevos usan `schemaVersion: 6`; la carga migra planes anteriores. Proyecto guarda por semana modo, etapa, fase, referencia oficial y `teacherText`; la carga prioriza la contextualización guardada y nunca la sustituye por una actualización del catálogo.
12. Identidad, contexto, proyección y autoguardado permanecen en el dispositivo. No se recopilan datos de personas estudiantes ni se envían prompts automáticamente.
13. El orden visual vigente es: título/subtítulo, identidad opcional, encabezado administrativo oficial, ejes, metodología, Contextualización y DUA, proyección de referencia, seguridad/recuperación y semanas. Contextualización/DUA y seguridad/recuperación pueden plegarse visualmente sin perder datos ni controles.
14. El encabezado administrativo, `PNFT_DATA`, `RDA_POR_CICLO` y los indicadores de logro oficiales son contenido protegido. Solo mediación e indicadores de evaluación admiten formato enriquecido, mediante una barra local de cada semana.
15. Los perfiles de evaluación deben provenir de una fuente oficial identificada, sumar 100% cuando sean porcentuales y seleccionarse según ciclo/modalidad. PIA orienta; no impone cantidades universales de instrumentos.
16. La proyección no distribuye ni escribe saberes en las semanas. La persona docente realiza esa selección en cada semana; el prompt semestral es ayuda externa opcional.
17. Proyección, cobertura y cualquier respuesta externa de IA no forman parte del PDF ni del Word oficial. La cobertura interna se calcula exclusivamente desde los saberes incorporados en `semanas`.
18. El navegador semanal, sus estados y el momento pedagógico son ayudas de interfaz: nunca deben borrar contenido al cambiar, ocultar o mostrar semanas.
19. Preescolar conserva el nivel técnico interno `0°`. Sus rutas `basic` y `optimal` deben provenir exclusivamente de `src/data/preschool-curriculum.js`, con trazabilidad a la Guía docente oficial; no se deben mezclar saberes o indicadores entre rutas o módulos.
20. `src/data/institutional-centers.js` solo puede contener `centro`, `codPres` y `codSaber`. Se excluye siempre `codPres = 0000`; no se incorporan personas asesoras, teléfonos, correos u otros datos personales.
21. La actualización del catálogo de centros es una operación técnica mediante `scripts/import-centers.mjs`. La interfaz docente no debe ofrecer carga, edición o sustitución de archivos Excel.
22. Un código presupuestario único puede completar el centro automáticamente. Un código ambiguo exige selección explícita; PIA nunca debe adivinar. `codSaber` permanece interno en `pia.institutional.codSaber` y no se muestra en el planeamiento oficial.
23. Los instrumentos de evaluación son recomendaciones orientadoras: no almacenan estudiantes, resultados ni calificaciones; una evidencia no puede contabilizarse dos veces y PIA no inventa plazos, cantidades o porcentajes.
24. El componente Proyecto solo se habilita si el perfil confirmado contiene Proyecto. Sus indicadores son un catálogo independiente del currículo; las fases sin fuente oficial permanecen vacías y nunca reciben indicadores inventados.
25. Los prompts deben copiar literalmente los indicadores oficiales, identificar saberes procedimentales y actitudinales cada semana, priorizar la integración y justificar todo tratamiento individual. Las actividades deben ser desarrolladas, continuas y aplicables.
26. El selector visible de una sola necesidad/instrumento no forma parte de Proyección. El catálogo se entrega internamente al prompt y la recomendación ocurre después de definir actividad y evidencia.
27. Proyecto no usa hitos, porcentajes de avance ni estados automáticos. Cada semana puede ser curricular, mixta o integrada; sus textos se ubican en las columnas oficiales de logro y evaluación.
28. Ocultar Proyecto, cambiar de perfil o de fase no elimina registros semanales. El borrado global y la restauración del texto oficial requieren confirmación explícita.
29. PDF y Word deben usar exclusivamente `PIAProjectComponentCatalog.exportSelection()` mediante
`PIAEnhancements.projectExportForWeek()`. No deben recalcular ni leer directamente el catálogo.
30. Para Proyecto, la exportación prioriza `teacherText`, usa `officialText` como respaldo y excluye
solo de la salida los indicadores con `selected: false`; su registro JSON no se elimina.
31. Prototipar y Probar/Evaluar pueden almacenar un logro y dos evaluaciones `teacher-authored`.
`officialText` debe permanecer vacío y la interfaz, prompts y exportadores nunca pueden rotularlos como oficiales.
32. La proyección global puede inicializar un registro semanal faltante, pero nunca sobrescribe un
registro semanal existente. Ocultar la proyección modifica solo `pia.ui.projectionExpanded`.
33. `pia.aiPrompts` conserva `general`, `semester` y `weekly`. Guardar, cargar, autoguardar y portable
deben preservar exactamente cualquier texto editado por la persona docente.
34. Word debe conservar en blanco las áreas de captura de Reflexiones y Observaciones, con alturas
mínimas explícitas compatibles con Microsoft Word.
35. Cada semana conserva un filtro curricular independiente en `semana.modulos`: Módulo 1, Módulo 2
o ambos. Una semana nueva propone Módulo 1 para I semestre y Módulo 2 para II semestre; la persona
docente puede cambiarlo y siempre debe permanecer al menos un módulo activo.
36. El filtro semanal limita únicamente las áreas y saberes ofrecidos en pantalla. Cambiarlo, plegar
la selección curricular o cambiar de semana nunca elimina áreas, saberes, indicadores, mediación ni
evaluación ya guardados; toda selección fuera del filtro debe conservarse y advertirse.
37. Los saberes semanales nuevos mantienen `saberes` para compatibilidad y añaden `saberRefs` con
`modulo`, `area` y `nombre`. Los indicadores se resuelven por esa referencia compuesta para evitar
usar un indicador de Módulo 1 cuando la selección corresponde a Módulo 2. Los planes anteriores sin
referencias se cargan con ambos módulos disponibles y no pierden contenido.
38. El panel “Selección curricular de la semana” puede plegarse mediante `details`; su apertura o
cierre es exclusivamente visual y no forma parte del PDF o Word oficial.
39. Generar nuevamente el prompt semestral debe considerar el estado actual del marco temporal. Si
existe un texto anterior distinto, PIA debe protegerlo y solicitar confirmación antes de sustituirlo.
40. `src/data/curricular-progression.js` es un catálogo relacional de solo lectura y nunca sustituye
`PNFT_DATA`, `RDA_POR_CICLO` ni `preschool-curriculum.js`. No puede cambiar textos oficiales.
41. La relación saber–familia debe resolverse mediante correspondencia exacta por área y nombre. No
se admite coincidencia aproximada silenciosa; todo saber nuevo o renombrado debe fallar de forma visible en pruebas.
42. En la matriz de progresión, texto significa alcance explícito, una celda vacía significa que no
existe abordaje conceptual documentado para ese nivel y `N/A` significa no aplicable. Un vacío no puede
interpretarse como refuerzo, enseñanza, dominio, indicador o evaluación. La presencia conceptual o el
fortalecimiento sin evaluación directa solo se registran cuando una fuente curricular lo declara expresamente.
43. La progresión alimenta exclusivamente una vista local informativa. No añade familias, antecedentes
ni continuidad al prompt semestral, no selecciona saberes, no escribe semanas, no se exporta, no cambia
el JSON v6 y no afirma dominio, aprendizaje alcanzado ni cumplimiento del RdA.
44. El proyecto PIA 1.7.0 y su Mapa de Trayectoria continúan independientes. PIA 1.6.13 autoriza solo
 la vista efímera de familias ANTES–AHORA–DESPUÉS descrita en SPEC; no incorpora expedientes, analíticas,
 persistencia, importaciones ni otras funciones de la línea 1.7.x.
45. El nivel seleccionado gobierna el prompt semestral. Todo antecedente se presenta como expectativa
curricular no comprobada, requiere verificación diagnóstica y nunca permite omitir el alcance actual.
46. La presentación docente de progresión usa AHORA, ANTES y DESPUÉS. Los estados técnicos `N/A`
pueden omitirse visualmente, pero su semántica interna permanece protegida.
47. Una familia puede contener varios saberes del mismo nivel. El bloque AHORA debe mostrar solo los
saberes seleccionados y nunca ampliar automáticamente el alcance curricular decidido por el docente.
48. El prompt de Preescolar utiliza exclusivamente el perfil `preschool`: evaluación diagnóstica y
formativa, sin distribución porcentual, Proyecto ni instrumentos exclusivamente sumativos.
49. Las experiencias de Preescolar pueden iniciar y cerrar dentro de una semana, pero deben mantener
continuidad curricular. El bloque de 80 minutos puede ser continuo o dos lecciones articuladas de 40 minutos.
50. PIA no impone una cantidad mínima semanal de áreas, saberes o indicadores en Preescolar. La
integración depende de afinidad, desarrollo infantil, profundidad, tiempo y contexto; toda propuesta
debe explicar su contribución al RdA y al perfil de salida sin declarar aprendizaje alcanzado.
51. Las competencias y perfiles de salida de Preescolar son texto oficial protegido en
`preschool-curriculum.js`. Solo se envían al prompt los correspondientes a las áreas seleccionadas.
52. `promptContext()` y `promptSummary()` se conservan únicamente como servicios internos de análisis y
prueba. El generador semestral no los consume; la interfaz 1.6.13 usa `trajectoryView()` y mantiene fuera
del prompt los referentes anteriores, posteriores y nombres de familias.
53. El prompt semestral conserva las reglas generales de integración y profundidad, pero recibe únicamente
el currículo del nivel, módulos, áreas y saberes seleccionados. La trayectoria no se añade automáticamente.
54. La simplificación de trayectoria nunca puede retirar ni debilitar el contrato de Preescolar de
1.6.5: competencias, perfil de salida, experiencias lúdicas completas y evaluación diagnóstica/formativa.
55. La barra de formato contextual se limita a Estrategias de mediación e Indicadores de evaluación.
Los Indicadores de logro del currículo de FT permanecen protegidos, sin `contenteditable` ni comandos
de formato.
56. La barra puede abrirse al seleccionar texto o mediante el control de la semana. Debe conservar la
selección activa, identificar el campo destinatario, cerrarse con `Esc` y mantener plegadas las opciones
secundarias para no obstruir la escritura.
57. Inicio, Desarrollo y Cierre son estilos rápidos exclusivos de Estrategias de mediación. El pegado
limpio es una preferencia temporal de interfaz; no modifica el esquema JSON. Los vínculos requieren
`https://`, validación docente y nunca producen solicitudes automáticas de PIA.
58. El HTML enriquecido guardado continúa saneándose antes de persistir. Los vínculos no HTTPS se
convierten en texto; el formato aplicado debe conservarse en JSON, Word y PDF mediante las rutas vigentes.
59. PIA 1.6.8 incorpora una portada local de bienvenida. Debe poder iniciarse o cargar un JSON desde
esa portada, recordar opcionalmente la preferencia de omitirla en el dispositivo y regresar a ella sin
borrar el plan. La portada no forma parte del PDF ni del Word oficial y no realiza solicitudes de red.
60. La identidad institucional opcional conserva únicamente escudo y lema, se presenta alineada a la
izquierda antes del encabezado administrativo y nunca duplica el nombre del centro. El tamaño máximo
del escudo debe mantenerse estable en web y Word.
61. El diagnóstico admite de cero a dos lecciones. Su modificación actualiza el marco temporal y
los momentos iniciales sin borrar contenido semanal; diagnóstico, ejecución y aprendizaje demostrado
continúan siendo estados diferentes.
62. Contextualización y DUA es una sección opcional y plegable. Puede combinar los tres campos abiertos
vigentes con opciones estructuradas de perfil, condiciones, tecnología y punto de partida. Plegarla,
cambiar una selección o regresar a la portada no elimina información.
63. Los perfiles de implementación describen contexto, no diagnóstico clínico ni modalidad inventada.
`Regular` es el valor inicial. Las opciones especiales solo muestran ayudas pertinentes y toda regla
de evaluación no confirmada debe rotularse “requiere validación institucional”.
64. PIA no almacena nombres, expedientes, diagnósticos ni otros datos personales del estudiantado en
Contextualización y DUA. Las ayudas deben redactarse para el grupo o la situación educativa general.
65. El escenario tecnológico debe distinguir disponibilidad suficiente, conectividad limitada, trabajo
sin Internet, equipos compartidos, un único equipo demostrativo, ausencia de dispositivos y recursos
de robótica. El prompt debe proponer alternativas equivalentes sin conexión sin reducir la intención
de aprendizaje del currículo del PNFT.
66. Un indicador de referencia de otro nivel solo puede seleccionarse desde los datos autorizados del
PNFT. Debe conservar nivel, módulo, área, saber, texto literal, motivo y contextualización docente por
separado; nunca puede rotularse como indicador oficial del nivel administrativo vigente.
67. La incorporación de una referencia curricular en una semana es explícita y reversible. Su selección,
texto contextualizado y procedencia deben persistir en JSON/autoguardado y, cuando corresponda, aparecer
en la columna de logro de PDF y Word sin sustituir los indicadores del nivel actual.
68. Los prompts general, semestral y semanal son borradores independientes. Escribir en el editor debe
conservar el contenido al cerrar; “Guardar cambios del prompt” lo confirma explícitamente y JSON,
autoguardado y portable deben preservarlo sin normalizar ni reconstruir el texto.
69. Actualizar un prompt desde los datos actuales de PIA o restablecer la propuesta generada nunca puede
sobrescribir una edición docente sin confirmación. Copiar o abrir una herramienta externa no equivale a
guardar, y PIA no envía automáticamente el contenido.
70. El contrato contextual del prompt incluye únicamente datos completados o condiciones marcadas;
diferencia currículo vigente, referencia de otro nivel y texto elaborado por la persona docente; exige
DUA, alternativas desconectadas y validación institucional cuando corresponda, sin presentar sugerencias
de IA como currículo oficial del PNFT. Los valores neutrales iniciales no producen texto ni marcadores
“pendiente” en el prompt.
71. Toda ampliación de PIA 1.6.8 debe preservar JSON anteriores, currículo, Proyecto, Preescolar,
progresión interna, formato contextual, exportaciones y versión portable. La validación automatizada
debe complementarse con pruebas humanas de portada, accesibilidad, guardado de prompts y referencias.
72. El prompt semestral requiere una metodología activa seleccionada. Fechas, ejes, contextualización,
condiciones y referencias son opcionales: si no fueron aportados, se omiten y la IA recibe la prohibición
de inventarlos. Una fecha parcial se conserva como tal y nunca autoriza completar la faltante.
73. El prompt semestral relaciona cada RdA con su área y cada saber conceptual con módulo, indicador(es)
de logro del PNFT y RdA. Sus tareas se numeran consecutivamente según los bloques realmente aplicables,
incluido Proyecto solo cuando corresponde al ciclo y perfil.
74. El juego de metodologías es una capa formativa local e independiente. No puede leer, escribir, borrar
ni calificar el planeamiento; tampoco forma parte de JSON, autoguardado, PDF o Word.
75. La ruta de juego de Preescolar aplica su contrato propio: experiencias breves y lúdicas, itinerarios
Básico/Óptimo, evaluación diagnóstica/formativa y progresión hacia RdA y perfil de salida.
76. Contextualización y DUA solo se incorpora a los prompts cuando `context.enabled` es verdadero. Al
activarse, se incluyen incluso las opciones iniciales seleccionadas; al desactivarse, los datos se conservan.
77. “Otra metodología” exige una fundamentación condicional sobre propósito curricular, continuidad,
protagonismo estudiantil, evidencia, realimentación y viabilidad. No se rotula como metodología oficial.
78. “Afinar semana con IA” conserva la metodología semestral y el currículo de la semana. Un cambio
metodológico solo puede aparecer como sugerencia separada y justificada para validación docente.
79. El apoyo diagnóstico sigue el proceso: precisar, diseñar, aplicar, sistematizar, analizar, decidir y
comunicar. Puede considerar dimensiones cognitiva, socioemocional y psicomotriz; no califica ni diagnostica clínicamente.
80. En Proyecto, Prototipar y Probar/Evaluar reciben indicadores oficiales del módulo vinculados por la
persona docente. Los registros `teacher-authored` de planes anteriores se preservan como texto histórico.
81. Si la metodología curricular es APD, esta puede coordinar currículo y Proyecto como una ruta común;
si es otra, PIA exige puentes explícitos con Pensamiento de Diseño como ruta del Proyecto.
82. PIA 1.6.10 conserva `schemaVersion: 6`. El diagnóstico, las sugerencias evaluativas y la revisión de
respuestas de IA deben migrarse y persistir sin alterar semanas, currículo ni textos históricos.
83. El apoyo diagnóstico distingue modo asesor y modo docente. En asesoría no puede inventar hallazgos;
en aplicación docente solo utiliza resultados generales aportados y nunca almacena datos personales.
84. Cognoscitiva, socioafectiva y psicomotora son áreas de valoración integrables, no tres pruebas ni
etapas consecutivas. La propuesta diagnóstica mantiene un máximo de dos lecciones.
85. Los indicadores del nivel seleccionado describen el nuevo aprendizaje. Los antecedentes solo se
exploran como hipótesis diagnósticas y los alcances posteriores nunca se trasladan al semestre actual.
86. Las ventanas evaluativas son orientación editable. Deben poder confirmarse, modificarse o descartarse;
solo las confirmadas llegan al prompt y ninguna escribe automáticamente una semana o calificación.
87. Las recomendaciones de tareas, prueba de ejecución y Proyecto deben respetar las reglas vigentes,
el calendario institucional, la evidencia y el criterio docente, sin dividir porcentajes ni duplicar evidencias.
88. La revisión de una respuesta de IA es local, determinista y orientadora. Guarda el texto aparte,
no lo incorpora al planeamiento, no certifica alineación y no sustituye la revisión profesional.
89. PIA 1.7.x y su Mapa de Trayectoria continúan como proyecto independiente; PIA 1.6.13 no copia sus
 expedientes, analíticas, persistencia, importaciones ni contratos.
90. El selector de lecciones diagnósticas permanece en Marco temporal. La acción para preparar el
diagnóstico se ubica después de Saberes y antes de Proyecto/evaluación; moverla no modifica los datos.
91. Abrir el apoyo diagnóstico requiere ciclo, nivel, al menos un módulo, un área, un saber conceptual
y una o dos lecciones. El diagnóstico sigue siendo opcional y nunca bloquea el prompt semestral.
92. Las ayudas contextuales proceden de un catálogo único, distinguen currículo del PNFT de funciones
de PIA y no pueden modificar ni persistir en el plan, los prompts o las exportaciones.
93. Una ayuda contextual debe funcionar con puntero, foco, clic y toque; solo una permanece visible,
se cierra con clic externo o `Esc`, conserva asociación accesible y queda fuera de impresión.
94. La acción “Explorar trayectoria curricular” requiere ciclo, nivel, al menos un módulo y un área con
saberes disponibles; se ubica debajo de la cobertura. Es una vista informativa y efímera, no un selector
o editor curricular.
95. AHORA puede consultar todos los saberes de los módulos y áreas seleccionados o filtrar solo los que
forman parte de la proyección. Conserva módulo, área, indicador literal y RdA. ANTES y DESPUÉS consultan
la referencia explícita más cercana de la misma familia sin trasladarla al planeamiento.
96. Los estados distinguen desarrollo documentado, presencia conceptual sin indicador directo,
fortalecimiento expresamente respaldado, ausencia de registro curricular y `not-applicable`. Una celda
vacía produce `no-curricular-record`; ningún estado genera indicadores.
97. El prompt semestral audita el tiempo después de construir la propuesta y no concluye viabilidad por
 conteo aislado. Debe usar una de las tres conclusiones definidas en SPEC y fundamentarla concretamente.
98. Los identificadores técnicos del Proyecto permanecen en inglés para compatibilidad, pero nunca se
 presentan sin localizar a la persona usuaria; `development` se muestra como “Etapa de desarrollo”.
99. Trayectoria y auditoría temporal no cambian `schemaVersion: 6`; la ventana no forma parte del JSON,
 autoguardado, PDF, Word ni versión portable guardada, aunque sí funciona dentro del HTML portable.
100. Los dos Excel fuente mantienen las huellas registradas en `curricular-progression.js`. Las guías
 docentes confirman indicadores y alcance; no se completan vacíos mediante inferencias.
101. La trayectoria dispone de vista de tarjetas y tabla comparativa, filtros por módulo, área y alcance,
encabezado contextual y fuente visible. Los filtros modifican solo la consulta y nunca el planeamiento.
102. Los íconos de áreas y metodologías proceden del recurso gráfico PNFT aportado, se integran localmente
en el HTML portable y siempre se acompañan de texto para no depender exclusivamente del color.
103. El diagnóstico inicia con cero lecciones y `diagnostic.enabled = false`. Solo el interruptor expreso
“Incluir las decisiones del diagnóstico en el prompt semestral” permite añadir su bloque al prompt.
104. “Reiniciar diagnóstico” borra únicamente configuración, resultados y prompt diagnósticos, y devuelve
las lecciones diagnósticas a cero; nunca altera módulos, saberes, semanas ni la proyección.
105. “Durante todo el periodo” no fija una frecuencia semanal de evaluación. La persona docente determina
la cantidad de observaciones. El campo se denomina “Observación o decisión docente” y no representa nota.
106. La experiencia 1.6.14 “Explorar un ejemplo de planeamiento” es formativa, local e independiente. No constituye un planeamiento obligatorio, no certifica competencia y nunca sustituye el criterio docente.
107. El recorrido contiene siete momentos flexibles. Sus números indican navegación y no grados, secuencia obligatoria o nivel de dominio.
108. Todo contenido del recorrido se rotula como referente oficial, ejemplo formativo o decisión docente. Los escenarios, actividades y tiempos ilustrativos no pueden presentarse como disposición oficial.
109. Los laboratorios ABJ, ABR y APD consultan las fuentes metodológicas aportadas y nunca modifican los catálogos curriculares.
110. La experiencia puede consultar `PNFT_DATA`, `RDA_POR_CICLO`, Preescolar, trayectoria y Proyecto solo para mostrar referencias. No accede a `state`, `semanas`, prompts, archivos ni exportadores del plan.
111. El avance formativo usa únicamente `pia.learning.example.v1`; no forma parte del esquema JSON v6, autoguardado del plan, PDF, Word ni contenido transitorio de la descarga portable.
112. Los eventos de la experiencia deben detenerse antes de los controladores generales que llaman a `markDirty`. Salir o reiniciar conserva el planeamiento.
113. La experiencia mantiene navegación con toque y teclado, foco visible, cierre con `Esc`, preferencia de movimiento reducido y diseño adaptable.
114. Antes de publicar 1.6.14 se requiere una prueba humana real en Chrome o Edge de escritorio y móvil para revisar legibilidad, desplazamiento, focos, diálogos y regreso a PIA. Una simulación DOM no sustituye esta validación visual.
115. Un perfil de evaluación seleccionado automáticamente es referencia, no confirmación. Ventanas evaluativas, Proyecto y prompt semestral requieren confirmación docente explícita del perfil aplicable.
116. Proyectar ambos módulos exige una confirmación independiente de que el marco temporal cubre los dos periodos. Esta confirmación no altera los filtros semanales ni elimina selecciones históricas.
117. El presupuesto temporal neto descuenta únicamente cantidades declaradas: diagnóstico, lecciones sin desarrollo curricular y reserva de aplicación/realimentación. Un texto de excepciones no autoriza inferir cantidades.
118. La auditoría temporal solicita balance de minutos netos, asignados y diferencia. PIA no convierte profundidad en minutos oficiales ni certifica viabilidad pedagógica automáticamente.
119. La revisión de respuestas es una comprobación técnica de coincidencias y estructura. Nunca puede rotularse como validación curricular, pedagógica, de aprendizaje o de promoción.
120. Las pruebas de catálogo deben recorrer los 235 indicadores de las 20 combinaciones y los catálogos efectivamente consumidos por Preescolar.
121. PIA 1.7.0 se desarrolla en una copia independiente de 1.6.15. La línea 1.6.15, sus distribuciones, huellas y evidencias permanecen inalteradas.
122. La Ruta hacia el RdA separa `structural-link` de `validated-contribution`. Compartir ciclo y área permite mostrar un vínculo estructural, pero nunca afirmar una contribución pedagógica validada.
123. Toda correspondencia validada requiere indicador y RdA literales, fuente, localizador, versión, autoridad revisora y fecha. Una relación incompleta debe fallar en pruebas y mostrarse como pendiente.
124. Los RdA se conservan completos. No se crean facetas, paráfrasis, porcentajes, pesos, barras de dominio, semáforos ni estados de “RdA alcanzado”.
125. La Ruta es derivada, efímera y de solo lectura; conserva `schemaVersion: 6` y queda fuera de semanas, prompts, diagnóstico, Proyecto, JSON, autoguardado, PDF y Word.
126. Solo AHORA identifica el currículo vigente. ANTES orienta una posible exploración diagnóstica y DESPUÉS informa continuidad; ninguno se incorpora automáticamente al plan.
127. Preescolar mantiene el itinerario activo sin mezclar Básico requerido y Óptimo. Un área ausente o un RdA “No aplica” no genera ruta activa, deuda ni alerta.
128. `area-absent` se distingue de `no-curricular-record`. El primero indica que el área no existe en la combinación; el segundo que la matriz no documenta abordaje de esa familia en el nivel.
129. Presencia conceptual y fortalecimiento no evaluable requieren fuente expresa. La repetición del nombre o una celda vacía nunca permiten inferir esos estados.
130. El cumplimiento del RdA solo puede valorarse mediante evidencias acumuladas y criterio profesional docente. PIA muestra trazabilidad curricular; no certifica aprendizaje ni promoción.
131. La experiencia formativa vive dentro de `.container`; nunca se aplica `inert` o `aria-hidden` a un ancestro que contenga la propia experiencia. Se aíslan únicamente sus hermanos o, si se reubica fuera, el contenedor del plan.
132. El cierre de la experiencia restaura exactamente los estados previos de `inert`, `aria-hidden` y foco. No se eliminan atributos preexistentes de accesibilidad.
133. DUA, apoyo de acceso, apoyo curricular no significativo y adecuación significativa o PEI aprobada son categorías distintas. PIA no convierte una selección de interfaz en aprobación institucional.
134. PIA no interpreta, redacta ni almacena una PEI individual. Solo admite orientaciones generales ya autorizadas, sin nombres, diagnósticos clínicos, expedientes ni datos sensibles.
135. Los apoyos DUA orientan representación, acción y expresión, participación, secuenciación, ritmo/tiempo y recursos accesibles; nunca reducen automáticamente el currículo.
136. El perfil Vocacional debe solicitar coordinación pedagógica, diagnóstico y criterio de selección/dosificación. La ausencia de confirmación permanece visible y no se completa mediante IA.
137. El catálogo curricular vigente llega hasta 9.º. PIA no inventa saberes, indicadores, RdA o perfiles para 10.º, 11.º o 12.º.
138. Una referencia de otro nivel conserva procedencia y literalidad, pero no se convierte automáticamente en currículo vigente, PEI o indicador evaluable.
139. Las orientaciones oficiales PNFT 2026 gobiernan el comportamiento. Videos, ejemplos y documentos explicativos anteriores sirven para comprender, no para autorizar cambios curriculares.
140. Toda ampliación inclusiva debe conservar `schemaVersion: 6`, funcionamiento local, privacidad, currículo protegido y compatibilidad con planes históricos.
