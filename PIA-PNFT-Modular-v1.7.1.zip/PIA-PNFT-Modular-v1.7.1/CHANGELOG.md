# Registro de cambios

## 1.7.1

- Corrige el congelamiento de “Explorar un ejemplo de planeamiento” causado por aplicar `inert` al contenedor ancestro de la propia experiencia.
- Aísla únicamente los elementos hermanos del plan y restaura sus estados de accesibilidad al cerrar.
- Añade una guía opcional para DUA, acceso, apoyos no significativos y adecuación significativa o PEI previamente aprobada.
- Incorpora apoyos estructurados de mediación y coordinación institucional sin datos personales.
- Amplía el perfil III Ciclo y Ciclo Diversificado Vocacional — Plan Nacional con coordinación, diagnóstico, selección/dosificación de saberes y tiempo semanal.
- Explicita que PIA llega curricularmente hasta 9.º y no genera contenido oficial inexistente para 10.º–12.º.
- Conserva `schemaVersion: 6`, currículo protegido, Ruta hacia el RdA, operación local y compatibilidad histórica.

## 1.7.0

- Incorpora “Explorar ruta hacia el RdA” como consulta curricular modular de solo lectura.
- Construye una ruta estructural desde Preescolar hasta 9.º usando familias, niveles, módulos, áreas, saberes, indicadores literales y RdA por ciclo.
- Separa el vínculo estructural de las correspondencias pedagógicas aprobadas en un catálogo independiente.
- Mantiene toda relación no aprobada como pendiente de validación curricular y prohíbe completarla mediante IA.
- Distingue desarrollo explícito, presencia o fortalecimiento con respaldo, ausencia de registro, no aplicable y área ausente.
- Mantiene el nivel actual como único currículo planificable; antecedentes y continuidades no pasan a semanas, prompts ni exportaciones.
- Conserva `schemaVersion: 6`, currículo protegido, operación local y compatibilidad con 1.6.15.

## 1.6.15

- Exige confirmación docente explícita del perfil de evaluación antes de generar referencias evaluativas o el prompt semestral.
- Condiciona Proyecto a un perfil confirmado y conserva sus datos cuando el perfil está pendiente.
- Añade confirmación especial para proyectar ambos módulos dentro de un mismo marco temporal.
- Calcula presupuesto neto en lecciones y minutos, descontando diagnóstico, excepciones cuantificadas y reserva de evaluación/realimentación.
- Solicita a la IA un balance numérico entre minutos netos, asignados y diferencia.
- Renombra y delimita la revisión de IA como comprobación técnica, con trazabilidad de saberes, RdA, indicadores y balance temporal.
- Corrige la comprobación de saberes procedimentales y actitudinales de Preescolar.
- Añade prueba exhaustiva de 235 indicadores y 20 combinaciones nivel–módulo.
- Mantiene currículo, esquema JSON v6, funcionamiento local, Proyecto y exportaciones.

## 1.6.14

- La portada sustituye “Aprender metodologías del PNFT” por **“Explorar un ejemplo de planeamiento”**.
- Incorpora una experiencia formativa local, independiente y progresiva con siete momentos: horizonte, punto de partida, ruta curricular, metodología, proyección, semana y revisión.
- Añade laboratorios de decisiones para ABJ, ABR y APD, fundamentados en los documentos metodológicos aportados.
- Integra ejemplos diferenciados para Preescolar, I, II y III Ciclo, además de una profundización sobre currículo y Proyecto en secundaria.
- Consulta en modo de solo lectura los catálogos existentes de currículo, RdA, trayectoria, Preescolar y Proyecto; el recorrido no crea ni modifica referentes oficiales.
- Distingue de forma permanente referente oficial, ejemplo formativo y decisión docente.
- Explica la relación entre semanas proyectadas y lecciones planificadas, el propósito de los prompts y la diferencia entre autoguardado, JSON y exportaciones.
- El progreso formativo se guarda únicamente en `pia.learning.example.v1`; queda fuera del JSON del plan, autoguardado del plan, PDF y Word.
- Los controles del recorrido quedan aislados de los eventos de edición del planeamiento y la descarga portable elimina cualquier contenido transitorio del recorrido.
- Se agregan navegación flexible, foco visible, salida con `Esc`, reducción de movimiento, diseño adaptable y lenguaje que evita presentar el recorrido como certificación o receta.

## 1.6.13

- Corrección curricular: las celdas vacías se registran como `no-curricular-record`; no se interpretan
  como fortalecimiento, enseñanza, dominio ni evaluación. `N/A` continúa como no aplicable.
- Estados preparados para presencia conceptual y fortalecimiento sin evaluación únicamente cuando una
  fuente curricular los respalde expresamente.
- Trayectoria con tarjetas y tabla comparativa, filtros por módulo, área y alcance, encabezado contextual,
  RdA y fuente visible por guía, nivel, módulo y área.
- Íconos PNFT aportados incorporados localmente al HTML autónomo; texto y color se mantienen como señales
  complementarias de accesibilidad.
- Trayectoria, familias y alcances anteriores/posteriores retirados del prompt semestral.
- Diagnóstico inicialmente desactivado y con cero lecciones; incorporación al prompt mediante selección
  expresa y acción independiente para reiniciarlo sin alterar módulos, saberes, semanas o proyección.
- “Nota” sustituida por “Observación o decisión docente”; aclaración de que “Durante todo el periodo” no
  impone evaluación semanal ni una cantidad fija de observaciones.
- Auditoría temporal posterior y localización “Etapa de desarrollo → Prototipar” preservadas.
- JSON v6, currículo oficial, exportaciones y funcionamiento portable preservados.
- 132 pruebas automatizadas aprobadas.

## 1.6.12

- Vista local **Trayectoria curricular del PNFT** con filtros por área, tarjetas de familia y lectura
  ANTES–AHORA–DESPUÉS basada en las 38 familias de la matriz oficial.
- Indicadores literales del PNFT en los niveles explícitos y diferenciación visible entre fortalecimiento
  sin evaluación directa y ausencia del saber o área en la trayectoria.
- AHORA limitado a los saberes efectivamente seleccionados; la vista no modifica estado ni exportaciones.
- Auditoría temporal posterior incorporada al prompt semestral con tres conclusiones controladas y
  prohibición de juzgar la viabilidad mediante un conteo aislado de indicadores y bloques.
- Presentación localizada **Etapa de desarrollo → Prototipar** en el prompt de Proyecto.
- JSON v6, currículo, semanas, diagnóstico, Proyecto, PDF, Word y portable preservados.
- 127 pruebas automatizadas aprobadas; revisión humana final en Edge/Chrome pendiente.

## 1.6.11

- Acción **Preparar evaluación diagnóstica** reubicada después de Saberes para la proyección.
- Selector de 0–2 lecciones conservado en Marco temporal y diagnóstico mantenido como función opcional.
- Habilitación del acceso diagnóstico únicamente con ciclo, nivel, módulo, área, saber conceptual y
  una o dos lecciones seleccionadas; la proyección semestral no queda condicionada por esta habilitación.
- Glosario contextual centralizado para conceptos curriculares, pedagógicos, normativos y funciones de PIA.
- Ayudas accesibles mediante puntero, foco, clic o toque; cierre por clic externo, cambio de ayuda o `Esc`.
- Posicionamiento responsivo, una sola ayuda visible y exclusión expresa de impresión y exportaciones.
- JSON v6, currículo del PNFT, prompts, Proyecto, semanas, autoguardado, PDF, Word y portable preservados.
- Validación automatizada final: 120/120 pruebas aprobadas.

## 1.6.10

- Flujo diagnóstico persistente con modos asesor/docente, máximo dos lecciones, áreas de valoración
  integradas y registro de decisiones generales sin datos personales.
- Separación explícita entre antecedentes por explorar, currículo actual obligatorio y alcances posteriores.
- Ventanas evaluativas sugeridas para trabajo cotidiano, tareas, prueba de ejecución y Proyecto, con
  estados sugerida/confirmada/descartada, semana editable y nota docente.
- Reglas 2026 para tareas y prueba de ejecución incorporadas como orientación; ninguna sugerencia
  escribe el planeamiento ni sustituye el calendario institucional.
- Momentos confirmados incorporados al prompt semestral y al afinamiento de la semana aplicable.
- Revisión local de respuestas de IA con comprobaciones de literalidad, estructura, selección curricular,
  alcance temporal y afirmaciones indebidas de logro; almacenamiento separado del planeamiento oficial.
- Persistencia de diagnóstico, sugerencias, respuestas y reportes mediante JSON v6, autoguardado y portable.
- Currículo del PNFT, Preescolar, Proyecto, juego metodológico, Word, PDF y línea separada 1.7.x preservados.

## 1.6.9

- Juego metodológico local desde la portada con siete misiones y realimentación inmediata.
- Ruta propia para Preescolar: Básico/Óptimo, juego, exploración, criterios formativos, RdA y perfil.
- Escenarios de secundaria con una ruta APD integrada o metodología curricular coordinada con APD del Proyecto.
- Activación explícita de Contextualización y DUA; sus datos se omiten del prompt cuando no se activa.
- Prompt diagnóstico guiado por proceso y tres dimensiones, dentro del máximo de dos lecciones.
- Ficha condicional de fundamentación para Otra metodología.
- Prompt semanal sustituido funcionalmente por Afinar semana con IA.
- Prototipar y Probar/Evaluar vinculados con indicadores oficiales del módulo; compatibilidad histórica preservada.
- Currículo del PNFT, JSON v6, autoguardado, PDF, Word y portable conservados.

## 1.6.8

- Afinamiento del 7 de setiembre: diagnóstico nuevamente limitado a 0–2 lecciones, conforme a la
  decisión pedagógica vigente y sin borrar contenido semanal.
- Prompt semestral condicional: metodología requerida; fechas, ejes, contexto, condiciones y referencias
  se omiten cuando no fueron aportados; los valores neutrales no generan texto “pendiente”.
- Ruta curricular explícita por área, saber, indicador de logro del PNFT y RdA, con numeración continua
  de las tareas realmente aplicables y Proyecto solo en el perfil correspondiente.
- Etiquetas de Contextualización y DUA afinadas en lenguaje docente, grupal y no estigmatizante.
- Portada local MEP–PNFT–PIA con inicio, carga de JSON, preferencia de omisión por dispositivo y
  retorno seguro al inicio; excluida de PDF y Word.
- Identidad institucional opcional limitada a escudo y lema, alineada a la izquierda y sin duplicar
  el nombre del centro educativo.
- Contextualización y DUA enriquecida con perfil de implementación, condiciones complementarias,
  escenario tecnológico y punto de partida grupal, sin recopilar datos personales.
- Perfiles contextuales para Regular, Aula Edad, aulas integradas, Vocacional y EPJA, separados de los
  perfiles de evaluación y sujetos a validación institucional cuando no exista una regla confirmada.
- Indicadores de referencia de otros niveles seleccionables únicamente desde el currículo autorizado
  del PNFT; literalidad, procedencia, motivo y contextualización docente conservados por separado.
- Incorporación semanal explícita y reversible de referencias, con persistencia en JSON/autoguardado y
  presencia en las columnas oficiales de PDF/Word cuando están seleccionadas.
- Prompts General, Semestral y Semanal con borradores independientes, guardado explícito, estado visible,
  actualización desde PIA y restablecimiento con confirmación antes de sobrescribir.
- Contrato contextual para DUA, alternativas equivalentes sin conexión, diferenciación de fuentes y
  decisiones que requieren validación institucional.
- Barra de formato contextual 1.6.7, currículo, Preescolar, Proyecto, progresión interna, versión portable
  y compatibilidad con planes anteriores preservados.
- Validación automatizada final: 105/105 pruebas; revisión humana multinavegador y Word recomendada antes
  del despliegue institucional.

## 1.6.7

- Apertura contextual de la barra al seleccionar texto en Mediación o Evaluación.
- Conservación del rango seleccionado para aplicar varios formatos sin regresar al encabezado.
- Identificación visible del campo destinatario y cierre mediante botón, clic externo o tecla `Esc`.
- Acciones prioritarias compactas y opciones secundarias plegadas para no saturar los campos.
- Sangría, limpieza de selección, subtítulos Inicio–Desarrollo–Cierre, pegado limpio opcional y
  vínculos HTTPS con validación docente.
- Indicadores de logro del currículo de FT protegidos y excluidos de los comandos de formato.
- Compatibilidad preservada con JSON v6, autoguardado, Word, PDF y versión portable.
- 96 pruebas automatizadas aprobadas.

## 1.6.6

- Trayectoria curricular detallada conservada al 100% como servicio interno de solo lectura.
- Sustitución del bloque visible AHORA–ANTES–DESPUÉS por una única orientación breve para la IA.
- Familias de los saberes seleccionados incorporadas dinámicamente en esa orientación.
- Salvaguardas de nivel actual, diagnóstico de antecedentes, refuerzos sin evaluación y alcances posteriores.
- Contrato lúdico, curricular y formativo de Preescolar 1.6.5 preservado sin cambios.
- Currículo oficial, JSON v6, semanas, Proyecto y exportaciones sin alteraciones.
- 93 pruebas automatizadas aprobadas.

## 1.6.5

- Competencias específicas y perfil de salida oficiales de Preescolar incorporados al contexto del prompt.
- Contrato de Preescolar con evaluación diagnóstica/formativa y experiencias lúdicas completas por semana.
- Bloque de 80 minutos compatible con ejecución continua o dos lecciones articuladas de 40 minutos.
- Integración por pertinencia pedagógica, sin imponer cantidades mínimas semanales.
- Proyecto omitido en Preescolar, I y II Ciclo y condicionado correctamente en III Ciclo.
- 92 pruebas automatizadas aprobadas.

## 1.6.4

- Trayectoria semestral presentada como AHORA, ANTES y DESPUÉS.
- Eliminación del ruido técnico: estados `N/A`, separadores `/` y mensajes sin niveles intermedios.
- Referencias no continuas diferenciadas de prerrequisitos directos.
- Alcance actual limitado a los saberes seleccionados, sin expansión automática por familia.
- Reglas explícitas para diagnóstico, continuidad posterior y protección del nivel vigente.
- 88 pruebas automatizadas aprobadas.

## 1.6.3

- Etiquetas de antecedentes reformuladas para evitar inferir aprendizaje previo.
- Mandato explícito de planear íntegramente el nivel seleccionado.
- Prerrequisitos sujetos a diagnóstico y apoyos contextualizados.
- Niveles intermedios previos ordenados cronológicamente.
- Cierre de 9.º descrito como límite del catálogo, no como final de la trayectoria educativa.
- 86 pruebas automatizadas aprobadas.

## 1.6.2

> Historial: la semántica de vacíos y el envío de la trayectoria al prompt quedaron corregidos y
> reemplazados en 1.6.13.

- Catálogo relacional interno con 38 familias de progresión, 10 niveles y las cuatro áreas del PNFT.
- Correspondencia exacta de los 235 registros curriculares actuales sin modificar textos oficiales.
- Contexto de fundamento previo, alcance actual y proyección posterior añadido entonces al prompt
  semestral; retirado del prompt en 1.6.13 y trasladado a consulta local.
- Regla aplicada entonces: celda vacía como refuerzo conceptual; corregida en 1.6.13 porque el vacío
  solo acredita ausencia de registro curricular.
- Salvaguardas contra indicadores inventados, evaluaciones inexistentes y afirmaciones de dominio o RdA alcanzado.
- Importador técnico reproducible desde los dos archivos Excel de referencia; sin carga en la interfaz.
- JSON v6, PDF, Word, portable y funcionamiento de 1.6.1 preservados.
- 85 pruebas automatizadas aprobadas.

## 1.6.1

- Filtro curricular independiente por semana para Módulo 1, Módulo 2 o ambos.
- Valor inicial coherente con el semestre para semanas nuevas; compatibilidad conservadora para planes anteriores.
- Áreas, RdA, saberes e indicadores semanales limitados al alcance curricular seleccionado.
- Referencias `saberRefs` con módulo, área y nombre para resolver indicadores sin ambigüedad.
- Avisos de selecciones conservadas fuera del filtro y prohibición de borrado silencioso.
- Panel semanal plegable para áreas, RdA y saberes conceptuales.
- Regeneración semestral sensible a fechas con protección del prompt anterior.
- Mejoras visuales recibidas y verificadas: Contextualización/DUA y soporte desplegables, encabezado de
  Proyección simplificado, orden curricular ajustado y conteos internos de RdA retirados de la interfaz.
- 80 pruebas automatizadas aprobadas.

## 1.6.0

- Selección semestral explícita de Prototipar y Probar/Evaluar.
- Un indicador de logro y dos indicadores de evaluación docentes por cada fase posterior, sin atribución oficial.
- Inicialización segura de los campos semanales desde la proyección y preservación de ediciones por semana.
- Prompt semestral estructurado por etapa y fase, distinguiendo texto oficial de texto docente.
- Persistencia JSON v6 de prompts general, semestral y semanales editados.
- Proyección plegable sin borrado de estado.
- Áreas Word ampliadas y blancas para Reflexiones y Observaciones.
- 75 pruebas automatizadas aprobadas.

## 1.5.2

- Indicadores de logro del Proyecto exportados en la columna oficial de logro de PDF y Word.
- Indicadores de evaluación del Proyecto exportados en la columna oficial de evaluación.
- Prioridad de contextualización docente con respaldo del texto oficial guardado.
- Exclusión de indicadores desmarcados únicamente en la salida, sin pérdida en JSON.
- Pruebas de selección efectiva, texto original/editado, ida y vuelta JSON y composición Word/PDF.
- 68 pruebas automatizadas aprobadas.

## 1.5.1

- JSON v5 con Proyecto persistente por semana y migración de planes anteriores.
- Modalidades curricular, mixta e integrada mediante Proyecto.
- Texto oficial inmutable y contextualización docente conservada por fase.
- Indicadores del Proyecto incorporados en las columnas oficiales de logro y evaluación.
- Instrumentos de evaluación como catálogo interno del prompt, recomendados después de la evidencia.
- Eliminación de hitos, porcentajes y estados automáticos del Proyecto.
- Contratos de prompts ampliados para articular currículo, Proyecto, evidencias e instrumentos.
- 64 pruebas automatizadas aprobadas.

## 1.5.0

- Catálogos versionados de instrumentos y componente Proyecto.
- Indicadores oficiales iniciales de Empatizar, Definir e Idear.
- Contratos estrictos de literalidad, integración de saberes y mediaciones desarrolladas.

## 1.4.1

- Itinerario de preescolar oculto y deshabilitado fuera de Materno Infantil/Transición y `0°`.

## 1.4.0

- Catálogo local de centros sin registros `0000` ni datos personales.
- Rutas oficiales separadas de Preescolar Básico requerido y Óptimo.
- Metodologías activas tratadas como andamiaje continuo en el prompt semestral.

## 1.3.0

- Flujo visual reorganizado según el recorrido docente aprobado.
- Identidad opcional limitada a escudo y lema; el nombre oficial permanece en Centro educativo.
- Contextualización y DUA compactos antes de la proyección semestral.
- Selección por módulo(s), áreas y saberes conceptuales, procedimentales y actitudinales.
- Diagnóstico máximo de dos lecciones, fases editables y distribución flexible por semanas.
- Perfiles de evaluación por ciclo/modalidad con fuente y reglas visibles.
- Prompt semestral ampliado y espacio local para revisar/aprobar la respuesta sin aplicación automática.
- Herramientas de formato contextual y protección de indicadores de logro oficiales.
- Esquema JSON v3 con migración compatible desde v1/v2.
- Puente backend y analítica continúan inactivos y sin red.
- 23 pruebas automatizadas aprobadas.

## 1.2.1-modular.1

- Proyección promovida a etapa principal del flujo, inmediatamente después de Metodología activa.
- Interfaz guiada en cuatro pasos con resumen en vivo y orientación contextual.
- Tarjetas seleccionables para módulos y áreas; buscador y acciones masivas para saberes.
- Distribución adaptable a pantallas pequeñas y foco de teclado reforzado.
- Herramientas de formato, recuperación y reutilización separadas como apoyo secundario.
- Núcleo curricular, guardado/carga, semanas, PDF, Word y portable preservados.

## 1.2.0-modular.1

- Capa avanzada reversible de proyección semestral.
- JSON v2, autoguardado, recuperación e historial local.
- Identidad institucional, contexto/DUA y formato offline.
- Revisión, diagnóstico, estrategias y revisión local de respuesta IA.
- Cobertura, prompt semestral y extensiones de PDF, Word y portable.
- Puente backend/analítica deliberadamente inactivo.
- Datos curriculares y funciones validadas de PIA 1.1.1 conservados.
