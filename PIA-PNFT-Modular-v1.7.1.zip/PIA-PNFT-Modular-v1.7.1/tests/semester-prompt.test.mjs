import assert from 'node:assert/strict';
import test from 'node:test';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..');
const evaluation=await readFile(resolve(root,'src/data/evaluation-profiles.js'),'utf8');
const promptSource=await readFile(resolve(root,'src/prompts/semester-projection-prompt.js'),'utf8');
const context=vm.createContext({result:null});
vm.runInContext(`${evaluation}\n${promptSource}\nresult={profiles:PIAEvaluationProfiles,prompt:PIASemesterPrompt};`,context);

test('el prompt semestral exige matriz, detalle, ruta curricular, DUA y evaluación dinámica sin trasladar la trayectoria',()=>{
  const input={level:'2°',cycle:'I Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:0,startDate:'2026-02-02',endDate:'2026-07-03',exceptions:'vacaciones',modules:['Módulo 1'],areas:['Área A'],methodology:'ABJ',axes:['Pensamiento computacional'],context:'grupo',resources:'sin conexión',dua:'múltiples formas',rdas:['RdA oficial'],concepts:[{name:'Dato',module:'Módulo 1',area:'Área A'}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador oficial'],evaluationProfile:context.result.profiles.profiles.primary};
  const text=context.result.prompt.build(input);
  for(const expected of ['MATRIZ SEMESTRAL','Desarrollo detallado','área → saber conceptual → indicador de logro oficial del PNFT → RdA','alternativa desconectada','dos indicadores de evaluación','65% trabajo cotidiano','no sustituye el planeamiento didáctico oficial','integración','profundidad expresada por sus indicadores','no modifique ni invente componentes del currículo oficial del PNFT']) assert.match(text,new RegExp(expected,'i'));
  assert.doesNotMatch(text,/ORIENTACIÓN PARA LA IA|TRAYECTORIA CURRICULAR PARA ORIENTAR|AHORA —|ANTES —|DESPUÉS —|REGLAS PARA UTILIZAR LA TRAYECTORIA|Evaluación diagnóstica pedagógica/);
  assert.doesNotMatch(text,/persona docente:\s*[^\n]+/i);
});

test('el punto 4 mantiene la metodología como andamiaje continuo y no la reinicia semanalmente',()=>{
  const base={level:'5°',cycle:'II Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Área A'],axes:['Pensamiento computacional'],context:'grupo',resources:'equipos',dua:'apoyos',rdas:['RdA'],concepts:[{name:'Dato',module:'Módulo 1',area:'Área A'}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador'],evaluationProfile:context.result.profiles.profiles.primary};
  const abr=context.result.prompt.build({...base,methodology:'Aprendizaje basado en retos (ABR)'});
  for(const expected of ['andamiaje continuo durante todo el semestre','No reinicie sus etapas','retome lo trabajado anteriormente','cómo acompaña y retroalimenta la persona docente','cómo la experiencia prepara la semana siguiente','gran idea','pregunta esencial','solución programada','no formule un reto nuevo']) assert.match(abr,new RegExp(expected,'i'));
  const abj=context.result.prompt.build({...base,methodology:'Aprendizaje basado en juegos (ABJ)'});
  for(const expected of ['experiencias lúdicas','pueden variar los juegos','conservar el hilo de aprendizaje','evaluación formativa']) assert.match(abj,new RegExp(expected,'i'));
  const apd=context.result.prompt.build({...base,methodology:'Aprendizaje Pensamiento por Diseño (APD)'});
  for(const expected of ['Empatizar, Definir e Idear','Prototipar','Probar y Evaluar','no repita todas las etapas']) assert.match(apd,new RegExp(expected,'i'));
});

test('la evaluación se recomienda después de la evidencia y Proyecto se integra sin hitos',()=>{
  const instrument={label:'Lista de cotejo',need:'Comprobar acciones',recommendedUse:'Procedimientos breves',evaluationFunctions:['formativa'],technicalRequirements:['Definir indicadores']};
  const input={level:'7°',cycle:'III Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Programación'],methodology:'APD',axes:['Pensamiento computacional'],context:'grupo',resources:'equipos',dua:'apoyos',rdas:['RdA'],concepts:[{name:'Dato',module:'Módulo 1',area:'Programación'}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador curricular literal'],evaluationProfile:context.result.profiles.profiles.secondary,evaluationInstruments:[instrument],projectPlanning:{enabled:true,title:'Proyecto',problem:'Problema',beneficiary:'Comunidad',expectedSolution:'Prototipo',indicatorSnapshots:[{text:'Indicador Proyecto literal',evaluationIndicators:[{text:'Indicador evaluación literal'}]}]}};
  const text=context.result.prompt.build(input);
  for(const expected of ['Diseñe primero las actividades y evidencias','uno o varios instrumentos','misma matriz','mixta','40 min currículo','Indicador Proyecto literal','Indicador evaluación literal']) assert.match(text,new RegExp(expected,'i'));
  assert.doesNotMatch(text,/hitos completados|avance operativo/i);
});

test('Preescolar usa un contrato lúdico y formativo sin ruido de Proyecto o evaluación sumativa',()=>{
  const instruments=[
    {id:'checklist',label:'Lista de cotejo',need:'Observar acciones',recommendedUse:'Exploración guiada',evaluationFunctions:['diagnóstica','formativa','sumativa'],technicalRequirements:['Definir conductas observables']},
    {id:'performance-test',label:'Prueba de ejecución',need:'Calificar ejecución',recommendedUse:'Prueba',evaluationFunctions:['sumativa'],technicalRequirements:['Definir puntuación']}
  ];
  const input={level:'0°',cycle:'Materno Infantil/Transición',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Programación y Algoritmos'],methodology:'Aprendizaje basado en juegos (ABJ)',axes:['Pensamiento computacional'],context:'grupo',resources:'equipos',dua:'apoyos',rdas:['RdA oficial'],concepts:[{name:'Evento',module:'Módulo 1',area:'Programación y Algoritmos'}],procedural:['Comunica'],attitudinal:['Aprender del error'],indicators:['Indicador oficial'],curricularProgression:'AHORA — PLANIFIQUE EN 0°',evaluationProfile:context.result.profiles.profiles.preschool,evaluationInstruments:instruments,projectPlanning:{enabled:true,title:'No debe incorporarse'},preschoolFramework:{itinerary:'Módulo 1 - Básico requerido',competencies:[{area:'Programación y Algoritmos',text:'Competencia oficial literal'}],exitProfiles:[{area:'Programación y Algoritmos',statements:['Perfil oficial literal']} ]}};
  const text=context.result.prompt.build(input);
  for(const expected of ['CONTRATO EXCLUSIVO PARA PREESCOLAR','Competencia oficial literal','Perfil oficial literal','inicio, exploración o juego guiado, aplicación y cierre','dos lecciones de 40 minutos','sin distribución porcentual','relación pedagógica auténtica','función diagnóstica o formativa']) assert.match(text,new RegExp(expected,'i'));
  assert.doesNotMatch(text,/Proyecto|sumativ|Prueba de ejecución|modo semanal/i);
});

test('Primaria omite Proyecto y III Ciclo conserva el estado no seleccionado',()=>{
  const base={weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Programación'],methodology:'ABJ',axes:['Pensamiento computacional'],context:'grupo',resources:'equipos',dua:'apoyos',rdas:['RdA'],concepts:[{name:'Dato',module:'Módulo 1',area:'Programación'}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador'],evaluationInstruments:[],projectPlanning:{enabled:false}};
  const primary=context.result.prompt.build({...base,level:'5°',cycle:'II Ciclo',evaluationProfile:context.result.profiles.profiles.primary});
  const secondary=context.result.prompt.build({...base,level:'7°',cycle:'III Ciclo',evaluationProfile:context.result.profiles.profiles.secondary});
  assert.doesNotMatch(primary,/Proyecto|mixta|integrada mediante/i);
  assert.match(secondary,/COMPONENTE PROYECTO[\s\S]*Componente Proyecto no seleccionado/);
  assert.doesNotMatch(secondary,/40 min currículo|modo semanal \(curricular, mixta/i);
});

test('el prompt omite datos opcionales no aportados y conserva numeración continua',()=>{
  const input={level:'5°',cycle:'II Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Área A'],methodology:'ABR',axes:[],rdas:['RdA'],rdaItems:[{area:'Área A',text:'RdA'}],concepts:[{name:'Dato',module:'Módulo 1',area:'Área A',indicators:['Indicador literal']}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador literal'],evaluationProfile:context.result.profiles.profiles.primary,evaluationInstruments:[],contextualizationBlock:'',referenceBlock:''};
  const text=context.result.prompt.build(input);
  assert.doesNotMatch(text,/Periodo editable|^• Ejes transversales:|^CONTEXTUALIZACIÓN Y DUA DECLARADA|^INDICADORES DE REFERENCIA|^CATÁLOGO INTERNO|\bPendiente\b/im);
  assert.match(text,/SABERES CONCEPTUALES E INDICADORES[\s\S]*Área: Área A[\s\S]*Saber conceptual: Dato[\s\S]*Indicador literal[\s\S]*RdA del área: RdA/i);
  const numbers=[...text.matchAll(/^(\d+)\. /gm)].map(match=>Number(match[1])).slice(-12);
  assert.deepEqual(numbers,[1,2,3,4,5,6,7,8,9,10,11,12]);
});

test('contextualización y referencias aparecen solamente cuando fueron aportadas',()=>{
  const base={level:'5°',cycle:'II Ciclo',weeks:22,lessons:44,blockMinutes:80,diagnosisLessons:2,startDate:'',endDate:'',exceptions:'',modules:['Módulo 1'],areas:['Área A'],methodology:'ABR',axes:[],rdas:['RdA'],concepts:[{name:'Dato',module:'Módulo 1',area:'Área A',indicators:['Indicador']}],procedural:['Colabora'],attitudinal:['Aprender del error'],indicators:['Indicador'],evaluationProfile:context.result.profiles.profiles.primary,evaluationInstruments:[]};
  const text=context.result.prompt.build({...base,contextualizationBlock:'\nCONTEXTUALIZACIÓN Y DUA DECLARADA POR LA PERSONA DOCENTE\n• Recursos: equipos compartidos.',referenceBlock:'\nINDICADORES DE REFERENCIA AUTORIZADOS DEL CURRÍCULO DEL PNFT\n1. Indicador de referencia.'});
  assert.match(text,/CONTEXTUALIZACIÓN Y DUA DECLARADA[\s\S]*equipos compartidos/i);
  assert.match(text,/INDICADORES DE REFERENCIA AUTORIZADOS[\s\S]*Indicador de referencia/i);
});
