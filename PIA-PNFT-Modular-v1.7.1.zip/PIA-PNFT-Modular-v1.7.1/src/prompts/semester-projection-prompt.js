        // PIA_SEMESTER_PROMPT_JS_START
        const PIASemesterPrompt = (() => {
            // Las mediaciones deben ser desarrolladas y no actividades escuetas.
            const list = (items, formatter = value => value) => items.length ? items.map((item,index)=>`${index+1}. ${formatter(item)}`).join('\n') : 'Pendiente';
            const hasProjectComponent = profile => Boolean(profile?.components?.some(([name])=>String(name).startsWith('Proyecto')));
            function methodologyGuidance(methodology, { preschool = false } = {}) {
                const value = String(methodology || '').toLocaleUpperCase('es');
                if (value.includes('ABJ') || value.includes('JUEGO')) return preschool
                    ? 'Para ABJ en Preescolar, diseñe cada experiencia semanal con un propósito comprensible y un cierre propio. El juego, cuento, canción, movimiento o dinámica puede iniciar y concluir en la misma semana, mientras el aprendizaje conserva continuidad con las experiencias siguientes. Priorice exploración lúdica, sensorial, concreta y guiada, con realimentación formativa.'
                    : 'Para ABJ, conecte las experiencias lúdicas en una ruta progresiva: pueden variar los juegos o dinámicas, pero deben conservar el hilo de aprendizaje, las normas, la realimentación, los incentivos pedagógicos pertinentes y la evaluación formativa de los resultados.';
                if (value.includes('ABR') || value.includes('RETO')) return 'Para ABR, mantenga el reto como eje articulador y conecte progresivamente la gran idea, la pregunta esencial, la investigación y bitácora, los saberes necesarios, la solución programada y el cierre reflexivo; no formule un reto nuevo y desvinculado cada semana.';
                if (value.includes('APD') || value.includes('DESIGN') || value.includes('DISEÑO')) return 'Para APD o Design Thinking, distribuya la etapa inicial (Empatizar, Definir e Idear), la etapa de desarrollo (Prototipar) y la etapa final (Probar y Evaluar) a lo largo del semestre; no repita todas las etapas en cada semana.';
                return 'Mantenga una secuencia metodológica continua, contextualizada y sujeta al criterio profesional docente.';
            }
            function build(input) {
                const evaluation = input.evaluationProfile;
                const evaluationConfirmed=input.evaluationProfileConfirmed===true;
                const isPreschool = evaluation?.id === 'preschool' || input.cycle === 'Materno Infantil/Transición' || input.level === '0°';
                const selectedAxes=Array.isArray(input.axes)?input.axes.filter(Boolean):[];
                const projectApplicable = input.cycle === 'III Ciclo' && hasProjectComponent(evaluation);
                const evaluationText = evaluation ? `${evaluation.label}: ${PIAEvaluationProfiles.describe(evaluation)}` : 'Pendiente de confirmación docente';
                const instruments = (input.evaluationInstruments || []).filter(instrument=>!isPreschool || (instrument.id !== 'performance-test' && instrument.evaluationFunctions.some(value=>['diagnóstica','formativa'].includes(value))));
                const instrumentText = list(instruments, instrument=>{const functions=isPreschool?instrument.evaluationFunctions.filter(value=>['diagnóstica','formativa'].includes(value)):instrument.evaluationFunctions;return `${instrument.label} — necesidad: ${instrument.need}; uso: ${instrument.recommendedUse}; funciones: ${functions.join(', ')}; requisitos: ${instrument.technicalRequirements.join(' | ')}`;});
                const instrumentSection=instruments.length?`\nCATÁLOGO INTERNO DE INSTRUMENTOS PARA RECOMENDACIÓN\n${instrumentText}\n`:'';
                const project = projectApplicable && input.projectPlanning?.enabled ? input.projectPlanning : null;
                const laterPhases=(project?.phaseSnapshots||[]).map(snapshot=>{const indicators=snapshot.record?.achievementIndicators||[],official=indicators.filter(item=>item.sourceType==='official-curriculum'),historical=indicators.filter(item=>item.sourceType==='teacher-authored'),stageName=PIAProjectComponentCatalog.getStage(snapshot.phase?.stageId)?.name||'Etapa pendiente';return `${stageName} → ${snapshot.phase?.name || 'fase pendiente'}\n   Indicadores oficiales del módulo vinculados con la fase:\n${official.length?official.map(item=>`   • ${item.officialText}`).join('\n'):'   • Pendientes de selección docente'}${historical.length?`\n   Texto histórico conservado de versiones anteriores; no presentar como oficial:\n${historical.map(item=>`   • ${item.teacherText||'Sin texto'}`).join('\n')}`:''}`;});
                const usesDesignAsMain=/APD|DESIGN|DISEÑO/i.test(String(input.methodology||''));
                const methodologyCoordination=usesDesignAsMain?'Pensamiento de Diseño organiza la mediación curricular y la ruta del Proyecto. Conserve la diferencia entre currículo, indicadores del Proyecto y componentes de evaluación.':`La metodología curricular principal es ${input.methodology}. Coordínela con Pensamiento de Diseño, que conserva la ruta del componente Proyecto; explicite los puentes entre ambas en las semanas mixtas o integradas.`;
                const projectText = project ? `• Nombre del proyecto: ${project.title || 'Pendiente'}\n• Problema: ${project.problem || 'Pendiente'}\n• Población beneficiaria: ${project.beneficiary || 'Pendiente'}\n• Producto o solución: ${project.expectedSolution || 'Pendiente'}\n• Ruta metodológica protegida del Proyecto: etapa inicial (Empatizar, Definir e Idear), desarrollo (Prototipar) y final (Probar/Evaluar).\n• Coordinación metodológica: ${methodologyCoordination}\n• Indicadores oficiales del Proyecto para la etapa inicial (COPIAR LITERALMENTE):\n${list(project.indicatorSnapshots||[], item=>`${item.text}\n   Indicadores de evaluación oficiales vinculados: ${(item.evaluationIndicators||[]).map(entry=>entry.text).join(' | ') || 'Pendiente de fuente oficial'}`)}\n• Prototipar y Probar/Evaluar — indicadores oficiales del módulo seleccionados por la persona docente:\n${laterPhases.length?laterPhases.join('\n'): 'Pendientes de selección docente'}` : 'Componente Proyecto no seleccionado. No introduzca indicadores, porcentajes ni etapas del componente Proyecto.';
                const projectSection = projectApplicable ? `\nCOMPONENTE PROYECTO\n${projectText}\n` : '';
                const preschool = input.preschoolFramework;
                const preschoolSection = isPreschool ? `\nMARCO CURRICULAR ESPECÍFICO DE PREESCOLAR\n• Itinerario seleccionado: ${preschool?.itinerary || 'Pendiente'}\n\nCOMPETENCIAS ESPECÍFICAS DEL PNFT POR ÁREA\n${list(preschool?.competencies || [], item=>`${item.area}: ${item.text}`)}\n\nPERFIL DE SALIDA DE PREESCOLAR POR ÁREA\n${list(preschool?.exitProfiles || [], item=>`${item.area}: ${(item.statements||[]).join(' | ')}`)}\n\nCONTRATO EXCLUSIVO PARA PREESCOLAR\n1. La evaluación es diagnóstica y formativa, sin distribución porcentual.\n2. Cada experiencia semanal debe tener propósito, inicio, exploración o juego guiado, aplicación y cierre, aunque la progresión curricular continúe en las semanas siguientes.\n3. El bloque de 80 minutos puede desarrollarse de forma continua o en dos lecciones de 40 minutos; si se fracciona, conserve la unidad y continuidad de la experiencia.\n4. Integre actividades lúdicas, sensoriales, concretas, guiadas, conectadas o desconectadas según el desarrollo infantil, los recursos y el contexto.\n5. No imponga una cantidad fija de áreas, saberes o indicadores por semana. Intégrelos cuando exista una relación pedagógica auténtica y trabaje uno de forma individual cuando su profundidad o el desarrollo infantil lo requieran.\n6. Distinga la evidencia observada del aprendizaje alcanzado. Registre progresos para orientar la mediación y la realimentación, sin convertirlos en calificaciones.\n7. Compruebe cómo la propuesta contribuye a los RdA y al perfil de salida de las áreas involucradas, sin afirmar que el perfil fue alcanzado por el solo hecho de planificar.\n` : '';
                const hasCompletePeriod=Boolean(input.startDate&&input.endDate),weekField=hasCompletePeriod?'semana y fecha aproximada':'semana';
                const matrixFields = project ? `${weekField}; modo semanal (curricular, mixta o integrada mediante Proyecto); fase metodológica; bloque semanal y distribución del tiempo` : isPreschool ? `${weekField}; propósito de la experiencia; organización del bloque de 80 minutos continuo o en dos lecciones de 40 minutos; momento de la experiencia lúdica` : `${weekField}; fase metodológica; bloque semanal y distribución del tiempo`;
                const axesPhrase=selectedAxes.length?', los ejes transversales seleccionados':'';
                const methodologyRule = isPreschool ? `Mantenga una progresión curricular coherente entre semanas, pero diseñe cada experiencia semanal con inicio y cierre propios. Describa qué realiza el estudiantado, cómo acompaña y realimenta la persona docente, los recursos, la evidencia observable y el enlace con la experiencia siguiente. ${methodologyGuidance(input.methodology,{preschool:true})}` : `Use la metodología seleccionada como andamiaje continuo durante todo el semestre. No reinicie sus etapas, fases o dinámica en cada semana. Organice una progresión coherente en la que cada bloque semanal retome lo trabajado anteriormente, avance hacia el siguiente propósito y articule intencionalmente los saberes conceptuales, procedimentales y actitudinales${axesPhrase} y los indicadores de logro del PNFT. Las estrategias de mediación deben describir con claridad qué realiza el estudiantado, cómo acompaña y retroalimenta la persona docente, cuáles recursos se utilizan, qué evidencia se espera y cómo la experiencia prepara la semana siguiente. ${methodologyGuidance(input.methodology)}`;
                const integrationRule = isPreschool ? 'Integre áreas, saberes e indicadores únicamente cuando la experiencia permita movilizarlos de manera auténtica y comprensible para el desarrollo infantil. No establezca un mínimo numérico semanal. Cuando corresponda trabajar un solo saber, explique brevemente la razón pedagógica.' : 'Priorice la integración pedagógica de dos o más saberes cuando exista afinidad, relación con el indicador de logro y viabilidad en 80 minutos. Si decide trabajar un saber de forma individual, identifique la decisión como “tratamiento individual justificado” y explique una razón de peso: profundidad conceptual, exploración inicial, práctica deliberada, seguridad, prerrequisito, complejidad del indicador o necesidad contextual. No aísle saberes por comodidad ni repita uno sin explicar profundización, refuerzo o integración.';
                const evaluationRule = isPreschool ? 'Diseñe primero las experiencias y las evidencias observables. Después recomiende instrumentos únicamente con función diagnóstica o formativa, indicando qué se observará, cuándo se registrará y cómo se utilizará la información para realimentar y ajustar la mediación. No proponga calificaciones, porcentajes ni componentes propios de otros perfiles educativos.' : 'Diseñe primero las actividades y evidencias. Después recomiende, para cada evidencia pertinente, uno o varios instrumentos del catálogo interno. Indique necesidad evaluativa, evidencia, función diagnóstica/formativa/sumativa, instrumento, justificación, requisitos de construcción, momento y tiempo de aplicación, comunicación y devolución/realimentación. Para tareas, condicione la asignación a necesidades de repaso o reforzamiento observadas, respete al menos dos días naturales para su realización, la devolución máxima de ocho días hábiles y las restricciones del calendario; los Lineamientos 2026 establecen al menos tres por periodo, excepto CONED. Para la prueba de ejecución, ubique una ventana posterior a la mediación y realimentación de los aprendizajes y sujeta al calendario institucional. No imponga un solo instrumento al semestre ni invente porcentajes; marque “requiere confirmación institucional” cuando corresponda.';
                const profileRule = isPreschool ? 'Aplique exclusivamente el perfil formativo de Preescolar. La planificación, ejecución u observación de una actividad no demuestra automáticamente que el aprendizaje, el RdA o el perfil de salida fueron alcanzados.' : project ? 'Aplique únicamente el perfil confirmado. El porcentaje de Proyecto corresponde al componente completo, no se divide automáticamente por etapas; una evidencia no puede contabilizarse dos veces en componentes distintos.' : 'Aplique únicamente el perfil de evaluación confirmado y no invente componentes, porcentajes, cantidades ni plazos.';
                const projectRule = project ? `Incorpore el componente Proyecto en la misma matriz como hilo metodológico y no como un segundo planeamiento. Distinga semana curricular (80 min), mixta (40 min currículo + 40 min Proyecto) e integrada mediante el Proyecto (80 min). Use literalmente los indicadores oficiales del componente Proyecto de la etapa inicial y, en Prototipar y Probar/Evaluar, los indicadores oficiales del módulo que la persona docente vinculó. ${methodologyCoordination} No invente indicadores ni divida automáticamente el porcentaje del componente entre fases.` : '';
                const rdaItems=(Array.isArray(input.rdaItems)&&input.rdaItems.length?input.rdaItems:(input.rdas||[]).map((text,index)=>({area:input.areas?.[index]||`Área ${index+1}`,text}))).filter(item=>item?.text);
                const rdaByArea=new Map(rdaItems.map(item=>[item.area,item.text]));
                const rdaText=list(rdaItems,item=>`${item.area}: ${item.text}`);
                const routeText=list(input.concepts||[],item=>{const linked=(item.indicators||[]).length?item.indicators:((input.concepts||[]).length===1?(input.indicators||[]):[]);return `Área: ${item.area}\n   Módulo: ${item.module}\n   Saber conceptual: ${item.name}\n   Indicador(es) de logro del PNFT:\n${linked.length?linked.map(text=>`   • ${text}`).join('\n'):'   • Sin indicador asociado en los datos recibidos'}\n   RdA del área: ${rdaByArea.get(item.area)||'No aportado en los datos recibidos'}`;});
                const curricularContext=[`• Módulos: ${(input.modules||[]).join(', ')}`,`• Áreas de conocimiento: ${(input.areas||[]).join(', ')}`,`• Metodología activa: ${input.methodology}`];
                if(selectedAxes.length)curricularContext.push(`• Ejes transversales: ${selectedAxes.join(', ')}`);
                const periodLine=hasCompletePeriod?`\n• Periodo: ${input.startDate} a ${input.endDate}.`:(input.startDate||input.endDate)?`\n• Periodo parcialmente definido: inicio ${input.startDate||'no indicado'}; cierre ${input.endDate||'no indicado'}. No complete ni invente la fecha faltante.`:'';
                const exceptionLine=input.exceptions?`\n• Periodos no lectivos o excepciones: ${input.exceptions}.`:'';
                const netLessons=Math.max(0,Number(input.netLessons ?? input.lessons)||0),netMinutes=Math.max(0,Number(input.netMinutes ?? netLessons*40)||0),nonTeachingLessons=Math.max(0,Number(input.nonTeachingLessons)||0),evaluationReserveLessons=Math.max(0,Number(input.evaluationReserveLessons)||0);
                const moduleScope=(input.modules||[]).length>1?'• Alcance excepcional confirmado por la persona docente: el marco temporal declarado corresponde a ambos módulos. Distribúyalos en secuencia sin mezclar sus indicadores ni duplicar tiempo.':'';
                const contextualizationSection=input.contextualizationBlock||'';
                const referenceSection=input.referenceBlock||'';
                const diagnosticSection=input.diagnosticPlanningBlock||'';
                const diagnosticActive=Boolean(diagnosticSection.trim());
                const evaluationGuidanceSection=input.evaluationGuidanceBlock||'';
                const taskRules=[
                    `Presente primero una MATRIZ SEMESTRAL con: ${matrixFields}; área de conocimiento; saber conceptual; indicador de logro del PNFT; relación con el RdA; saber procedimental; saber actitudinal; integración y enlace con la experiencia siguiente; evidencia; función e instrumento de evaluación.`,
                    'Desarrolle cada semana incorporando el indicador de logro y los saberes conceptuales seleccionados, organice la estrategia de mediación mediante una estructura didáctica de  inicio, desarrollo y cierre. Describa de manera aplicable las consignas, las acciones del estudiantado, las preguntas y el acompañamiento de la persona docente, los recursos y los tiempos aproximados dentro del bloque. Integre los saberes cuando exista relación pedagógica entre ellos y mantenga una progresión coherente entre las experiencias de aprendizaje. Incluya, cuando corresponda, una alternativa desconectada y apoyos DUA. Finalice cada semana con un apartado denominado “Enlace y progresión”, que indique cómo lo desarrollado se relaciona con los saberes trabajados y prepara la experiencia siguiente.',
                    `Mantenga explícita la ruta área → saber conceptual → indicador de logro oficial del PNFT → RdA. Cada indicador de logro oficial del PNFT incluido arriba es una cadena protegida: CÓPIELO COMPLETO Y LITERAL, sin resumir, abreviar, parafrasear, corregir ni combinar. No modifique ni invente componentes del currículo oficial del PNFT ni indicadores${project?', incluidos los del componente Proyecto':''}. Planee íntegramente el alcance del nivel seleccionado, con la profundidad expresada por sus indicadores; no incorpore como currículo obligatorio saberes o indicadores de otros niveles.`,
                    methodologyRule,
                    integrationRule,
                    'En CADA semana identifique y muestre literalmente cuáles saberes procedimentales y saberes actitudinales seleccionados se movilizan y describa cómo se evidencian en las acciones. No use frases genéricas como “se trabaja la colaboración” sin señalar la conducta o evidencia observable.',
                    'Para cada indicador de logro oficial del PNFT proponga dos indicadores de evaluación alternativos, observables y medibles, identificándolos expresamente como sugerencias editables.',
                    evaluationRule,
                    profileRule
                ];
                if(projectRule)taskRules.push(projectRule);
                taskRules.push(`Después de construir la matriz y el desarrollo semanal, revise la viabilidad temporal de su propia propuesta y compruebe las semanas, lecciones y minutos disponibles. Sume los minutos asignados y confróntelos con el presupuesto neto de ${netLessons} lecciones (${netMinutes} minutos). Compruebe que la propuesta no exceda ese tiempo${diagnosticActive?', que respete el diagnóstico activado':''}, que considere los periodos no lectivos declarados y que contemple tiempo razonable para exploración, práctica, aplicación, realimentación y evaluación. Muestre el balance: minutos netos disponibles, minutos asignados y diferencia. No determine la viabilidad únicamente comparando la cantidad de indicadores con la cantidad de bloques: considere integración auténtica, profundidad, continuidad y evidencias compartidas. Una diferencia como 18 indicadores para 19 bloques no constituye por sí sola un problema. No elimine, resuma ni modifique currículo oficial para ajustar el tiempo.`);
                taskRules.push('Diferencie proyectado, ejecutado y evidencia de aprendizaje. La ejecución no demuestra automáticamente dominio o aprendizaje alcanzado.','Termine con cobertura por área, saberes pendientes, decisiones justificadas de integración o tratamiento individual y asuntos que requieren criterio docente.');
                const prompt=`PROYECCIÓN GENERAL DEL MÓDULO – ${input.level || 'Nivel pendiente'} – ${input.cycle || 'Ciclo pendiente'}

PROPÓSITO Y ALCANCE
Construya una proyección semestral editable, organizada por periodos bimestrales. Esta proyección orienta la ruta del semestre y no sustituye el planeamiento didáctico oficial. La persona docente conserva la validación y decisión final.

MARCO TEMPORAL
• ${input.weeks} semanas; ${input.lessons} lecciones de Formación Tecnológica; bloque semanal de ${input.blockMinutes} minutos.${periodLine}${diagnosticActive?`\n• Evaluación diagnóstica pedagógica activada: máximo ${input.diagnosisLessons} lecciones.`:''}${exceptionLine}
• Presupuesto neto para desarrollo curricular: ${netLessons} lecciones (${netMinutes} minutos).
• Reservas descontadas: ${input.diagnosisLessons||0} lecciones de diagnóstico; ${nonTeachingLessons} lecciones sin desarrollo curricular; ${evaluationReserveLessons} lecciones para aplicación y realimentación de instrumentos.
${diagnosticSection}

SELECCIÓN CURRICULAR
${curricularContext.join('\n')}
${moduleScope}
${contextualizationSection}
${preschoolSection}

RESULTADOS DE APRENDIZAJE (RdA) DEL PNFT POR ÁREA
${rdaText}

SABERES CONCEPTUALES E INDICADORES DE LOGRO DEL PNFT
${routeText}

SABERES PROCEDIMENTALES SELECCIONADOS
${list(input.procedural)}

SABERES ACTITUDINALES SELECCIONADOS
${list(input.attitudinal)}
${referenceSection}

${evaluationConfirmed?'PERFIL DE EVALUACIÓN CONFIRMADO POR LA PERSONA DOCENTE':'PERFIL DE EVALUACIÓN DE REFERENCIA — NO CONFIRMADO'}
${evaluationText}
${evaluationGuidanceSection}

${instrumentSection}
${projectSection}

TAREA PARA LA IA
Construya una propuesta integral para todo el semestre y agrúpela en periodos bimestrales.${diagnosticActive?' La evaluación diagnóstica pedagógica fue activada expresamente; ubíquela antes del desarrollo del módulo y comience la matriz curricular después de ese periodo.':''} Cubra el desarrollo, la integración, el refuerzo, la retroalimentación y el cierre del semestre.${input.exceptions?' Muestre los periodos no lectivos declarados dentro de la secuencia temporal para conservar la continuidad del calendario, pero no los considere semanas de desarrollo curricular ni les asigne actividades, saberes, indicadores o evaluación.':''} No invente fechas, condiciones ni información que la persona docente no haya aportado.

Antes de presentar la matriz, escriba literalmente: Recuerde: PIA estructura el currículo → la IA propone una secuencia → la persona docente valida y decide de acuerdo con su criterio y contexto.

${taskRules.map((rule,index)=>`${index+1}. ${rule}`).join('\n')}

CONTRATO DE RESPUESTA
Antes de responder, compruebe internamente que no acortó ningún indicador oficial del PNFT, que cada semana muestra saber procedimental y actitudinal, que toda decisión de trabajar un saber solo está justificada y que ningún refuerzo sin evaluación directa fue convertido en indicador o evidencia de logro. Devuelva exactamente: A) Matriz semestral; B) Desarrollo detallado por periodos bimestrales y semanas; C) Instrumentos e indicadores de evaluación sugeridos; D) Cobertura curricular; E) Auditoría de integración, progresión y literalidad; F) Auditoría temporal con balance numérico; G) Decisiones pendientes de validación docente. En la auditoría temporal utilice una sola conclusión: “Viabilidad temporal confirmada”, “Revisión temporal sugerida” o “Requiere ajuste temporal”, y fundaméntela en la distribución realmente propuesta, no en un conteo aislado. PIA podrá comprobar coincidencias y sumas declaradas, pero la coherencia pedagógica y la suficiencia de la profundidad requieren revisión profesional.

NOTA PEDAGÓGICA
La propuesta es una sugerencia editable. La persona docente debe contextualizarla, validar los documentos oficiales del PNFT, aplicar las disposiciones institucionales y ejercer su criterio profesional.`;
                return prompt.replace(/\n{3,}/g,'\n\n').trim();
            }
            return { build, methodologyGuidance };
        })();
        // PIA_SEMESTER_PROMPT_JS_END
