        // PIA_ENHANCEMENTS_JS_START
        const PIAProjectionCore = (() => {
            const AREA_KEYS = {
                'Apropiación tecnológica y Digital': 'apropiacion',
                'Programación y Algoritmos': 'programacion',
                'Computación física y Robótica': 'robotica',
                'Ciencia de datos e Inteligencia artificial': 'ciencia'
            };
            const PROCEDURAL = [
                ['reconoce','Reconoce patrones'],['abstrae','Abstrae'],['generaliza','Generaliza'],['transfiere','Transfiere'],
                ['modulariza','Modulariza'],['formula','Formula algoritmos'],['remezcla','Remezcla'],['depura','Depura'],
                ['programa','Programa'],['comunica','Comunica'],['colabora','Colabora'],['piensa','Piensa de forma creativa'],
                ['maneja','Maneja las tecnologías de forma ética y segura']
            ];
            const ATTITUDINAL = [['gusto','Gusto por la precisión'],['aprender','Aprender del error'],['flexibilidad','Flexibilidad para manejar problemas'],['tolerancia','Tolerancia a la frustración']];
            function escapeHtml(value) {
                return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
            }
            function conceptId(level, moduleName, area, index) { return [level,moduleName,area,index].map(encodeURIComponent).join('|'); }
            function listConcepts(data, level, modules, areas) {
                const result = [];
                (modules || []).forEach(moduleName => (areas || []).forEach(area => {
                    const items = data?.[level]?.[moduleName]?.[area]?.saberes || [];
                    items.forEach((item, index) => result.push({ id: conceptId(level,moduleName,area,index), level, module: moduleName, area, name: item.nombre, indicators: [...(item.indicadores || [])] }));
                }));
                return result;
            }
            function distribute(concepts, weekCount, preferred = 2, reservedWeeks = 0) {
                const total = Math.max(1, Number(weekCount) || 1);
                const reserved = Math.min(total, Math.max(0, Number(reservedWeeks) || 0));
                const rows = Array.from({length: total}, (_, i) => ({week: i + 1, phase:i<reserved?'diagnóstico':'desarrollo', concepts: [], executed: false}));
                const available = rows.slice(reserved); if (!concepts.length || !available.length) return rows;
                concepts.forEach((concept, index) => available[Math.min(available.length - 1, Math.floor(index / preferred)) % available.length].concepts.push(concept));
                if (concepts.length > available.length * preferred) {
                    available.forEach(row => { row.concepts = []; });
                    concepts.forEach((concept, index) => available[index % available.length].concepts.push(concept));
                }
                return rows;
            }
            function coverage(concepts, assignments) {
                const byArea = {};
                concepts.forEach(c => { byArea[c.area] ||= {selected:new Set(),projected:new Set(),executed:new Set()}; byArea[c.area].selected.add(c.id); });
                assignments.forEach(row => row.concepts.forEach(c => {
                    byArea[c.area] ||= {selected:new Set(),projected:new Set(),executed:new Set()};
                    byArea[c.area].projected.add(c.id); if (row.executed) byArea[c.area].executed.add(c.id);
                }));
                return Object.entries(byArea).map(([area,x]) => ({area, total:x.selected.size, projected:x.projected.size, executed:x.executed.size, projectedPct:x.selected.size ? Math.round(x.projected.size*100/x.selected.size) : 0, executedPct:x.selected.size ? Math.round(x.executed.size*100/x.selected.size) : 0}));
            }
            function defaultEnhancements() {
                return { schemaVersion:6, identity:{name:'',motto:'',shieldDataUrl:''}, institutional:{codSaber:''}, context:{enabled:false,group:'',resources:'',dua:'',implementationProfile:'regular',conditions:[],technologyScenario:'sufficient',groupDiagnosis:'pending',supportFramework:'dua',institutionalCoordination:'not-required',duaSupports:[],authorizedSupportNotes:'',vocationalCoordination:false,vocationalSelectionBasis:'',referenceIndicators:[]}, methodology:{purpose:'',route:'',studentRole:'',evidence:''}, status:'draft', calendar:{weeks:22,diagnosisLessons:0,nonTeachingLessons:0,evaluationReserveLessons:0,startDate:'',endDate:'',exceptions:'',blockMinutes:80}, diagnostic:{enabled:false,mode:'advisor',purpose:'initial-period',priorSource:'linked',teacherReference:'',dimensions:{cognitive:true,socioaffective:true,psychomotor:true},experience:'',strengths:'',needs:'',decisions:'',communication:'',status:'planned',prompt:'',generatedPrompt:'',savedAt:''}, evaluation:{profileId:'',confirmed:false,guidance:{generatedAt:'',sourceFingerprint:'',suggestions:[]},projectPlanning:{enabled:false,catalogVersion:'',title:'',problem:'',beneficiary:'',expectedSolution:'',selectedIndicatorIds:[],selectedPhaseIds:[],phaseRecords:{}}}, aiProposal:{originalHtml:'',reviewedHtml:'',status:'empty',sourceFingerprint:'',approvedAt:''}, aiPrompts:{general:'',semester:'',weekly:{}}, aiPromptMeta:{generated:{general:'',semester:'',weekly:{}},savedAt:{general:'',semester:'',weekly:{}}}, aiReview:{generalResponse:'',semesterResponse:'',weeklyResponses:{},reports:{general:[],semester:[],weekly:{}}}, ui:{projectionExpanded:true}, projection:{preschoolTrack:'optimal',modules:[],multiModuleConfirmed:false,areas:[],conceptIds:[],procedural:[],attitudinal:[],assignments:[]}, strategies:[] };
            }
            function migrate(value) {
                const base = defaultEnhancements(); const source = value?.pia || value?.enhancements || {};
                const calendar={...base.calendar,...source.calendar};
                if(source.calendar?.diagnosisLessons===undefined&&source.calendar?.diagnosisWeeks!==undefined) calendar.diagnosisLessons=Math.min(2,Math.max(0,Number(source.calendar.diagnosisWeeks)||0)*2);
                calendar.diagnosisLessons=Math.min(2,Math.max(0,Number(calendar.diagnosisLessons)||0));
                calendar.nonTeachingLessons=Math.max(0,Number(calendar.nonTeachingLessons)||0);
                calendar.evaluationReserveLessons=Math.max(0,Number(calendar.evaluationReserveLessons)||0);
                delete calendar.diagnosisWeeks;
                const oldProject=source.evaluation?.projectPlanning||{};
                const selectedIndicatorIds=Array.isArray(oldProject.selectedIndicatorIds)?oldProject.selectedIndicatorIds:Array.isArray(oldProject.indicatorSnapshots)?oldProject.indicatorSnapshots.map(item=>item.id).filter(Boolean):[];
                const selectedPhaseIds=Array.isArray(oldProject.selectedPhaseIds)?oldProject.selectedPhaseIds:[];
                const phaseRecords=oldProject.phaseRecords&&typeof oldProject.phaseRecords==='object'?JSON.parse(JSON.stringify(oldProject.phaseRecords)):{};
                const weekly=source.aiPrompts?.weekly&&typeof source.aiPrompts.weekly==='object'?source.aiPrompts.weekly:{};
                const references=typeof PIAReferenceCurriculum!=='undefined'?PIAReferenceCurriculum.normalizeList(source.context?.referenceIndicators):Array.isArray(source.context?.referenceIndicators)?source.context.referenceIndicators:[];
                const priorContext=source.context||{},hasPriorContext=Boolean(String(priorContext.group||'').trim()||String(priorContext.resources||'').trim()||String(priorContext.dua||'').trim()||String(priorContext.authorizedSupportNotes||'').trim()||String(priorContext.vocationalSelectionBasis||'').trim()||(priorContext.conditions||[]).length||(priorContext.duaSupports||[]).length||priorContext.vocationalCoordination||(!['', 'dua'].includes(priorContext.supportFramework))||(!['', 'not-required'].includes(priorContext.institutionalCoordination))||(!['', 'regular'].includes(priorContext.implementationProfile))||(!['', 'sufficient'].includes(priorContext.technologyScenario))||(!['', 'pending'].includes(priorContext.groupDiagnosis)));
                const context={...base.context,...priorContext,enabled:priorContext.enabled===undefined?hasPriorContext:Boolean(priorContext.enabled),conditions:Array.isArray(priorContext.conditions)?priorContext.conditions:[],duaSupports:Array.isArray(priorContext.duaSupports)?priorContext.duaSupports:[],vocationalCoordination:Boolean(priorContext.vocationalCoordination),referenceIndicators:references};
                const meta=source.aiPromptMeta||{};
                const priorDiagnostic=source.diagnostic||{},hasPriorDiagnostic=Boolean(String(priorDiagnostic.prompt||'').trim()||String(priorDiagnostic.experience||'').trim()||String(priorDiagnostic.savedAt||'').trim()||['strengths','needs','decisions','communication'].some(key=>String(priorDiagnostic[key]||'').trim()));
                const diagnostic={...base.diagnostic,...priorDiagnostic,enabled:priorDiagnostic.enabled===undefined?hasPriorDiagnostic:Boolean(priorDiagnostic.enabled),dimensions:{...base.diagnostic.dimensions,...priorDiagnostic.dimensions}};
                const guidance={...base.evaluation.guidance,...source.evaluation?.guidance,suggestions:Array.isArray(source.evaluation?.guidance?.suggestions)?source.evaluation.guidance.suggestions:[]};
                const review=source.aiReview||{};
                return { ...base, ...source, schemaVersion:6, identity:{...base.identity,...source.identity,name:''}, institutional:{...base.institutional,...source.institutional}, context, methodology:{...base.methodology,...source.methodology}, calendar, diagnostic, evaluation:{...base.evaluation,...source.evaluation,guidance,projectPlanning:{...base.evaluation.projectPlanning,...oldProject,selectedIndicatorIds,selectedPhaseIds,phaseRecords}}, aiProposal:{...base.aiProposal,...source.aiProposal}, aiPrompts:{...base.aiPrompts,...source.aiPrompts,weekly:{...weekly}}, aiPromptMeta:{...base.aiPromptMeta,...meta,generated:{...base.aiPromptMeta.generated,...meta.generated,weekly:{...(meta.generated?.weekly||{})}},savedAt:{...base.aiPromptMeta.savedAt,...meta.savedAt,weekly:{...(meta.savedAt?.weekly||{})}}}, aiReview:{...base.aiReview,...review,weeklyResponses:{...(review.weeklyResponses||{})},reports:{...base.aiReview.reports,...review.reports,weekly:{...(review.reports?.weekly||{})}}}, ui:{...base.ui,...source.ui}, projection:{...base.projection,...source.projection}, strategies:Array.isArray(source.strategies)?source.strategies:[] };
            }
            return {AREA_KEYS,PROCEDURAL,ATTITUDINAL,escapeHtml,conceptId,listConcepts,distribute,coverage,defaultEnhancements,migrate};
        })();
