import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import vm from 'node:vm';
import { fragments } from './fragment-manifest.mjs';

const root = resolve(import.meta.dirname, '..');
const jsFragments = fragments.filter((file) => file.endsWith('.js'));
const cssFragments = fragments.filter((file) => file.endsWith('.css'));

for (const file of jsFragments) {
  const source = await readFile(join(root, file), 'utf8');
  new vm.Script(source, { filename: file });
}

const combinedCss = Buffer.concat(
  await Promise.all(cssFragments.map((file) => readFile(join(root, file)))),
);
const reference = await readFile(join(root, 'reference/index.original.html'));
const styleOpen = reference.indexOf(Buffer.from('    <style>\r\n')) + Buffer.byteLength('    <style>\r\n');
const styleClose = reference.indexOf(Buffer.from('    </style>\r\n'));
function maskAuthorizedExportCss(buffer, label) {
  let source = buffer.toString('utf8');
  const enhancementStart = source.indexOf('/* PIA_ENHANCEMENTS_CSS_START */');
  if (enhancementStart >= 0) {
    const enhancementEndMarker = '/* PIA_ENHANCEMENTS_CSS_END */';
    const enhancementEnd = source.indexOf(enhancementEndMarker, enhancementStart);
    assert.ok(enhancementEnd > enhancementStart, `${label}: CSS de mejoras incompleto`);
    let resume = enhancementEnd + enhancementEndMarker.length;
    if (source[resume] === '\r' && source[resume + 1] === '\n') resume += 2;
    else if (source[resume] === '\n') resume += 1;
    source = `${source.slice(0, enhancementStart)}${source.slice(resume)}`;
  }
  const startMarker = '        .export-options {';
  const endMarker = '        .checkbox-group {';
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start);
  assert.ok(start >= 0 && end > start, `${label}: no se pudo aislar el CSS autorizado de exportación`);
  return `${source.slice(0, start)}<AUTHORIZED_EXPORT_OPTIONS_CSS>\n${source.slice(end)}`;
}
function normalizeNonSemanticWhitespace(source) {
  return source.replace(/\r\n/g, '\n').replace(/[\t ]+$/gm, '').replace(/\n{3,}/g, '\n\n');
}
assert.equal(
  normalizeNonSemanticWhitespace(maskAuthorizedExportCss(combinedCss, 'fuente')),
  normalizeNonSemanticWhitespace(maskAuthorizedExportCss(reference.subarray(styleOpen, styleClose), 'referencia')),
  'CSS contiene diferencias fuera de las opciones de exportación',
);

const allSource = await Promise.all([
  ...fragments.map((file) => readFile(join(root, file), 'utf8')),
  readFile(join(root, 'src/learning/experience.js'), 'utf8'),
  readFile(join(root, 'src/learning/experience.css'), 'utf8'),
]);
const networkText = allSource.join('\n');
const urls = [...networkText.matchAll(/https?:\/\/[^\s'"`<]+/g)].map((match) => match[0]);
const allowedPrefixes = [
  'http://www.w3.org/2000/svg',
  'http://www.w3.org/TR/REC-html40',
  'https://fonts.googleapis.com/',
  'https://copilot.microsoft.com/',
  'https://chat.openai.com/',
  'https://www.mep.go.cr/',
];
assert.ok(urls.every((url) => allowedPrefixes.some((prefix) => url.startsWith(prefix))), 'URL nueva');
assert.equal(/\b(fetch|XMLHttpRequest|WebSocket|EventSource|sendBeacon)\b/.test(networkText), false, 'API de red nueva');

console.log(`JS_FRAGMENTS=${jsFragments.length}`);
console.log(`CSS_FRAGMENTS=${cssFragments.length}`);
console.log(`URLS=${urls.length}`);
console.log('SOURCE_VERIFICATION=PASS');
