# Estado operativo — PIA-PNFT Modular 1.6.15

## Actualización 1.6.15

- Estado: implementación correctiva completa; 143/143 pruebas automatizadas aprobadas.
- Currículo: catálogos protegidos sin cambios; prueba exhaustiva de 235 indicadores y 20 combinaciones.
- Evaluación: perfil de referencia pendiente hasta confirmación docente explícita; Proyecto condicionado a esa confirmación.
- Módulos: la selección conjunta exige confirmar que el marco temporal cubre ambos periodos.
- Tiempo: presupuesto neto calculado en lecciones y minutos después de las reservas declaradas.
- IA: prompt con balance temporal numérico y comprobación técnica delimitada; no se presenta como certificación pedagógica.
- Preescolar: comprobación específica de sus saberes procedimentales y actitudinales.
- Compatibilidad: `schemaVersion: 6`, planes anteriores, operación local, JSON, PDF, Word y portable preservados.
- Pendiente institucional: prueba humana final en Chrome/Edge de escritorio y móvil.

## Actualización 1.6.14

- Estado: implementación completa y pruebas automatizadas aprobadas.
- Alcance: experiencia formativa guiada desde la portada, sin cambios al currículo oficial ni al esquema JSON v6.
- Recorrido: siete momentos y tres laboratorios de metodología; ejemplos diferenciados por ciclo e integración de Proyecto en secundaria.
- Protección: el ejemplo no modifica el plan y su avance utiliza una clave local independiente.
- Persistencia: el planeamiento conserva autoguardado, JSON, portable, PDF y Word; la experiencia queda fuera de las salidas oficiales.
- Verificación de interacción: apertura, siete vistas, ABJ/ABR/APD, salida y preservación del plan verificadas en DOM ejecutable sin errores de consola.
- Limitación de validación: el navegador remoto bloqueó la URL local, por lo que la revisión visual real en Chrome o Edge debe realizarse antes de publicación. La entrega no se rotula como visualmente validada.

- Fecha de corte: 2026-09-11.
- Estado: versión correctiva construida sobre PIA 1.6.12; consolida la trayectoria curricular, el
  diagnóstico opcional, la orientación evaluativa y la auditoría temporal posterior.
- Validación automatizada: 132/132 pruebas aprobadas. La revisión visual final se ejecuta antes de la entrega.
- Fuente editable: `src/`.
- Salidas: `index.html`, `dist/web/index.html`, `dist/portable/index.html`.
- Referencia protegida SHA-256: `70a72f7c0218da49b9d748ff0a12648ec2364d04668625b1d8cd07428e3814e9`.
- Datos curriculares base: `pnft-data.js` y `rda-por-ciclo.js` conservados. Preescolar se corrige mediante
  un catálogo oficial aislado y reversible para Básico requerido y Óptimo.
- Centros: 4.651 registros mínimos; 4.448 códigos de coincidencia única y 63 ambiguos. Se excluyen
  todos los `0000`; no se incluyen personas asesoras, correos ni teléfonos.
- Backend, API, autenticación y analítica activa: no implementados.
- Planes: JSON v6 con migración de versiones anteriores y conservación de texto oficial, contextualizado y prompts editados.
- Portada: entrada local MEP–PNFT–PIA con inicio, carga de JSON, preferencia de omisión por dispositivo
  y retorno sin pérdida. No se imprime ni se exporta.
- Identidad institucional: escudo y lema opcionales alineados a la izquierda; el nombre del centro no
  se duplica y el encabezado administrativo oficial permanece intacto.
- Diagnóstico: inicia con 0 lecciones y desactivado; dispone de modo asesor y docente, áreas de valoración,
  experiencia, resultados generales, decisiones, prompt editable, guardado y reinicio independiente. Solo
  se incorpora al prompt semestral mediante activación expresa.
- Acceso al diagnóstico: el selector de lecciones permanece en Marco temporal y el botón se presenta
  después de Saberes. Se habilita con ciclo, nivel, módulo, área, saber conceptual y una o dos lecciones;
  omitirlo nunca bloquea la proyección semestral.
- Ayudas contextuales: glosario interno para DUA, referencias, proyección, diagnóstico, RdA, saberes,
  Proyecto y evaluación. Funciona mediante puntero, teclado o toque, muestra una ayuda a la vez y queda
  fuera del estado persistente, los prompts y las exportaciones.
- Contextualización y DUA: conserva los tres campos abiertos e incorpora perfil de implementación,
  condiciones complementarias, escenario tecnológico y punto de partida grupal. No admite datos
  personales del estudiantado.
- Contexto en prompts: solo se incluyen campos completados o selecciones no neutrales. Los valores
  iniciales, las condiciones no marcadas y las referencias no elegidas se omiten para evitar ruido.
- Perfiles de implementación: Regular, Aula Edad, aulas integradas, Vocacional y EPJA. Son contexto
  pedagógico y no sustituyen una modalidad o un perfil de evaluación confirmado.
- Referencias curriculares: selección controlada de indicadores de otros niveles desde el catálogo del
  PNFT, con procedencia, motivo y contextualización separados. No se presentan como indicadores oficiales
  del nivel administrativo actual.
- Prompts: General, Semestral y Semanal mantienen borradores independientes y permiten guardar,
  actualizar desde PIA o restablecer la propuesta generada con protección contra sobrescritura.
- Proyección: referencia curricular local con RdA visibles; sin distribución automática ni espacio
  para pegar/aprobar respuestas de IA.
- Semanas: navegación compacta, momento pedagógico visible y formato contextual exclusivo de
  mediación/evaluación. Al sombrear texto, la barra conserva la selección e identifica el campo activo;
  las opciones secundarias permanecen plegadas para no cubrir ni saturar la escritura.
- Edición enriquecida: incorpora estilos rápidos Inicio–Desarrollo–Cierre para mediación, sangría,
  limpieza de selección, pegado limpio opcional y vínculos HTTPS revisados por la persona docente.
  Los Indicadores de logro del currículo de FT continúan protegidos.
- Currículo semanal: selector independiente de Módulo 1, Módulo 2 o ambos junto al momento pedagógico.
  Filtra las áreas y saberes disponibles, muestra los RdA aplicables y conserva selecciones externas sin borrarlas.
- Correspondencia semanal: `saberRefs` identifica módulo, área y saber; el indicador automático se
  obtiene del módulo exacto, manteniendo `saberes` para exportación y compatibilidad histórica.
- Visualización semanal: áreas, RdA y saberes conceptuales se agrupan en un panel plegable que no
  modifica ni elimina el contenido de la semana.
- Prompt semestral: requiere metodología activa, la usa como andamiaje continuo y progresivo, omite
  datos opcionales ausentes y enlaza cada área, saber, indicador de logro del PNFT y RdA.
- Progresión curricular: 38 familias, cuatro áreas y diez niveles. Los 235 saberes-indicadores de
  PIA se relacionan de forma exacta con su familia; la vista permite consultar el módulo completo o
  solo los saberes de la proyección y no altera el currículo.
- Lectura de matriz: una celda vacía significa que no existe abordaje conceptual documentado; no permite
  inferir refuerzo, enseñanza ni dominio. `N/A` significa no aplicable. Fortalecimiento o presencia sin
  indicador solo se registran con respaldo curricular expreso.
- Interpretación: el nivel seleccionado gobierna toda la proyección; los antecedentes no confirman
  enseñanza o aprendizaje y deben comprobarse mediante diagnóstico.
- Prompt docente: no recibe la trayectoria, las familias ni los alcances anteriores o posteriores. La
  ventana local presenta tarjetas y tabla, filtros por módulo, área y alcance, RdA y fuentes oficiales.
- Auditoría temporal: la IA revisa su distribución ya construida y emite una conclusión fundada; PIA no
  interpreta una diferencia entre cantidad de indicadores y bloques como sobrecarga automática.
- Evaluación: catálogo interno y ventanas orientadoras editables. “Durante todo el periodo” no impone
  frecuencia semanal; la persona docente decide cuántas observaciones realizar. El campo “Observación o
  decisión docente” no representa una calificación.
- Revisión de IA: las respuestas general, semestral y semanal pueden pegarse y conservarse localmente.
  PIA detecta coincidencias literales y alertas contractuales básicas, pero no incorpora ni aprueba la respuesta.
- Proyecto: activación condicionada, ruta completa seleccionable y modalidad semanal curricular/mixta/integrada. La etapa inicial conserva indicadores oficiales; Prototipar y Probar/Evaluar vinculan indicadores oficiales del módulo y conservan textos históricos anteriores.
- Juego metodológico: siete misiones locales, accesibles y responsivas; incluye ruta diferenciada de Preescolar, ABJ, ABR, APD, una o dos metodologías en secundaria y evaluación diagnóstica/DUA. No modifica el plan.
- Vista: Proyección semestral puede plegarse sin pérdida de información.
- Vista complementaria: Contextualización/DUA y Seguridad/recuperación son desplegables; los botones
  de autoguardado y diagnóstico conservan sus identificadores y el modal permanece independiente.
- Prompt semestral: al regenerarse, toma las fechas actuales y protege un texto previo mediante confirmación.
- IA: contratos estrictos de literalidad, integración justificada, saberes de los tres tipos por semana y actividades desarrolladas.
- Interfaz de Preescolar: itinerario visible y habilitado exclusivamente en Materno Infantil/Transición + `0°`.
- Prompt de Preescolar: incorpora competencia y perfil de salida de las áreas elegidas, conserva el
  enfoque lúdico y emite solamente evaluación diagnóstica/formativa sin distribución porcentual.
- Proyecto en prompts: ausente en Preescolar, I y II Ciclo; en III Ciclo muestra el estado no
  seleccionado o, si se activa, la ruta e indicadores correspondientes.
- Exportación oficial: PDF y Word excluyen Proyección y Cobertura e incorporan, dentro de las columnas
  existentes, los indicadores seleccionados del Proyecto usando la edición docente o el original guardado.
- Word reserva espacios blancos amplios para Reflexiones y Observaciones.
- Continuación recomendada: validación curricular asesora de las 38 familias, piloto docente,
  observación de usabilidad, prueba de los perfiles/contextos y definición institucional de requisitos
  de seguridad/privacidad antes de activar analítica o backend.
